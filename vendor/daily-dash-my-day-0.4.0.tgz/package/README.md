# @daily-dash/my-day

My Day, The Daily Dash's first slice, as a feature package: its screens, hooks, repositories and local
tables over `@daily-dash/client`, written in RecoverySky's idiom (`ThemedStyle<T>` functions applied
with `themed()`) and wearing The Daily Dash's look, dark by default (amendment A11). Two hosts mount it:
`apps/app` today, RecoverySky as a tab next. It owns no session, database or router of its own; the host
hands it those (the app packages design, `docs/superpowers/specs/2026-10-06-app-packages-design.md` §4.2,
§6, §11.7).

This is the host guide, written for the engineer mounting My Day in RecoverySky. Today My Day has one
screen, `TodayScreen`; the guide grows with each one.

## Install

Inside the workspace, `"@daily-dash/my-day": "workspace:*"` beside `"@daily-dash/client": "workspace:*"`.
My Day is mounted inside the host's `ClientProvider` (`@daily-dash/client`'s README), whose session and
database its hooks read.

### Vendoring into a host

Outside the workspace (RecoverySky, until the packages are published), a host installs three tarballs.
In this repository, `pnpm pack:tarballs` builds and packs `@daily-dash/sdk`, `@daily-dash/client` and
`@daily-dash/my-day` into `dist-tarballs/` (`--check` also installs them into a throwaway npm project and
proves they resolve). Copy the three `.tgz` files into the host, for example under `vendor/`, and name
each one twice in its `package.json`: as a dependency, and under `overrides` (`pnpm.overrides` for pnpm,
`resolutions` for Yarn). Inside the tarballs `client` and `my-day` ask for `@daily-dash/sdk` (and
`my-day` for `@daily-dash/client`) by version, and no registry has those versions; the overrides send
every such request to the vendored file.

```json
{
  "dependencies": {
    "@daily-dash/sdk": "file:vendor/daily-dash-sdk-0.2.0.tgz",
    "@daily-dash/client": "file:vendor/daily-dash-client-0.4.0.tgz",
    "@daily-dash/my-day": "file:vendor/daily-dash-my-day-0.4.0.tgz"
  },
  "overrides": {
    "@daily-dash/sdk": "file:vendor/daily-dash-sdk-0.2.0.tgz",
    "@daily-dash/client": "file:vendor/daily-dash-client-0.4.0.tgz",
    "@daily-dash/my-day": "file:vendor/daily-dash-my-day-0.4.0.tgz"
  }
}
```

The peers (`## Peers` below, and `@daily-dash/client`'s) are the host's own. A new version is a new set
of tarballs: bump with the `release` skill, run `pnpm pack:tarballs`, replace the files and the names.
`@daily-dash/client/test` is workspace-only and is not in the tarball.

## The two adapters

A host writes two small adapters and mounts `MyDayProvider` with them:

```tsx
<MyDayProvider navigation={myDayNavigation} surfaces={{ photo, Blur }}>
  {/* My Day's screens: see "Screens" */}
</MyDayProvider>
```

- **Navigation**, `MyDayNavigation`: `go(route, ...params)`, `back()` and `openCrisisPath()` over the
  host's router, where `params` is `[]` for a route that takes none and `[MyDayRoutes[R]]` for one that does, so a screen
  cannot call a route with its params missing. A host adapter must declare the rest parameter,
  `go: (route, ...params) => …`; `go: (route) => …` fails `typecheck`. `MyDayRoutes` names every screen
  with its params; an adapter written as a table keyed by `MyDayRoutes` fails `typecheck` when the
  package adds a route the host has not wired. `apps/app` writes it over Expo Router;
  `examples/react-navigation-host.tsx` shows it over React Navigation.
- **The crisis path**, `openCrisisPath()`: when `GET /v1/today` says the person is in crisis
  (`steering.crisis`), the today card puts a crisis card first, and its one button calls this
  (amendment A9). The crisis path is yours: My Day never names a phone number, a URL or a screen of its
  own. In RecoverySky, wire it to your crisis screen (meetings, support contacts, the crisis line), as
  the example's `navigation.navigate("Crisis")` does. `apps/app` wires a support screen of its own at
  `/my-day/support`.
- **Features**, on `ClientProvider`: the check-in keeps its own tables and outbox root, so a host lists
  `myDayFeature` (and, for a test database, `myDaySchema`) on `ClientProvider`'s `features`
  (app packages amendment A12). Without it the check-in screen has no repositories. The same feature
  brings the routine's `md_routine_items` and `md_routine_ticks` tables and the `my-day.routine` root: one
  root for every routine write, so they replay in order (routine spec §3). The check-in's question order
  has its own table, `md_checkin_settings`, and root, `my-day.checkin-settings`.
- **Capabilities**, optional: `capabilities` on `MyDayProvider` says what the host can do for My Day beyond
  drawing it (adaptive check-in spec §5, §11). A capability the host does not name is off, and what needs it
  is absent rather than disabled. `reminders` is for a host that holds a registered push token for the
  signed-in account: only then does the check-in's exit sheet offer **Remind me later**, and the server
  sends the push (My Day registers no device). A host with no push leaves it out. `sky` is for a host that has Sky's chat (Sky moments design §7): `{ moments, open }`. `moments` is the host's moments table, from `GET /v1/client-config`'s `assistant.moments`, each kind's surface (`tab`, `bubble` or `off`); My Day shows nothing for a moment that is `off`. `open(moment)` takes the moment My Day decided is due, `{ kind, context }`, and the host draws it where its table says. With it: a pillar step with no intent offers **Tell Sky about your sleep** (the `pillar` moment) and the night's summary lists the pillars without one; the summary opens the `evening` moment once a night after the save settles; the Check in card asks **Want to talk about it?** after a low check-in (`talk`) and the routine card offers help when the server says the routine wants it (`schedule`); the routine editor has a **Sky** action (`edit`); every header has **?** (`help`). A host with no Sky leaves it out.
  `useMyDayCapabilities()` reads them back for a host screen of its own.

  ```tsx
  <MyDayProvider
    navigation={myDayNavigation}
    capabilities={{ reminders: hasPushToken, sky: { moments, open: openSkyMoment } }}
  >
    {/* My Day's screens */}
  </MyDayProvider>
  ```

- **Theme**, optional: with none, My Day wears The Daily Dash's look in dark, `dailyDashDark`. There are two
  constants, `dailyDashDark` and `dailyDashLight`; a host with a light scheme passes the one its scheme
  names, and may replace `colors.tint`, `tintInactive` and `onTint` with its own (RecoverySky follows its
  tint picker). Load Inter and Playfair Display (weights 400 to 700) at boot under the family names it
  gives, as `@expo-google-fonts` names them. `apps/app` passes `ddTokensToMyDayTheme(theme)` so a Theme
  Editor override reaches My Day. A host's own Ignite theme does not fit `MyDayTheme`; that is on purpose.
- **Copy**, optional: `<MyDayProvider copy={…}>` takes a whole `MyDayCopy`, every word My Day shows.
  `defaultMyDayCopy` is today's English, and a host that translates or rewords spreads it and replaces
  what it needs: `copy={{ ...defaultMyDayCopy, … }}`. `MyDayCopy` has no optional member, so a missing
  word is a type error, not a blank. A leaf that carries a number or a name stays a function
  (`week: (n) => …`); the host backs it with its own interpolation. `@daily-dash/my-day/copy` exports
  `MyDayCopy` and `defaultMyDayCopy` and imports nothing of React or Expo, so a host's Node-run test can
  read `defaultMyDayCopy`. The main entry exports both too.
- **Surfaces**, optional: `photo`, an image drawn behind every My Day screen, and `Blur`, a component
  drawn inside every glass surface (it receives `surface`, `"card"` or `"header"`, and fills its
  parent). Without them the screen is the theme's background and the glass is translucent only. With
  expo-blur: `<BlurView intensity={surface === "card" ? 20 : 40} tint={isDark ? "dark" : "light"} style={StyleSheet.absoluteFill} />`. The tint follows the host's scheme.

## Screens

`TodayScreen` is the today card: the crisis card first when there is one, then the day's quote, the
person's focal areas, Check in, Grateful for, the routine by part of the day in the server's order, and
Rate your day (slice 1 spec §6.4; the order is the product owner's, 2026-10-09). It takes
no props; it reads its data through the host's `ClientProvider` and its theme and navigation through
`MyDayProvider`. Mount it inside your tab, directly as the example does, or as the first screen of a
stack inside it once My Day has more than one screen:

```tsx
<Tab.Screen name="MyDay">
  {({ navigation }) => (
    <MyDayProvider surfaces={surfaces} navigation={reactNavigationAdapter(navigation)}>
      <TodayScreen />
    </MyDayProvider>
  )}
</Tab.Screen>
```

`examples/react-navigation-host.tsx` is the whole of it, typechecked with the package: the providers
and `TodayScreen` straight in the tab. As screens arrive, put a stack there instead, with `TodayScreen`
first and a `Stack.Screen` per key of `MyDayRoutes`. `apps/app` mounts it over Expo Router at
`/my-day`.

`CheckInScreen` is the any-time check-in, which the person takes as often as they like (adaptive check-in
spec §2, §8). There is one type, `wellness`, named **Check in**. The screen takes `typeKey` as a prop; its
route is `checkIn: { typeKey }` in `MyDayRoutes`, which RecoverySky maps to a stack screen taking `typeKey`,
and the today card's Check in button opens it with `go("checkIn", { typeKey })`. The server plans the
check-in and My Day renders the steps it is handed, one question per step with one tap per answer and no
counter. The gate comes first, how the person feels from 1 to 5. A low answer (1 or 2) is followed by
"What's bothering you?", then the self-harm question, asked on every low day, then the questions of the
topics picked; a higher one by a few questions the server chose from what the person finds hard, after any
it asked last time and got no answer to. A question asked for a topic, one owed from last time included,
shows that topic's framing line above it. Every step but the gate and the topics step has a quiet **Skip**.
**Close**, on every step, goes back before the first answer, and after it opens an exit sheet: **That's
enough for now**, **Keep going**, and **Remind me later** with its three choices, which appears only when the
host sets `capabilities.reminders`. The crisis card and the support card come first when the server says so.
The gate works offline from the stored form; the plan after the gate and after the topics step needs the
server, and a screen that cannot get it in a few seconds offers Done with a note that some questions need a
connection. Every write leaves through the outbox and reads as pending until the server confirms it (ADR
0034, ADR 0045). Mount it as a stack screen beside `TodayScreen` under the same `MyDayProvider`; `apps/app`
mounts it at `/my-day/check-in/<type>`.

The Check in card also holds the one setting, **Mix up the questions**: a switch that asks the server to
shuffle the questions within a check-in (`GET` and `PUT /v1/me/checkin-settings`, kept on the device and
sent through the outbox). `useCheckinSettings()` is exported for a host that wants the same switch
elsewhere: it answers `{ questionOrder, set }`, and `set.mutate("shuffled")` or `set.mutate("ordered")`
writes the choice.

`RoutineScreen` is the routine's edit screen: the parts of the day with Move up and Move down, Add an
item, the starter templates with a preview, and the switched-off items with Switch on. It takes no props;
its route is `routine` in `MyDayRoutes`, and the today card's Edit routine and Start your routine open it.
The today card itself now ticks and skips: one tap on the ring ticks or clears, Skip sets an item aside for
the day, and the count is the server's.

`RoutineItemScreen` adds, renames, moves, times and switches off one item. Its routes are `routineNew` (no
params) and `routineItem: { itemId }`, which RecoverySky maps to stack screens taking `itemId`; it is the
same component, with `itemId` absent for a new item. `apps/app` mounts them at `/my-day/routine/new` and
`/my-day/routine/<id>`.

`NightScreen` is Rate your day for one date: the steps (one per visible pillar, then gratitude) or the
saved night's summary. Its route is `night: { date }`; `NightsScreen`, Past nights, is `nights`. A host
maps them to stack screens; `apps/app` mounts them at `/my-day/night/<date>` and `/my-day/nights`.
Focal areas, the crisis flag and which dates are writable are the server's; a night waiting to send
shows none of them.

A pillar's step shows the pillar's intent, when it has one, in one line under the pillar's name
(`Now: … · Aim: …`, from `GET /v1/pillars`), whatever the host's capabilities; with none, it offers Sky's
interview only when the host sets `capabilities.sky` (above). To see the line in mock mode, answer
`GET /v1/pillars` with Sleep given `myDayFixtures.sleepIntent`. The type `PillarIntent` is exported.

On a pillar's step, once the pillar is rated, its own actions show at once, ordered by how often each was
ticked in the last fourteen days (the server's count), then by their order on the pillar. After the rating
has held for 600 ms, Sky's ideas are read online from `POST /v1/pillars/{id}/action-ideas` and join them as
chips under "Sky suggests", and an action an idea names moves first; a tapped idea is kept in the draft and
sent with the night as a new action and its token (assistant design §6.1). A title is one chip however it
is cased, trimmed, composed or broken by an invisible character, as the API folds it. A step opened again, or
come back to with Previous, shows the ideas it already has at once, with no hold and no second ask. While the
night's save waits, its summary lists the kept ideas on their pillars' rows; once it lands, the pillars
refresh from `GET /v1/pillars`, so a kept idea is one of the pillar's own actions at once.
Offline, with Sky switched off, over budget or with the agent down, the actions show alone, and nothing
shows while the ideas are awaited. A host sets no capability for this: the server decides every one of
those cases, and a failed ask is the same as none. To see the chips in mock mode, answer that route with
`myDayFixtures.actionIdeasOf(pillarId)`. `useActionIdeas(pillarId, date, rating)` is exported from the main
entry, with the types `ActionIdea`, `ActionIdeas` and `PillarAction`.

## Data

`useToday()` reads `GET /v1/today` online through `client`'s `useSdk()` (amendment A10), with no local
table: what My Day keeps on the device belongs to its feature spec. The answer is the server's: My Day
orders, groups and labels it and computes nothing (no due state, no count, no crisis); a value it does not
know still renders. A failed read shows a message with Try again. Its query keys start `["my-day", …]`
(`myDayKeys`), apart from the platform's.

Routine writes (ticks, skips, adds, renames, moves, order, switch off and on) queue through the outbox under
the moment the person acted, and read as pending until the server answers; applying a template is online
only. The week count and the long-routine warning are the server's.

### Gratitude list

The Grateful for section is part of `TodayScreen`; a host mounts nothing more for it. The feature brings
the `md_gratitudes` table and the `my-day.gratitude` root, one root per entry (its id is the entry's).
The hooks are exported from the main entry and take any date, so a host's own screen (or My Day's Rate
your day) can read and write a past day's list too: `useGratitudes(date)` reads the stored list and
refreshes it from `GET /v1/gratitudes?date=`, `useGratitudeWriter(date)` gives `add`, `edit` and
`remove`, each shown at once and queued through the outbox, and `useGratitudeRejection(date)` lists the
writes the server refused with one action, `dismiss`, since a refused gratitude never passes on retry.

## The theme shape

`MyDayTheme` keeps Ignite's key names and adds The Daily Dash's (design §6.2, amendment A11).
`dailyDashDark` and `dailyDashLight` are the whole of it with values; spread one to change a few.

| Key          | Keys inside                                                                                                                                                                                                    |
| ------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `colors`     | `text`, `textDim`, `background`, `card`, `border`, `separator`, `tint`, `onTint`, `tintInactive`, `accent`, `error`, `errorBackground`, `cardGlass`, `headerGlass`, `textShadow`, `control`, `input` (strings) |
| `spacing`    | `xxxs`, `xxs`, `xs`, `sm`, `md`, `lg`, `xl`, `xxl`, `xxxl` (numbers)                                                                                                                                           |
| `typography` | `primary` (body) and `secondary` (headings), each `light`, `normal`, `medium`, `semiBold`, `bold` (font family names)                                                                                          |
| `surface`    | `cardRadius`, `cardPadding`, `cardShadow`, `hairline`, `tickSize`, `badgeRadius`, `buttonHeight`, `buttonRadius`, `pressedOpacity`, `disabledOpacity`, `textShadow`, `tracking`, `wideAt`                      |
| `isDark`     | a boolean                                                                                                                                                                                                      |

Inside the package no colour, size or font literal appears outside `src/theme/` (design §6.4); lint
refuses one.

## Peers

The host supplies these; their ranges agree with `@daily-dash/client`'s.

| Peer                    | Range                            |
| ----------------------- | -------------------------------- |
| `expo`                  | `>=54.0.0 <58`                   |
| `expo-sqlite`           | `>=16.0.0 <17 \|\| >=57.0.0 <58` |
| `react`                 | `>=19.1.0 <20`                   |
| `react-native`          | `>=0.81.0 <0.87`                 |
| `@tanstack/react-query` | `^5.104.0`                       |
| `drizzle-orm`           | `^0.45.1`                        |

`expo-secure-store`, `expo-crypto` and `zod` are `@daily-dash/client`'s peers; My Day reaches them through
it. `drizzle-orm` is a peer of both, since the check-in's schema module is written in it.

## Mock mode

`myDayFixtures` (`today`, an ordinary day, and `crisisToday`, a crisis night with no word and no focal areas)
holds My Day's `GET /v1/today` answers, typed from the SDK, for a host's msw handlers (design §4.5).
Import it from the `@daily-dash/my-day/fixtures` subpath, never the main entry: Metro does not
tree-shake, so a fixture in the main entry would ship in every production bundle.

The check-in's fixtures sit beside them: `checkinTypes` (`GET /v1/checkin-types`, the one type,
`wellness`), `wellnessForm` (`GET /v1/checkin-types/{key}/form`, whose one step is the gate), and four
builders of a check-in as the server plans it, for the create, answer and complete handlers:
`checkinOf({ ... })`, a new check-in with only the gate; `lowCheckinOf({ ... })`, the gate answered 2 with
the topics step planned; `plannedCheckinOf({ ... })`, then Your body picked, with the safety question and
Body's questions planned; and `calmCheckinOf({ ... })`, the gate answered 5 with one owed question and one
history pick. A host's mock stands in for the plan: it answers the gate with `lowCheckinOf` for 2 or less
and `calmCheckinOf` for 3 or more, and the topics step with `plannedCheckinOf`, keeping each check-in by
its id and the answers it was given.

The routine's fixtures are `routineItems` (`GET /v1/routine/items`), `routineTemplates`
(`GET /v1/catalogue/routine-templates`), `routineItemOf({ ... })` and `routineTickOf({ ... })`, for the
create, tick and apply handlers.

The gratitude list's fixtures are `gratitudes` (`GET /v1/gratitudes?date=`, two entries on the ordinary
day) and `gratitudeOf({ ... })`, one entry as the create and edit handlers answer it.
