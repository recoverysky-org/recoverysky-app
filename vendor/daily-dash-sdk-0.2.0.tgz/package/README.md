# @daily-dash/sdk

The Daily Dash client SDK: the one package between the API's contract and every client (ADR 0039). It holds
the transport (`X-Client`, `Idempotency-Key`, the retry ladder, one refresh and replay on a `401`), one typed
function per `/v1` operation generated from the committed OpenAPI document, the client's error vocabulary
(`SdkError`, `unwrap`) and the outbox engine behind a store port. The design is
[the client SDK design](../../docs/superpowers/specs/2026-10-02-client-sdk-design.md); this file is how to use
and change it.

> **Status: workspace package, private.** `apps/app` is its one consumer and imports its TypeScript source
> (`exports` points at `src/`). The publishable shape (`publishConfig`, a `tsup` build to `dist/` as ESM with
> declarations) is proven on every run by `pnpm pack:check` and is not published. Publishing to npmjs, a
> `/react` subpath and RecoverySky's adoption are follow-ups in `TODO.md`.

## Prerequisites

- Node 24 and pnpm 10; `pnpm install` at the repository root. The generator (`@hey-api/openapi-ts` 0.99.0)
  declares `node >=22.18.0`, which the repository's 24.21.0 satisfies.
- `zod` 4 is a peer dependency (`^4.6.5`): the consumer and the SDK share one zod, or a generated schema fails
  an `instanceof` check in the consumer.
- `@jenova-marie/ts-rust-result` (exactly 2.2.18) is the only runtime dependency.

## Use

```ts
const transport = createTransport({ baseUrl, clientHeader, getAccessToken, onUnauthorized, log });
const sdk = createSdk(transport);
const me = await sdk.getMe(); // SdkResult<Me>; in a React hook: unwrap(await repository.read())
```

An operation takes one argument object holding the parts it has (`params`, `query`, `body`,
`idempotencyKey`) and the call's own `timeoutMs` and `retry`. `idempotencyKey` is required by type on every
mutation (ADR 0018):

```ts
await sdk.putReflection({ params: { date }, body, idempotencyKey });
```

Every function also carries its descriptor (`sdk.putReflection.descriptor`), so the outbox can queue a call as
method, path and body. The outbox: `createSyncWorker({ store, api, appliers, … })` over an `OutboxStore`
the consumer implements (or `memoryStore()`), with the queue functions under `outboxQueue`. A consumer proves
its store with `outboxStoreContract` from `@daily-dash/sdk/store-contract`.

## Regenerating

After any contract change in the API:

```bash
pnpm --filter @daily-dash/api openapi:generate   # the API's committed openapi/openapi.json
pnpm --filter @daily-dash/sdk generate           # src/generated/ from that document
```

Then fix what `tsc` reports at each caller. Never edit `src/generated/` by hand; `pnpm generate:check` fails
CI when it differs from a fresh run. `scripts/generatorProfile.ts` is the one file that knows the generator.

What a client reads is relaxed before generation (ADR 0019, ADR 0040): unknown fields pass, every enum is
read as a string, and a value is held to its type and to no `pattern`, `format` or bound; a literal
(`const`) stays closed. So an id is a `string` here, not a checked uuid, and an instant is a `string`, not a
checked date-time: code that parses one handles the unreadable case. What a client writes stays exactly as
the API declares it, every constraint included.

## Tests

```bash
pnpm test             # vitest: transport, operations, outbox, the store contract on memoryStore
pnpm test:coverage    # gates: 85 % lines overall, 95 % on src/errors, src/transport, src/operations, src/outbox
pnpm generate:check   # src/generated/ equals a fresh run
pnpm pack:check       # builds, packs and imports the tarball from plain Node
pnpm test:all         # exactly what CI runs (sdk.yml): format:check, typecheck, lint, coverage, generate:check, pack:check
```

| Layer          | Files                               | Owns                                                                                                                                                                                                                      |
| -------------- | ----------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Unit           | `src/**/*.test.ts`                  | Every `*Logic.ts` module (table-driven), the transport against a fake `fetch` and injected clock, `unwrap`, the factories, the queue functions and the engine on `memoryStore`, path and query building in `operations/`. |
| Store contract | `outboxStoreContract`               | `memoryStore` here; the app's `drizzleOutboxStore` in its `*.db.test.ts`.                                                                                                                                                 |
| Generated      | `pnpm generate:check`               | The committed `src/generated/` equals a fresh run; `generated.test.ts` pins the relaxed reads and the closed writes.                                                                                                      |
| Operations     | `src/operations/operations.test.ts` | For every descriptor: the function exists, sends its method and path, requires a key exactly when `idempotent`, and sends no bearer exactly when `auth` is false.                                                         |
| Pack           | `pnpm pack:check`                   | The built tarball imports from plain Node and exposes the public surface.                                                                                                                                                 |
| App            | the app's own layers                | The app's tests pass on the SDK, the worker test among them on the drizzle store (`apps/app/src/repositories/sync.db.test.ts`).                                                                                           |

Scripts' tests (`scripts/**/*.test.ts`) run under the same `pnpm test`. Time and randomness are injected; no
test reads the wall clock or the network.

## Layout

```
packages/sdk/
  scripts/                clientDocument.ts (relaxes what is read, names every operation part),
                          generatorProfile.ts (the generator's call), emitOperations.ts (the descriptors),
                          generate.ts (the pipeline and --check), pack-check.mjs
  tsup.config.ts          the publish build only
  src/
    index.ts              the public surface, named exports only
    generated/            zod.gen.ts and operations.gen.ts: committed, never edited by hand
    operations/           createSdk, the descriptor types, pathLogic.ts
    transport/            client.ts, problemLogic.ts, retryLogic.ts, reachLogic.ts, traceparentLogic.ts
    outbox/               engine.ts, outboxLogic.ts, nextAttemptLogic.ts, queue.ts, queueLogic.ts,
                          store.ts, types.ts, memoryStore.ts, storeContract.ts
    errors/               results.ts (SdkError, ok, err, the factories), unwrap.ts
    logging.ts            the Logger shape the SDK accepts; silentLogger()
    test/                 result.ts (okValue, errValue), logger.ts (captureLogger)
```

## What it never does

- **No React, no Expo, no Node built-ins** in `src/`: Hermes, a browser and Node 24 run the same source, and
  lint refuses `node:*`, React, Expo, `process`, `Buffer`, `require` and `__dirname` there.
- **No storage of its own.** The outbox's rows live in the consumer's storage behind `OutboxStore`; the engine
  hands the server's answer to the consumer's applier and never edits it (ADR 0034).
- **No logging of content or identity.** It logs on the logger it is given, at `debug` for requests, with ids,
  methods, paths, codes and counts only; a thrown error is logged by its name, never its message
  (standards §3.3).
- **No throws past an exported function** except `unwrap`, which exists to throw at the React boundary.
