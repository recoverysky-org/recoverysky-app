#!/usr/bin/env python3
"""
TREX Python Runner - Bridge between TypeScript and Python TREX implementation.

Usage:
    python trex_runner.py <input_json> <output_json>

The input JSON should contain a 'command' object specifying the operation.
The output JSON will contain 'success', 'result', and optionally 'error'.
"""

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

# Add parent directory to path for trex_py imports
# Assumes trex_py is a sibling directory to trex-ts
SCRIPT_DIR = Path(__file__).resolve().parent
TREX_PY_DIR = SCRIPT_DIR.parents[3] / "trex_py" / "src"
sys.path.insert(0, str(TREX_PY_DIR))

try:
    from trex_py import TREX, Periodicity, TREXJSON
    from trex_py.core.constants import SkipMode
    from trex_py.core.ranges import build_search_ranges, in_range
    from returns.result import Success, Failure
except ImportError as e:
    # Write import error to stderr and exit
    print(f"Failed to import trex_py: {e}", file=sys.stderr)
    print(f"Expected trex_py at: {TREX_PY_DIR}", file=sys.stderr)
    sys.exit(2)


def is_success(result) -> bool:
    """Check if a result is successful."""
    return isinstance(result, Success)


def is_failure(result) -> bool:
    """Check if a result is a failure."""
    return isinstance(result, Failure)


def parse_datetime(dt_str: str) -> datetime:
    """Parse ISO datetime string to datetime object."""
    # Handle various ISO formats
    if dt_str.endswith("Z"):
        dt_str = dt_str[:-1] + "+00:00"
    return datetime.fromisoformat(dt_str)


def periodicity_from_int(value: int) -> Periodicity:
    """Convert integer to Periodicity enum."""
    return Periodicity(value)


def periodicity_to_name(value: int) -> str:
    """Convert integer to periodicity name string."""
    names = {
        0: "CONTINUOUS",
        1: "DAILY",
        2: "WEEKLY",
        3: "MONTHLY",
        4: "YEARLY",
    }
    return names.get(value, str(value))


def skip_mode_from_int(value: int) -> SkipMode:
    """Convert integer to SkipMode enum."""
    return SkipMode(value)


def trex_to_dict(trex: TREX) -> dict[str, Any]:
    """Convert TREX instance to JSON-serializable dict."""
    json_obj = trex.to_json()
    return {
        # Core fields (required)
        "coordinate": json_obj.coordinate,
        "timezone": json_obj.timezone,
        "periodicity": json_obj.periodicity.value if hasattr(json_obj.periodicity, "value") else json_obj.periodicity,
        # Optional fields
        "coordinate_end": json_obj.coordinate_end,
        "duration_ms": json_obj.duration_ms,
        # RRULE fields
        "dtstart": json_obj.dtstart.isoformat() if json_obj.dtstart else None,
        "dtend": json_obj.dtend.isoformat() if json_obj.dtend else None,
        "rrule_str": json_obj.rrule_str,
        "rrule_json": json_obj.rrule_json,
        # Denormalized fields
        "hour": json_obj.hour,
        "minute": json_obj.minute,
        "dow": json_obj.dow,
        "dom": json_obj.dom,
        "month": json_obj.month,
    }


def search_ranges_to_dict(ranges) -> dict[str, Any]:
    """Convert SearchRanges to JSON-serializable dict."""

    def criteria_to_dict(criteria) -> dict[str, Any]:
        return {
            "ranges": [{"start": r.start, "end": r.end} for r in criteria.ranges],
            "wrapped": criteria.wrapped,
            "dst_expanded": criteria.dst_expanded,
            "requires_post_filter": criteria.requires_post_filter,
            "requires_calendar_day_filter": criteria.requires_calendar_day_filter,
        }

    return {
        "continuous": criteria_to_dict(ranges.continuous),
        "daily": criteria_to_dict(ranges.daily),
        "weekly": criteria_to_dict(ranges.weekly),
        "monthly": criteria_to_dict(ranges.monthly),
        "yearly": criteria_to_dict(ranges.yearly),
    }


def handle_from_datetime(params: dict[str, Any]) -> dict[str, Any]:
    """Handle from_datetime command."""
    dt = parse_datetime(params["datetime"])
    periodicity = periodicity_from_int(params["periodicity"])
    duration_ms = params.get("duration_ms", 0)

    result = TREX.from_datetime(dt, periodicity, duration_ms)
    if is_failure(result):
        raise result.failure()

    return trex_to_dict(result.unwrap())


def handle_from_wall_clock(params: dict[str, Any]) -> dict[str, Any]:
    """Handle from_wall_clock command."""
    components = params["components"]
    periodicity = periodicity_from_int(params["periodicity"])
    duration_ms = params.get("duration_ms", 0)

    result = TREX.from_wall_clock(
        hour=components["hour"],
        minute=components["minute"],
        timezone=components["timezone"],
        periodicity=periodicity,
        dow=components.get("dow"),
        dom=components.get("dom"),
        month=components.get("month"),
        duration_ms=duration_ms,
    )
    if is_failure(result):
        raise result.failure()

    return trex_to_dict(result.unwrap())


def handle_from_json(params: dict[str, Any]) -> dict[str, Any]:
    """Handle from_json command."""
    data = params["data"]

    # Convert to TREXJSON Pydantic model
    json_obj = TREXJSON(
        coordinate=data["coordinate"],
        timezone=data["timezone"],
        periodicity=periodicity_from_int(data["periodicity"]),
        coordinate_end=data.get("coordinate_end"),
        duration_ms=data.get("duration_ms"),
        hour=data.get("hour"),
        minute=data.get("minute"),
        dow=data.get("dow"),
        dom=data.get("dom"),
        month=data.get("month"),
    )

    # Python TREX uses from_coordinate, not from_json
    result = TREX.from_coordinate(json_obj)
    if is_failure(result):
        raise result.failure()

    return trex_to_dict(result.unwrap())


def handle_from_millis(params: dict[str, Any]) -> dict[str, Any]:
    """Handle from_millis command."""
    # Python TREX uses from_coordinate with a TREXJSON object
    json_obj = TREXJSON(
        coordinate=params["coordinate"],
        timezone=params["timezone"],
        periodicity=periodicity_from_int(params["periodicity"]),
        duration_ms=params.get("duration_ms", 0),
    )
    result = TREX.from_coordinate(json_obj)
    if is_failure(result):
        raise result.failure()

    return trex_to_dict(result.unwrap())


def handle_from_rrule_str(params: dict[str, Any]) -> dict[str, Any]:
    """Handle from_rrule_str command."""
    # Python TREX uses from_rrule, not from_rrule_str
    result = TREX.from_rrule(params["rrule_complete"])
    if is_failure(result):
        raise result.failure()

    return trex_to_dict(result.unwrap())


def handle_build_search_ranges(params: dict[str, Any]) -> dict[str, Any]:
    """Handle build_search_ranges command."""
    start = parse_datetime(params["start"])
    end = parse_datetime(params["end"])
    timezone = params["timezone"]
    periodicities = params.get("periodicities")

    result = build_search_ranges(
        start=start,
        end=end,
        timezone=timezone,
        periodicities=periodicities,
        enable_dst_detection=True,
    )
    if is_failure(result):
        raise result.failure()

    return search_ranges_to_dict(result.unwrap())


def handle_get_next_occurrence(params: dict[str, Any]) -> dict[str, Any]:
    """Handle get_next_occurrence command."""
    coordinate = params["coordinate"]
    timezone = params["timezone"]
    periodicity = periodicity_from_int(params["periodicity"])
    from_dt = parse_datetime(params["from_dt"]) if params.get("from_dt") else None

    # Create TREX instance first using from_coordinate
    json_obj = TREXJSON(
        coordinate=coordinate,
        timezone=timezone,
        periodicity=periodicity,
    )
    trex_result = TREX.from_coordinate(json_obj)
    if is_failure(trex_result):
        raise trex_result.failure()

    trex = trex_result.unwrap()
    result = trex.get_next_occurrence(from_dt)
    if is_failure(result):
        raise result.failure()

    dt = result.unwrap()
    return {"datetime": dt.isoformat()}


def handle_hydrate(params: dict[str, Any]) -> dict[str, Any]:
    """Handle hydrate command."""
    from trex_py.core.utils.hydrate import hydrate

    coordinate = params["coordinate"]
    timezone = params["timezone"]
    periodicity = periodicity_from_int(params["periodicity"])
    reference_time = parse_datetime(params["reference_time"])
    skip_mode = skip_mode_from_int(params.get("skip_mode", 0))

    result = hydrate(
        coordinate=coordinate,
        timezone=timezone,
        periodicity=periodicity,
        reference_time=reference_time,
        skip_mode=skip_mode,
    )
    if is_failure(result):
        raise result.failure()

    hydrated = result.unwrap()
    return {
        "datetime": hydrated.datetime.isoformat(),
        "hour": hydrated.hour,
        "minute": hydrated.minute,
        "position": hydrated.position,
        "is_ghost_day": hydrated.is_ghost_day,
    }


def handle_in_range(params: dict[str, Any]) -> bool:
    """Handle in_range command."""
    from trex_py.core.types import SearchRange

    coordinate = params["coordinate"]
    ranges = [SearchRange(start=r["start"], end=r["end"]) for r in params["ranges"]]
    coordinate_end = params.get("coordinate_end")

    return in_range(coordinate, ranges, coordinate_end)


def handle_memory_search(params: dict[str, Any]) -> dict[str, Any]:
    """Handle memory_search command - search events using MemoryAdapter."""
    import asyncio
    from trex_py.db import MemoryAdapter, MemoryAdapterConfig

    events_data = params["events"]
    start = parse_datetime(params["start"])
    end = parse_datetime(params["end"])
    periodicities_raw = params.get("periodicities")
    config_data = params.get("config", {})
    collect_meta = params.get("meta", False)

    # Convert periodicities to names (Python search expects string names)
    periodicities = None
    if periodicities_raw:
        periodicities = [periodicity_to_name(p) for p in periodicities_raw]

    # Convert events to the format expected by MemoryAdapter
    from trex_py.db.types import TREXEvent

    trex_events = []
    for event in events_data:
        trex_event = TREXEvent(
            id=event["id"],  # TREXEvent uses id, not id
            coordinate=event["coordinate"],
            timezone=event["timezone"],
            periodicity=periodicity_from_int(event["periodicity"]),
            hour=event.get("hour"),
            minute=event.get("minute"),
            dow=event.get("dow"),
            dom=event.get("dom"),
            month=event.get("month"),
            duration_ms=event.get("duration_ms"),
            coordinate_end=event.get("coordinate_end"),
        )
        trex_events.append(trex_event)

    # Build adapter config from TypeScript config
    # Only pass parameters that MemoryAdapterConfig actually accepts
    adapter_config = MemoryAdapterConfig(
        enable_rrule=config_data.get("enableRrule", True),
        enable_dst_post_filter=config_data.get("enableDstPostFilter", True),
        enable_calendar_day_filter=config_data.get("enableCalendarDayFilter", True),
        enable_range_cache=config_data.get("enableRangeCache", True),
        range_cache_size=config_data.get("rangeCacheSize", 1000),
        enable_cache_stats=config_data.get("enableCacheStats", False),
        debug=config_data.get("debug", False),
        timing=config_data.get("timing", True),
        log_ranges=config_data.get("logRanges", False),
        log_candidates=config_data.get("logCandidates", False),
    )

    # Create adapter with events (Python MemoryAdapter takes events at construction)
    adapter = MemoryAdapter(trex_events, config=adapter_config)

    # Run synchronous search
    search_result = adapter.search(
        start=start,
        end=end,
        periodicities=periodicities,
        meta=collect_meta,
    )
    if is_failure(search_result):
        raise search_result.failure()

    result = search_result.unwrap()

    # Convert result to JSON-serializable format
    matches = []
    for match in result.matches:
        matches.append({
            "id": match.id,
            "coordinate": match.coordinate,
            "timezone": match.timezone,
            "periodicity": match.periodicity.value if hasattr(match.periodicity, "value") else match.periodicity,
            "hour": getattr(match, "hour", None),
            "minute": getattr(match, "minute", None),
            "dow": getattr(match, "dow", None),
            "dom": getattr(match, "dom", None),
            "month": getattr(match, "month", None),
            "duration_ms": getattr(match, "duration_ms", None),
            "coordinate_end": getattr(match, "coordinate_end", None),
        })

    response = {
        "matches": matches,
        "count": result.count,
        "wrapped": result.wrapped,
    }

    if hasattr(result, "live_count") and result.live_count is not None:
        response["liveCount"] = result.live_count

    if collect_meta and result.meta:
        # Convert metadata to dict (simplified version)
        response["meta"] = {
            "totalEvents": result.meta.total_events,
            "totalMatches": result.meta.total_matches,
            "timezoneCount": result.meta.timezone_count,
        }

    return response


def handle_memory_search_live(params: dict[str, Any]) -> dict[str, Any]:
    """Handle memory_search_live command - search for live events."""
    import asyncio
    from trex_py.db import MemoryAdapter, MemoryAdapterConfig
    from trex_py.db.types import TREXEvent

    events_data = params["events"]
    now = parse_datetime(params["now"])
    periodicities_raw = params.get("periodicities")
    config_data = params.get("config", {})
    collect_meta = params.get("meta", False)

    # Convert periodicities to names (Python search expects string names)
    periodicities = None
    if periodicities_raw:
        periodicities = [periodicity_to_name(p) for p in periodicities_raw]

    # Convert events
    trex_events = []
    for event in events_data:
        trex_event = TREXEvent(
            id=event["id"],  # TREXEvent uses id, not id
            coordinate=event["coordinate"],
            timezone=event["timezone"],
            periodicity=periodicity_from_int(event["periodicity"]),
            hour=event.get("hour"),
            minute=event.get("minute"),
            dow=event.get("dow"),
            dom=event.get("dom"),
            month=event.get("month"),
            duration_ms=event.get("duration_ms"),
            coordinate_end=event.get("coordinate_end"),
        )
        trex_events.append(trex_event)

    # Build adapter config (only valid parameters)
    adapter_config = MemoryAdapterConfig(
        enable_rrule=config_data.get("enableRrule", True),
        enable_dst_post_filter=config_data.get("enableDstPostFilter", True),
        enable_calendar_day_filter=config_data.get("enableCalendarDayFilter", True),
        enable_range_cache=config_data.get("enableRangeCache", True),
        range_cache_size=config_data.get("rangeCacheSize", 1000),
        enable_cache_stats=config_data.get("enableCacheStats", False),
        debug=config_data.get("debug", False),
        timing=config_data.get("timing", True),
    )

    # Create adapter with events
    adapter = MemoryAdapter(trex_events, config=adapter_config)

    # Run synchronous search_live
    search_result = adapter.search_live(now=now, periodicities=periodicities, meta=collect_meta)
    if is_failure(search_result):
        raise search_result.failure()

    result = search_result.unwrap()

    matches = []
    for match in result.matches:
        matches.append({
            "id": match.id,
            "coordinate": match.coordinate,
            "timezone": match.timezone,
            "periodicity": match.periodicity.value if hasattr(match.periodicity, "value") else match.periodicity,
            "hour": getattr(match, "hour", None),
            "minute": getattr(match, "minute", None),
            "dow": getattr(match, "dow", None),
            "dom": getattr(match, "dom", None),
            "month": getattr(match, "month", None),
            "duration_ms": getattr(match, "duration_ms", None),
            "coordinate_end": getattr(match, "coordinate_end", None),
        })

    return {
        "matches": matches,
        "count": result.count,
        "wrapped": result.wrapped,
        "liveCount": getattr(result, "live_count", len(matches)),
    }


# =============================================================================
# TREXPy Adapter Commands (backend-agnostic)
# =============================================================================


def handle_trex_py_search(params: dict[str, Any]) -> dict[str, Any]:
    """Handle trex_py_search command - search events with backend support."""
    backend = params.get("backend", "memory")

    if backend == "memory":
        # Delegate to memory search (events passed from TypeScript)
        return handle_memory_search(params)
    elif backend == "postgresql":
        # TODO: Implement PostgreSQL adapter when available
        raise NotImplementedError("PostgreSQL backend not yet implemented in trex_py")
    else:
        raise ValueError(f"Unknown backend: {backend}")


def handle_trex_py_search_live(params: dict[str, Any]) -> dict[str, Any]:
    """Handle trex_py_search_live command - search live events with backend support."""
    backend = params.get("backend", "memory")

    if backend == "memory":
        # Delegate to memory search_live (events passed from TypeScript)
        return handle_memory_search_live(params)
    elif backend == "postgresql":
        # TODO: Implement PostgreSQL adapter when available
        raise NotImplementedError("PostgreSQL backend not yet implemented in trex_py")
    else:
        raise ValueError(f"Unknown backend: {backend}")


def handle_trex_py_insert(params: dict[str, Any]) -> dict[str, Any]:
    """Handle trex_py_insert command - insert events (postgresql only)."""
    backend = params.get("backend", "memory")

    if backend == "memory":
        # Memory backend: TypeScript handles storage, this is a no-op
        # Just return the count of events
        return {"inserted": len(params.get("events", []))}
    elif backend == "postgresql":
        # TODO: Implement PostgreSQL adapter when available
        raise NotImplementedError("PostgreSQL backend not yet implemented in trex_py")
    else:
        raise ValueError(f"Unknown backend: {backend}")


def handle_trex_py_delete(params: dict[str, Any]) -> dict[str, Any]:
    """Handle trex_py_delete command - delete events (postgresql only)."""
    backend = params.get("backend", "memory")

    if backend == "memory":
        # Memory backend: TypeScript handles storage, this is a no-op
        return {"deleted": len(params.get("eventIds", []))}
    elif backend == "postgresql":
        # TODO: Implement PostgreSQL adapter when available
        raise NotImplementedError("PostgreSQL backend not yet implemented in trex_py")
    else:
        raise ValueError(f"Unknown backend: {backend}")


def handle_trex_py_clear(params: dict[str, Any]) -> dict[str, Any]:
    """Handle trex_py_clear command - clear all events (postgresql only)."""
    backend = params.get("backend", "memory")

    if backend == "memory":
        # Memory backend: TypeScript handles storage, this is a no-op
        return {}
    elif backend == "postgresql":
        # TODO: Implement PostgreSQL adapter when available
        raise NotImplementedError("PostgreSQL backend not yet implemented in trex_py")
    else:
        raise ValueError(f"Unknown backend: {backend}")


def handle_trex_py_count(params: dict[str, Any]) -> dict[str, Any]:
    """Handle trex_py_count command - count events (postgresql only)."""
    backend = params.get("backend", "memory")

    if backend == "memory":
        # Memory backend: TypeScript handles counting
        raise ValueError("Memory backend count should be handled in TypeScript")
    elif backend == "postgresql":
        # TODO: Implement PostgreSQL adapter when available
        raise NotImplementedError("PostgreSQL backend not yet implemented in trex_py")
    else:
        raise ValueError(f"Unknown backend: {backend}")


def handle_trex_py_get_all(params: dict[str, Any]) -> dict[str, Any]:
    """Handle trex_py_get_all command - get all events (postgresql only)."""
    backend = params.get("backend", "memory")

    if backend == "memory":
        # Memory backend: TypeScript handles storage
        raise ValueError("Memory backend getAll should be handled in TypeScript")
    elif backend == "postgresql":
        # TODO: Implement PostgreSQL adapter when available
        raise NotImplementedError("PostgreSQL backend not yet implemented in trex_py")
    else:
        raise ValueError(f"Unknown backend: {backend}")


def handle_trex_py_get(params: dict[str, Any]) -> dict[str, Any]:
    """Handle trex_py_get command - get event by ID (postgresql only)."""
    backend = params.get("backend", "memory")

    if backend == "memory":
        # Memory backend: TypeScript handles storage
        raise ValueError("Memory backend get should be handled in TypeScript")
    elif backend == "postgresql":
        # TODO: Implement PostgreSQL adapter when available
        raise NotImplementedError("PostgreSQL backend not yet implemented in trex_py")
    else:
        raise ValueError(f"Unknown backend: {backend}")


def handle_trex_py_has(params: dict[str, Any]) -> dict[str, Any]:
    """Handle trex_py_has command - check if event exists (postgresql only)."""
    backend = params.get("backend", "memory")

    if backend == "memory":
        # Memory backend: TypeScript handles storage
        raise ValueError("Memory backend has should be handled in TypeScript")
    elif backend == "postgresql":
        # TODO: Implement PostgreSQL adapter when available
        raise NotImplementedError("PostgreSQL backend not yet implemented in trex_py")
    else:
        raise ValueError(f"Unknown backend: {backend}")


# Command dispatcher
HANDLERS = {
    # Core TREX commands
    "from_datetime": handle_from_datetime,
    "from_wall_clock": handle_from_wall_clock,
    "from_json": handle_from_json,
    "from_millis": handle_from_millis,
    "from_rrule_str": handle_from_rrule_str,
    "build_search_ranges": handle_build_search_ranges,
    "get_next_occurrence": handle_get_next_occurrence,
    "hydrate": handle_hydrate,
    "in_range": handle_in_range,
    # TREXPy adapter commands (backend-agnostic)
    "trex_py_search": handle_trex_py_search,
    "trex_py_search_live": handle_trex_py_search_live,
    "trex_py_insert": handle_trex_py_insert,
    "trex_py_delete": handle_trex_py_delete,
    "trex_py_clear": handle_trex_py_clear,
    "trex_py_count": handle_trex_py_count,
    "trex_py_get_all": handle_trex_py_get_all,
    "trex_py_get": handle_trex_py_get,
    "trex_py_has": handle_trex_py_has,
    # Legacy memory adapter commands (deprecated)
    "memory_search": handle_memory_search,
    "memory_search_live": handle_memory_search_live,
}


def main() -> None:
    if len(sys.argv) != 3:
        print("Usage: trex_runner.py <input_json> <output_json>", file=sys.stderr)
        sys.exit(1)

    input_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])

    try:
        # Read input
        params = json.loads(input_path.read_text())
        command = params.get("command", {})
        command_type = command.get("type")

        if not command_type:
            raise ValueError("Missing command type")

        handler = HANDLERS.get(command_type)
        if not handler:
            raise ValueError(f"Unknown command type: {command_type}")

        # Execute command
        result = handler(command)

        # Write success output
        output_path.write_text(
            json.dumps(
                {
                    "success": True,
                    "result": result,
                },
                indent=2,
                default=str,
            )
        )
        sys.exit(0)

    except Exception as e:
        # Write error output
        error_type = type(e).__name__
        output_path.write_text(
            json.dumps(
                {
                    "success": False,
                    "error": str(e),
                    "error_type": error_type,
                },
                indent=2,
            )
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
