# @trex/core

**Minimal core TREX library: Wall-clock time encoding that survives DST transitions and IANA rule changes.**

Encode once. Store forever. Hydrate with current rules. No recalculation needed.

[![Tests](https://img.shields.io/badge/tests-passing-brightgreen)]()
[![Coverage](https://img.shields.io/badge/coverage-75%2B%25-brightgreen)]()
[![TypeScript](https://img.shields.io/badge/TypeScript-strict-blue)]()

---

## What is TREX?

TREX (Temporal Reference Event Index) solves the **"6pm event problem"** where traditional UTC timestamps break with DST rule changes.

### The Problem

```typescript
// ❌ Traditional: Store as UTC timestamp
const standup = "2025-01-15T14:00:00Z"; // 9am EST = 2pm UTC
// January: 14:00 UTC = 9am EST ✓
// July: 14:00 UTC = 10am EDT ❌
// Your 9am standup just moved to 10am!
```

**Why this happens:**
- UTC timestamps represent a fixed moment in time
- DST changes the UTC offset, shifting wall-clock times
- For RECURRING events, storing a fixed timestamp doesn't capture "always at 9am"

**Traditional solutions fail:**
- **UTC timestamps**: Wall-clock time shifts with DST
- **Wall-clock storage**: Requires recalculation on every query
- **Pre-computed occurrences**: 100x storage, requires updates when rules change

### The TREX Solution

**Encode wall-clock time as milliseconds within stable reference frames.**

```typescript
import { TREX, Periodicity } from '@trex/core';
import { Temporal } from 'temporal-polyfill';

// 1️⃣ ENCODE ONCE
const dt = Temporal.ZonedDateTime.from({
  year: 2025, month: 1, day: 16, hour: 9, minute: 0,
  timeZone: 'America/New_York'
});
const standup = TREX.fromDateTime(dt, Periodicity.DAILY).unwrap();

// 2️⃣ STORE THESE 3 FIELDS
const json = standup.toJSON();
// { coordinate: 32400000, timezone: 'America/New_York', periodicity: 1 }

// 3️⃣ HYDRATE WITH CURRENT RULES (ALWAYS 9AM!)
const next = standup.getNextOccurrence().unwrap();
// January (EST): 2025-01-16T09:00:00-05:00[America/New_York] ✅
// July (EDT): 2025-07-17T09:00:00-04:00[America/New_York] ✅
// Still 9am wall-clock time, correct offset applied automatically

// 4️⃣ IANA RULE CHANGES? NO MIGRATION NEEDED
// Update Node.js (new IANA tzdata included)
// Events automatically use new rules on hydration ✅
```

**Key Benefits:**
- ✅ Wall-clock time preserved (9am stays 9am across EST ↔ EDT)
- ✅ Zero database migrations when IANA rules change
- ✅ Automatic DST handling on hydration with current rules
- ✅ Minimal storage (3 required fields per event)
- ✅ Type-safe error handling (Result type pattern)

---

## Installation

```bash
pnpm add @trex/core temporal-polyfill
# or
npm install @trex/core temporal-polyfill
# or
yarn add @trex/core temporal-polyfill
```

**Requirements:**
- Node.js 18+ (for Node.js usage with Python bridge)
- TypeScript 5.0+ (recommended)

**Browser Requirements:**
- No Node.js or Python needed
- Pure TypeScript implementation

---

## Quick Start

```typescript
import { TREX, Periodicity } from '@trex/core';
import { Temporal } from 'temporal-polyfill';

// 1️⃣ Create event from datetime
const dt = Temporal.ZonedDateTime.from({
  year: 2025, month: 1, day: 15, hour: 9, minute: 0,
  timeZone: 'America/New_York'
});

const result = TREX.fromDateTime(dt, Periodicity.DAILY);
if (!result.ok) {
  console.error(result.error);
  return;
}
const standup = result.value;

// 2️⃣ Store to database (3 required fields)
const json = standup.toJSON();
// {
//   coordinate: 32400000,
//   timezone: 'America/New_York',
//   periodicity: 1,
//   duration_ms: 0,
//   hour: 9,
//   minute: 0
// }

// 3️⃣ Get next occurrence with current IANA rules
const nextResult = standup.getNextOccurrence();
if (!nextResult.ok) {
  console.error(nextResult.error);
  return;
}
const next = nextResult.value;
console.log(next.toString()); // 2025-01-15T09:00:00-05:00[America/New_York]

// 4️⃣ Restore from database
const restored = TREX.fromJSON({
  coordinate: 32400000,
  timezone: 'America/New_York',
  periodicity: 1
});

if (restored.ok) {
  const occurrence = restored.value.getNextOccurrence().unwrap();
  // Always 9am, DST-aware, current IANA rules ✅
}
```

---

## Browser Usage

For browser applications, use the dedicated browser entry point which provides pure TypeScript implementations without any Node.js or Python dependencies:

```typescript
import {
  TREXBrowser,
  Periodicity,
  BrowserMemoryAdapter,
  DateTime
} from '@trex-ts/core/browser';

// 1️⃣ Create event from wall-clock components (synchronous!)
const result = TREXBrowser.fromWallClock(
  { hour: 18, minute: 0, timezone: 'America/New_York', dow: 4 },
  Periodicity.WEEKLY
);

if (result.ok) {
  const event = result.value;
  console.log(event.toJSON());
  // { coordinate: 280800000, timezone: 'America/New_York', periodicity: 2, ... }

  // 2️⃣ Get next occurrence
  const next = event.getNextOccurrence();
  if (next.ok) {
    console.log(next.value.toISO()); // 2025-01-16T18:00:00.000-05:00
  }
}

// 3️⃣ Use in-memory storage with RRULE-based search
const adapter = new BrowserMemoryAdapter();
await adapter.insert([{ id: '1', ...event.toJSON() }]);

const results = await adapter.search(
  '2025-01-16T00:00:00-05:00',
  '2025-01-16T23:59:59-05:00'
);
console.log(results.matches); // Events occurring in that window
```

### Browser vs Node.js API

| Feature | Node.js (`@trex/core`) | Browser (`@trex/core/browser`) |
|---------|------------------------|-------------------------------|
| Factory methods | `async` (Python bridge) | `sync` (pure TypeScript) |
| Class name | `TREX` | `TREXBrowser` |
| Memory adapter | `TREXPyAdapter` | `BrowserMemoryAdapter` |
| PostgreSQL | ✅ Available | ❌ Not available |
| Dependencies | Python 3.10+ | None (pure TS) |

### Browser Factory Methods

All browser factory methods are **synchronous** (no async/await needed):

```typescript
// From wall-clock components
const weekly = TREXBrowser.fromWallClock(
  { hour: 18, minute: 0, timezone: 'America/New_York', dow: 4 },
  Periodicity.WEEKLY
);

// From Luxon DateTime
const dt = DateTime.fromObject(
  { hour: 9, minute: 0 },
  { zone: 'America/New_York' }
);
const daily = TREXBrowser.fromDateTime(dt, Periodicity.DAILY);

// From Date object
const date = new Date('2025-01-16T09:00:00-05:00');
const fromDate = TREXBrowser.fromDate(date, 'America/New_York', Periodicity.DAILY);

// From JSON (restore from database)
const restored = TREXBrowser.fromJSON({
  coordinate: 32400000,
  timezone: 'America/New_York',
  periodicity: 1
});

// From raw coordinate
const fromMillis = TREXBrowser.fromMillis(
  32400000,
  'America/New_York',
  Periodicity.DAILY
);
```

### Browser Module Exports

The browser entry point exports these categories:

```typescript
import {
  // Core class
  TREXBrowser,

  // Normalization (wall-clock → coordinate)
  normalize,
  calculateDayOfYear,
  calculateCoordinateEnd,
  DAYS_BEFORE_MONTH,
  DAYS_IN_MONTH,
  PERIOD_MAX_MS,

  // RRULE generation
  generateRRule,
  decodeCoordinate,
  parseRRuleToJson,

  // Search ranges
  buildSearchRanges,
  createSearchRanges,
  inRange,
  isLiveInterval,

  // Hydration (coordinate → DateTime)
  hydrate,
  hydrateNext,
  hydrateCurrent,
  extractWallClockTime,
  extractPosition,
  getWeekStart,
  isLeapYear,
  getDaysInMonth,
  adjustForDstGap,

  // Adapter
  BrowserMemoryAdapter,

  // Types and constants
  Periodicity,
  SkipMode,
  MINUTE_MS,
  HOUR_MS,
  DAY_MS,
  WEEK_MS,
  MONTH_MS,
  YEAR_MS,

  // Luxon DateTime (re-exported for convenience)
  DateTime
} from '@trex-ts/core/browser';
```

---

## Core Concepts

### Periodicities

| Type | Value | Use Case | Reference Period | Range (ms) |
|------|-------|----------|------------------|------------|
| `CONTINUOUS` | 0 | 24/7 hotlines, always-on services | Fixed marker | 31,622,400,000 |
| `DAILY` | 1 | Daily standup, medication | Jan 1, 1970 | 0-86,399,999 |
| `WEEKLY` | 2 | Weekly meetings, classes | Jan 1-7, 1970 | 0-604,799,999 |
| `MONTHLY` | 3 | Monthly billing, reports | Jan 1-31, 1970 | 0-2,678,399,999 |
| `YEARLY` | 4 | Birthdays, anniversaries | 1972 (leap year) | 0-31,622,399,999 |

**About CONTINUOUS events:**
- CONTINUOUS events represent perpetual 24/7 availability (always-on services, support hotlines)
- They are **always included in search results** regardless of the query time window
- Use `TREXEngineAdapter.createEventFromContinuous()` to create them properly (see [Database Adapters](#database-adapters) section)

**What the coordinate represents:**
- Milliseconds within the reference period for that periodicity
- Example: 32,400,000 ms = 9:00 AM (9 hours × 60 min × 60 sec × 1000 ms)
- Reference period never changes, DST is irrelevant (always applies current IANA rules on hydration)

### Encoding Formula

All periodicities use the same formula:

```
coordinate = (periodPosition - 1) × DAY_MS + hour × HOUR_MS + minute × MINUTE_MS
```

Where `periodPosition` depends on periodicity:
- **DAILY**: Always 1 (no variation)
- **WEEKLY**: 1-7 (ISO weekday: Mon=1, Sun=7)
- **MONTHLY**: 1-31 (day-of-month)
- **YEARLY**: 1-366 (day-of-year)

### Three-Phase Algorithm

1. **Normalization** (wall-clock → coordinate):
   - Input: hour, minute, timezone, periodicity, and periodicity-specific components
   - Output: coordinate (source of truth)
   - Validation ensures valid inputs before encoding

2. **Storage** (database):
   - 3 required fields: `coordinate`, `timezone`, `periodicity`
   - Optional denormalized fields: `hour`, `minute`, `dow`, `dom`, `month`

3. **Hydration** (coordinate → ZonedDateTime):
   - Decodes coordinate back to wall-clock time
   - Applies **current IANA timezone rules** automatically
   - Returns ZonedDateTime with correct offset (EST vs EDT, etc.)

---

## Factory Methods

### `TREX.fromDateTime()`

Create a TREX event from a Temporal.ZonedDateTime:

```typescript
const dt = Temporal.ZonedDateTime.from({
  year: 2025, month: 1, day: 15, hour: 9, minute: 0,
  timeZone: 'America/New_York'
});

const result = TREX.fromDateTime(dt, Periodicity.DAILY, duration_ms);
if (result.ok) {
  const event = result.value;
  console.log(event.coordinate);   // Normalized coordinate
  console.log(event.timezone);     // 'America/New_York'
  console.log(event.periodicity);  // 1 (DAILY)
}
```

**Parameters:**
- `dt: Temporal.ZonedDateTime` - Must have timezone
- `periodicity: PeriodicityType` - Event recurrence type
- `duration_ms?: number` - Event duration in milliseconds (default: 0)

**Returns:** `TREXResult<TREX>`

### `TREX.fromJSON()`

Restore a TREX event from serialized data:

```typescript
const json = {
  coordinate: 32400000,
  timezone: 'America/New_York',
  periodicity: 1,
  duration_ms: 0  // optional
};

const result = TREX.fromJSON(json);
if (result.ok) {
  const event = result.value;
  // Now hydrate to get next occurrence
}
```

**Parameters:**
- `data: TREXJSON` - Serialized event data

**Returns:** `TREXResult<TREX>`

### `TREX.fromMillis()`

Create from raw coordinate values (advanced):

```typescript
const result = TREX.fromMillis(
  32400000,                 // coordinate
  'America/New_York',       // timezone
  Periodicity.DAILY,        // periodicity
  0                         // duration_ms (optional)
);

if (result.ok) {
  const event = result.value;
}
```

**Parameters:**
- `coordinate: number` - Milliseconds within reference frame
- `timezone: string` - IANA timezone identifier
- `periodicity: PeriodicityType` - Event recurrence type
- `duration_ms?: number` - Event duration (default: 0)

**Returns:** `TREXResult<TREX>`

---

## Instance Methods

### `toJSON()`

Serialize for storage:

```typescript
const event = TREX.fromDateTime(dt, Periodicity.DAILY).unwrap();
const json = event.toJSON();

// {
//   coordinate: 32400000,
//   timezone: 'America/New_York',
//   periodicity: 1,
//   duration_ms: 0,
//   coordinate_end: 32400000,
//   hour: 9,
//   minute: 0
// }
```

**Returns:** `TREXJSON` with all fields

### `getNextOccurrence()`

Get the next occurrence with current IANA DST rules:

```typescript
const event = TREX.fromDateTime(dt, Periodicity.DAILY).unwrap();
const result = event.getNextOccurrence(fromDt);

if (result.ok) {
  const next = result.value; // Temporal.ZonedDateTime
  console.log(next.toString()); // 2025-01-15T09:00:00-05:00[America/New_York]
}
```

**Parameters:**
- `fromDt?: Temporal.ZonedDateTime` - Start point (defaults to now)

**Returns:** `TREXResult<Temporal.ZonedDateTime>`

**Behavior:**
- Auto-advances if occurrence equals reference time
- Respects CONTINUOUS events (no auto-advance for continuous)
- Applies current IANA rules automatically

### `toString()`

Human-readable representation:

```typescript
const event = TREX.fromDateTime(dt, Periodicity.WEEKLY).unwrap();
console.log(event.toString());
// "TREX(09:00 WEEKLY Thursday America/New_York)"
```

### `equals()`

Equality comparison:

```typescript
const event1 = TREX.fromDateTime(dt1, Periodicity.DAILY).unwrap();
const event2 = TREX.fromDateTime(dt2, Periodicity.DAILY).unwrap();

if (event1.equals(event2)) {
  console.log('Same event');
}
```

### `hash()`

Hash code for use in sets/maps:

```typescript
const events = new Map<number, TREX>();
const event = TREX.fromDateTime(dt, Periodicity.DAILY).unwrap();
events.set(event.hash(), event);
```

---

## Properties

```typescript
event.coordinate: number      // Encoded time (source of truth)
event.timezone: string       // IANA timezone
event.periodicity: number    // 0-4: CONTINUOUS, DAILY, WEEKLY, MONTHLY, YEARLY
event.duration_ms: number     // Event duration in milliseconds

// Calculated properties
event.coordinate_end: number  // End coordinate (with period wrapping)
```

---

## Error Handling

All operations return `Result<T, TREXError>` (never throw exceptions):

```typescript
import type { TREXResult } from '@trex/core';

const result: TREXResult<TREX> = TREX.fromDateTime(dt, Periodicity.DAILY);

if (!result.ok) {
  console.error(result.error.message);  // Detailed error message
  console.error(result.error.code);     // Error code
  return;
}

const event = result.value;
```

**Convenience methods:**

```typescript
// Unwrap with panic on error
const event = result.unwrap();

// Unwrap with fallback
const event = result.unwrapOr(defaultEvent);

// Transform on success
const json = result.map(e => e.toJSON());
```

---

## Real Examples

### Daily Standup (Preserved Across DST)

```typescript
import { TREX, Periodicity } from '@trex/core';
import { Temporal } from 'temporal-polyfill';

// Create daily standup at 9am
const dt = Temporal.ZonedDateTime.from({
  year: 2025, month: 1, day: 15, hour: 9, minute: 0,
  timeZone: 'America/New_York'
});

const standup = TREX.fromDateTime(dt, Periodicity.DAILY).unwrap();

// Store
await db.insert({
  name: 'Engineering Standup',
  coordinate: standup.coordinate,
  timezone: standup.timezone,
  periodicity: standup.periodicity
});

// Later: Get next occurrence
const next = standup.getNextOccurrence().unwrap();

// January (EST): 09:00 EST (UTC-5)
// July (EDT): 09:00 EDT (UTC-4)
// Always 9am local time, DST handled automatically ✅
```

### Weekly Meeting (Friday 6pm)

```typescript
// Friday 6pm meeting
const friday = Temporal.ZonedDateTime.from({
  year: 2025, month: 1, day: 17, hour: 18, minute: 0,  // Friday
  timeZone: 'America/Los_Angeles'
});

const meeting = TREX.fromDateTime(friday, Periodicity.WEEKLY).unwrap();

// Store
const json = meeting.toJSON();
// {
//   coordinate: 50400000,  // Friday (4) at 6pm (18:00)
//   timezone: 'America/Los_Angeles',
//   periodicity: 2         // WEEKLY
// }

// Later: Get next Friday meeting
const next = meeting.getNextOccurrence().unwrap();
console.log(next.toString());
// 2025-01-17T18:00:00-08:00[America/Los_Angeles]  (PST)
// or
// 2025-07-18T18:00:00-07:00[America/Los_Angeles]  (PDT)
// Always Friday 6pm, DST applied automatically ✅
```

### Monthly Billing (15th at 2am UTC)

```typescript
const billing = Temporal.ZonedDateTime.from({
  year: 2025, month: 1, day: 15, hour: 2, minute: 0,
  timeZone: 'UTC'
});

const billingEvent = TREX.fromDateTime(
  billing,
  Periodicity.MONTHLY
).unwrap();

// Get next billing dates
let from = Temporal.Now.zonedDateTimeISO('UTC');
for (let i = 0; i < 6; i++) {
  const next = billingEvent.getNextOccurrence(from).unwrap();
  console.log(next.toPlainDate().toString());
  // 2025-01-15
  // 2025-02-15
  // 2025-03-15
  // ... (continues on 15th of each month)
  from = next.add({ days: 1 });
}
```

### Yearly Event (Birthday)

```typescript
const birthday = Temporal.ZonedDateTime.from({
  year: 1990, month: 6, day: 15, hour: 0, minute: 0,  // June 15th
  timeZone: 'America/New_York'
});

const birthdayEvent = TREX.fromDateTime(
  birthday,
  Periodicity.YEARLY
).unwrap();

const next = birthdayEvent.getNextOccurrence().unwrap();
// June 15, 2025 at midnight
// June 15, 2026 at midnight
// ... repeats yearly on June 15th
```

---

## TREXJSON Format Reference

The canonical format for storing TREX events in any database. This matches the Python `trex_py` implementation exactly.

### Core Fields (Required)

These three fields are the **source of truth** and must always be stored:

| Field | Type | Description |
|-------|------|-------------|
| `coordinate` | `int` | Milliseconds within the reference frame (encodes wall-clock time) |
| `timezone` | `string` | IANA timezone identifier (e.g., `"America/New_York"`) |
| `periodicity` | `int` | Event recurrence type: 0=CONTINUOUS, 1=DAILY, 2=WEEKLY, 3=MONTHLY, 4=YEARLY |

### Optional Fields

| Field | Type | Description |
|-------|------|-------------|
| `coordinate_end` | `int \| null` | End coordinate (coordinate + duration with period wrapping) |
| `duration_ms` | `int \| null` | Event duration in milliseconds (0 = instant event) |

### RRULE Fields (For Recurrence Series)

| Field | Type | Description |
|-------|------|-------------|
| `dtstart` | `datetime \| null` | Start of recurrence series (when event begins recurring) |
| `dtend` | `datetime \| null` | End of recurrence series (NULL = infinite recurrence) |
| `rrule_str` | `string \| null` | RFC 5545 RRULE string for dateutil/export |
| `rrule_json` | `object \| null` | RRULE components for SQL queries |

### Denormalized Fields (Optional, For Query Optimization)

These are computed from `coordinate` and provided for database indexing convenience. **Never use these as source of truth.**

| Field | Type | Description | Applicable Periodicities |
|-------|------|-------------|-------------------------|
| `hour` | `int \| null` | Wall-clock hour (0-23) | All |
| `minute` | `int \| null` | Wall-clock minute (0-59) | All |
| `dow` | `int \| null` | Day of week (1-7, ISO 8601: Mon=1, Sun=7) | WEEKLY |
| `dom` | `int \| null` | Day of month (1-31) | MONTHLY, YEARLY |
| `month` | `int \| null` | Month (1-12) | YEARLY |

### Full TREXJSON Interface

```typescript
interface TREXJSON {
  // Core fields (source of truth) - REQUIRED
  coordinate: number;      // Milliseconds within reference frame
  timezone: string;        // IANA timezone identifier
  periodicity: number;     // 0-4: CONTINUOUS, DAILY, WEEKLY, MONTHLY, YEARLY

  // Optional fields
  coordinate_end?: number; // End coordinate (with period wrapping)
  duration_ms?: number;    // Event duration in milliseconds

  // RRULE fields (for recurrence series)
  dtstart?: Date | null;   // Start of recurrence series
  dtend?: Date | null;     // End of recurrence series (null = infinite)
  rrule_str?: string;      // RFC 5545 RRULE string
  rrule_json?: object;     // RRULE components for SQL queries

  // Denormalized fields (computed from coordinate, for indexing)
  hour?: number;           // 0-23
  minute?: number;         // 0-59
  dow?: number;            // 1-7 (ISO weekday)
  dom?: number;            // 1-31 (day of month)
  month?: number;          // 1-12
}
```

### Example Values by Periodicity

```typescript
// DAILY: 9:00 AM every day
{
  coordinate: 32400000,        // 9 hours × 3,600,000 ms/hour
  timezone: "America/New_York",
  periodicity: 1,
  hour: 9,
  minute: 0
}

// WEEKLY: Thursday 6:00 PM
{
  coordinate: 280800000,       // (4-1) days × 86,400,000 + 18 hours × 3,600,000
  timezone: "America/New_York",
  periodicity: 2,
  hour: 18,
  minute: 0,
  dow: 4                       // Thursday (ISO 8601)
}

// MONTHLY: 15th at 2:00 PM
{
  coordinate: 1258800000,      // (15-1) days × 86,400,000 + 14 hours × 3,600,000
  timezone: "America/New_York",
  periodicity: 3,
  hour: 14,
  minute: 0,
  dom: 15
}

// YEARLY: March 15th at 9:00 AM
{
  coordinate: 6397200000,      // (74-1) days × 86,400,000 + 9 hours × 3,600,000
  timezone: "America/New_York",  // (day 74 = March 15 in leap year 1972)
  periodicity: 4,
  hour: 9,
  minute: 0,
  dom: 15,
  month: 3
}
```

---

## Database Integration (Basic)

### Minimal Schema

```sql
CREATE TABLE events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,

  -- TREX core (required)
  coordinate BIGINT NOT NULL,
  timezone VARCHAR(50) NOT NULL,
  periodicity SMALLINT NOT NULL,

  -- Optional: duration
  duration_ms BIGINT DEFAULT 0,

  created TIMESTAMPTZ DEFAULT NOW()
);

-- Index for queries (not needed for core usage)
CREATE INDEX idx_events_trex ON events(periodicity, coordinate, timezone);
```

### Storage Pattern

```typescript
const event = TREX.fromDateTime(dt, Periodicity.DAILY).unwrap();
const json = event.toJSON();

await db.query(
  `INSERT INTO events (name, coordinate, timezone, periodicity, duration_ms)
   VALUES ($1, $2, $3, $4, $5)`,
  ['My Event', json.coordinate, json.timezone, json.periodicity, json.duration_ms]
);
```

### Retrieval Pattern

```typescript
const row = await db.query(
  'SELECT coordinate, timezone, periodicity FROM events WHERE id = $1',
  [eventId]
);

const event = TREX.fromJSON({
  coordinate: row.coordinate,
  timezone: row.timezone,
  periodicity: row.periodicity
}).unwrap();

const next = event.getNextOccurrence().unwrap();
```

---

## Database Adapters

For production use with in-memory or PostgreSQL storage, use `TREXEngineAdapter` which communicates with the [trex-engine](https://github.com/jenova-marie/trex-engine) HTTP API.

### TREXEngineAdapter

```typescript
import { TREXEngineAdapter } from '@trex/core';

const adapter = new TREXEngineAdapter({
  backend: 'memory',              // 'memory' or 'postgresql'
  baseUrl: 'http://localhost:7631', // trex-engine API URL
});
```

### Creating Events

```typescript
// From wall-clock components
const daily = await adapter.createEventFromWallClock({
  hour: 9,
  minute: 0,
  timezone: 'America/New_York',
  periodicity: 'DAILY',
  duration_ms: 3600000,  // 1 hour
});

// From datetime string
const weekly = await adapter.createEventFromDatetime({
  datetime: '2025-01-20T14:30:00',
  timezone: 'America/New_York',
  periodicity: 'WEEKLY',
});

// From RRULE
const recurring = await adapter.createEventFromRrule({
  rrule: 'DTSTART;TZID=America/New_York:20250120T090000\nRRULE:FREQ=WEEKLY;BYDAY=MO,WE,FR',
});

// CONTINUOUS (24/7 availability)
const alwaysOn = await adapter.createEventFromContinuous({
  timezone: 'America/New_York',  // Optional, defaults to 'Etc/UTC'
});
```

### CONTINUOUS Events (24/7 Availability)

CONTINUOUS events represent perpetual availability and are always included in search results:

```typescript
// Single CONTINUOUS event
const hotline = await adapter.createEventFromContinuous({
  timezone: 'America/New_York',
});

if (hotline.ok) {
  await adapter.insert([hotline.value]);
  // This event will match ANY search query
}

// Bulk creation for multiple always-on services
const services = await adapter.createBulkFromContinuous({
  events: [
    { timezone: 'America/New_York', id: 'support-hotline-east' },
    { timezone: 'America/Los_Angeles', id: 'support-hotline-west' },
    { timezone: 'Europe/London', id: 'support-hotline-eu' },
  ],
});
```

### Insert and Search

```typescript
// Insert events
if (daily.ok && weekly.ok) {
  await adapter.insert([daily.value, weekly.value]);
}

// Search for events in a time window
const results = await adapter.search(
  '2025-01-20T08:00:00-05:00',
  '2025-01-20T18:00:00-05:00'
);

if (results.ok) {
  console.log(`Found ${results.value.count} events`);
  for (const event of results.value.matches) {
    console.log(event.id, event.coordinate, event.timezone);
  }
}

// Search for "live" events at a specific moment
const live = await adapter.searchLive('2025-01-20T09:30:00-05:00');
```

### PostgreSQL Backend

```typescript
const adapter = new TREXEngineAdapter({ backend: 'postgresql' });

// Connect to database
await adapter.connectDatabase({
  host: 'localhost',
  port: 5432,
  database: 'trex',
  username: 'user',
  password: 'pass',
  postFilterMode: 'pgrx',  // 'pgrx' (fastest), 'rrule', or 'legacy'
});

// Insert, search, etc. work the same way
await adapter.insert([event]);
const results = await adapter.search(start, end);

// Disconnect when done
await adapter.disconnectDatabase();
```

---

## DST Transitions

TREX automatically handles DST transitions on hydration:

```typescript
// Event at 2am on DST transition day (2am → 3am EDT)
const spring = Temporal.ZonedDateTime.from({
  year: 2025, month: 3, day: 9, hour: 2, minute: 0,
  timeZone: 'America/New_York'
});

const event = TREX.fromDateTime(spring, Periodicity.DAILY).unwrap();

// Hydrating on DST transition day:
const occurrence = event.getNextOccurrence().unwrap();
// If time doesn't exist (gap): uses next valid occurrence
// If time is ambiguous (fold): uses earlier occurrence
// Temporal API handles resolution automatically ✅
```

---

## Performance

### Encoding & Hydration

| Operation | Time |
|-----------|------|
| `fromDateTime()` | ~0.1-0.5ms |
| `toJSON()` | ~0.05ms |
| `getNextOccurrence()` | ~0.2-0.5ms |
| Property access | <0.001ms |

**Complexity:** O(1) for all operations (no loops, pure arithmetic)

### Memory

Per event:
- **TREX instance**: ~200 bytes (object overhead + 4 fields)
- **Serialized JSON**: ~50-100 bytes (3 required fields)

---

## Limitations

### CONTINUOUS Events

CONTINUOUS events (`periodicity: 0`) represent 24/7 availability and have special behavior:

```typescript
// ✅ RECOMMENDED: Use TREXEngineAdapter to create CONTINUOUS events
import { TREXEngineAdapter } from '@trex/core';

const adapter = new TREXEngineAdapter();
const result = await adapter.createEventFromContinuous({
  timezone: 'America/New_York',  // Optional, defaults to 'Etc/UTC'
});

if (result.ok) {
  const event = result.value;
  // coordinate: 31622400000 (fixed marker)
  // periodicity: 0 (CONTINUOUS)
  // Always included in search results regardless of query window
}

// For bulk creation:
const bulkResult = await adapter.createBulkFromContinuous({
  events: [
    { timezone: 'America/New_York' },
    { timezone: 'Europe/London' },
  ],
});
```

**Note:** CONTINUOUS events don't "repeat" in the traditional sense - they represent perpetual availability and are always matched by any search query.

### Invalid Dates (Monthly/Yearly)

Events on days that don't exist in certain months are skipped:

```typescript
// Monthly event on 31st
const event = TREX.fromDateTime(
  Temporal.ZonedDateTime.from({
    year: 2025, month: 1, day: 31, hour: 0, minute: 0,
    timeZone: 'UTC'
  }),
  Periodicity.MONTHLY
).unwrap();

// Feb 31 doesn't exist → skips to March 31
// April 31 doesn't exist → skips to May 31
```

---

## TypeScript Support

Fully typed with strict mode:

```typescript
import { TREX, Periodicity, TREXJSON, type TREXResult } from '@trex/core';
import { Temporal } from 'temporal-polyfill';

const result: TREXResult<TREX> = TREX.fromDateTime(dt, Periodicity.DAILY);
const json: TREXJSON = result.unwrap().toJSON();
```

---

## Testing

Run the test suite:

```bash
pnpm test           # Run all tests
pnpm test:watch     # Watch mode
pnpm test:coverage  # Coverage report
```

**Test coverage:**
- ✅ All 5 periodicities
- ✅ All factory methods
- ✅ DST transitions (US, Europe, no-DST zones)
- ✅ Edge cases (midnight, leap years, Feb 29)
- ✅ Round-trip serialization
- ✅ Error handling

---

## Building

```bash
pnpm build          # Compile to dist/ (ESM + CJS + .d.ts)
pnpm type-check     # Type-check only
pnpm docs           # Generate TypeDoc documentation
```

---

## Contributing

Contributions welcome!

```bash
git clone https://github.com/jenova-marie/trex.git
cd trex-ts/packages/core
pnpm install
pnpm test
pnpm build
```

**Requirements:**
- All code must pass `pnpm type-check`
- All tests must pass (`pnpm test`)
- Follow existing code style

---

## License

Copyright Jenova Marie ❤️

---

## References

- **Python Implementation:** [trex_py](https://github.com/jenova-marie/trex_py) (reference implementation)
- **Temporal API:** [TC39 Proposal](https://tc39.es/proposal-temporal/) (stage 3)
- **IANA Timezone Data:** [IANA Time Zone Database](https://www.iana.org/time-zones)

---

**Encode once. Store forever. Hydrate with current rules. Zero maintenance.**
