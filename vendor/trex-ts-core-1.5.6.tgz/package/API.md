# TREX API Reference

**Encode recurring event times once. Search across timezones with O(log n) performance. Wall-clock time preserved across DST.**

---

## What is TREX?

TREX stores recurring event times as `coordinate` (milliseconds within Jan 1-7 1970) + `timezone`, preserving wall-clock time across DST transitions. A "6pm event" stays 6pm whether in EST or EDT.

**Key insight:** Use January 1970 as a stable reference frame to encode wall-clock intent, then hydrate with current DST rules for any target week.

---

## Core Concepts

### Periodicities

| Type | Value | Reference Frame | Range | Example |
|------|-------|-----------------|-------|---------|
| DAILY | 1 | Jan 1, 1970 | 0-86,399,999 ms | 9am standup |
| WEEKLY | 2 | Jan 1-7, 1970 | 0-604,799,999 ms | Thursday 6pm |
| MONTHLY | 3 | Jan 1-31, 1970 | 0-2,678,399,999 ms | 15th at 2pm |
| YEARLY | 4 | Jan 1-Dec 31, 1972 | 0-31,622,399,999 ms | June 15th |
| CONTINUOUS | 0 | Jan 1, 1971 | Fixed value | 24/7 service |

### Storage Format

```typescript
{
  coordinate: number,      // Wall-clock time encoded in reference frame
  timezone: string,       // IANA timezone (e.g., 'America/New_York')
  periodicity: number     // 0=CONTINUOUS, 1=DAILY, 2=WEEKLY, 3=MONTHLY, 4=YEARLY
}
```

---

## Factory Methods

### TREX.fromDateTime(dt, periodicity)

Create from Luxon DateTime with explicit periodicity.

```typescript
import { TREX, Periodicity } from 'TREX';
import { DateTime } from 'luxon';

// Daily event: 9am every day
const dt = DateTime.fromObject(
  { hour: 9, minute: 0 },
  { zone: 'America/New_York' }
);
const daily = TREX.fromDateTime(dt, Periodicity.DAILY);

// Weekly event: Thursday 6pm
const weeklyDt = DateTime.fromObject(
  { weekday: 4, hour: 18, minute: 0 },
  { zone: 'America/New_York' }
);
const weekly = TREX.fromDateTime(weeklyDt, Periodicity.WEEKLY);

// Monthly event: 15th at 2pm
const monthlyDt = DateTime.fromObject(
  { day: 15, hour: 14, minute: 0 },
  { zone: 'America/New_York' }
);
const monthly = TREX.fromDateTime(monthlyDt, Periodicity.MONTHLY);

// Yearly event: June 15th at 2pm
const yearlyDt = DateTime.fromObject(
  { month: 6, day: 15, hour: 14, minute: 0 },
  { zone: 'America/New_York' }
);
const yearly = TREX.fromDateTime(yearlyDt, Periodicity.YEARLY);

// All return Result<TREX, TREXError>
if (daily.ok) {
  console.log(daily.value.toString()); // "Daily 09:00 America/New_York"
}
```

### TREX.fromJSON(json)

Restore from database storage.

```typescript
const row = await db.events.findOne({ id: 'abc' });

const event = TREX.fromJSON({
  coordinate: row.coordinate,
  timezone: row.timezone,
  periodicity: row.periodicity
});

if (event.ok) {
  const next = event.value.getNextOccurrence();
}
```

### TREX.fromContinuous()

Create a 24/7 event (always active).

```typescript
const support = TREX.fromContinuous();
if (support.ok) {
  console.log(support.value.periodicity); // Periodicity.CONTINUOUS (0)
}
```

### TREX.fromRRULE(rruleString, dtstart)

Create from RFC 5545 RRULE string.

```typescript
const weekly = await TREX.fromRRULE('FREQ=WEEKLY;BYDAY=TH', dtstart);
const monthly = await TREX.fromRRULE('FREQ=MONTHLY;BYMONTHDAY=15', dtstart);
```

---

## Instance Methods

### getNextOccurrence(from?)

Get the next future occurrence with current DST rules.

```typescript
const event = TREX.fromDateTime(dt, Periodicity.WEEKLY).unwrap();

// Next occurrence from now
const next = event.getNextOccurrence();
if (next.ok) {
  console.log(next.value.toISO());
  // "2025-10-30T18:00:00-04:00" (EDT)
  // or "2026-01-29T18:00:00-05:00" (EST)
  // Always 6pm wall-clock time!
}

// Next occurrence from specific date
const futureRef = DateTime.fromObject({ year: 2026, month: 1, day: 15 });
const futureNext = event.getNextOccurrence(futureRef);
```

### toJSON()

Serialize for database storage.

```typescript
const event = TREX.fromDateTime(dt, Periodicity.WEEKLY).unwrap();
const json = event.toJSON();

// { coordinate: 82800000, timezone: 'America/New_York', periodicity: 2, hour: 18, minute: 0, dow: 4 }

await db.events.insert({
  coordinate: json.coordinate,
  timezone: json.timezone,
  periodicity: json.periodicity,
  wall_hour: json.hour,
  wall_minute: json.minute,
  wall_dow: json.dow
});
```

### toDateTime(from?)

Get raw 1970 reference DateTime (for internal use) or hydrate to specific week.

```typescript
const event = TREX.fromDateTime(dt, Periodicity.WEEKLY).unwrap();

// Raw 1970 reference
const raw = event.toDateTime();

// Hydrate to specific week
const marchWeek = DateTime.fromObject({ year: 2025, month: 3, day: 15 });
const hydrated = event.toDateTime(marchWeek);
```

### toString()

Human-readable format.

```typescript
const event = TREX.fromDateTime(dt, Periodicity.WEEKLY).unwrap();
console.log(event.toString());
// "Thursday 18:00 America/New_York"

// Monthly:
// "15th 14:00 America/New_York"

// Yearly:
// "June 15th 14:00 America/New_York"
```

### toRRULE()

Export as RFC 5545 RRULE string.

```typescript
const event = TREX.fromDateTime(dt, Periodicity.WEEKLY).unwrap();
console.log(event.toRRULE());
// "FREQ=WEEKLY;BYDAY=TH"

// For complete iCalendar:
const next = event.getNextOccurrence();
if (next.ok) {
  console.log(`DTSTART;TZID=America/New_York:${next.value.toFormat("yyyyMMdd'T'HHmmss")}`);
  console.log(`RRULE:${event.toRRULE()}`);
}
```

### toUTC(from?)

Get next occurrence in UTC timezone.

```typescript
const event = TREX.fromDateTime(dt, Periodicity.WEEKLY).unwrap();

// Summer (EDT: UTC-4)
const summer = DateTime.fromObject({ year: 2025, month: 7, day: 15 });
const summerUTC = event.toUTC(summer);
// "2025-07-31T22:00:00.000Z" (6pm EDT = 10pm UTC)

// Winter (EST: UTC-5)
const winter = DateTime.fromObject({ year: 2026, month: 1, day: 15 });
const winterUTC = event.toUTC(winter);
// "2026-01-29T23:00:00.000Z" (6pm EST = 11pm UTC)
```

### isLive(duration, from?)

Check if event is currently happening.

```typescript
const event = TREX.fromDateTime(dt, Periodicity.WEEKLY).unwrap();

// Is 1-hour event happening now?
const live = event.isLive(HOUR_MS); // 1 hour in ms
if (live.ok && live.value) {
  console.log('Event in progress!');
}

// Check at specific time
const checkTime = DateTime.fromISO('2025-10-30T18:30:00-04:00');
const isDuring = event.isLive(HOUR_MS, checkTime);
if (isDuring.ok && isDuring.value) {
  console.log('Event was happening at that time');
}
```

### addMillis(duration)

Add milliseconds and return new TREX with adjusted time.

```typescript
const event = TREX.fromDateTime(dt, Periodicity.WEEKLY).unwrap();

// Add 1 hour
const adjusted = event.addMillis(HOUR_MS);
if (adjusted.ok) {
  console.log(adjusted.value.hour); // 19 (6pm + 1 hour)
}
```

### equals(other)

Check equality.

```typescript
const event1 = TREX.fromDateTime(dt1, Periodicity.WEEKLY).unwrap();
const event2 = TREX.fromDateTime(dt2, Periodicity.WEEKLY).unwrap();

if (event1.equals(event2)) {
  console.log('Same event');
}

// Safe with null/undefined
event1.equals(null); // false (doesn't throw)
```

---

## Instance Properties

### coordinate
Milliseconds within reference frame (0-604,799,999 for WEEKLY).

### timezone
IANA timezone identifier (e.g., 'America/New_York').

### periodicity
Periodicity type (0-4).

### hour
Wall-clock hour (0-23).

### minute
Wall-clock minute (0-59).

### dow (WEEKLY only)
ISO weekday (1-7, where 1=Monday, 7=Sunday).

### dayName (WEEKLY only)
Day name ("Monday", "Tuesday", trex.).

### dom (MONTHLY/YEARLY only)
Day of month (1-31).

### month (YEARLY only)
Month number (1-12).

---

## Constants

```typescript
import {
  Periodicity,      // { CONTINUOUS: 0, DAILY: 1, WEEKLY: 2, MONTHLY: 3, YEARLY: 4 }
  DAY_MS,           // 86,400,000
  WEEK_MS,          // 604,800,000
  MONTH_MS,         // 2,678,400,000
  YEAR_MS,          // 31,622,400,000
  COORDINATE_MAX,     // 31,536,000,000
  ISO_DOW,          // { MONDAY: 1, TUESDAY: 2, ..., SUNDAY: 7 }
  DAY_NAMES,        // ["Monday", "Tuesday", ...]
  PeriodicityKeys,  // { CONTINUOUS: 'CONTINUOUS', DAILY: 'DAILY', ... }
  ALL_PERIODICITIES // ["CONTINUOUS", "DAILY", "WEEKLY", "MONTHLY", "YEARLY"]
} from 'TREX';
```

---

## Types

### TREXJSON
Serialization format for storage (returned by `toJSON()`).
- `coordinate`: number
- `timezone`: string
- `periodicity?`: number (defaults to WEEKLY)
- `hour?`: number (denormalized, optional)
- `minute?`: number (denormalized, optional)
- `dow?`: number (denormalized, WEEKLY only)
- `day?`: number (denormalized, MONTHLY/YEARLY only)
- `month?`: number (denormalized, YEARLY only)

### NormalizedData
Minimal data for creating TREX (used internally).
- `coordinate`: number
- `timezone`: string
- `periodicity`: number

### SearchRange
Single contiguous range for search.
```typescript
{ start: number, end: number }  // [start, end) - start inclusive, end exclusive
```

### RangeCriteria
Search ranges for a periodicity.
```typescript
{
  periodicity: number,     // Periodicity.DAILY, trex.
  ranges: SearchRange[],   // Can be multiple if wrapping period boundary
  wrapped: boolean         // Whether range wraps boundary
}
```

### SearchRanges
Complete search criteria for all periodicities.
```typescript
{
  continuous?: RangeCriteria,
  daily?: RangeCriteria,
  weekly?: RangeCriteria,
  monthly?: RangeCriteria,
  yearly?: RangeCriteria
}
```

---

## Search Utilities

### buildSearchRanges(start, end, periodicities?)

Build search ranges for a time window.

```typescript
import { buildSearchRanges } from 'TREX';
import { DateTime } from 'luxon';

const start = DateTime.fromObject(
  { year: 2025, month: 1, day: 15, hour: 14, minute: 0 },
  { zone: 'America/New_York' }
);
const end = start.plus({ hours: 4 });

// Search all periodicities
const ranges = buildSearchRanges(start, end);
if (ranges.ok) {
  console.log(ranges.value.daily);
  console.log(ranges.value.weekly);
  console.log(ranges.value.monthly);
  console.log(ranges.value.yearly);
}

// Search specific periodicities
const weeklyOnly = buildSearchRanges(start, end, [Periodicity.WEEKLY]);
```

### buildRangesForEventTimezone(coordinate, timezone, start, end, periodicity)

Build ranges for an event in a different timezone.

```typescript
import { buildRangesForEventTimezone } from 'TREX';

// Event stored in New York, search from London perspective
const ranges = buildRangesForEventTimezone(
  82800000,                    // coordinate
  'America/New_York',          // event timezone
  DateTime.fromObject({...}, { zone: 'Europe/London' }),  // search start
  DateTime.fromObject({...}, { zone: 'Europe/London' }),  // search end
  Periodicity.WEEKLY
);
```

### inRange(value, ranges)

Check if value falls within any range.

```typescript
import { inRange } from 'TREX';

const ranges = [
  { start: 64800000, end: 68400000 },  // Range 1
  { start: 0, end: HOUR_MS }           // Range 2 (wrapped)
];

if (inRange(82800000, ranges)) {
  console.log('Event matches search criteria');
}
```

---

## Database Integration

### PostgreSQL Schema

```sql
CREATE TABLE events (
  id UUID PRIMARY KEY,

  -- Core trex fields (source of truth)
  coordinate BIGINT NOT NULL,
  timezone VARCHAR(50) NOT NULL,
  periodicity SMALLINT NOT NULL,

  -- Denormalized for queries
  wall_hour SMALLINT,
  wall_minute SMALLINT,
  wall_dow SMALLINT,    -- WEEKLY
  wall_dom SMALLINT,    -- MONTHLY, YEARLY
  wall_month SMALLINT,  -- YEARLY

  created TIMESTAMPTZ DEFAULT NOW()
);

-- O(log n) indexed search
CREATE INDEX idx_events_search ON events(periodicity, coordinate, timezone);
```

### Insert Pattern

```typescript
const event = TREX.fromDateTime(dt, Periodicity.WEEKLY).unwrap();
const json = event.toJSON();

await db.query(`
  INSERT INTO events (coordinate, timezone, periodicity, wall_hour, wall_minute, wall_dow)
  VALUES ($1, $2, $3, $4, $5, $6)
`, [json.coordinate, json.timezone, json.periodicity, json.hour, json.minute, json.dow]);
```

### Query Pattern (O(log n))

```typescript
const rows = await db.query(`
  SELECT coordinate, timezone, periodicity
  FROM events
  WHERE periodicity = $1
    AND coordinate BETWEEN $2 AND $3
    AND timezone = $4
`, [Periodicity.WEEKLY, startMillis, endMillis, 'America/New_York']);

const events = rows.map(row =>
  TREX.fromJSON({
    coordinate: row.coordinate,
    timezone: row.timezone,
    periodicity: row.periodicity
  }).unwrap()
);
```

---

## Complete Example: Global Team Meeting

```typescript
import { TREX, Periodicity } from 'TREX';
import { DateTime } from 'luxon';

// Create: Friday 3pm Pacific (US team)
const dt = DateTime.fromObject(
  { weekday: 5, hour: 15, minute: 0 },
  { zone: 'America/Los_Angeles' }
);
const meeting = TREX.fromDateTime(dt, Periodicity.WEEKLY).unwrap();

// Store
const json = meeting.toJSON();
await db.events.insert({
  name: 'Global Sync',
  coordinate: json.coordinate,
  timezone: json.timezone,
  periodicity: json.periodicity
});

// Get next occurrence
const next = meeting.getNextOccurrence().unwrap();

// View in different timezones
console.log(next.toFormat('cccc h:mm a z'));
// "Friday 3:00 PM PST"

const tokyo = next.setZone('Asia/Tokyo');
console.log(tokyo.toFormat('cccc h:mm a z'));
// "Saturday 8:00 AM JST"

const london = next.setZone('Europe/London');
console.log(london.toFormat('cccc h:mm a z'));
// "Friday 11:00 PM GMT"

// Update Node.js (gets new IANA tzdata) → automatically uses new DST rules
// No database migration needed!
```

---

## Browser API

The browser module (`@trex-ts/core/browser`) provides pure TypeScript implementations that work in browsers without Node.js or Python.

### TREXBrowser Class

Browser-compatible TREX class with synchronous factory methods.

#### TREXBrowser.fromWallClock(components, periodicity, duration_ms?)

Create from wall-clock time components. **Synchronous** (no async needed).

```typescript
import { TREXBrowser, Periodicity } from '@trex-ts/core/browser';

// Weekly event: Thursday 6pm
const result = TREXBrowser.fromWallClock(
  { hour: 18, minute: 0, timezone: 'America/New_York', dow: 4 },
  Periodicity.WEEKLY
);

// Daily event: 9am
const daily = TREXBrowser.fromWallClock(
  { hour: 9, minute: 0, timezone: 'America/New_York' },
  Periodicity.DAILY
);

// Monthly event: 15th at 2pm
const monthly = TREXBrowser.fromWallClock(
  { hour: 14, minute: 0, timezone: 'America/New_York', dom: 15 },
  Periodicity.MONTHLY
);

// Yearly event: June 15th at 2pm
const yearly = TREXBrowser.fromWallClock(
  { hour: 14, minute: 0, timezone: 'America/New_York', dom: 15, month: 6 },
  Periodicity.YEARLY
);
```

**WallClockComponents:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `hour` | number | Yes | 0-23 |
| `minute` | number | Yes | 0-59 |
| `timezone` | string | Yes | IANA timezone |
| `dow` | number | WEEKLY | Day of week (1-7, Mon=1) |
| `dom` | number | MONTHLY/YEARLY | Day of month (1-31) |
| `month` | number | YEARLY | Month (1-12) |

#### TREXBrowser.fromDateTime(dt, periodicity, duration_ms?)

Create from Luxon DateTime.

```typescript
import { TREXBrowser, Periodicity, DateTime } from '@trex-ts/core/browser';

const dt = DateTime.fromObject(
  { hour: 9, minute: 0 },
  { zone: 'America/New_York' }
);
const result = TREXBrowser.fromDateTime(dt, Periodicity.DAILY);
```

#### TREXBrowser.fromDate(date, timezone, periodicity, duration_ms?)

Create from JavaScript Date object.

```typescript
const date = new Date('2025-01-16T09:00:00-05:00');
const result = TREXBrowser.fromDate(date, 'America/New_York', Periodicity.DAILY);
```

#### TREXBrowser.fromJSON(data)

Restore from serialized data.

```typescript
const result = TREXBrowser.fromJSON({
  coordinate: 32400000,
  timezone: 'America/New_York',
  periodicity: 1
});
```

#### TREXBrowser.fromMillis(coordinate, timezone, periodicity, duration_ms?)

Create from raw coordinate value.

```typescript
const result = TREXBrowser.fromMillis(
  32400000,
  'America/New_York',
  Periodicity.DAILY
);
```

### TREXBrowser Instance Methods

#### getNextOccurrence(from?)

Get the next occurrence as Luxon DateTime.

```typescript
const event = TREXBrowser.fromWallClock(
  { hour: 18, minute: 0, timezone: 'America/New_York', dow: 4 },
  Periodicity.WEEKLY
).value;

const next = event.getNextOccurrence();
if (next.ok) {
  console.log(next.value.toISO()); // "2025-01-16T18:00:00.000-05:00"
}

// From specific reference time
const ref = DateTime.fromISO('2025-06-01T00:00:00', { zone: 'America/New_York' });
const summer = event.getNextOccurrence(ref);
// Uses EDT offset automatically
```

#### toJSON()

Serialize for storage.

```typescript
const json = event.toJSON();
// {
//   coordinate: 280800000,
//   timezone: 'America/New_York',
//   periodicity: 2,
//   coordinate_end: 280800000,
//   duration_ms: 0,
//   hour: 18,
//   minute: 0,
//   dow: 4,
//   rrule_str: 'RRULE:FREQ=WEEKLY;BYDAY=TH',
//   rrule_json: { freq: 'WEEKLY', byday: ['TH'] },
//   dtstart: '1970-01-01T18:00:00.000-05:00'
// }
```

#### toString()

Human-readable representation.

```typescript
console.log(event.toString());
// "TREX(18:00 WEEKLY Thursday America/New_York)"
```

#### equals(other)

Check equality.

```typescript
if (event1.equals(event2)) {
  console.log('Same event');
}
```

### BrowserMemoryAdapter

In-memory event storage with RRULE-based search.

```typescript
import { BrowserMemoryAdapter } from '@trex-ts/core/browser';

const adapter = new BrowserMemoryAdapter();

// Insert events
const event = TREXBrowser.fromWallClock(
  { hour: 18, minute: 0, timezone: 'America/New_York', dow: 4 },
  Periodicity.WEEKLY
).value;

await adapter.insert([{ id: 'meeting-1', ...event.toJSON() }]);

// Search by time window
const results = await adapter.search(
  '2025-01-16T00:00:00-05:00',
  '2025-01-16T23:59:59-05:00'
);
console.log(results.matches); // Events in that window

// Search for "live" events at a moment
const live = await adapter.searchLive('2025-01-16T18:30:00-05:00');

// Other operations
const count = await adapter.count();
const all = await adapter.getAll();
const has = await adapter.has('meeting-1');
const single = await adapter.get('meeting-1');
await adapter.delete(['meeting-1']);
await adapter.clear();
```

### Normalization Functions

Pure TypeScript functions for encoding wall-clock time to coordinates.

#### normalize(components, periodicity, duration_ms?)

Encode wall-clock components to TREX coordinate.

```typescript
import { normalize, Periodicity } from '@trex-ts/core/browser';

const result = normalize(
  { hour: 18, minute: 0, timezone: 'America/New_York', dow: 4 },
  Periodicity.WEEKLY
);

if (result.ok) {
  console.log(result.value.coordinate); // 280800000
  console.log(result.value.timezone);   // 'America/New_York'
}
```

#### calculateDayOfYear(month, dom, isLeapYear)

Calculate day-of-year (1-366) for YEARLY periodicity.

```typescript
import { calculateDayOfYear } from '@trex-ts/core/browser';

const doy = calculateDayOfYear(6, 15, false); // June 15th, non-leap year
// 166
```

#### calculateCoordinateEnd(coordinate, duration_ms, periodicity)

Calculate end coordinate with period wrapping.

```typescript
import { calculateCoordinateEnd, Periodicity, HOUR_MS } from '@trex-ts/core/browser';

const end = calculateCoordinateEnd(280800000, HOUR_MS, Periodicity.WEEKLY);
// 284400000 (1 hour later, handles wraparound)
```

### RRULE Generation

Generate RFC 5545 RRULE strings from TREX events.

#### generateRRule(components, periodicity)

```typescript
import { generateRRule, Periodicity } from '@trex-ts/core/browser';

const rrule = generateRRule(
  { hour: 18, minute: 0, timezone: 'America/New_York', dow: 4 },
  Periodicity.WEEKLY
);

console.log(rrule.rrule_str);  // "RRULE:FREQ=WEEKLY;BYDAY=TH"
console.log(rrule.dtstart);    // "1970-01-01T18:00:00.000-05:00"
console.log(rrule.rrule_json); // { freq: 'WEEKLY', byday: ['TH'] }
```

#### decodeCoordinate(coordinate, periodicity)

Decode coordinate back to wall-clock components.

```typescript
import { decodeCoordinate, Periodicity } from '@trex-ts/core/browser';

const components = decodeCoordinate(280800000, Periodicity.WEEKLY);
// { hour: 18, minute: 0, dow: 4 }
```

#### parseRRuleToJson(rruleStr)

Parse RRULE string to JSON object.

```typescript
import { parseRRuleToJson } from '@trex-ts/core/browser';

const json = parseRRuleToJson('FREQ=WEEKLY;BYDAY=TH');
// { freq: 'WEEKLY', byday: ['TH'] }
```

### Search Ranges

Build coordinate ranges for time window searches.

#### buildSearchRanges(start, end, timezone?)

```typescript
import { buildSearchRanges, DateTime } from '@trex-ts/core/browser';

const start = DateTime.fromISO('2025-01-16T14:00:00', { zone: 'America/New_York' });
const end = DateTime.fromISO('2025-01-16T20:00:00', { zone: 'America/New_York' });

const ranges = buildSearchRanges(start, end);
// {
//   daily: { periodicity: 1, ranges: [...], wrapped: false },
//   weekly: { periodicity: 2, ranges: [...], wrapped: false },
//   monthly: { periodicity: 3, ranges: [...], wrapped: false },
//   yearly: { periodicity: 4, ranges: [...], wrapped: false }
// }
```

#### createSearchRanges(startMs, endMs, periodicity)

Create ranges for a single periodicity.

```typescript
import { createSearchRanges, Periodicity, HOUR_MS } from '@trex-ts/core/browser';

const ranges = createSearchRanges(
  14 * HOUR_MS,  // 2pm
  20 * HOUR_MS,  // 8pm
  Periodicity.DAILY
);
```

#### inRange(coordinate, ranges)

Check if coordinate falls within any range.

```typescript
import { inRange } from '@trex-ts/core/browser';

const matches = inRange(280800000, ranges.weekly.ranges);
```

#### isLiveInterval(coordinate, coordinateEnd, now, nowEnd, periodMax)

Check if event is currently "live" (happening now).

```typescript
import { isLiveInterval, WEEK_MS, HOUR_MS } from '@trex-ts/core/browser';

const isLive = isLiveInterval(
  280800000,           // event start
  280800000 + HOUR_MS, // event end (1 hour duration)
  currentMs,           // current time as coordinate
  currentMs,           // current end (instant check)
  WEEK_MS              // period max for WEEKLY
);
```

### Hydration Functions

Decode coordinates back to DateTime objects.

#### hydrate(trex, next?, referenceTime?, skipMode?)

Main hydration function with flexible current/next period control.

```typescript
import { hydrate, Periodicity } from '@trex-ts/core/browser';

const trex = {
  coordinate: 280800000,  // Thursday 6pm
  timezone: 'America/New_York',
  periodicity: Periodicity.WEEKLY
};

// Get current period occurrence (may be in past)
// If today is Friday, returns yesterday (Thursday)
const current = hydrate(trex);  // next=false is default

// Get next future occurrence
// If today is Friday, returns next Thursday
const next = hydrate(trex, true);
```

**Parameters:**
| Param | Type | Default | Description |
|-------|------|---------|-------------|
| `trex` | TREXJSON | required | TREX event data |
| `next` | boolean | `false` | If true, advance to next period if in past |
| `referenceTime` | DateTime \| Date | now | Reference point for hydration |
| `skipMode` | SkipMode | OMIT | How to handle ghost days (Feb 30, etc.) |

#### hydrateNext(trex, referenceTime?, skipMode?)

Convenience wrapper for `hydrate(trex, true, ...)`. Always returns next future occurrence.

```typescript
import { hydrateNext, Periodicity } from '@trex-ts/core/browser';

const trex = {
  coordinate: 280800000,
  timezone: 'America/New_York',
  periodicity: Periodicity.WEEKLY
};

const result = hydrateNext(trex);
if (result.ok) {
  console.log(result.value.toISO()); // Next Thursday 6pm
}
```

#### hydrateCurrent(trex, referenceTime?, skipMode?)

Convenience wrapper for `hydrate(trex, false, ...)`. Returns current period occurrence (may be in past).

```typescript
import { hydrateCurrent, Periodicity } from '@trex-ts/core/browser';

// If today is Tuesday and event is Monday 9am
const trex = {
  coordinate: 32400000,  // Monday 9am
  timezone: 'America/New_York',
  periodicity: Periodicity.WEEKLY
};

const result = hydrateCurrent(trex);
// Returns yesterday (Monday) at 9am, not next Monday
```

#### extractWallClockTime(coordinate)

Extract hour and minute from coordinate.

```typescript
import { extractWallClockTime } from '@trex-ts/core/browser';

const { hour, minute } = extractWallClockTime(280800000);
// { hour: 18, minute: 0 }
```

#### extractPosition(coordinate, periodicity)

Extract period position from coordinate.

```typescript
import { extractPosition, Periodicity } from '@trex-ts/core/browser';

const position = extractPosition(280800000, Periodicity.WEEKLY);
// 4 (Thursday)
```

---

## Error Handling

All methods return `Result<T, E>` types. Always check `.ok` before accessing `.value`:

```typescript
const result = TREX.fromDateTime(dt, Periodicity.DAILY);

if (result.ok) {
  const event = result.value;
  // Use event safely
} else {
  const error = result.error;
  console.error(error.message);
}
```

---

## Key Behaviors

- **Wall-clock time preserved:** 6pm stays 6pm across EST/EDT transitions
- **Always rehydrate in stored timezone:** Don't rehydrate in different timezone (you'll get wrong wall-clock components)
- **O(log n) search:** Single indexed integer range query on coordinate
- **DST-proof:** Uses current IANA rules on hydration, survives DST rule changes
- **Immutable:** All instances are immutable value objects
- **Type-safe:** All operations return Result types, never throw

---

**For more details:** See README.md for complete examples, the T-REX specification (`content/T-REX.md`) for algorithm details, or the [generated TypeDoc documentation](./docs/index.html).
