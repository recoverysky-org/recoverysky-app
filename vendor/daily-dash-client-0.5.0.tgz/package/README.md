# @daily-dash/client

The Daily Dash client platform: what every feature needs and no feature may own twice. The Daily Dash
session over an injected Auth0 token source (the exchange, refresh, the owner record, the vault, the
account hash); the per-account database with its platform openers, migration runner, core tables, outbox
store and sync worker (ADR 0034); the transport and the SDK wired to the session (ADR 0018, 0019); the
hooks infrastructure, where a hook unwraps a Result and throws (ADR 0039 rule 8); and `AppError`, the
logger call shape over an injected sink and the clock. One instance per host: `apps/app` mounts it today,
RecoverySky next. It owns no screen, no theme, no router and no Expo configuration (the app packages
design, `docs/superpowers/specs/2026-10-06-app-packages-design.md` §3.1). Its architecture, the rules
behind the data layer, the hooks, the transport, the sync worker and the session, is
`packages/client/docs/architecture.md`.

## Hosting

A host mounts `ClientProvider` with only what hosts genuinely differ in (design §4.1, with the plan's
amendments A1 to A5). The package reads no environment: everything it needs is a prop.

| Prop           | What it is                                                                                                                                                                                          |
| -------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `client`       | Who is calling, `{ app, version, channel }`: the `X-Client` header's parts (ADR 0019). `app` is `"daily-dash"` or `"recoverysky"`; the channel is yours.                                            |
| `apiBaseUrl`   | Where The Daily Dash API is.                                                                                                                                                                        |
| `auth`         | `{ products, loadSignIn }`: the products the host signs in with, and the host's Auth0 adapter for one, loaded when the session first needs it.                                                      |
| `logger`       | The host's logger (`createLogger` over its sinks); the package logs through children of it.                                                                                                         |
| `schemas`      | Extra schema modules the account's database is migrated with; the core module is applied first wherever it sits in the list (design §7.2). Optional.                                                |
| `features`     | The feature modules (`FeatureModule`, such as `myDayFeature`) whose tables and outbox appliers the account's database is built with; each one's schema is migrated after the core module. Optional. |
| `storage`      | The vault for the session's records; defaults to the platform's (SecureStore, the web vault). Optional.                                                                                             |
| `connectivity` | `{ reach, onReconnect }`: hears how each request ended, and kicks the outbox when the network is back (spec §6.2). Optional.                                                                        |
| `onRefused`    | Hears every 410 and 426 the transports meet; a 426 is the host's to draw. Optional.                                                                                                                 |
| `track`        | The host's analytics, for the session's events. Optional.                                                                                                                                           |
| `session`      | A session the host built with `createClientSession` (amendment A5), or a test's fake; read once, on mount. A host's own session is the host's to route a 410 to (`sessionRefusal`). Optional.       |
| `buildFor`     | A test seam: the data layer's build for an account hash; defaults to `buildData`. Optional.                                                                                                         |
| `fetchImpl`    | The `fetch` both transports use; defaults to the global one. Optional.                                                                                                                              |
| `children`     | The host's tree. Always rendered.                                                                                                                                                                   |

`ClientProvider` renders its children always and only reports: `useSession()` says where the session is,
`useDb()` says where the database is (`{ state: { phase: "idle" | "opening" | "ready" | "failed" }, reset }`,
a failure carrying `code`, `message` and `unsupportedBrowser`). The blocking screens (restoring, sign-in,
wrong account, deleted, a failed or unsupported database) are the host's to draw over those two; a hook
that reads the repositories works only once `useDb().state.phase` is `ready`. A feature's hooks read the
account's SDK with `useSdk()` and unwrap what it answers (amendment A10); a screen never calls it.

RecoverySky, mounting My Day:

```tsx
<ClientProvider client={{ app: "recoverysky", version, channel }} apiBaseUrl={DD_API} auth={{ products: ["recoverysky"], loadSignIn }} logger={log} features={[myDayFeature]}>
```

A component test renders over the same providers with `renderWithClient` from `@daily-dash/client/test`
(an ios and a web twin, one `ScreenQueries` surface), wrapping its own theme around it.

## Host prerequisites

- `expo-sqlite`'s web driver runs SQLite in a worker over OPFS, which needs the page cross-origin
  isolated (`Cross-Origin-Embedder-Policy: credentialless`, `Cross-Origin-Opener-Policy: same-origin`,
  as `apps/app/app.config.ts` sets them) and Metro shipping the `wasm` asset extension (as
  `apps/app/metro.config.js` adds it).

Nothing else.

## What a host never logs

A failed open's Result carries the raw SQLite cause in `error.cause`; only the chain the platform logs
is redacted. Log a client error by its fields (`code`, `details.kind`) and never print `cause` itself
(plan A ruling R19; the architecture, "Data").
