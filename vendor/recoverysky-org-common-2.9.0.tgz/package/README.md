# @recoverysky-org/common

Shared TypeScript library for RecoverySky recovery meeting management system.

## Features

- **Data Models**: Type-safe models for meetings, schedules, system prompts, and TREX time expressions (AA, NA recovery meetings)
- **Foreign Key Constraints**: `meetings.sid → schedules.id` (required, CASCADE delete)
- **Runtime Validation**: Comprehensive Zod validation with 40+ rules for meetings, schedules, system prompts, and TREX
- **Deterministic Hashing**: SHA256 change detection with sorted keys for consistent hashing
- **Schema Generation Pipeline**: TypeScript → JSON Schema → RxDB → Drizzle ORM
- **Browser Exports**: Browser-compatible entry point via `@recoverysky-org/common/browser`
- **SQLite Exports**: Mobile-first entry point via `@recoverysky-org/common/sqlite` for React Native/Expo
- **RxDB Integration**: Offline-first database schemas for client-side sync
- **Drizzle ORM**: PostgreSQL and SQLite schemas for server/mobile persistence
- **Repositories**: Database access layer for PostgreSQL (MeetingRepository, ScheduleRepository, SystemPromptRepository, TrexRepository) and SQLite (MeetingSqliteRepository, ScheduleSqliteRepository, SyncQueueRepository)
- **Offline Sync Queue**: Built-in sync queue management for offline-first mobile apps
- **Database Seeding**: Infrastructure for populating initial data (system prompts, etc.)
- **Decorators**: Custom decorators for model integration and function injection

## Installation

```bash
npm install @recoverysky-org/common
# or
pnpm add @recoverysky-org/common
```

## Documentation

**[API Documentation](./docs/index.html)** - Complete TypeDoc-generated API documentation

To generate documentation locally:
```bash
pnpm docs              # Generate docs to ./docs
pnpm docs:watch        # Generate docs and watch for changes
pnpm docs:serve        # Generate and serve docs on http://localhost:8080
```

## Usage

### Basic Models

```typescript
import { Meeting, Schedule } from '@recoverysky-org/common';

// Create a new meeting (sid is required - every meeting must belong to a schedule)
const result = Meeting.create({
  sid: 'schedule-123',  // Required FK to schedules.id
  name: 'Monday Night Big Book',
  fellowship: 'AA',
  zid: '123456789'
});
if (result.ok) {
  const meeting = result.value;

  // update() validates meeting + trex, generates deterministic SHA256 hash
  const updateResult = await meeting.update();
  if (updateResult.ok) {
    console.log('Meeting validated and updated:', meeting.sha256);
  } else {
    console.error('Validation failed:', updateResult.error.message);
  }
}

// Create a meeting with TREX time expression
const meetingWithTrex = Meeting.create(
  { sid: 'schedule-123', name: 'Weekly Step Study', fellowship: 'AA', zid: '987654321' },
  {
    id: 'trex-123',
    coordinate: 259200000,  // Thursday 00:00 UTC
    timezone: 'America/New_York',
    periodicity: 2,  // WEEKLY (CONTINUOUS=0, DAILY=1, WEEKLY=2, MONTHLY=3, YEARLY=4)
    duration_ms: 3600000
  }
);
if (meetingWithTrex.ok) {
  const meeting = meetingWithTrex.value;
  console.log('Meeting with TREX:', meeting.trex?.timezone);

  // SHA256 hash includes both meeting and trex data
  await meeting.update();
  console.log('Hash:', meeting.sha256);
}

// Create a schedule with timezone for display
// Note: zids array is required (at least one Zoom ID) unless status is ORPHANED
const scheduleResult = Schedule.create(
  { zids: ['123456789'], name: 'Weekly Meetings' },  // zids required
  undefined,  // meetingsData
  undefined,  // trexesData
  'America/New_York'  // timezone (defaults to system timezone)
);
if (scheduleResult.ok) {
  const schedule = scheduleResult.value;
  console.log('Schedule created:', schedule.name);
}

// Get next occurrence of a meeting (requires Python TREX executor)
const nextResult = await meeting.getNextOccurrence();
if (nextResult.ok) {
  console.log('Next meeting:', new Date(nextResult.value));
}
```

### Schedule Data Grid

Get a weekly schedule grid with formatted times for each meeting:

```typescript
import { Schedule, Meeting } from '@recoverysky-org/common';

// Create a fully hydrated schedule from database rows
const schedule = new Schedule(
  scheduleRow,      // schedule data
  meetingRows,      // array of meetings
  trexRows,         // array of TREX data (matched by id)
  'America/New_York' // display timezone
);

// Check if schedule has meetings every day
if (schedule.daily) {
  console.log('This schedule covers all 7 days!');
}

// Get schedule data as array of arrays
// Each inner array: [Mon, Tue, Wed, Thu, Fri, Sat, Sun]
// Values are formatted times (e.g., "9:00 AM") or null
const result = await schedule.getScheduleData();
if (result.ok) {
  for (const meetingRow of result.value) {
    console.log(meetingRow);
    // e.g., [null, null, null, "7:00 PM", null, null, null] for Thursday meeting
  }
}

// Change timezone (auto-clears cache)
schedule.setTimezone('Europe/London');
const ukTimes = await schedule.getScheduleData();

// Results are cached - subsequent calls return cached data instantly
// Use clearScheduleDataCache() to force recalculation
schedule.clearScheduleDataCache();
```

### Runtime Validation

```typescript
import {
  validateMeeting,
  validateMeetings,
  validateSchedule,
  validateTrex,
  validateTrexes,
  meetingZodSchema,
  scheduleZodSchema,
  systemPromptZodSchema,
  trexCreateSchema,
  timestampSchema
} from '@recoverysky-org/common';

// Single meeting validation
const meetingResult = validateMeeting(untrustedData);
if (meetingResult.ok) {
  console.log('Valid meeting:', meetingResult.value);
} else {
  console.error('Errors:', meetingResult.error.issues);
}

// Batch meeting validation
const batchResult = validateMeetings(scrapedMeetings);
if (batchResult.ok) {
  const { valid, invalid } = batchResult.value;
  console.log(`Valid: ${valid.length}, Invalid: ${invalid.length}`);
}

// Meeting validation (sid is required)
const meetingValidation = validateMeeting({
  sid: 'schedule-123',  // Required FK
  zid: '123456789',
  name: 'Test Meeting',
  fellowship: 'AA'
});

// TREX validation
const trexResult = validateTrex({
  id: 'trex-123',
  coordinate: 259200000,
  timezone: 'America/New_York',
  periodicity: 2  // WEEKLY
});
if (trexResult.ok) {
  console.log('Valid TREX:', trexResult.value);
}

// Direct Zod schema usage
const validation = meetingZodSchema.safeParse(meeting);
if (!validation.success) {
  console.error('Errors:', validation.error.format());
}

// Timestamp validation (accepts both ISO 8601 and PostgreSQL formats)
// ISO 8601:   "2025-12-04T02:18:31.342+00:00" (T separator, full offset)
// PostgreSQL: "2025-12-04 02:18:31.342+00"    (space separator, abbreviated offset)
const tsResult = timestampSchema.safeParse("2025-12-04 02:18:31.342+00");
console.log(tsResult.success); // true
```

**See**: [Validation Guide](./content/VALIDATION.md) for comprehensive validation documentation.

### Browser Exports

For browser environments, use the browser-compatible entry point that excludes Node.js dependencies:

```typescript
import {
  meeting, schedule, trex, system_prompt,  // Models
  Periodicity,                              // Local enum (CONTINUOUS, DAILY, WEEKLY, MONTHLY, YEARLY)
  validateMeeting, validateSchedule,        // Validation helpers
  trexZodSchema, meetingZodSchema,          // Zod schemas
  MeetingStatus, Fellowship,                // Enums
  ok, err,                                  // Result helpers
} from '@recoverysky-org/common/browser';

// Browser bundle excludes:
// - Meeting/Schedule classes (depend on @trex-ts/core Python executor)
// - All repositories (require PostgreSQL)
// - TREX class from @trex-ts/core
```

### SQLite Exports (React Native / Expo)

For mobile apps using SQLite (expo-sqlite, better-sqlite3), use the SQLite entry point:

```typescript
import {
  // SQLite table schemas
  meetings, schedules, trexes, syncQueue,
  meetingTypes, meetingTags, scheduleMeetings,

  // SQLite repositories with offline-first support
  MeetingSqliteRepository,
  ScheduleSqliteRepository,
  SyncQueueRepository,

  // Drizzle operators
  eq, and, or, inArray,

  // Types and enums (same as main export)
  MeetingStatus, Fellowship,

  // Validation (browser-safe)
  validateMeeting, validateSchedule,
} from '@recoverysky-org/common/sqlite';

// Initialize with expo-sqlite
import { openDatabaseSync } from 'expo-sqlite';
import { drizzle } from 'drizzle-orm/expo-sqlite';

const expoDb = openDatabaseSync('recoverysky.db');
const db = drizzle(expoDb);

// Create repositories
const meetingRepo = new MeetingSqliteRepository(db);
const scheduleRepo = new ScheduleSqliteRepository(db);
const syncQueueRepo = new SyncQueueRepository(db);

// Find meeting with types and tags (normalized in SQLite)
const result = await meetingRepo.findById('meeting-123');
if (result.ok && result.value) {
  const { meeting, types, tags } = result.value;
  console.log('Meeting:', meeting.name);
  console.log('Types:', types);   // e.g., ['Open', 'Speaker']
  console.log('Tags:', tags);     // e.g., ['Beginner Friendly']
}

// Queue offline operations for sync
await syncQueueRepo.enqueue({
  tableName: 'meetings',
  recordId: 'meeting-123',
  operation: 'update',
  payload: JSON.stringify({ name: 'Updated Name' }),
});

// Get pending sync items
const pending = await syncQueueRepo.getPending();
if (pending.ok) {
  console.log('Pending sync items:', pending.value.length);
}
```

**SQLite Key Differences from PostgreSQL:**
- Arrays (meetingTypes, tags) are normalized into junction tables
- `MeetingWithRelations` includes resolved `types[]` and `tags[]`
- `SyncQueueRepository` manages offline CRUD operations
- Uses SQLite-compatible column types (TEXT, INTEGER)

### RxDB Schemas

```typescript
import { meetingRxDBSchema } from '@recoverysky-org/common/lib/models/rxdb/meeting.rxdb';

// Use in RxDB collection
const collections = {
  meetings: {
    schema: meetingRxDBSchema
  }
};
```

### Drizzle Schemas

```typescript
// PostgreSQL schemas (default)
import { meetings } from '@recoverysky-org/common/lib/models/drizzle/pg/meetings.drizzle';

// Use with Drizzle ORM (PostgreSQL)
const allMeetings = await db.select().from(meetings);

// For SQLite, use the sqlite entry point
import { meetings as sqliteMeetings } from '@recoverysky-org/common/sqlite';
```

### Database Seeding

Populate initial data using seed files:

```bash
# Apply all seeds to production
pnpm seed:prod

# Apply all seeds to local development
pnpm seed:local

# Apply specific seed
bash src/scripts/apply-seeds.sh prod system_prompts
```

Seed files are located in `src/seeds/` and use `ON CONFLICT` for idempotency (safe to re-run).

## Development

```bash
# Install dependencies
pnpm install

# Build
pnpm build

# Generate schemas
pnpm ts:schema     # TypeScript schemas
pnpm json:schema   # JSON schemas
pnpm rxdb:schema   # RxDB schemas
pnpm drizzle:schema # Drizzle schemas

# Full build pipeline
pnpm make

# Database migrations
pnpm migrate:prod    # Migrate production database
pnpm migrate:local   # Migrate local database

# Database seeding
pnpm seed:prod       # Apply seeds to production
pnpm seed:local      # Apply seeds to local
```

### Testing

```bash
# Run all tests
pnpm test

# Run unit tests only (excludes integration tests)
pnpm test:unit

# Run integration tests (requires local database)
pnpm test:integration

# Run repository integration tests
pnpm test:repos

# Run specific test by name
pnpm vitest run -t "test name"
```

Integration tests use `.env.local` for database configuration:
```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=recoverysky
DB_USER=postgres
DB_PASSWORD=postgres
```

## Schema Generation Pipeline

The library uses a multi-step transformation pipeline:

1. **Source Models** (`src/models/*.ts`) - Plain TypeScript classes
2. **TypeScript Schemas** (`src/models/schema/*.schema.ts`) - Generated type schemas
3. **JSON Schemas** (`src/models/json/*.json`) - Standard JSON Schema format
4. **RxDB Schemas** (`src/models/rxdb/*.rxdb.ts`) - Client-side database schemas
5. **Drizzle Schemas**:
   - PostgreSQL (`src/models/drizzle/pg/*.drizzle.ts`) - Server-side tables with jsonb arrays
   - SQLite (`src/models/drizzle/sqlite/*.drizzle.ts`) - Mobile tables with normalized junction tables

Run `pnpm make` to regenerate the entire pipeline after modifying models.

**Schema generation commands:**
```bash
pnpm drizzle:schema      # Generate both pg and sqlite schemas
pnpm drizzle:schema:pg   # PostgreSQL schemas only
pnpm drizzle:schema:sqlite  # SQLite schemas only
```

## Architecture

```
src/
├── classes/          # Business logic classes
│   ├── Meeting/     # Meeting class (SHA256, TREX, getNextOccurrence)
│   └── Schedule/    # Schedule class (getScheduleData, timezone, daily)
├── models/          # Data models and generated schemas
│   ├── meeting.ts   # Base meeting model
│   ├── schedule.ts  # Base schedule model
│   ├── system_prompt.ts # System prompt model
│   ├── trex.ts      # TREX time expression model
│   ├── zod/         # Zod validation schemas
│   │   ├── meeting.zod.ts
│   │   ├── schedule.zod.ts
│   │   ├── system_prompt.zod.ts
│   │   ├── timestamp.zod.ts  # Shared timestamp validation
│   │   └── trex.zod.ts
│   ├── schema/      # Generated TS schemas
│   ├── json/        # Generated JSON schemas
│   ├── rxdb/        # Generated RxDB schemas
│   └── drizzle/     # Generated Drizzle schemas
│       ├── index.ts   # Re-exports pg/ for backwards compat
│       ├── pg/        # PostgreSQL schemas (jsonb arrays)
│       │   ├── meetings.drizzle.ts
│       │   ├── schedules.drizzle.ts
│       │   ├── trexes.drizzle.ts
│       │   └── views/  # Denormalized view definitions
│       └── sqlite/    # SQLite schemas (normalized tables)
│           ├── meetings.drizzle.ts
│           ├── meeting_types.drizzle.ts  # Junction table
│           ├── meeting_tags.drizzle.ts   # Junction table
│           ├── schedule_meetings.drizzle.ts
│           └── sync_queue.drizzle.ts     # Offline sync queue
├── repositories/    # Database access layer
│   ├── MeetingRepository.ts      # PostgreSQL
│   ├── ScheduleRepository.ts     # PostgreSQL
│   ├── SystemPromptRepository.ts # PostgreSQL
│   ├── TrexRepository.ts         # PostgreSQL
│   └── sqlite/                   # SQLite repositories
│       ├── MeetingSqliteRepository.ts
│       ├── ScheduleSqliteRepository.ts
│       └── SyncQueueRepository.ts
├── foreignkeys/     # Foreign key definitions
│   └── meetings.fk.ts  # meetings.sid → schedules.id (CASCADE)
├── indexes/         # Database index definitions
│   ├── schedules.indexes.ts  # GIN indexes for mids/zids
│   └── system_prompts.indexes.ts
├── seeds/           # Database seed files
│   └── system_prompts.seed.sql
├── decorators/      # Custom decorators
├── enums/           # Enumerations
├── types/           # TypeScript type definitions
│   └── database.ts  # DrizzleDatabase, DrizzleSqliteDatabase types
├── utils/           # Utility functions (validation, crypto, etc.)
├── browser.ts       # Browser-compatible exports (no Node.js deps)
├── sqlite.ts        # SQLite exports for React Native/Expo
└── index.ts         # Main barrel export
```

## License

MIT

## Repository

https://github.com/recoverysky-org/recoverysky-common
