# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

`@recoverysky-org/common` is a shared TypeScript library for the RecoverySky organization that provides:
- **Dual-database architecture**: PostgreSQL (server) + SQLite (mobile/offline via expo-sqlite)
- Common data models: meetings, schedules, TREX, attendances, attendance reports, chat messages, feedbacks, user profiles, zoom auths, system prompts
- Type-safe schema generation pipeline (TypeScript → JSON Schema → Drizzle ORM)
- Zod validation with helper functions
- Deterministic SHA256 hashing (sorted keys) for change detection
- Repository layer for both PG and SQLite database operations
- JWT utilities
- Three package exports: `@recoverysky-org/common` (main), `./browser`, `./sqlite`

This is a monorepo dependency distributed as a tarball to sibling projects.

## Iris Orchestration

This project is part of the Iris orchestration system with team name: `team-common`

---

## ⚠️ CRITICAL: Error Handling with ts-rust-result

**THIS PROJECT USES DOMAIN-SPECIFIC RESULT HELPERS - NOT THE BASE LIBRARY**

### Required Pattern (src/errors/results.ts)

```typescript
// ✅ CORRECT - Always import from domain helpers
import { ok, err } from '../errors/results.js';
import { invalidFieldValue, unexpected } from '@jenova-marie/ts-rust-result/errors';

function doSomething(): RecoverySkyResult<Data> {
  if (error) return err(invalidFieldValue('field', value, 'expected'));
  return ok(data);  // ✨ NO type parameters needed!
}
```

```typescript
// ❌ WRONG - NEVER import from base library
import { ok, err } from '@jenova-marie/ts-rust-result';  // NO!
import { Ok, Err } from '@jenova-marie/ts-rust-result';   // NO!

// ❌ WRONG - These don't exist in our domain helpers
return Ok(data);   // Compile error - Ok is not a function
return Err(error); // Compile error - Err is not a function
```

### Domain Result Helpers

This project uses `createDomainResult<RecoverySkyError>()` which binds `ok` and `err` to our error types:

**Location:** `src/errors/results.ts`

**Available Helpers:**
```typescript
import { ok, err } from './errors/results.js';

// Domain-specific Result types (already bound to RecoverySkyError)
import type {
  RecoverySkyResult,  // General purpose
  DateTimeResult,     // That70sDateTime utilities
  MeetingResult,      // Meeting class methods
  ScheduleResult,     // Schedule class methods
  JWKResult,          // Crypto operations
  CryptoResult,       // Hash/encryption
} from './errors/results.js';
```

**Key Benefits:**
- ✅ ZERO type assertions needed
- ✅ No `ok<T>()` or `err<E>()` generic parameters
- ✅ Clean recursive error propagation
- ✅ Better IDE autocomplete

### Error Constructor Functions

**Always use error constructors from `@jenova-marie/ts-rust-result/errors`:**

```typescript
import {
  invalidFieldValue,    // Field validation errors
  requiredFieldMissing, // Missing required fields
  unexpected,           // Unexpected errors (third-party failures)
  parseError,           // Parsing failures
  validationError,      // Validation failures
} from '@jenova-marie/ts-rust-result/errors';

// ✅ CORRECT
if (!value) {
  return err(requiredFieldMissing('fieldName'));
}

if (value < 0) {
  return err(invalidFieldValue('fieldName', value, 'positive number'));
}

// Wrap third-party errors
if (!thirdPartyResult.ok) {
  return err(unexpected('Operation failed', thirdPartyResult.error));
}
```

### Common Mistakes to Avoid

**1. Using Base Library Instead of Domain Helpers**
```typescript
// ❌ WRONG
import { ok, err } from '@jenova-marie/ts-rust-result';

// ✅ CORRECT
import { ok, err } from '../errors/results.js';
```

**2. Using Ok/Err (capitalized) Instead of ok/err**
```typescript
// ❌ WRONG - These are types, not functions
return Ok(value);   // Compile error
return Err(error);  // Compile error

// ✅ CORRECT - These are the domain helper functions
return ok(value);   // Works perfectly
return err(error);  // Works perfectly
```

**3. Trying to Add Type Parameters**
```typescript
// ❌ WRONG - Domain helpers don't need type params
return ok<MyType>(value);        // Unnecessary
return err<MyError>(error);      // Unnecessary

// ✅ CORRECT - Let TypeScript infer
return ok(value);   // TypeScript infers the type
return err(error);  // TypeScript infers the error type
```

**4. Not Wrapping Third-Party Library Calls**
```typescript
// ❌ WRONG - Own functions don't need wrapping
const result = await tryResult(() => myOwnFunction());  // NO!

// ✅ CORRECT - Only wrap third-party calls
const result = await tryResult(() => externalLibrary.doSomething());

// ✅ CORRECT - Own functions return Result directly
function myOwnFunction(): RecoverySkyResult<Data> {
  return ok(data);
}
```

### ts-rust-result Documentation

**Full Documentation:** https://github.com/jenova-marie/ts-rust-result

**Key Concepts:**
- Treats errors as values (not exceptions)
- Functions declare failure via return type `Result<T, E>`
- Own functions return `Result<T>` directly
- Third-party calls wrap in `tryResult()`
- Never throw exceptions - return `err()` instead

---

## ⚠️ CRITICAL: ESM Module Requirements

**THIS PROJECT USES ES MODULES (ESM) - NOT COMMONJS**

### Import/Export Rules

**1. Always use `.js` extensions in imports**
```typescript
// ✅ CORRECT - .js extension required
import { ok, err } from '../errors/results.js';
import { Meeting } from '../classes/Meeting/Meeting.js';
import type { meeting } from '../models/meeting.js';

// ❌ WRONG - Missing .js extension
import { ok, err } from '../errors/results';      // Build error
import { Meeting } from '../classes/Meeting/Meeting';  // Build error
```

**2. All exports must use `.js` in file references**
```typescript
// ✅ CORRECT - package.json
{
  "type": "module",
  "exports": {
    ".": {
      "import": "./lib/index.js",
      "types": "./lib/index.d.ts"
    }
  }
}
```

**3. Type imports should use `type` keyword**
```typescript
// ✅ CORRECT - Separate type imports
import { ok, err } from '../errors/results.js';
import type { RecoverySkyResult } from '../errors/results.js';

// ✅ ALSO CORRECT - Inline type imports
import { ok, err, type RecoverySkyResult } from '../errors/results.js';
```

### Common ESM Mistakes

**1. Missing .js extensions**
```typescript
// ❌ WRONG
import { helper } from './utils/helper';

// ✅ CORRECT
import { helper } from './utils/helper.js';
```

**2. Mixing CommonJS and ESM**
```typescript
// ❌ WRONG
const { ok, err } = require('../errors/results');  // NO!

// ✅ CORRECT
import { ok, err } from '../errors/results.js';
```

**3. Not specifying "type": "module" in package.json**
```json
// ✅ CORRECT - package.json MUST have this
{
  "type": "module"
}
```

### Why ESM?

- ✅ Better tree-shaking for smaller bundles
- ✅ Native browser support
- ✅ Required by modern tools (Vite, etc.)
- ✅ Future-proof (CommonJS is legacy)

---

## ⚠️ CHECKLIST: Before Claiming "Production Ready"

**Run through this checklist EVERY TIME before saying something is complete:**

### 1. Build Check
```bash
pnpm build
# Must complete with ZERO errors
```

### 2. Import Syntax Check
- [ ] All imports use `.js` extensions
- [ ] All imports use `ok`/`err` from `../errors/results.js` (NOT base library)
- [ ] All type imports use `type` keyword or inline `type`
- [ ] No `Ok`/`Err` (capitalized) anywhere

### 3. Error Handling Check
- [ ] All functions return `Result<T, E>` types
- [ ] All errors use error constructors (`invalidFieldValue`, `unexpected`, etc.)
- [ ] No `throw` statements (use `return err()` instead)
- [ ] Third-party calls wrapped in `tryResult()`
- [ ] Own functions return `Result` directly (NO tryResult)

### 4. ESM Compliance Check
- [ ] `package.json` has `"type": "module"`
- [ ] All exports use `.js` extensions
- [ ] No `require()` statements
- [ ] No `module.exports`

### 5. Test Check
```bash
pnpm test                    # Run all tests
pnpm test:unit               # Unit tests only (excludes integration)
pnpm test:integration        # Integration tests only
pnpm test:repos              # Repository integration tests
pnpm vitest run -t "test name"  # Run specific test by name
```

### 6. Type Check
- [ ] No `any` types (except in carefully controlled situations)
- [ ] No type assertions unless absolutely necessary
- [ ] Return types explicitly declared on all exported functions

### 7. Browser Exports Check
- [ ] New models added to `browser.ts` (if browser-safe)
- [ ] New enums added to `browser.ts`
- [ ] New Zod schemas added to `browser.ts`
- [ ] New pure utilities added to `browser.ts`
- [ ] Repositories NOT added to `browser.ts` (server-only)

**ONLY AFTER ALL CHECKS PASS can you claim something is "production ready" or "complete"**

---

## Development Commands

### Build Process
```bash
# Full build pipeline
pnpm run make          # Version bump, build, generate all schemas, create tarball

# Individual build steps
pnpm build             # Compile TypeScript to lib/
pnpm ts:schema         # Generate TypeScript schemas from models
pnpm json:schema       # Generate JSON schemas from models
pnpm rxdb:schema       # Generate RxDB schemas from JSON schemas
pnpm drizzle:schema    # Generate Drizzle ORM tables from JSON schemas
pnpm drizzle:generate  # Generate Drizzle migrations
```

### Database Migrations

**Full workflow when models change:**
```bash
pnpm make              # 1. Build + generate all schemas + migrations + tarball
pnpm migrate:prod      # 2. Push schema then apply triggers/views/FKs
pnpm seed:prod         # 3. Apply seed data (if needed)
```

**Individual migration targets:**
```bash
pnpm migrate:prod      # Production database
pnpm migrate:local     # Local database
```

### Distribution
```bash
pnpm distribute        # Build, pack, and copy tarball to ../recoverysky-zoom/
```

### Local Development & Iris Requests
```bash
# Quick tarball creation for local development (no version number)
pnpm pack:stable       # Creates recoverysky-common.tgz

# Use this when:
# - Building for Iris team requests
# - Rapid iteration between sibling projects
# - Testing changes without version bumps
# - Installing: pnpm add file:./recoverysky-common.tgz
```

**Why `pack:stable`?**
- ✅ Creates `recoverysky-common.tgz` without version number
- ✅ No need to update version in consuming project's `package.json`
- ✅ Faster iteration cycle for local development
- ✅ Same pattern as `ts-rust-result` library
- ✅ Avoids recursive `pack` script issues

**Full Build vs Quick Pack:**
```bash
# Full pipeline (use for releases/commits)
pnpm make              # Build + schemas + migrations + pack:stable

# Quick pack only (use for Iris/local testing)
pnpm pack:stable       # Just create tarball from current lib/
```

## Schema Generation Pipeline

The library uses a multi-step schema transformation pipeline:

1. **Source Models** (`models/*.ts`) — Plain TypeScript classes
2. **JSON Schemas** (`models/json/*.json`) — Generated by `scripts/ts-to-json.ts`
3. **Drizzle PG Schemas** (`models/drizzle/pg/*.drizzle.ts`) — Generated by `scripts/json-to-drizzle.ts`
4. **Drizzle SQLite Schemas** (`models/drizzle/sqlite/*.drizzle.ts`) — Generated by `scripts/json-to-drizzle-sqlite.ts`
5. **PG Migrations** (`models/migrations/*.sql`) — Generated by `drizzle-kit generate`
6. **SQLite Migrations** (`models/migrations/sqlite/*.sql`) — Generated by `drizzle-kit generate --config=drizzle.sqlite.config.ts`

**Type mapping differences:**
- PG: `boolean()` native, `jsonb()` for arrays/objects
- SQLite: `integer()` for booleans (0/1), `text()` for JSON (serialized)

**Important**: Always run `pnpm make` when modifying models to regenerate the entire pipeline.

## Architecture

### Core Classes

#### Meeting (`classes/Meeting/Meeting.ts`)
Extends `models/meeting.ts` with business logic:
- `constructor(meetingData?, trexData?)`: Hydrates from database rows with optional TREX
- `create(data?, trexData?)`: Factory with ObjectID generation, timestamps, and optional TREX attachment
- `update()`: Validates meeting + TREX via Zod, generates deterministic SHA256 hash (sorted keys)
- `getNextOccurrence(fromDt?)`: Returns next occurrence millis using TREX engine (Python executor)
- `toJSON()`: Deterministic serialization with sorted keys for consistent hashing
- `isStale()`: Checks if updated >24h ago
- Decorated with `@RxModel('meeting')` for RxDB integration

**SHA256 Hash Determinism:**
- Hash is computed from meeting + TREX data with sorted keys
- Excludes: `id`, `version`, `updated`, `sha256` (internal identifiers)
- Includes all TREX fields except `id`
- Same data produces same hash regardless of creation path or property order

#### Schedule (`classes/Schedule/Schedule.ts`)
Extends `models/schedule.ts` with business logic:
- `constructor(scheduleData?, meetingsData?, trexesData?, timezone?)`: Hydrates from database rows
- `create(data?, meetingsData?, trexesData?, timezone?)`: Factory with UUID, timestamps
- `meetings`: Array of hydrated Meeting instances (not serialized to JSON)
- `daily`: Getter returning true if schedule covers all 7 days of the week
- `getScheduleData(fromDt?)`: Returns weekly grid `Array<Array<string | null>>` with formatted times (e.g., "9:00 AM")
- `setTimezone(tz)`: Changes display timezone (auto-clears cache)
- `clearScheduleDataCache()`: Forces recalculation of schedule data
- Results are cached after first calculation for performance

#### TREX Model (`models/trex.ts`)
Plain data model for TREX (Temporal Recurring Event indeX) aligned with TREXJSON interface from @trex-ts/core.

**Required Fields:**
- `id`, `coordinate`, `timezone`, `periodicity` (core)
- `coordinate_end`, `duration_ms` (timing)
- `dtstart`, `dtend` (nullable), `rrule_str`, `rrule_json` (recurrence)

**Optional/Nullable Fields (denormalized):**
- `hour`, `minute`, `dow`, `dom`, `month`

**Periodicity Values (from @trex-ts/core v1.1.3):**
- `CONTINUOUS = 0` - 24/7 always-active
- `DAILY = 1` - Daily recurring
- `WEEKLY = 2` - Weekly recurring (default for meetings)
- `MONTHLY = 3` - Monthly recurring
- `YEARLY = 4` - Yearly recurring

**Periodicity-based Field Validation:**
- `dow` - only valid for WEEKLY (null for others)
- `dom` - only valid for MONTHLY/YEARLY (null for DAILY/WEEKLY)
- `month` - only valid for YEARLY (null for others)

### Decorators (`decorators/`)

- `@RxModel(name)`: Links class to RxDB schema by name
- `@addFunctions({})`: Injects utility functions into class instances (function injection pattern)
- `@Log()`: Method logging decorator

### Utilities (`utils/`)

- `createNewJWK`: Generate new JSON Web Keys (uses Web Crypto API, browser-safe)
- `getNextFrequency`: Calculate next occurrence for recurring meetings
- `deterministicStringify`: JSON stringify with sorted keys for consistent hashing
- **Validation Helpers** (`utils/validation.ts`):
  - `validateMeeting(data)`: Single meeting validation using Zod
  - `validateMeetings(meetings)`: Batch meeting validation with error collection
  - `validateSchedule(data)`: Single schedule validation using Zod
  - `validateSchedules(schedules)`: Batch schedule validation with error collection
  - `validateTrex(data)`: Single TREX validation using Zod with:
    - Coordinate range validation per periodicity
    - Periodicity-based field validation (dow→WEEKLY, dom→MONTHLY/YEARLY, month→YEARLY)
  - `validateTrexes(trexes)`: Batch TREX validation with error collection
  - All return `Result<T, E>` types for type-safe error handling

## Runtime Validation

The library includes comprehensive Zod validation schemas and helper functions for runtime validation:

### Available Validation Functions

```typescript
import {
  validateMeeting,
  validateMeetings,
  validateSchedule,
  validateSchedules,
  validateTrex,
  validateTrexes,
  type BatchValidationResult,
  type BatchValidationError
} from '@recoverysky-org/common';
```

### Single Item Validation

```typescript
// Validate a single meeting
const result = validateMeeting(meetingData);
if (result.ok) {
  console.log('Valid meeting:', result.value);
  await saveMeeting(result.value);
} else {
  // result.error is z.ZodError with detailed issues
  result.error.issues.forEach(issue => {
    console.error(`${issue.path.join('.')}: ${issue.message}`);
  });
}

// Validate a single schedule
const scheduleResult = validateSchedule(scheduleData);
scheduleResult.match(
  (valid) => saveSchedule(valid),
  (error) => handleError(error)
);

// Validate a TREX time expression (aligned with TREXJSON interface)
const trexResult = validateTrex({
  id: 'trex-123',
  coordinate: 259200000,        // Thursday 00:00 UTC in WEEKLY frame
  coordinate_end: 262800000,    // Required: end coordinate
  timezone: 'America/New_York',
  periodicity: 2,               // WEEKLY (CONTINUOUS=0, DAILY=1, WEEKLY=2, MONTHLY=3, YEARLY=4)
  duration_ms: 3600000,         // Required: 1 hour
  dtstart: '2025-01-01T00:00:00-05:00',  // Required: recurrence start
  dtend: null,                  // Required but nullable: null = infinite
  rrule_str: 'FREQ=WEEKLY;BYDAY=TH',     // Required: RFC 5545 RRULE
  rrule_json: { freq: 'WEEKLY', byday: ['TH'] },  // Required: parsed RRULE
  dow: 4                        // Optional: Thursday (only valid for WEEKLY)
});
if (trexResult.ok) {
  console.log('Valid TREX:', trexResult.value);
}
```

### Batch Validation

```typescript
// Validate multiple meetings, collecting both valid and invalid
const batchResult = validateMeetings(scrapedMeetings);
if (batchResult.ok) {
  const { valid, invalid } = batchResult.value;
  console.log(`Valid: ${valid.length}, Invalid: ${invalid.length}`);

  // Process valid meetings
  await Promise.all(valid.map(m => saveMeeting(m)));

  // Report validation errors
  invalid.forEach(({ index, data, errors }) => {
    console.error(`Meeting at index ${index} (${data.name}) failed:`);
    errors.forEach(err => {
      console.error(`  - ${err.path.join('.')}: ${err.message}`);
    });
  });
}
```

### Direct Schema Usage

For advanced use cases, import the Zod schemas directly:

```typescript
import {
  meetingZodSchema,
  meetingCreateSchema,
  meetingUpdateSchema,
  scheduleZodSchema,
  scheduleCreateSchema,
  trexZodSchema,
  trexCreateSchema
} from '@recoverysky-org/common';

// Custom validation with transforms
const customSchema = meetingZodSchema.transform(data => ({
  ...data,
  name: data.name.trim().toUpperCase()
}));

// Extend schemas
const extendedSchema = meetingCreateSchema.extend({
  customField: z.string().optional()
});

// TREX schema with coordinate range validation per periodicity
const trexResult = trexCreateSchema.safeParse(trexData);
```

### When to Use Validation Helpers

**Use validation helpers when:**
- ✅ Validating external data (API responses, user input, scraped data)
- ✅ Batch validation where you need to collect all errors
- ✅ You want `Result<T, E>` pattern for error handling
- ✅ You need automatic logging of validation failures

**Use direct schemas when:**
- ✅ Integrating with form libraries (React Hook Form, Formik)
- ✅ Custom validation pipelines with transforms
- ✅ Extending schemas with additional fields
- ✅ Type inference with `z.infer<typeof schema>`

**See** `content/VALIDATION.md` for comprehensive validation documentation.

### Enums (`enums/`)

- `Fellowship`: AA, NA, etc.
- `MeetingStatus`: ACTIVE, MISSING, ENDED, etc.
- `Periodicity`: CONTINUOUS, DAILY, WEEKLY, MONTHLY, YEARLY (local copy for browser compatibility)
- `ScheduleStatus`: Schedule lifecycle states
- `SearchType`: Meeting search types
- `SpecificDay`: Day-of-week constants
- `VerifiedStatus`: Meeting verification states

## Database Configuration

Four Drizzle configurations exist:
- `drizzle.prod.config.ts`: Production PostgreSQL (db.rso:5432, database: recoverysky)
- `drizzle.local.config.ts`: Local PostgreSQL (localhost:5432)
- `drizzle.pgrx.config.ts`: Local pgrx development (localhost:28816)
- `drizzle.sqlite.config.ts`: SQLite schema generation (no credentials needed)

**Environment Files** (gitignored, contain credentials):
- `.env.prod` - Production credentials (uses `$PGUSER`/`$PGPASSWORD`)
- `.env.local` - Local development credentials
- `.env.pgrx` - pgrx testing credentials

Shell scripts (`apply-fk.sh`, `apply-triggers.sh`, `apply-views.sh`) source these `.env` files based on the environment argument.

**Migration Commands:**
```bash
pnpm migrate:prod   # Schema push → triggers → views → foreign keys
pnpm migrate:local  # Same order for local
pnpm migrate:pgrx   # Same order for pgrx
```

**Execution order matters:** Schema push (`drizzle-kit push`) runs first to create/alter tables, then triggers/views/FKs are applied. Triggers reference tables that must already exist.

**Foreign Key Migrations:**
- FK migrations use `DROP CONSTRAINT IF EXISTS` before `ADD CONSTRAINT` for idempotency
- Safe to re-run without "constraint already exists" errors

**Database Seeding:**
```bash
pnpm seed:prod    # Apply all seeds to production
pnpm seed:local   # Apply all seeds to local
bash src/scripts/apply-seeds.sh prod system_prompts  # Apply specific seed
```
- Seed files in `src/seeds/` use `ON CONFLICT` for idempotency (safe to re-run)
- Seeding infrastructure: `apply-seeds.sh` sources `.env` files for credentials

## Type Safety

The library maintains strict type safety across three TypeScript configs:
- `tsconfig.json`: Main build configuration
- `tsconfig.models.json`: Models compilation
- `tsconfig.schema.json`: Schema generation from models

The `generate-index-dts.ts` script ensures all type declarations are properly exported in `lib/index.d.ts`.

## Distribution Model

This library is NOT published to npm. Instead:
1. `pnpm run make` creates a tarball
2. `distribute-common.sh` copies to sibling projects
3. Consuming projects install via: `pnpm add file:./recoverysky-common.tgz`

Version format: `0.1.1-dev.{timestamp}`

## SQLite Exports

The `./sqlite` export provides repositories for mobile/offline-first apps (expo-sqlite):

```typescript
import {
  MeetingSqliteRepository,
  ScheduleSqliteRepository,
  AttendanceSqliteRepository,
  AttendanceReportSqliteRepository,
  ChatMessageSqliteRepository,
  FeedbackSqliteRepository,
  SyncQueueRepository,
  ZoomAuthSqliteRepository,
} from '@recoverysky-org/common/sqlite';
```

SQLite repositories handle type conversions (boolean↔integer, JSON↔text) internally.

## Browser Exports

The `./browser` export provides browser-compatible code (no Node.js dependencies):

```typescript
import {
  meeting, schedule, trex, system_prompt,  // Models
  Meeting, Schedule,                        // Classes (with TREXBrowser)
  Periodicity,                              // Enum
  validateMeeting, validateSchedule,        // Validation
  MeetingStatus, Fellowship,                // Enums
} from '@recoverysky-org/common/browser';
```

**Export to browser.ts:** Models, enums, Zod schemas, pure utilities
**Do NOT export to browser.ts:** Repositories, Node-only code

## Model Relationships

```
attendance_report (1) ←→ (many) attendance
  └── attendance.arid = attendance_report.id
  └── AttendanceSqliteRepository.findByReportId(arid)
  └── AttendanceSqliteRepository.markProduced(id, arid)

schedule (1) ←→ (many) meeting
  └── via schedule_meetings junction table

meeting (1) ←→ (1) trex
  └── meeting.tid = trex.id
```

## Key Files

- `index.ts`: Main export barrel (classes, models, utils, types, enums, decorators, PG repositories)
- `browser.ts`: Browser-compatible exports (no Node.js dependencies)
- `sqlite.ts`: SQLite repository exports for mobile/offline
- `models/index.ts`: Exports all model classes
- `lib/`: Compiled output directory (gitignored)
- Your Iris MCP team name is "team-common"
