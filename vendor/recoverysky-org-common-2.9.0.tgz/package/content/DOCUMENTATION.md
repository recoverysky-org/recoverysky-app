# @recoverysky-org/common Documentation

Complete documentation for the RecoverySky Common Library - a dual-ORM TypeScript library supporting both RxDB (client-side) and Drizzle ORM (server-side) from a single source of truth.

## Quick Links

- **[README](./README.md)** - Installation, quick start, basic usage
- **[API Documentation](./docs/index.html)** - Complete TypeDoc-generated API reference (open locally after installation)

## Documentation Guide

### Getting Started
New to this library? Start here:

1. **[README](./README.md)** - Overview, installation, basic examples
2. **[Consumer Guide](./content/consumer-guide.md)** - Comprehensive usage guide
3. **[Validation Guide](./content/VALIDATION.md)** - Runtime validation with Zod
4. **[Architecture Guide](./content/architecture.md)** - Understanding the design

### Core Concepts

#### Models vs Classes
The most important concept to understand:

- **Models** (lowercase: `meeting`, `schedule`)
  - Plain TypeScript classes defining data structure
  - Used for type annotations
  - No business logic, just data shape
  - Located in `src/models/`

- **Classes** (Uppercase: `Meeting`, `Schedule`)
  - Rich classes extending models
  - Contains business logic methods
  - Factory patterns (`Meeting.create()`)
  - Located in `src/classes/`

**See**: [Consumer Guide - Understanding Exports](./content/consumer-guide.md#understanding-exports)

#### Schema Generation Pipeline
Automated transformation from models to database schemas:

```
Models (TS) → TS Schemas → JSON Schemas → RxDB Schemas + Drizzle Schemas → SQL Migrations
```

**See**: [Schema Generation](./content/schema-generation.md)

### Detailed Documentation

#### [Consumer Guide](./content/consumer-guide.md)
Comprehensive guide for library consumers:
- Installation and setup
- Understanding exports and naming conventions
- Common use cases (RxDB, Drizzle, That70sDateTime)
- Type safety patterns (Result<T, E>)
- Advanced patterns (batch operations, conversions)
- Troubleshooting common issues
- Best practices

**Read this if**: You're using this library in your project and need practical examples.

#### [Architecture Guide](./content/architecture.md)
Deep dive into the library's design:
- The three-layer pattern (Models → Classes → Schemas)
- Why this architecture exists
- How it solves dual-ORM requirements
- Consumer perspective and patterns
- Design principles
- Common pitfalls
- Extension points
- Performance considerations

**Read this if**: You want to understand why the library is designed this way, or you're contributing to it.

#### [Schema Generation](./content/schema-generation.md)
Complete pipeline documentation:
- Overview of the 5-step transformation process
- Step-by-step breakdown of each script
- Configuration and customization
- Running the pipeline
- Adding new models
- Troubleshooting schema issues
- Performance optimization
- Best practices

**Read this if**: You're modifying models, debugging schema generation, or extending the pipeline.

#### [Validation Guide](./content/VALIDATION.md)
Runtime validation with Zod:
- Why Zod and how it works
- Automatic validation in `update()` methods
- Available validation schemas
- Comprehensive field validation rules
- Cross-field validation
- Common use cases and patterns
- Error handling and debugging
- Integration with RxDB and Drizzle
- Performance considerations
- Best practices

**Read this if**: You want to understand runtime validation, handle validation errors, or use Zod schemas directly.

### API Reference

#### [TypeDoc Generated Docs](./docs/index.html)
Complete API documentation generated from TypeScript source:
- All classes, interfaces, types
- Method signatures and parameters
- Return types and examples
- JSDoc comments from source code

**To generate locally**:
```bash
pnpm docs              # Generate to ./docs
pnpm docs:watch        # Generate and watch for changes
pnpm docs:serve        # Generate and serve on http://localhost:8080
```

**Read this if**: You need detailed API reference for a specific class or method.

## Documentation by Use Case

### I want to...

#### Create a new Meeting instance
```typescript
import { Meeting } from '@recoverysky-org/common';

const result = Meeting.create();
if (result.ok) {
    const meeting = result.value;
    meeting.name = 'Monday Night Big Book';
    await meeting.update();
}
```
**See**: [Consumer Guide - Creating Instances](./content/consumer-guide.md#1-creating-new-meeting-instances)

#### Use with RxDB (client-side database)
```typescript
import { meetingSchema, meetingDocType } from '@recoverysky-org/common/lib/models/rxdb/meeting.rxdb';

const collections = {
    meetings: { schema: meetingSchema }
};

const docs: meetingDocType[] = await db.meetings.find().exec();
```
**See**: [Consumer Guide - RxDB Usage](./content/consumer-guide.md#2-working-with-rxdb-client-side)

#### Use with Drizzle ORM (server-side database)
```typescript
import { meetings } from '@recoverysky-org/common/lib/models/drizzle/meetings.drizzle';

const rows = await db.select().from(meetings);
```
**See**: [Consumer Guide - Drizzle Usage](./content/consumer-guide.md#3-working-with-drizzle-orm-server-side)

#### Manage recurring meeting times
```typescript
import { makeThat70sDateTime, hydrateSeventies } from '@recoverysky-org/common';

const seventies = makeThat70sDateTime({ DateTime: now, millis: now.toMillis() });
const currentTime = hydrateSeventies(seventies, timezone);
```
**See**: [Consumer Guide - That70sDateTime](./content/consumer-guide.md#4-using-that70sdatetime)

#### Validate meeting and schedule data
```typescript
import { validateMeeting, validateMeetings, validateSchedule } from '@recoverysky-org/common';

// Single validation - returns Result<T, E>
const result = validateMeeting(meetingData);
if (result.ok) {
    console.log('Valid meeting:', result.value);
    await saveMeeting(result.value);
} else {
    // Detailed error information
    result.error.issues.forEach(issue => {
        console.error(`${issue.path.join('.')}: ${issue.message}`);
    });
}

// Batch validation - collects both valid and invalid
const batchResult = validateMeetings(meetingsArray);
if (batchResult.ok) {
    const { valid, invalid } = batchResult.value;
    console.log(`Valid: ${valid.length}, Invalid: ${invalid.length}`);

    // Process valid items
    await Promise.all(valid.map(m => saveMeeting(m)));

    // Report errors for invalid items
    invalid.forEach(({ index, data, errors }) => {
        console.error(`Item ${index} (${data.name}) failed validation:`, errors);
    });
}

// Schedule validation
const scheduleResult = validateSchedule(scheduleData);
scheduleResult.match(
    (valid) => saveSchedule(valid),
    (error) => handleValidationError(error)
);
```
**See**: [Validation Guide](./content/VALIDATION.md) for comprehensive documentation

#### Add a new model to the library
1. Create `src/models/mymodel.ts`
2. Export from `src/models/index.ts`
3. Run `pnpm make`

**See**: [Schema Generation - Adding New Models](./content/schema-generation.md#adding-new-models)

#### Understand why there are two versions of Meeting
The architecture requires separating data structure (models) from business logic (classes) to support both RxDB and Drizzle ORM.

**See**: [Architecture Guide - Why This Architecture](./content/architecture.md#why-this-architecture)

#### Debug schema generation errors
Common causes: complex default values, union types, circular dependencies.

**See**: [Schema Generation - Troubleshooting](./content/schema-generation.md#troubleshooting)

#### Extend the library with custom functionality
Add methods to classes, customize schema generation scripts, create new decorators.

**See**: [Architecture Guide - Extension Points](./content/architecture.md#extension-points)

## Key Concepts Reference

### Naming Conventions

| Export | Case | Example | Purpose |
|--------|------|---------|---------|
| Model | lowercase | `meeting` | Data type, type annotations |
| Class | Uppercase | `Meeting` | Business logic, methods |
| RxDB Schema | camelCase | `meetingSchema` | RxDB collection schema |
| RxDB Type | camelCase | `meetingDocType` | TypeScript type for docs |
| Drizzle Table | plural | `meetings` | PostgreSQL table |

### File Structure

```
@recoverysky-org/common/
├── src/
│   ├── models/              # Plain data models
│   │   ├── meeting.ts       # meeting model (lowercase)
│   │   ├── schedule.ts      # schedule model
│   │   ├── schema/          # Generated TS schemas
│   │   ├── json/            # Generated JSON schemas
│   │   ├── rxdb/            # Generated RxDB schemas
│   │   └── drizzle/         # Generated Drizzle schemas
│   ├── classes/             # Business logic classes
│   │   ├── Meeting/         # Meeting class (Uppercase)
│   │   ├── Schedule/        # Schedule class
│   │   └── That70sDateTime/ # Datetime utility
│   ├── decorators/          # Custom decorators
│   ├── enums/               # Enumerations
│   ├── types/               # TypeScript types
│   └── utils/               # Utility functions
├── content/                 # Documentation (markdown)
│   ├── consumer-guide.md
│   ├── architecture.md
│   └── schema-generation.md
├── docs/                    # Generated API docs (HTML)
├── README.md                # Quick start guide
└── DOCUMENTATION.md         # This file
```

### Import Patterns

```typescript
// Classes (business logic)
import { Meeting, Schedule } from '@recoverysky-org/common';

// Models (type annotations)
import { meeting, schedule } from '@recoverysky-org/common/models';

// RxDB schemas
import { meetingSchema, meetingDocType } from '@recoverysky-org/common/lib/models/rxdb/meeting.rxdb';

// Drizzle tables
import { meetings, schedules } from '@recoverysky-org/common/lib/models/drizzle/meetings.drizzle';

// Utilities
import { makeThat70sDateTime, hydrateSeventies } from '@recoverysky-org/common';
```

## Development Workflow

### For Library Contributors

1. **Modify models**: Edit `src/models/*.ts`
2. **Regenerate schemas**: Run `pnpm make`
3. **Update classes**: Edit `src/classes/**/*.ts` if adding business logic
4. **Test changes**: Verify in both RxDB and Drizzle contexts
5. **Update docs**: Regenerate with `pnpm docs`
6. **Commit all**: Include generated files in version control

### For Library Consumers

1. **Install**: `pnpm add @recoverysky-org/common`
2. **Import classes**: Use `Meeting`, `Schedule` from main export
3. **Import schemas**: Use `meetingSchema` or `meetings` table as needed
4. **Read docs**: Check `node_modules/@recoverysky-org/common/DOCUMENTATION.md`
5. **Follow patterns**: Use factories, Result types, and conventions

## Troubleshooting

### Common Issues

#### "Method doesn't exist on type"
You're using a model where you need a class.
```typescript
// ❌ Wrong
import { meeting } from '@recoverysky-org/common/models';
const m = new meeting();
m.update(); // ERROR

// ✅ Correct
import { Meeting } from '@recoverysky-org/common';
const m = Meeting.create().unwrap();
await m.update(); // Works!
```

#### "Cannot find module"
You're importing from wrong path.
```typescript
// ❌ Wrong
import { meetingSchema } from '@recoverysky-org/common';

// ✅ Correct
import { meetingSchema } from '@recoverysky-org/common/lib/models/rxdb/meeting.rxdb';
```

#### "Type mismatch with ORM"
You're using class type where ORM expects plain data type.
```typescript
// ❌ Wrong
const docs: Meeting[] = await db.meetings.find().exec();

// ✅ Correct
const docs: meetingDocType[] = await db.meetings.find().exec();
const meetings = docs.map(d => Object.assign(new Meeting(), d));
```

**See**: [Consumer Guide - Troubleshooting](./content/consumer-guide.md#troubleshooting) for more issues.

## Contributing

### Documentation
- Consumer guides: Edit `content/*.md`
- API reference: Update JSDoc comments in source
- README: Edit `README.md`
- This file: Edit `DOCUMENTATION.md`

### Code
- Models: Edit `src/models/*.ts` then run `pnpm make`
- Classes: Edit `src/classes/**/*.ts`
- Pipeline: Edit `src/scripts/*.ts`

### Testing
```bash
pnpm build              # Compile TypeScript
pnpm make               # Full build + schema generation
pnpm drizzle:migrate:local  # Test database migration
pnpm docs               # Generate API docs
```

## Support

- **Issues**: https://github.com/recoverysky-org/recoverysky-common/issues
- **Discussions**: https://github.com/recoverysky-org/recoverysky-common/discussions
- **Documentation**: https://github.com/recoverysky-org/recoverysky-common/tree/main/content

## License

MIT - See [LICENSE](./LICENSE) for details.

---

**Last Updated**: 2025-01-23
**Version**: 0.3.0
