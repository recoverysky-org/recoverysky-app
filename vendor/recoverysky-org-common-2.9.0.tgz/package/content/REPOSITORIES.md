# Repository Pattern - Data Access Layer

## Overview

The repository layer provides efficient bulk operations for PostgreSQL using Drizzle ORM. All methods return `Result<T, E>` for type-safe error handling.

**Available Repositories:**
- `MeetingRepository` - Meetings table operations
- `ScheduleRepository` - Schedules table operations

**Key Features:**
- ✅ Bulk insert (single query for multiple rows)
- ✅ Bulk upsert (insert or update on conflict)
- ✅ Batch updates (transaction-based atomic updates)
- ✅ Batch status updates (single UPDATE with WHERE IN)
- ✅ Find operations (by ID, IDs, status, etc.)
- ✅ Result type error handling
- ✅ Automatic audit logging via database triggers

---

## Setup

### 1. Install Dependencies

```bash
npm install postgres drizzle-orm
# or
pnpm add postgres drizzle-orm
```

### 2. Initialize Repository

```typescript
import { MeetingRepository, ScheduleRepository } from '@recoverysky-org/common';
import postgres from 'postgres';
import { drizzle } from 'drizzle-orm/postgres-js';

// Create PostgreSQL connection
const connectionString = 'postgresql://user:password@localhost:5432/recoverysky';
const client = postgres(connectionString);
const db = drizzle(client);

// Initialize repositories
const meetingRepo = new MeetingRepository(db);
const scheduleRepo = new ScheduleRepository(db);
```

---

## Hybrid API Design

Repositories provide **two ways to query data**:

### 1. Named Methods (for common operations)

Use predefined methods for frequently-needed operations:
- ✅ Discoverable via IDE autocomplete
- ✅ Well-documented with examples
- ✅ Best practices built-in
- ✅ Clear, self-documenting code

```typescript
// Named methods - clear and discoverable
const meeting = await meetingRepo.findById('123');
const meetings = await meetingRepo.findByStatus(MeetingStatus.ACTIVE);
await meetingRepo.bulkInsert(meetings);
```

### 2. Generic search() Method (for custom queries)

Use `search<T>()` for complex, one-off queries:
- ✅ Accepts any Drizzle query function
- ✅ Automatic Result<T, E> wrapping
- ✅ Maximum flexibility for complex operations
- ✅ No repository updates needed

```typescript
import { and, eq, gt, like } from 'drizzle-orm';

// Custom query using repo.table - no schema imports needed!
const result = await meetingRepo.search(db =>
  db.select()
    .from(repo.table)
    .where(and(
      eq(repo.table.fellowship, 'AA'),
      like(repo.table.location, '%New York%'),
      gt(repo.table.created, Date.now() - 604800000),
      eq(repo.table.status, MeetingStatus.ACTIVE)
    ))
    .orderBy(repo.table.created)
    .limit(100)
);

if (result.ok) {
  console.log(`Found ${result.value.length} AA meetings in NYC`);
}
```

### When to Use Each Approach

**Use Named Methods when:**
- ✅ Operation is common across the application
- ✅ You want clear, self-documenting code
- ✅ The query pattern is simple (single WHERE condition)
- ✅ You're new to the codebase

**Use search() when:**
- ✅ Query is complex (AND/OR/NOT, joins, subqueries)
- ✅ Query is one-off or rarely used
- ✅ You need aggregations (COUNT, SUM, etc.)
- ✅ You need custom ORDER BY / LIMIT / OFFSET

### Schema Access via repo.table

The `table` property provides type-safe access to the Drizzle schema **without requiring separate imports**:

```typescript
import { eq } from 'drizzle-orm';

// ✅ Access schema through repo.table
const result = await meetingRepo.search(db =>
  db.select()
    .from(repo.table)
    .where(eq(repo.table.fellowship, 'AA'))
);

// ✅ TypeScript autocomplete works!
repo.table.id          // string column
repo.table.status      // MeetingStatus column
repo.table.millis70s   // number column
repo.table.meetingTypes // JSON column
```

**Why this is better than importing schemas:**

```typescript
// ❌ OLD WAY - awkward import path
import { meetings } from '@recoverysky-org/common/lib/models/drizzle/meetings.drizzle';
const result = await repo.search(db => db.select().from(meetings));

// ✅ NEW WAY - clean, discoverable
const result = await repo.search(db => db.select().from(repo.table));
```

### Direct Database Access (Advanced)

For maximum control, bypass Result wrapping and access the database directly:

```typescript
import { and, eq, gt } from 'drizzle-orm';

// Direct database access (no Result wrapping - you handle errors)
try {
  const rows = await meetingRepo.db
    .select()
    .from(repo.table)
    .where(and(
      eq(repo.table.fellowship, 'NA'),
      gt(repo.table.created, yesterday)
    ));

  console.log(`Found ${rows.length} meetings`);
} catch (error) {
  console.error('Query failed:', error);
}
```

**When to use direct access:**
- ⚠️ You need to handle errors with custom logic
- ⚠️ You're using Drizzle's streaming API
- ⚠️ You're building a complex transaction
- ⚠️ Performance-critical code where Result wrapping adds overhead

---

## MeetingRepository Operations

### Bulk Insert

Insert multiple meetings in a single query (most efficient).

```typescript
import { Meeting, MeetingStatus } from '@recoverysky-org/common';

// Create meetings
const meetings = [
  Meeting.create({
    zid: '123456789',
    name: 'Monday Night Big Book',
    fellowship: 'AA',
    millis70s: 259200000,
    endMillis70s: 262800000,
    periodicity: Periodicity.WEEKLY,
    timezone: 'America/New_York',
    status: MeetingStatus.ACTIVE,
  }).unwrap(),

  Meeting.create({
    zid: '987654321',
    name: 'Tuesday Morning Meditation',
    fellowship: 'AA',
    millis70s: 345600000,
    endMillis70s: 349200000,
    periodicity: Periodicity.WEEKLY,
    timezone: 'America/New_York',
    status: MeetingStatus.ACTIVE,
  }).unwrap(),
];

// Bulk insert
const result = await meetingRepo.bulkInsert(meetings);

result.match(
  (inserted) => {
    console.log(`✅ Inserted ${inserted.length} meetings`);
    inserted.forEach(m => console.log(`  - ${m.name}`));
  },
  (error) => {
    console.error('❌ Bulk insert failed:', error.message);
  }
);
```

### Bulk Upsert

Insert new meetings or update existing ones (by ID conflict).

```typescript
// Scraper result: some meetings are new, some exist
const scrapedMeetings = await fetchMeetingsFromSource();

// Upsert all (insert new, update existing)
const result = await meetingRepo.bulkUpsert(scrapedMeetings);

if (result.ok) {
  console.log(`✅ Upserted ${result.value.length} meetings`);
}
```

### Batch Update

Update multiple meetings with different changes (atomic transaction).

```typescript
const updates = [
  {
    id: 'meeting-1',
    changes: {
      name: 'Updated Name',
      status: MeetingStatus.ACTIVE,
      updated: Date.now(),
    }
  },
  {
    id: 'meeting-2',
    changes: {
      url: 'https://zoom.us/j/newmeeting',
      updated: Date.now(),
    }
  },
];

const result = await meetingRepo.batchUpdate(updates);

result.match(
  (count) => console.log(`✅ Updated ${count} meetings`),
  (error) => console.error('❌ Batch update failed:', error.message)
);
```

### Batch Status Update

Efficiently update status for multiple meetings (single query).

```typescript
import { MeetingStatus } from '@recoverysky-org/common';

// Mark meetings as MISSING (disappeared from scraper)
const missingIds = ['id1', 'id2', 'id3'];
const result = await meetingRepo.batchStatusUpdate(
  missingIds,
  MeetingStatus.MISSING
);

if (result.ok) {
  console.log(`✅ Marked ${result.value} meetings as MISSING`);
}

// Mark as DELETED
const deletedIds = ['id4', 'id5'];
await meetingRepo.batchStatusUpdate(deletedIds, MeetingStatus.DELETED);

// Reactivate
const activeIds = ['id6', 'id7'];
await meetingRepo.batchStatusUpdate(activeIds, MeetingStatus.ACTIVE);
```

### Find Operations

```typescript
// Find by ID
const meeting = await meetingRepo.findById('meeting-123');
if (meeting.ok && meeting.value) {
  console.log('Found:', meeting.value.name);
}

// Find by multiple IDs
const meetings = await meetingRepo.findByIds(['id1', 'id2', 'id3']);

// Find by schedule ID
const scheduleMeetings = await meetingRepo.findByScheduleId('schedule-123');

// Find by status
const missingMeetings = await meetingRepo.findByStatus(MeetingStatus.MISSING);
if (missingMeetings.ok) {
  console.log(`Found ${missingMeetings.value.length} MISSING meetings`);
}
```

---

## ScheduleRepository Operations

### Bulk Insert

```typescript
import { Schedule, ScheduleStatus } from '@recoverysky-org/common';

const schedules = [
  {
    id: 'schedule-1',
    zids: ['123456789'],
    name: 'Weekly AA Meetings',
    mids: ['mid1', 'mid2'],
    fellowship: 'AA',
    status: ScheduleStatus.ACTIVE,
    created: Date.now(),
    updated: Date.now(),
    version: 0,
    sha256: '',
  },
];

const result = await scheduleRepo.bulkInsert(schedules);
```

### Bulk Upsert

```typescript
const result = await scheduleRepo.bulkUpsert(schedules);
```

### Batch Update

```typescript
const updates = [
  {
    id: 'schedule-1',
    changes: {
      name: 'Updated Schedule Name',
      updated: Date.now(),
    }
  },
];

const result = await scheduleRepo.batchUpdate(updates);
```

### Batch Status Update

```typescript
import { ScheduleStatus } from '@recoverysky-org/common';

// Mark schedules as ORPHANED (no active meetings)
const orphanedIds = ['schedule-1', 'schedule-2'];
const result = await scheduleRepo.batchStatusUpdate(
  orphanedIds,
  ScheduleStatus.ORPHANED
);
```

### Find Operations

```typescript
// Find by ID
const schedule = await scheduleRepo.findById('schedule-123');

// Find by multiple IDs
const schedules = await scheduleRepo.findByIds(['id1', 'id2', 'id3']);

// Find by status
const orphanedSchedules = await scheduleRepo.findByStatus(ScheduleStatus.ORPHANED);

// Find all (use with caution)
const allSchedules = await scheduleRepo.findAll();
```

---

## Complete Scraper Example

### Scenario: Zoom Scraper with Merge/Diff Logic

```typescript
import {
  MeetingRepository,
  MeetingStatus,
  validateMeetings,
  Meeting,
} from '@recoverysky-org/common';

async function scrapeAndSync() {
  // 1. Fetch current meetings from scraper source
  const scrapedData = await fetchZoomMeetings();

  // 2. Validate scraped data
  const validation = validateMeetings(scrapedData);
  if (!validation.ok) {
    console.error('Validation failed');
    return;
  }

  const { valid: scrapedMeetings, invalid } = validation.value;
  console.log(`✅ Valid: ${scrapedMeetings.length}, ❌ Invalid: ${invalid.length}`);

  // 3. Get current database state
  const dbResult = await meetingRepo.findByStatus(MeetingStatus.ACTIVE);
  if (!dbResult.ok) {
    console.error('Failed to fetch database meetings');
    return;
  }
  const dbMeetings = dbResult.value;

  // 4. Compute diff: which meetings disappeared?
  const scrapedIds = new Set(scrapedMeetings.map(m => m.id));
  const missingIds = dbMeetings
    .filter(m => !scrapedIds.has(m.id))
    .map(m => m.id);

  console.log(`📊 Database: ${dbMeetings.length}, Scraped: ${scrapedMeetings.length}`);
  console.log(`⚠️  Missing from scraper: ${missingIds.length}`);

  // 5. Mark missing meetings (don't delete yet)
  if (missingIds.length > 0) {
    const markResult = await meetingRepo.batchStatusUpdate(
      missingIds,
      MeetingStatus.MISSING
    );
    if (markResult.ok) {
      console.log(`✅ Marked ${markResult.value} meetings as MISSING`);
    }
  }

  // 6. Upsert scraped meetings (insert new, update existing)
  const upsertResult = await meetingRepo.bulkUpsert(scrapedMeetings);
  if (upsertResult.ok) {
    console.log(`✅ Upserted ${upsertResult.value.length} meetings`);
  }

  // 7. Cleanup: Delete meetings that have been MISSING for >30 days
  const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
  const missingMeetingsResult = await meetingRepo.findByStatus(MeetingStatus.MISSING);

  if (missingMeetingsResult.ok) {
    const staleIds = missingMeetingsResult.value
      .filter(m => m.updated < thirtyDaysAgo)
      .map(m => m.id);

    if (staleIds.length > 0) {
      const deleteResult = await meetingRepo.batchStatusUpdate(
        staleIds,
        MeetingStatus.DELETED
      );
      console.log(`🗑️  Deleted ${deleteResult.ok ? deleteResult.value : 0} stale meetings`);
    }
  }
}
```

---

## Advanced search() Examples

The generic `search<T>()` method unlocks complex Drizzle ORM features without cluttering the repository with specific methods.

### Aggregations

```typescript
import { sql } from 'drizzle-orm';

// Count meetings by status
const result = await meetingRepo.search(db =>
  db.select({
    status: repo.table.status,
    count: sql<number>`count(*)`
  })
  .from(repo.table)
  .groupBy(repo.table.status)
);

if (result.ok) {
  result.value.forEach(row => {
    console.log(`${row.status}: ${row.count} meetings`);
  });
}
```

### Complex WHERE Clauses

```typescript
import { and, eq, gt, like, or } from 'drizzle-orm';

// Find meetings: (AA in NYC) OR (NA and verified) created this week
const result = await meetingRepo.search(db =>
  db.select()
    .from(repo.table)
    .where(
      and(
        or(
          and(
            eq(repo.table.fellowship, 'AA'),
            like(repo.table.location, '%New York%')
          ),
          and(
            eq(repo.table.fellowship, 'NA'),
            eq(repo.table.verified, VerifiedStatus.VERIFIED)
          )
        ),
        gt(repo.table.created, Date.now() - 604800000)
      )
    )
    .orderBy(repo.table.created)
);
```

### Subqueries and CTEs

```typescript
import { desc, eq, sql } from 'drizzle-orm';

// Find schedules with the most meetings
// Note: This demonstrates a JOIN between schedules and meetings
const result = await scheduleRepo.search(async db => {
  // Import meetings table from meetingRepo for the subquery
  const meetingsTable = meetingRepo.table;

  const meetingCounts = db
    .select({
      sid: meetingsTable.sid,
      count: sql<number>`count(*)`.as('count')
    })
    .from(meetingsTable)
    .groupBy(meetingsTable.sid)
    .as('meeting_counts');

  return db
    .select({
      schedule: repo.table,
      meetingCount: meetingCounts.count
    })
    .from(repo.table)
    .leftJoin(meetingCounts, eq(repo.table.id, meetingCounts.sid))
    .orderBy(desc(meetingCounts.count))
    .limit(10);
});
```

### Array Operations (PostgreSQL-specific)

```typescript
import { sql } from 'drizzle-orm';

// Find schedules with specific meeting IDs
const result = await scheduleRepo.search(db =>
  db.select()
    .from(repo.table)
    .where(sql`${repo.table.mids} @> ARRAY['mid1', 'mid2']::text[]`)
);

// Find schedules with >5 meetings
const result = await scheduleRepo.search(db =>
  db.select()
    .from(repo.table)
    .where(sql`array_length(${repo.table.mids}, 1) > 5`)
);
```

### Pagination

```typescript
import { eq } from 'drizzle-orm';

const PAGE_SIZE = 20;
const page = 2;

const result = await meetingRepo.search(db =>
  db.select()
    .from(repo.table)
    .where(eq(repo.table.status, MeetingStatus.ACTIVE))
    .orderBy(repo.table.created)
    .limit(PAGE_SIZE)
    .offset((page - 1) * PAGE_SIZE)
);
```

### Full-Text Search (PostgreSQL)

```typescript
import { sql } from 'drizzle-orm';

// Search meetings by name/description
const searchTerm = 'big book';

const result = await meetingRepo.search(db =>
  db.select()
    .from(repo.table)
    .where(
      sql`to_tsvector('english', ${repo.table.name} || ' ' || ${repo.table.description}) @@ plainto_tsquery('english', ${searchTerm})`
    )
    .orderBy(
      sql`ts_rank(to_tsvector('english', ${repo.table.name}), plainto_tsquery('english', ${searchTerm})) DESC`
    )
);
```

### Date Range Queries

```typescript
import { and, gt, lt } from 'drizzle-orm';

// Find meetings created between two dates
const startDate = new Date('2025-01-01').getTime();
const endDate = new Date('2025-12-31').getTime();

const result = await meetingRepo.search(db =>
  db.select()
    .from(repo.table)
    .where(
      and(
        gt(repo.table.created, startDate),
        lt(repo.table.created, endDate)
      )
    )
);
```

### Update with SELECT

```typescript
import { and, eq, inArray, lt } from 'drizzle-orm';

// Update meetings based on complex conditions
const result = await meetingRepo.search(async db => {
  const oldMeetings = await db
    .select({ id: repo.table.id })
    .from(repo.table)
    .where(
      and(
        eq(repo.table.status, MeetingStatus.ACTIVE),
        lt(repo.table.updated, Date.now() - 30 * 24 * 60 * 60 * 1000)
      )
    );

  if (oldMeetings.length === 0) return { updated: 0 };

  const ids = oldMeetings.map(m => m.id);
  const updated = await db
    .update(repo.table)
    .set({ status: MeetingStatus.MISSING })
    .where(inArray(repo.table.id, ids))
    .returning();

  return { updated: updated.length };
});
```

---

## Performance Tips

### 1. Use Bulk Operations Over Individual Inserts

```typescript
// ❌ SLOW - Individual inserts (N queries)
for (const meeting of meetings) {
  await db.insert(meetings).values(meeting);
}

// ✅ FAST - Bulk insert (1 query)
await meetingRepo.bulkInsert(meetings);
```

### 2. Use Batch Status Updates Over Individual Updates

```typescript
// ❌ SLOW - Individual updates (N queries)
for (const id of ids) {
  await db.update(meetings)
    .set({ status: MeetingStatus.MISSING })
    .where(eq(meetings.id, id));
}

// ✅ FAST - Batch update (1 query)
await meetingRepo.batchStatusUpdate(ids, MeetingStatus.MISSING);
```

### 3. Use Upsert for Idempotent Operations

```typescript
// ✅ Upsert handles both insert and update
await meetingRepo.bulkUpsert(scrapedMeetings);

// No need to check existence first
```

### 4. Use Transactions for Related Updates

```typescript
await db.transaction(async (tx) => {
  // All succeed or all fail
  await meetingRepo.batchUpdate(meetingUpdates);
  await scheduleRepo.batchUpdate(scheduleUpdates);
});
```

---

## Error Handling

All repository methods return `Result<T, E>` types:

```typescript
const result = await meetingRepo.bulkInsert(meetings);

// Pattern matching
result.match(
  (inserted) => console.log('Success:', inserted),
  (error) => console.error('Error:', error.message)
);

// Conditional handling
if (result.ok) {
  const meetings = result.value;
  // Process meetings
} else {
  const error = result.error;
  console.error('Failed:', error.message);
  console.error('Cause:', error.cause);
}

// Unwrap (throws if error)
const meetings = result.unwrap(); // Use with caution
```

---

## Audit Logging

Database triggers automatically log all changes to `meetings_history` table:

```sql
-- Automatic audit logging via triggers
INSERT INTO meetings VALUES (...);   -- Logged as 'INSERT'
UPDATE meetings SET status = 'DELETED' WHERE id = '...';  -- Logged as 'UPDATE'
DELETE FROM meetings WHERE id = '...';  -- Logged as 'DELETE'
```

**Query audit history:**

```typescript
import { db } from './db';
import { meeting_histories } from '@recoverysky-org/common';

// Find all changes to a specific meeting
const history = await db
  .select()
  .from(meeting_histories)
  .where(eq(meeting_histories.mid, 'meeting-123'))
  .orderBy(meeting_histories.changed_at);

// See what changed
history.forEach(record => {
  console.log(`${record.operation} at ${new Date(record.changed_at)}`);
  if (record.operation === 'UPDATE') {
    console.log('Changed fields:', record.changed_fields);
  }
});
```

---

## TypeScript Support

All repositories are fully typed:

```typescript
import type { meeting, schedule } from '@recoverysky-org/common';

// Autocomplete for changes
const changes: Partial<meeting> = {
  name: 'Updated Name',
  status: MeetingStatus.ACTIVE,
  // TypeScript ensures only valid fields
};

// Type inference
const result = await meetingRepo.findById('123');
if (result.ok && result.value) {
  // result.value is typed as meeting | null
  const name: string = result.value.name;
}
```

---

## Additional Resources

- [Validation Guide](./VALIDATION.md) - Runtime validation with Zod
- [Schema Generation](./schema-generation.md) - How schemas are generated
- [Architecture](./architecture.md) - Overall library design
- [Drizzle ORM Docs](https://orm.drizzle.team) - Official Drizzle documentation
