# Runtime Validation Guide

## Overview

`@recoverysky-org/common` includes comprehensive runtime validation using [Zod v4](https://zod.dev/), providing type-safe validation for all meeting and schedule data. Validation is **automatically integrated** into the `Meeting.update()` and `Schedule.update()` methods, but schemas are also exported for standalone use.

## Why Zod?

- ✅ **Type-safe** - Zod schemas automatically infer TypeScript types
- ✅ **Lightweight** - Only ~8KB (vs Ajv's ~140KB)
- ✅ **Comprehensive** - 40+ validation rules across all fields
- ✅ **Developer-friendly** - Clear, actionable error messages
- ✅ **Zero config** - Bundled as a dependency, consumers don't install separately

## Quick Start

### Automatic Validation (Recommended)

Validation happens automatically when you call `update()`:

```typescript
import { Meeting } from '@recoverysky-org/common';

const meeting = Meeting.create().unwrap();
meeting.name = 'AA Meeting';
meeting.fellowship = 'AA';
meeting.zid = '123'; // Too short!

const result = await meeting.update();
if (!result.ok) {
  console.error(result.error.message);
  // "Validation failed: zid: Zoom ID must be at least 9 digits"
}
```

### Standalone Validation

Use the schemas directly for validation without updating:

```typescript
import { meetingZodSchema } from '@recoverysky-org/common';

const validationResult = meetingZodSchema.safeParse(meeting);
if (!validationResult.success) {
  console.error(validationResult.error.format());
  // Detailed error breakdown by field
}
```

## Available Schemas

### Meeting Schemas

```typescript
import {
  meetingZodSchema,        // Full validation
  meetingPartialSchema,    // Partial updates
  meetingCreateSchema,     // New meeting creation
  meetingUpdateSchema,     // Update validation (used in .update())
} from '@recoverysky-org/common';
```

### Schedule Schemas

```typescript
import {
  scheduleZodSchema,       // Full validation
  schedulePartialSchema,   // Partial updates
  scheduleCreateSchema,    // New schedule creation
  scheduleUpdateSchema,    // Update validation (used in .update())
  occurrenceZodSchema,     // Occurrence validation
} from '@recoverysky-org/common';
```

## Validation Helper Functions

The library provides convenient helper functions that wrap the Zod schemas for easier validation:

### Meeting Helpers

```typescript
import {
  validateMeeting,          // Validate single meeting
  validateMeetings,         // Batch validate meetings
  type BatchValidationError,
  type BatchValidationResult,
} from '@recoverysky-org/common';
```

#### `validateMeeting(data: Partial<meeting>): Result<meeting, z.ZodError>`

Validates a single meeting using `meetingCreateSchema`. Returns a `Result` containing either the validated meeting or a Zod error.

**Example:**
```typescript
import { validateMeeting } from '@recoverysky-org/common';

const meetingData = {
  zid: '123456789',
  name: 'Monday Night Big Book',
  fellowship: 'AA',
  millis70s: 259200000, // Thursday 00:00 in That70s format
  duration: 3600000, // 1 hour
  timezone: 'America/New_York',
  time: '19:00',
  hour: 19,
  minute: 0,
};

const result = validateMeeting(meetingData);
if (result.ok) {
  console.log('Valid meeting:', result.value);
  await saveMeeting(result.value);
} else {
  // result.error is z.ZodError with detailed issues
  result.error.issues.forEach(issue => {
    console.error(`${issue.path.join('.')}: ${issue.message}`);
  });
}
```

**Using Result pattern matching:**
```typescript
const result = validateMeeting(data);
result.match(
  (validMeeting) => saveMeeting(validMeeting),
  (error) => {
    error.issues.forEach(issue => {
      console.error(`${issue.path.join('.')}: ${issue.message}`);
    });
  }
);
```

#### `validateMeetings(meetings: Partial<meeting>[]): Result<BatchValidationResult<meeting>, Error>`

Validates multiple meetings in batch. Unlike sequential validation that stops at the first error, this collects both valid and invalid results.

**Returns:**
```typescript
{
  valid: meeting[],           // Successfully validated meetings
  invalid: Array<{            // Failed validations with context
    index: number,            // Index in original array
    data: Partial<meeting>,   // Original data that failed
    errors: z.ZodIssue[]      // Zod validation errors
  }>
}
```

**Example:**
```typescript
import { validateMeetings } from '@recoverysky-org/common';

const meetingsToValidate = [
  {
    zid: '123456789',
    name: 'Valid Meeting',
    fellowship: 'AA',
    millis70s: 259200000,
    duration: 3600000,
    // ... complete valid data
  },
  {
    zid: 'invalid', // Invalid: not numeric
    name: 'Invalid Meeting',
    // ... missing required fields
  },
  {
    zid: '987654321',
    name: 'Another Valid Meeting',
    fellowship: 'NA',
    millis70s: 345600000,
    duration: 3600000,
    // ... complete valid data
  }
];

const result = validateMeetings(meetingsToValidate);
if (result.ok) {
  const { valid, invalid } = result.value;
  console.log(`Successfully validated ${valid.length} meetings`);
  console.log(`Failed to validate ${invalid.length} meetings`);

  // Process valid meetings
  await Promise.all(valid.map(m => saveMeeting(m)));

  // Report invalid meetings
  invalid.forEach(({ index, data, errors }) => {
    console.error(`Meeting at index ${index} (${data.name}) failed:`);
    errors.forEach(err => {
      console.error(`  - ${err.path.join('.')}: ${err.message}`);
    });
  });
}
```

### Schedule Helpers

```typescript
import {
  validateSchedule,         // Validate single schedule
  validateSchedules,        // Batch validate schedules
} from '@recoverysky-org/common';
```

#### `validateSchedule(data: Partial<schedule>): Result<schedule, z.ZodError>`

Validates a single schedule using `scheduleCreateSchema`.

**Example:**
```typescript
import { validateSchedule } from '@recoverysky-org/common';

const scheduleData = {
  zid: '123456789',
  name: 'Weekly AA Meetings',
  mids: ['mid1', 'mid2', 'mid3'],
  uids: ['uid1', 'uid2', 'uid3'],
  occurrences: [
    {
      mid: 'mid1',
      dayOfWeek: 'Monday',
      millis70s: 259200000,
      duration: 3600000
    }
  ],
  dailyStartDateTime: -1,
};

const result = validateSchedule(scheduleData);
if (result.ok) {
  console.log('Valid schedule:', result.value);
  await saveSchedule(result.value);
} else {
  console.error('Validation failed:', result.error.issues);
}
```

**Using unwrapOr:**
```typescript
const result = validateSchedule(scheduleData);
const schedule = result.unwrapOr(null);
if (schedule) {
  await saveSchedule(schedule);
}
```

#### `validateSchedules(schedules: Partial<schedule>[]): Result<BatchValidationResult<schedule>, Error>`

Validates multiple schedules in batch, collecting both valid and invalid results.

**Example:**
```typescript
import { validateSchedules } from '@recoverysky-org/common';

const schedulesToValidate = [
  {
    zid: '123456789',
    name: 'Valid Schedule',
    mids: ['mid1'],
    uids: ['uid1'],
    occurrences: [],
    dailyStartDateTime: -1,
  },
  {
    zid: 'invalid',  // Invalid: not numeric
    name: 'Invalid Schedule',
  },
];

const result = validateSchedules(schedulesToValidate);
result.match(
  ({ valid, invalid }) => {
    console.log(`Valid: ${valid.length}, Invalid: ${invalid.length}`);

    // Process valid schedules
    valid.forEach(s => saveSchedule(s));

    // Generate error report
    invalid.forEach(({ index, data, errors }) => {
      console.error(`Schedule "${data.name}" at index ${index}:`);
      errors.forEach(err => {
        console.error(`  - ${err.path.join('.')}: ${err.message}`);
      });
    });
  },
  (error) => console.error('Batch validation error:', error)
);
```

### When to Use Helper Functions vs Direct Schemas

**Use Helper Functions when:**
- ✅ Validating external data (API responses, user input, imports)
- ✅ Batch validation where you need to collect all errors
- ✅ You want Result<T, E> pattern for error handling
- ✅ You need logging of validation failures

**Use Direct Schemas when:**
- ✅ Integrating with form libraries (React Hook Form, Formik)
- ✅ You need the raw Zod schema object (e.g., for .shape, .extend())
- ✅ Custom validation pipelines with transforms
- ✅ Type inference with `z.infer<typeof schema>`

**Example using both:**
```typescript
import { validateMeetings, meetingZodSchema } from '@recoverysky-org/common';

// Batch validation with helper
const batchResult = validateMeetings(scrapedMeetings);

// Direct schema for custom logic
const customSchema = meetingZodSchema.extend({
  customField: z.string().optional()
});
```

## Validation Rules

### Meeting Field Validation

#### Identity Fields
```typescript
id: z.string().min(1, "ID is required")

sid: z.string().min(1, "Schedule ID is required")

iid: z.string().nullable()  // Optional import ID

uid: z.string().min(1, "UID is required")

zid: z.string()
  .min(9, "Zoom ID must be at least 9 digits")
  .max(11, "Zoom ID must be at most 11 digits")
  .regex(/^\d+$/, "Zoom ID must contain only digits")
```

#### Status and Verification
```typescript
status: z.nativeEnum(MeetingStatus, {
  message: "Invalid meeting status. Must be INVALID, ACTIVE, PAUSED, or DELETED"
})

verified: z.boolean()
```

#### Timestamps
```typescript
created: z.number()
  .int("Created timestamp must be an integer")
  .nonnegative("Created timestamp must be non-negative")

updated: z.number()
  .int("Updated timestamp must be an integer")
  .nonnegative("Updated timestamp must be non-negative")
```

#### Meeting Classification
```typescript
fellowship: z.string()
  .min(1, "Fellowship is required")
  .max(50, "Fellowship name too long")

meetingTypes: z.array(z.string())
  .min(1, "At least one meeting type is required")

language: z.string()
  .min(2, "Language code must be at least 2 characters")
  .max(10, "Language code too long")
  .regex(/^[a-z]{2}(-[A-Z]{2})?$/, "Invalid language code format (e.g., 'en', 'es', 'en-US')")
```

#### Scheduling
```typescript
millis70s: z.number()
  .int("Start datetime must be an integer")
  .min(0, "Start datetime must be non-negative (That70s timestamp)")
  .max(604800000, "Start datetime must be within epoch week (0-604800000ms)")

duration: z.number()
  .int("Duration must be an integer")
  .positive("Duration must be positive")
  .max(86400000, "Duration cannot exceed 24 hours (86400000ms)")

timezone: z.string()
  .min(1, "Timezone is required")
  .regex(/^[A-Za-z_]+\/[A-Za-z_]+$/, "Invalid timezone format (e.g., 'America/New_York')")

time: z.string()
  .regex(/^([01]\d|2[0-3]):([0-5]\d)$/, "Invalid time format. Must be HH:MM in 24h format")
```

#### Contact Information
```typescript
email: z.string()
  .email("Invalid email address")
  .or(z.literal(""))

url: z.string().url("Must be a valid URL")

website: z.string()
  .url("Invalid website URL")
  .or(z.literal(""))

name: z.string()
  .min(1, "Meeting name is required")
  .max(200, "Meeting name too long (max 200 characters)")
```

#### Data Integrity
```typescript
sha256: z.string()
  .length(64, "SHA256 hash must be 64 characters")
  .regex(/^[a-f0-9]{64}$/, "SHA256 hash must be lowercase hexadecimal")
  .or(z.literal(""))
```

### Cross-Field Validation

```typescript
// updated >= created
.refine((data) => data.updated >= data.created, {
  message: "Updated timestamp must be >= created timestamp",
  path: ["updated"]
})

// Time components match
.refine((data) => {
  const [hours, minutes] = data.time.split(':').map(Number);
  return hours === data.hour && minutes === data.minute;
}, {
  message: "Time string must match hour and minute values",
  path: ["time"]
})

// Restricted meetings need description
.refine((data) => {
  if (data.restricted && !data.restrictedDescription) {
    return false;
  }
  return true;
}, {
  message: "Restricted meetings must have a restrictedDescription",
  path: ["restrictedDescription"]
})
```

## Common Use Cases

### 1. Validate Before Saving

```typescript
import { Meeting, meetingZodSchema } from '@recoverysky-org/common';

const meeting = Meeting.create().unwrap();
meeting.name = 'Monday Night Big Book';
meeting.fellowship = 'AA';
meeting.zid = '123456789';
meeting.millis70s = 86400000; // Thursday 00:00 in That70s time

// Validate before update
const validation = meetingZodSchema.safeParse(meeting);
if (validation.success) {
  await meeting.update(); // Will also validate
} else {
  console.error('Validation errors:', validation.error.format());
}
```

### 2. Validate User Input

```typescript
import { meetingPartialSchema } from '@recoverysky-org/common';

// Validate partial updates from user form
const userInput = {
  name: 'New Meeting Name',
  duration: 3600000,
  email: 'contact@example.com'
};

const validation = meetingPartialSchema.safeParse(userInput);
if (validation.success) {
  Object.assign(meeting, validation.data);
} else {
  // Show errors to user
  const errors = validation.error.issues.map(e => ({
    field: e.path.join('.'),
    message: e.message
  }));
  console.error(errors);
}
```

### 3. Validate API Responses

```typescript
import { meetingZodSchema } from '@recoverysky-org/common';

async function fetchMeeting(id: string) {
  const response = await fetch(`/api/meetings/${id}`);
  const data = await response.json();

  // Validate external data
  const validation = meetingZodSchema.safeParse(data);
  if (!validation.success) {
    throw new Error(`Invalid meeting data: ${validation.error.message}`);
  }

  return validation.data; // Type-safe!
}
```

### 4. Batch Validation

```typescript
import { meetingZodSchema } from '@recoverysky-org/common';

async function validateBatch(meetings: unknown[]) {
  const results = meetings.map((m, index) => {
    const validation = meetingZodSchema.safeParse(m);
    return {
      index,
      valid: validation.success,
      errors: validation.success ? null : validation.error.issues
    };
  });

  const invalid = results.filter(r => !r.valid);
  if (invalid.length > 0) {
    console.error(`${invalid.length} invalid meetings:`, invalid);
  }

  return results;
}
```

### 5. Form Validation

```typescript
import { meetingCreateSchema } from '@recoverysky-org/common';

// Validate form data before creating meeting
function validateMeetingForm(formData: unknown) {
  const validation = meetingCreateSchema.safeParse(formData);

  if (!validation.success) {
    // Convert Zod errors to form-friendly format
    const fieldErrors: Record<string, string> = {};
    validation.error.issues.forEach(issue => {
      const field = issue.path.join('.');
      fieldErrors[field] = issue.message;
    });
    return { valid: false, errors: fieldErrors };
  }

  return { valid: true, data: validation.data };
}
```

## Error Handling

### Understanding Zod Errors

```typescript
const result = meetingZodSchema.safeParse(invalidData);
if (!result.success) {
  // result.error is ZodError

  // Array of individual issues
  result.error.issues.forEach(issue => {
    console.log(issue.path);      // ['name']
    console.log(issue.message);   // "Meeting name is required"
    console.log(issue.code);      // "too_small"
  });

  // Formatted nested object
  const formatted = result.error.format();
  console.log(formatted.name?._errors); // ["Meeting name is required"]

  // Flattened object
  const flattened = result.error.flatten();
  console.log(flattened.fieldErrors.name); // ["Meeting name is required"]
}
```

### Custom Error Messages

```typescript
import { meetingZodSchema } from '@recoverysky-org/common';

function validateWithCustomErrors(data: unknown) {
  const result = meetingZodSchema.safeParse(data);

  if (!result.success) {
    const customErrors = result.error.issues.map(issue => {
      const field = issue.path.join('.');
      return `⚠️ ${field}: ${issue.message}`;
    }).join('\n');

    throw new Error(`Validation failed:\n${customErrors}`);
  }

  return result.data;
}
```

## Integration with RxDB

When using RxDB, validate data before insertion:

```typescript
import { meetingZodSchema } from '@recoverysky-org/common';
import { Meeting } from '@recoverysky-org/common';

async function insertMeeting(db: RxDatabase, data: unknown) {
  // Validate with Zod first
  const validation = meetingZodSchema.safeParse(data);
  if (!validation.success) {
    throw new Error(`Invalid meeting: ${validation.error.message}`);
  }

  // Insert validated data
  const doc = await db.meetings.insert(validation.data);

  // Convert to class for business logic
  const meeting = Object.assign(new Meeting(), doc.toJSON());
  return meeting;
}
```

## Integration with Drizzle

Validate before database insertion:

```typescript
import { meetingZodSchema } from '@recoverysky-org/common';
import { meetings } from '@recoverysky-org/common/lib/models/drizzle/meetings.drizzle';

async function saveMeeting(db: DrizzleDB, data: unknown) {
  // Validate with Zod
  const validation = meetingZodSchema.safeParse(data);
  if (!validation.success) {
    throw new Error(`Validation failed: ${validation.error.message}`);
  }

  // Insert into PostgreSQL
  const [inserted] = await db
    .insert(meetings)
    .values(validation.data)
    .returning();

  return inserted;
}
```

## Performance Considerations

### Caching Schemas

Zod schemas are reusable - they don't need to be recreated:

```typescript
import { meetingZodSchema } from '@recoverysky-org/common';

// ✅ Good - reuse imported schema
for (const data of largeBatch) {
  meetingZodSchema.safeParse(data);
}

// ❌ Bad - don't recreate schemas
for (const data of largeBatch) {
  const schema = z.object({...}); // Wasteful!
  schema.safeParse(data);
}
```

### Partial Validation for Large Objects

For better performance on large datasets, validate only changed fields:

```typescript
import { meetingPartialSchema } from '@recoverysky-org/common';

// Only validate the fields that changed
const updates = { name: 'New Name', duration: 7200000 };
const validation = meetingPartialSchema.safeParse(updates);

if (validation.success) {
  Object.assign(meeting, validation.data);
}
```

### Async Validation

Zod validation is synchronous, but you can wrap it:

```typescript
async function validateAsync(data: unknown) {
  return new Promise((resolve, reject) => {
    const result = meetingZodSchema.safeParse(data);
    if (result.success) {
      resolve(result.data);
    } else {
      reject(result.error);
    }
  });
}
```

## TypeScript Integration

### Type Inference

Zod schemas automatically infer TypeScript types:

```typescript
import { meetingZodSchema, type MeetingZod } from '@recoverysky-org/common';

// MeetingZod is inferred from the schema
const meeting: MeetingZod = {
  id: '123',
  name: 'AA Meeting',
  // ... all required fields
};

// Or extract the type
type InferredMeeting = z.infer<typeof meetingZodSchema>;
```

### Type Guards

Use Zod for runtime type guards:

```typescript
function isMeeting(data: unknown): data is MeetingZod {
  return meetingZodSchema.safeParse(data).success;
}

if (isMeeting(unknownData)) {
  // TypeScript knows this is MeetingZod
  console.log(unknownData.name);
}
```

## Best Practices

### ✅ Do

- **Use automatic validation** - Let `update()` handle validation
- **Validate user input** - Always validate data from external sources
- **Use partial schemas** - Validate only changed fields when updating
- **Handle errors gracefully** - Provide clear error messages to users
- **Reuse schemas** - Import schemas instead of recreating them
- **Type inference** - Use `z.infer<>` or exported types

### ❌ Don't

- **Don't skip validation** - Always call `update()` before saving
- **Don't modify schemas** - Use the exported schemas as-is
- **Don't validate internal data** - Trust data from `Meeting.create()`
- **Don't ignore errors** - Always check `result.ok` or handle exceptions
- **Don't recreate schemas** - Import once, reuse everywhere

## Troubleshooting

### Issue: "Validation failed but data looks correct"

Check for type mismatches:

```typescript
// ❌ Wrong - string instead of number
meeting.millis70s = "86400000";

// ✅ Correct - number
meeting.millis70s = 86400000;
```

### Issue: "Enum validation fails"

Make sure you're using the correct enum value:

```typescript
import { MeetingStatus } from '@recoverysky-org/common';

// ❌ Wrong - string literal
meeting.status = "ACTIVE";

// ✅ Correct - enum value
meeting.status = MeetingStatus.ACTIVE;
```

### Issue: "Cross-field validation fails"

Ensure related fields are consistent:

```typescript
// ❌ Wrong - updated < created
meeting.created = 100000;
meeting.updated = 50000;

// ✅ Correct - updated >= created
meeting.created = 100000;
meeting.updated = 150000;
```

## Advanced Usage

### Custom Refinements

While the exported schemas cover all validation needs, you can add custom refinements:

```typescript
import { meetingZodSchema } from '@recoverysky-org/common';

const customSchema = meetingZodSchema.refine(
  (data) => {
    // Custom business rule
    return data.duration >= 3600000; // At least 1 hour
  },
  {
    message: "Meetings must be at least 1 hour long",
    path: ["duration"]
  }
);
```

### Transformations

Transform data during validation:

```typescript
const transformSchema = meetingZodSchema.transform((data) => ({
  ...data,
  name: data.name.trim().toUpperCase()
}));

const result = transformSchema.safeParse(meeting);
// result.data.name is now trimmed and uppercase
```

### Conditional Validation

Add validation based on other fields:

```typescript
const conditionalSchema = meetingZodSchema.superRefine((data, ctx) => {
  if (data.requiresLogin && !data.password) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "Password required when login is required",
      path: ["password"]
    });
  }
});
```

## Migration Guide

If you were validating manually before, here's how to migrate:

### Before (Manual Validation)

```typescript
function validateMeeting(m: any) {
  if (!m.name || m.name.length < 1) {
    throw new Error('Name is required');
  }
  if (!m.zid || m.zid.length < 9) {
    throw new Error('Invalid Zoom ID');
  }
  // ... many more checks
}
```

### After (Zod Validation)

```typescript
import { meetingZodSchema } from '@recoverysky-org/common';

const result = meetingZodSchema.safeParse(m);
if (!result.success) {
  throw new Error(result.error.message);
}
// All validation done!
```

## Summary

Zod validation in `@recoverysky-org/common` provides:

- ✅ **Automatic validation** in `update()` methods
- ✅ **40+ validation rules** across all fields
- ✅ **Type-safe** with TypeScript inference
- ✅ **Lightweight** at ~8KB
- ✅ **Flexible** schemas for different use cases
- ✅ **Clear errors** with actionable messages
- ✅ **Zero config** - bundled and ready to use

For more details, see:
- [Zod Documentation](https://zod.dev/)
- [Consumer Guide](./consumer-guide.md)
- [Architecture Guide](./architecture.md)
