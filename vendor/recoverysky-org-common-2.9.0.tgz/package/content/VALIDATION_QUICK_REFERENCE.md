# Validation Quick Reference

## What Gets Exported

```typescript
// === From src/utils/validation.ts ===
export function validateMeeting(data: Partial<meeting>): Result<meeting, ZodError>
export function validateMeetings(data: Partial<meeting>[]): Result<BatchValidationResult<meeting>, Error>
export function validateSchedule(data: Partial<schedule>): Result<schedule, ZodError>
export function validateSchedules(data: Partial<schedule>[]): Result<BatchValidationResult<schedule>, Error>
export interface BatchValidationError<T>
export interface BatchValidationResult<T>

// === From src/models/zod/meeting.zod.ts ===
export const meetingZodSchema: ZodObject<...>
export const meetingCreateSchema: ZodObject<...>
export const meetingUpdateSchema: ZodObject<...>
export const meetingPartialSchema: ZodObject<...>
export type MeetingZod = z.infer<typeof meetingZodSchema>

// === From src/models/zod/schedule.zod.ts ===
export const scheduleZodSchema: ZodObject<...>
export const scheduleCreateSchema: ZodObject<...>
export const scheduleUpdateSchema: ZodObject<...>
export const schedulePartialSchema: ZodObject<...>
export type ScheduleZod = z.infer<typeof scheduleZodSchema>
export const occurrenceZodSchema: ZodObject<...>
export type OccurrenceZod = z.infer<typeof occurrenceZodSchema>
```

## Two Ways to Import and Use

### Option A: Helper Functions (Recommended)

```typescript
import { validateMeeting, validateMeetings } from '@recoverysky-org/common';

// Single
const result = validateMeeting(data);
if (result.ok) {
  console.log('Valid:', result.value);
} else {
  console.error('Errors:', result.error.issues);
}

// Batch
const batchResult = validateMeetings(dataArray);
if (batchResult.ok) {
  const { valid, invalid } = batchResult.value;
  console.log(`${valid.length} valid, ${invalid.length} invalid`);
}
```

**Exported from:** `src/utils/validation.ts`

**Returns:** `Result<T, ZodError>` type (ts-rust-result pattern)

**Best for:**
- ✅ Most use cases
- ✅ Batch validation
- ✅ Consistent error handling
- ✅ Clean Result pattern workflow

### Option B: Zod Schemas Directly

```typescript
import { meetingCreateSchema } from '@recoverysky-org/common';

// Using safeParse (no exceptions)
const result = meetingCreateSchema.safeParse(data);
if (result.success) {
  console.log('Valid:', result.data);
} else {
  console.error('Errors:', result.error.issues);
}

// Using parse (throws exceptions)
try {
  const validated = meetingCreateSchema.parse(data);
} catch (error) {
  // handle error
}
```

**Exported from:** `src/models/zod/meeting.zod.ts` and `src/models/zod/schedule.zod.ts`

**Returns:** `ZodParseResult<T>` type (native Zod)

**Best for:**
- ✅ Form validation (react-hook-form, etc.)
- ✅ Custom validation pipelines
- ✅ Type inference
- ✅ When you prefer native Zod API

## Which Schema to Use?

| Schema | Use Case | Required Fields |
|--------|----------|-----------------|
| `meetingZodSchema` | Validating complete meeting objects | All fields required |
| `meetingCreateSchema` | Creating new meetings (user input) | zid, name, fellowship, millis70s, periodicity, endMillis70s |
| `meetingUpdateSchema` | Updating existing meetings | zid, millis70s (identifiers only) |
| `meetingPartialSchema` | Any partial meeting object | None (all optional) |

Same structure for schedules: `scheduleZodSchema`, `scheduleCreateSchema`, `scheduleUpdateSchema`, `schedulePartialSchema`

## Error Output Comparison

### Using Helper Function
```typescript
const result = validateMeeting(data);

if (!result.ok) {
  result.error.issues.forEach(issue => {
    console.log({
      path: issue.path.join('.'),
      message: issue.message,
      code: issue.code, // 'invalid_type', 'too_small', 'invalid_string', etc.
      received: issue.received, // actual value type
      expected: issue.expected  // expected value type
    });
  });
}
```

### Using Zod Schema
```typescript
const result = meetingCreateSchema.safeParse(data);

if (!result.success) {
  result.error.issues.forEach(issue => {
    // Same interface as above
    console.log({
      path: issue.path.join('.'),
      message: issue.message,
      code: issue.code,
      received: issue.received,
      expected: issue.expected
    });
  });
}
```

## Common Validation Scenarios

### Scenario 1: API Endpoint (Create)
```typescript
import { validateMeeting } from '@recoverysky-org/common';

app.post('/meetings', (req, res) => {
  const result = validateMeeting(req.body);

  result.match(
    async (meeting) => {
      const saved = await db.meetings.insert(meeting);
      res.json(saved);
    },
    (error) => {
      res.status(400).json({
        error: 'Validation failed',
        issues: error.issues
      });
    }
  );
});
```

### Scenario 2: Bulk Import
```typescript
import { validateMeetings } from '@recoverysky-org/common';

async function importCsv(file: File) {
  const meetings = await parseCsv(file);
  const result = validateMeetings(meetings);

  if (result.ok) {
    const { valid, invalid } = result.value;

    // Save valid ones
    await db.meetings.insertMany(valid);

    // Report errors
    invalid.forEach(({ index, errors }) => {
      console.warn(`Row ${index + 1}: ${errors[0].message}`);
    });
  }
}
```

### Scenario 3: React Form
```typescript
import { meetingCreateSchema } from '@recoverysky-org/common';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';

export function MeetingForm() {
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(meetingCreateSchema),
    mode: 'onBlur'
  });

  return (
    <form onSubmit={handleSubmit(async (data) => {
      // data is automatically type-validated by Zod
      await api.meetings.create(data);
    })}>
      <input {...register('name')} />
      {errors.name && <span>{errors.name.message}</span>}
      {/* ... more fields ... */}
    </form>
  );
}
```

### Scenario 4: Database Query Result
```typescript
import { validateMeeting } from '@recoverysky-org/common';

async function fetchAndValidate(id: string) {
  // Always validate data from external sources
  const row = await db.query('SELECT * FROM meetings WHERE id = ?', [id]);
  const result = validateMeeting(row);

  return result; // Result<meeting, ZodError>
}
```

## Error Codes You'll See

Common Zod error codes for the Zoom URL validation:

```typescript
// Zoom URL validation errors
"invalid_string"  // URL doesn't match regex pattern
"invalid_type"    // Field is wrong type (string vs number, etc.)
"too_small"       // ZID is less than 9 digits
"too_big"         // ZID is more than 11 digits
"invalid_enum"    // Status/verified field has invalid value
"custom"          // Cross-field validation failed (e.g., sid missing but status not INVALID)
```

## Implementation Checklist

When implementing validation in your code:

- [ ] Import `validateMeeting` or Zod schema
- [ ] Call validation BEFORE saving to database
- [ ] Check `result.ok` or `result.success`
- [ ] Handle errors by showing to user or logging
- [ ] For batch ops, process valid and invalid separately
- [ ] Cache validation results if validating same data multiple times

## Performance Tips

1. **Validate at entry points only** - Don't validate in loops
2. **Batch validate when possible** - `validateMeetings([...])` is efficient
3. **Cache results** - Don't re-validate same data
4. **Validate async operations separately** - Use Promise.all() for parallel validation
5. **Use schemas directly for forms** - Less overhead than helper functions

## Troubleshooting

### "Validation passed but TypeScript still complains"
```typescript
// ❌ Wrong
const result = validateMeeting(data);
const meeting: meeting = result.value; // Error: might be undefined

// ✅ Correct
if (result.ok) {
  const meeting: meeting = result.value; // OK: result is narrowed
}
```

### "Can't figure out which schema to use"
- **Creating new?** → Use `*CreateSchema`
- **Updating existing?** → Use `*UpdateSchema`
- **Validating unknown data?** → Use helper function (`validateMeeting`)
- **Full validation?** → Use `*ZodSchema` directly

### "Need custom validation logic"
```typescript
// Extend the schema
const customSchema = meetingCreateSchema.extend({
  customField: z.string().optional()
}).refine(
  (data) => yourCustomLogic(data),
  { message: "Custom validation failed" }
);

// Use it
const result = customSchema.safeParse(data);
```

## See Also

- **Full Guide:** `HOW_VALIDATION_WORKS.md`
- **Implementation:** `src/utils/validation.ts`
- **Meeting Schema:** `src/models/zod/meeting.zod.ts`
- **Schedule Schema:** `src/models/zod/schedule.zod.ts`
- **Content:** `content/VALIDATION.md`
