# How Zod Validation Works in @recoverysky-org/common

## Overview

**Zod validation is NOT automatic.** It must be explicitly called by consumers. The library provides Zod schemas and helper functions, but validation only happens when you invoke them.

## Two Approaches to Validation

### Option 1: Using Helper Functions (Recommended) ✅

The library provides convenience functions that wrap Zod schemas and return Result types:

```typescript
import { validateMeeting, validateMeetings } from '@recoverysky-org/common';

// Single meeting validation
const result = validateMeeting({
  zid: '123456789',
  name: 'Monday Night AA',
  fellowship: 'AA',
  millis70s: 259200000,
  duration: 3600000,
  timezone: 'America/New_York',
  url: 'https://zoom.us/j/123456789',
  // ... other fields
});

if (result.ok) {
  console.log('Valid meeting:', result.value);
  // Use the validated meeting
} else {
  console.error('Validation failed:', result.error);
  // result.error is a Zod error with issues array
  result.error.issues.forEach(issue => {
    console.error(`${issue.path.join('.')}: ${issue.message}`);
  });
}
```

**Benefits:**
- ✅ Returns `Result<T, ZodError>` type for clean error handling
- ✅ Automatic console logging of validation errors (helpful for debugging)
- ✅ Handles both success and failure cases uniformly
- ✅ Type-safe - result.value is properly typed
- ✅ Works with ts-rust-result pattern used throughout the library

### Option 2: Using Zod Schemas Directly

If you prefer direct Zod usage (e.g., for form validation):

```typescript
import { meetingZodSchema, meetingCreateSchema } from '@recoverysky-org/common';

// Using safeParse (recommended - no exceptions)
const result = meetingZodSchema.safeParse(meetingData);

if (result.success) {
  console.log('Valid:', result.data);
} else {
  console.error('Invalid:', result.error);
  result.error.issues.forEach(issue => {
    console.log(`${issue.path.join('.')}: ${issue.message}`);
  });
}

// Using parse (throws on error)
try {
  const validated = meetingZodSchema.parse(meetingData);
  // Use validated meeting
} catch (error) {
  if (error instanceof z.ZodError) {
    // Handle validation errors
  }
}
```

**When to use direct schemas:**
- Form validation in React with react-hook-form
- Custom validation pipelines with transforms
- Type inference with `z.infer<typeof schema>`
- When you don't want Result pattern overhead

## Three Schema Variants

The library exports three Zod schemas for meetings:

### 1. `meetingZodSchema` - Full schema
```typescript
import { meetingZodSchema } from '@recoverysky-org/common';

// Validates COMPLETE meeting objects with ALL required fields
const result = meetingZodSchema.safeParse(completeData);
```

**Required fields:**
- id, sid, uid, zid
- status, verified
- created, updated
- url, password, passwordEnc
- fellowship, meetingTypes, language
- closed, requiresLogin, restricted
- periodicity, millis70s, duration, endMillis70s, timezone, dow
- description, email, name, phone, website, conferencePhone
- notes, tags, location
- sha256
- Plus optional: iid, restrictedDescription

### 2. `meetingCreateSchema` - Creation schema
```typescript
import { meetingCreateSchema } from '@recoverysky-org/common';

// Validates PARTIAL data for creating new meetings
// System fields (id, uid, sid, created, updated, sha256) are auto-generated
const result = meetingCreateSchema.safeParse({
  zid: '123456789',
  name: 'Monday Night AA',
  fellowship: 'AA',
  millis70s: 259200000,
  periodicity: 2,
  endMillis70s: 262800000,
  // ... other optional fields
});
```

**Only requires:**
- zid
- name
- fellowship
- millis70s
- periodicity
- endMillis70s

**Everything else optional**, including:
- url, password, passwordEnc
- status, verified
- description, email, phone, website, etc.

### 3. `meetingUpdateSchema` - Update schema
```typescript
import { meetingUpdateSchema } from '@recoverysky-org/common';

// Validates PARTIAL data for updates
// Only requires critical fields that identify the meeting
const result = meetingUpdateSchema.safeParse({
  zid: '123456789', // Required
  millis70s: 259200000, // Required
  // ... other optional fields to update
});
```

**Only requires:**
- zid
- millis70s

## Validation Helper Functions

### Validate Single Meeting
```typescript
import { validateMeeting } from '@recoverysky-org/common';

const result = validateMeeting({
  zid: '123456789',
  name: 'Meeting Name',
  fellowship: 'AA',
  // ...
});

result.match(
  (validMeeting) => {
    // Success - type is 'meeting'
    saveMeeting(validMeeting);
  },
  (zodError) => {
    // Error - handle Zod validation issues
    zodError.issues.forEach(issue => {
      console.error(`${issue.path.join('.')}: ${issue.message}`);
    });
  }
);
```

### Validate Multiple Meetings (Batch)
```typescript
import { validateMeetings } from '@recoverysky-org/common';

const meetings = [
  { /* meeting 1 */ },
  { /* meeting 2 */ },
  { /* meeting 3 */ }
];

const result = validateMeetings(meetings);

if (result.ok) {
  const { valid, invalid } = result.value;

  console.log(`Valid: ${valid.length}, Invalid: ${invalid.length}`);

  // Process valid meetings
  valid.forEach(meeting => saveMeeting(meeting));

  // Handle invalid ones
  invalid.forEach(({ index, data, errors }) => {
    console.error(`Meeting at index ${index} failed:`);
    errors.forEach(err => {
      console.error(`  - ${err.path.join('.')}: ${err.message}`);
    });
  });
} else {
  console.error('Batch validation failed:', result.error);
}
```

### Validate Single Schedule
```typescript
import { validateSchedule } from '@recoverysky-org/common';

const result = validateSchedule({
  zid: '123456789',
  name: 'Weekly AA Meetings',
  // ...
});
```

### Validate Multiple Schedules
```typescript
import { validateSchedules } from '@recoverysky-org/common';

const result = validateSchedules(scheduleArray);

if (result.ok) {
  const { valid, invalid } = result.value;
  // ...
}
```

## Real-World Examples

### Example 1: Validating Scraped Meeting Data

```typescript
import { validateMeetings } from '@recoverysky-org/common';

async function importMeetingsFromWebsite(meetings: unknown[]) {
  // Validate all scraped meetings in one batch
  const result = validateMeetings(meetings as any[]);

  if (!result.ok) {
    console.error('Batch validation failed:', result.error);
    return;
  }

  const { valid, invalid } = result.value;

  // Save valid meetings
  const saved = await Promise.all(
    valid.map(m => db.meetings.insert(m))
  );

  // Log validation issues for review
  invalid.forEach(({ index, data, errors }) => {
    console.warn(`Meeting ${index} (${data.name}) has validation issues:`, errors);
  });

  return { saved, failed: invalid.length };
}
```

### Example 2: API Endpoint Validation

```typescript
import { validateMeeting } from '@recoverysky-org/common';
import express from 'express';

const app = express();

app.post('/api/meetings', async (req, res) => {
  const result = validateMeeting(req.body);

  result.match(
    async (validMeeting) => {
      // Validation succeeded
      const saved = await db.meetings.insert(validMeeting);
      res.json({ success: true, meeting: saved });
    },
    (zodError) => {
      // Validation failed - send error response
      res.status(400).json({
        error: 'Validation failed',
        issues: zodError.issues.map(issue => ({
          path: issue.path.join('.'),
          message: issue.message,
          code: issue.code
        }))
      });
    }
  );
});
```

### Example 3: Form Validation with React

```typescript
import { meetingCreateSchema } from '@recoverysky-org/common';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';

export function MeetingForm() {
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(meetingCreateSchema),
  });

  return (
    <form onSubmit={handleSubmit(async (data) => {
      // data is automatically validated by zodResolver
      const response = await fetch('/api/meetings', {
        method: 'POST',
        body: JSON.stringify(data)
      });
    })}>
      <input {...register('zid')} />
      {errors.zid && <span>{errors.zid.message}</span>}

      <input {...register('name')} />
      {errors.name && <span>{errors.name.message}</span>}

      {/* ... other fields ... */}
    </form>
  );
}
```

## Export Structure

```typescript
// Validation helpers (recommended)
export { validateMeeting, validateMeetings, validateSchedule, validateSchedules };
export type { BatchValidationError, BatchValidationResult };

// Zod schemas (for direct usage)
export {
  meetingZodSchema,
  meetingCreateSchema,
  meetingUpdateSchema,
  meetingPartialSchema,
  scheduleZodSchema,
  scheduleCreateSchema,
  scheduleUpdateSchema,
  schedulePartialSchema
};

// Zod types
export type { MeetingZod, ScheduleZod, OccurrenceZod };

// Plain data models
export type { meeting, schedule };

// Classes (with business logic)
export { Meeting, Schedule };
```

## Key Points

1. **NOT automatic**: Validation only runs when you explicitly call it
2. **Two approaches**: Helper functions (Result pattern) or direct Zod schemas
3. **Three variants**: Full, create, and update schemas for different use cases
4. **Type-safe**: Results are properly typed, no need for assertions
5. **Error handling**: Zod errors include path, message, and error code
6. **Batch processing**: Can validate multiple items and collect errors
7. **Flexible**: Works with forms, APIs, imports, and manual validation

## When to Validate

- ✅ Before saving to database
- ✅ When receiving data from external sources (API, web scraping, imports)
- ✅ Before passing to functions expecting validated data
- ✅ At API boundaries to ensure request data is valid
- ✅ In forms before submission

## When NOT to Validate

- ❌ Reading from database (data should already be valid)
- ❌ Within database models (redundant if only saving valid data)
- ❌ For performance-critical loops (validate once at entry point)
- ❌ For simple type checks (use TypeScript types instead)

## Error Handling Patterns

### Pattern 1: Result.match() (Recommended)
```typescript
result.match(
  (validData) => { /* success */ },
  (error) => { /* error */ }
);
```

### Pattern 2: if/else
```typescript
if (result.ok) {
  // Use result.value
} else {
  // Handle result.error
}
```

### Pattern 3: Try/catch (with direct schema)
```typescript
try {
  const validated = schema.parse(data);
} catch (error) {
  if (error instanceof z.ZodError) {
    // Handle validation errors
  }
}
```

## Performance Considerations

- Validation runs on every call - cache results if validating same data multiple times
- Batch validation is more efficient than validating items sequentially
- Zod is fast but not instant - validate at entry points, not in tight loops
- For large datasets, validate in chunks rather than all at once

## See Also

- `src/utils/validation.ts` - Helper function implementations
- `src/models/zod/meeting.zod.ts` - Meeting schema definition
- `src/models/zod/schedule.zod.ts` - Schedule schema definition
- `content/VALIDATION.md` - Detailed validation documentation
