# Architecture Guide

## Overview

`@recoverysky-org/common` uses a dual-layer architecture to support both client-side (RxDB) and server-side (Drizzle ORM) database operations while maintaining a single source of truth for data models.

## The Three-Layer Pattern

### Layer 1: Models (Data Types)
**Location**: `src/models/`
**Files**: `meeting.ts`, `schedule.ts`
**Exports**: Lowercase names (`meeting`, `schedule`)

**Purpose**: Plain TypeScript classes that define the data structure. These are serializable, contain no business logic, and serve as the foundation for schema generation.

**Key Characteristics**:
- No methods (except constructor)
- Only property declarations with default values
- JSON-serializable
- Used as base for schema generation pipeline

**Example**:
```typescript
// src/models/meeting.ts
export class meeting {
    id: string = '';
    name: string = '';
    fellowship: string = '';
    // ... more properties
}
```

### Layer 2: Classes (Business Logic)
**Location**: `src/classes/`
**Files**: `Meeting/Meeting.ts`, `Schedule/Schedule.ts`
**Exports**: Uppercase names (`Meeting`, `Schedule`)

**Purpose**: Rich classes that extend the plain models with business logic, factory methods, and computed properties.

**Key Characteristics**:
- Extends the corresponding model (`Meeting extends meeting`)
- Contains methods (`create()`, `update()`, `isStale()`)
- Uses decorators (`@RxModel`, `@addFunctions`)
- Implements business rules and validation

**Example**:
```typescript
// src/classes/Meeting/Meeting.ts
@RxModel("meeting")
export class Meeting extends meeting {
    static create(): MeetingResult<Meeting> { ... }
    async update(): Promise<MeetingResult<void>> { ... }
    isStale(): boolean { ... }
}
```

### Layer 3: Schema Generation
**Location**: `src/models/schema/`, `src/models/json/`, `src/models/rxdb/`, `src/models/drizzle/`
**Generated**: Yes (automated pipeline)

**Purpose**: Auto-generated schemas for different ORM layers from the plain models.

**Pipeline Flow**:
```
models/*.ts
    ↓ (ts-to-schema.ts)
schema/*.schema.ts
    ↓ (ts-to-json.ts)
json/*.json
    ├→ (schema-to-rxdb.ts)
    │  rxdb/*.rxdb.ts
    └→ (json-to-drizzle.ts)
       drizzle/*.drizzle.ts
```

## Why This Architecture?

### The Problem
You need to support **two fundamentally different database systems**:

1. **RxDB** (Client-side)
   - Offline-first, reactive database
   - Requires JSON Schema with specific metadata
   - Document-based (NoSQL-style)
   - Needs: `version`, `primaryKey`, `additionalProperties`

2. **Drizzle ORM** (Server-side)
   - PostgreSQL relational database
   - Requires typed table definitions
   - Column-based (SQL-style)
   - Needs: data types, constraints, migrations

### The Solution
By separating models (data shape) from classes (business logic):

- **Single Source of Truth**: Data structure defined once in `models/`
- **DRY Principle**: No duplication between client and server schemas
- **Type Safety**: TypeScript ensures consistency across all layers
- **Flexibility**: Consumers can use plain data OR rich classes
- **Automation**: Schema generation prevents manual sync issues

## Consumer Perspective

### When to Use What?

| Use Case | Import | Example |
|----------|--------|---------|
| Type annotation | `meeting` (model) | `function save(data: meeting)` |
| Creating instances | `Meeting.create()` (class) | `const m = Meeting.create().unwrap()` |
| Business logic | `Meeting` (class) | `m.update()`, `m.isStale()` |
| RxDB schema | `meetingSchema` | `collections: { meetings: { schema: meetingSchema } }` |
| RxDB document type | `meetingDocType` | `const docs: meetingDocType[]` |
| Drizzle table | `meetings` (plural) | `db.select().from(meetings)` |

### Common Patterns

#### Creating New Instances
```typescript
import { Meeting } from '@recoverysky-org/common';

const result = Meeting.create();
if (result.ok) {
    const meeting = result.value;
    meeting.name = 'Monday Night';
    await meeting.update();
}
```

#### Working with RxDB
```typescript
import { meetingSchema, meetingDocType } from '@recoverysky-org/common/lib/models/rxdb/meeting.rxdb';
import { Meeting } from '@recoverysky-org/common';

// Define collection
const collections = {
    meetings: { schema: meetingSchema }
};

// Query database (returns plain data)
const docs: meetingDocType[] = await db.meetings.find().exec();

// Convert to class for business logic
const meeting = Object.assign(new Meeting(), docs[0]);
console.log(meeting.isStale());
```

#### Working with Drizzle
```typescript
import { meetings } from '@recoverysky-org/common/lib/models/drizzle/meetings.drizzle';
import { Meeting } from '@recoverysky-org/common';

// Query table (returns plain data)
const rows = await db.select().from(meetings);

// Convert to class for business logic
const meeting = Object.assign(new Meeting(), rows[0]);
await meeting.update();
```

## Design Principles

### 1. Separation of Concerns
- **Models**: Data structure only
- **Classes**: Business logic only
- **Schemas**: ORM-specific transformations

### 2. Convention Over Configuration
- Lowercase exports = data types
- Uppercase exports = classes
- Plural exports = SQL tables
- `*.schema.ts` = TypeScript schemas
- `*.json` = JSON schemas
- `*.rxdb.ts` = RxDB schemas
- `*.drizzle.ts` = Drizzle schemas

### 3. Progressive Enhancement
Consumers can choose their level of abstraction:
- **Minimal**: Use plain models as types
- **Standard**: Use classes for business logic
- **Advanced**: Extend classes with custom methods

### 4. Type Safety First
Every layer maintains strict TypeScript types:
- Models define the base types
- Schemas preserve type information
- Classes inherit and extend types
- Results use Result<T, E> pattern for safety

## Common Pitfalls

### ❌ Don't Mix Model and Class Instances
```typescript
// BAD: Using plain model when class is needed
const m = new meeting();
m.update(); // ERROR: method doesn't exist
```

```typescript
// GOOD: Use class factory
const m = Meeting.create().unwrap();
await m.update(); // Works!
```

### ❌ Don't Import Wrong Case
```typescript
// BAD: Importing model when you need class
import { meeting } from '@recoverysky-org/common';
const m = meeting.create(); // ERROR: static method doesn't exist
```

```typescript
// GOOD: Import class for factory methods
import { Meeting } from '@recoverysky-org/common';
const m = Meeting.create();
```

### ❌ Don't Modify Generated Schemas
```typescript
// BAD: Editing generated files
// src/models/rxdb/meeting.rxdb.ts - DO NOT EDIT THIS FILE
```

```typescript
// GOOD: Modify source and regenerate
// 1. Edit src/models/meeting.ts
// 2. Run: pnpm make
```

## Extension Points

### Adding New Models
1. Create `src/models/yourmodel.ts`
2. Define as plain class with properties
3. Run `pnpm make` to generate all schemas
4. Create `src/classes/YourModel/YourModel.ts` extending the model
5. Add business logic methods

### Adding Custom Methods
```typescript
// src/classes/Meeting/Meeting.ts
export class Meeting extends meeting {
    // Add your custom methods
    myCustomMethod(): void {
        // Business logic here
    }
}
```

### Extending Schema Generation
The pipeline scripts are in `src/scripts/`:
- `ts-to-schema.ts` - Extract TypeScript type info
- `ts-to-json.ts` - Generate JSON Schema
- `schema-to-rxdb.ts` - Generate RxDB schemas
- `json-to-drizzle.ts` - Generate Drizzle tables

Modify these scripts to customize schema generation behavior.

## Performance Considerations

### Schema Generation is Build-Time
All schema generation happens at build time (`pnpm make`), not runtime. This means:
- Zero runtime overhead
- All types are statically analyzable
- Tree-shaking works effectively

### Class Instantiation
Creating class instances is lightweight:
```typescript
// Factory pattern (recommended)
const m1 = Meeting.create(); // Includes ID generation, timestamps

// Direct instantiation (if you need more control)
const m2 = new Meeting();
m2.id = myCustomId;
```

### Converting Between Layers
```typescript
// Plain data → Class (zero-copy)
const meeting = Object.assign(new Meeting(), plainData);

// Class → Plain data (JSON serialization)
const plainData = JSON.parse(JSON.stringify(meeting));
```

## Summary

The architecture may seem complex at first, but it solves a real problem: **supporting both offline-first client databases and server-side relational databases from a single source of truth**.

The three-layer pattern (Models → Classes → Schemas) provides:
- **Consistency**: Same data shape everywhere
- **Flexibility**: Use plain data or rich classes
- **Type Safety**: Full TypeScript coverage
- **Automation**: Schema generation prevents drift
- **Maintainability**: Edit once, deploy everywhere
