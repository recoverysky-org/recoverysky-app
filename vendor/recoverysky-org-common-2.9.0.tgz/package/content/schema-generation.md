# Schema Generation Pipeline

## Overview

The schema generation pipeline is the heart of `@recoverysky-org/common`. It automatically transforms plain TypeScript models into multiple schema formats required by different database systems.

## The Pipeline

```
src/models/*.ts
    ↓
    ↓ [1] ts-to-schema.ts (TypeScript reflection)
    ↓
src/models/schema/*.schema.ts
    ↓
    ↓ [2] ts-to-json.ts (typescript-json-schema)
    ↓
src/models/json/*.json
    ├───────────────────────────────┐
    ↓                               ↓
    ↓ [3] schema-to-rxdb.ts        ↓ [4] json-to-drizzle.ts
    ↓                               ↓
src/models/rxdb/*.rxdb.ts      src/models/drizzle/*.drizzle.ts
                                    ↓
                                    ↓ [5] drizzle-kit generate
                                    ↓
                              src/models/migrations/*.sql
```

## Step-by-Step Breakdown

### Step 1: TypeScript Schema Generation
**Script**: `src/scripts/ts-to-schema.ts`
**Command**: `pnpm ts:schema`

**Input**: Plain TypeScript model classes
```typescript
// src/models/meeting.ts
export class meeting {
    id: string = '';
    name: string = '';
    fellowship: string = '';
    // ...
}
```

**Output**: TypeScript schema literals
```typescript
// src/models/schema/meeting.schema.ts
export const meetingSchemaLiteral = {
    title: "meeting",
    version: 0,
    primaryKey: "id",
    type: "object",
    properties: {
        id: { type: "string" },
        name: { type: "string" },
        fellowship: { type: "string" }
    },
    required: ["id", "name", "fellowship"]
} as const;
```

**What It Does**:
- Uses TypeScript compiler API to extract type information
- Generates JSON Schema-compatible literals
- Adds RxDB metadata (`version`, `primaryKey`, `additionalProperties`)
- Preserves type information for downstream processing

### Step 2: JSON Schema Generation
**Script**: `src/scripts/ts-to-json.ts`
**Command**: `pnpm json:schema`
**Tool**: `typescript-json-schema`

**Input**: TypeScript models
**Output**: Standard JSON Schema files

```json
{
  "title": "meeting",
  "version": 0,
  "primaryKey": "id",
  "type": "object",
  "properties": {
    "id": { "type": "string" },
    "name": { "type": "string" },
    "fellowship": { "type": "string" }
  },
  "required": ["id", "name", "fellowship"],
  "additionalProperties": false
}
```

**What It Does**:
- Converts TypeScript types to standard JSON Schema format
- Validates schema structure
- Adds RxDB-required fields
- Creates portable, ORM-agnostic schema definition

**Configuration**:
```typescript
const command = `npx typescript-json-schema tsconfig.schema.json ${typeName} \
  --required \
  --noExtraProps \
  --strictNullChecks \
  --out ${outFile}`;
```

### Step 3: RxDB Schema Generation
**Script**: `src/scripts/schema-to-rxdb.ts`
**Command**: `pnpm rxdb:schema`

**Input**: TypeScript schema literals
**Output**: RxDB-compatible TypeScript modules

```typescript
// src/models/rxdb/meeting.rxdb.ts
import { ExtractDocumentTypeFromTypedRxJsonSchema, RxCollection, RxDocument, RxJsonSchema, toTypedRxJsonSchema } from 'rxdb';
import { meetingSchemaLiteral } from '../schema/meeting.schema';
import { meeting } from '../meeting';

export { meetingSchemaLiteral };

const schemaTyped = toTypedRxJsonSchema(meetingSchemaLiteral);

export type meetingDocType = ExtractDocumentTypeFromTypedRxJsonSchema<typeof schemaTyped>;
export const meetingSchema: RxJsonSchema<meetingDocType> = meetingSchemaLiteral;

export type meetingDocMethods = {};
export const meetingDocMethods: meetingDocMethods = {};

export type meetingDocument = RxDocument<meetingDocType, meetingDocMethods>;
export type meetingCollectionMethods = {
  countAllDocuments: () => Promise<number>;
};
export type meetingCollection = RxCollection<meetingDocType, meetingDocMethods, meetingCollectionMethods>;

export const meetingCollectionMethods: meetingCollectionMethods = {
  countAllDocuments: async function (this: meetingCollection) {
    return (await this.find().exec()).length;
  }
};
```

**What It Does**:
- Generates RxDB collection types
- Creates document types
- Adds collection methods
- Provides typed interfaces for RxDB operations

**Generated Exports**:
- `meetingSchema` - RxDB schema object
- `meetingDocType` - TypeScript type for documents
- `meetingDocument` - RxDB document type
- `meetingCollection` - RxDB collection type
- `meetingCollectionMethods` - Custom collection methods

### Step 4: Drizzle Schema Generation
**Script**: `src/scripts/json-to-drizzle.ts`
**Command**: `pnpm drizzle:schema`

**Input**: JSON Schema files
**Output**: Drizzle ORM table definitions

```typescript
// src/models/drizzle/meetings.drizzle.ts
import { pgTable, text, integer, boolean, varchar, json, timestamp } from 'drizzle-orm/pg-core';

export const meetings = pgTable('meetings', {
  id: text('id').notNull().primaryKey(),
  sid: text('sid').notNull(),
  iid: text('iid'),
  uid: text('uid').notNull(),
  zid: text('zid').notNull(),
  sha256: text('sha256').notNull(),
  status: text('status').notNull(),
  verified: boolean('verified').notNull(),
  created: integer('created').notNull(),
  updated: integer('updated').notNull(),
  url: text('url').notNull(),
  password: text('password').notNull(),
  passwordEnc: text('passwordEnc').notNull(),
  fellowship: text('fellowship').notNull(),
  meetingTypes: json('meetingTypes').notNull(),
  // ... more columns
});
```

**What It Does**:
- Maps JSON Schema types to PostgreSQL types
- Handles type conversions:
  - `string` → `text()`
  - `number` → `integer()`
  - `boolean` → `boolean()`
  - `array` → `json()`
  - `object` → `json()`
- Applies constraints (`notNull()`, `primaryKey()`, `unique()`)
- Pluralizes table names (`meeting` → `meetings`)
- Generates indexes if specified in schema

**Type Mapping**:
```typescript
const typeMap: Record<string, string> = {
  string: 'text',
  number: 'integer',
  boolean: 'boolean',
  array: 'json',
  object: 'json',
  null: 'text',
};
```

**Pluralization Rules**:
```typescript
const toPluralTableName = (name: string): string => {
  if (name.endsWith('y')) return name.slice(0, -1) + 'ies';
  if (name.endsWith('s')) return name + 'es';
  return name + 's';
};
// meeting → meetings
// schedule → schedules
// category → categories
```

### Step 5: SQL Migration Generation
**Tool**: `drizzle-kit`
**Command**: `pnpm drizzle:generate`

**Input**: Drizzle schema files
**Output**: SQL migration files

```sql
-- src/models/migrations/0000_initial.sql
CREATE TABLE IF NOT EXISTS "meetings" (
    "id" text PRIMARY KEY NOT NULL,
    "sid" text NOT NULL,
    "iid" text,
    "uid" text NOT NULL,
    "zid" text NOT NULL,
    "sha256" text NOT NULL,
    "status" text NOT NULL,
    "verified" boolean NOT NULL,
    "created" integer NOT NULL,
    "updated" integer NOT NULL,
    -- ... more columns
);
```

**What It Does**:
- Compares current schema with database state
- Generates SQL migration scripts
- Handles schema changes (add/remove/modify columns)
- Creates indexes and constraints

## Running the Pipeline

### Full Build (Recommended)
```bash
pnpm make
```

This runs:
1. `pnpm build` - Compile TypeScript
2. `pnpm ts:schema` - Generate TS schemas
3. `pnpm json:schema` - Generate JSON schemas
4. `pnpm rxdb:schema` - Generate RxDB schemas
5. `pnpm drizzle:schema` - Generate Drizzle schemas
6. `pnpm drizzle:generate` - Generate SQL migrations
7. `pnpm pack` - Create tarball for distribution

### Individual Steps
```bash
# Just TypeScript schemas
pnpm ts:schema

# Just JSON schemas
pnpm json:schema

# Just RxDB schemas
pnpm rxdb:schema

# Just Drizzle schemas
pnpm drizzle:schema

# Just SQL migrations
pnpm drizzle:generate
```

## Customizing the Pipeline

### Adding New Models

1. **Create model file**:
```typescript
// src/models/mymodel.ts
export class mymodel {
    id: string = '';
    name: string = '';
    // ... properties
}
```

2. **Export from index**:
```typescript
// src/models/index.ts
export * from './mymodel';
```

3. **Run pipeline**:
```bash
pnpm make
```

4. **Created files**:
- `src/models/schema/mymodel.schema.ts`
- `src/models/json/mymodel.json`
- `src/models/rxdb/mymodel.rxdb.ts`
- `src/models/drizzle/mymodels.drizzle.ts` (note plural)

### Customizing Type Mappings

Edit `src/scripts/json-to-drizzle.ts`:

```typescript
const typeMap: Record<string, string> = {
  string: 'text',
  number: 'integer',
  boolean: 'boolean',
  array: 'json',
  object: 'json',

  // Add custom mappings
  timestamp: 'timestamp',
  uuid: 'uuid',
  bigint: 'bigint',
};
```

### Adding Schema Metadata

Customize JSON schema generation in `src/scripts/ts-to-json.ts`:

```typescript
const schema = JSON.parse(fs.readFileSync(outFile, 'utf-8'));
schema.version = 0;
schema.primaryKey = 'id';
schema.additionalProperties = false;

// Add custom metadata
schema.indexes = ['created', 'updated', ['fellowship', 'verified']];
schema.timestamps = true;
schema.softDelete = false;

fs.writeFileSync(outFile, JSON.stringify(schema, null, 2));
```

### Custom RxDB Collection Methods

Edit `src/scripts/schema-to-rxdb.ts`:

```typescript
export const ${baseName}CollectionMethods: ${className}CollectionMethods = {
  countAllDocuments: async function (this: ${className}Collection) {
    return (await this.find().exec()).length;
  },

  // Add custom methods
  findActive: async function (this: ${className}Collection) {
    return this.find().where('status').eq('active').exec();
  },

  findStale: async function (this: ${className}Collection) {
    const yesterday = Date.now() - 86400000;
    return this.find().where('updated').lt(yesterday).exec();
  }
};
```

## Troubleshooting

### Issue: Schema generation fails
**Symptoms**: Error during `pnpm ts:schema` or `pnpm json:schema`

**Common Causes**:
1. Complex default values (object literals, enums)
2. Union types with complex initializers
3. Circular dependencies

**Solutions**:
```typescript
// ❌ Problematic
export class mymodel {
    config: object = { foo: 'bar' }; // Complex default
    status: Status = Status.ACTIVE; // Enum default
}

// ✅ Fixed
export class mymodel {
    config: object = {}; // Simple default
    status: string = 'active'; // String default
}
```

### Issue: Drizzle type mismatch
**Symptoms**: Generated Drizzle schema has wrong column type

**Solution**: Add type hints in JSON schema:

```typescript
// src/scripts/ts-to-json.ts
const schema = JSON.parse(fs.readFileSync(outFile, 'utf-8'));

// Add format hints
if (schema.properties.created) {
    schema.properties.created.format = 'timestamp';
}
if (schema.properties.email) {
    schema.properties.email.format = 'email';
}
```

### Issue: Migration conflicts
**Symptoms**: Drizzle migration fails with "column already exists"

**Solution**:
```bash
# Reset local database
pnpm drizzle:migrate:local

# Or manually drop tables
psql -d mydb -c "DROP TABLE meetings CASCADE;"

# Regenerate and migrate
pnpm make
pnpm drizzle:migrate:local
```

### Issue: RxDB schema validation fails
**Symptoms**: "Schema validation failed" when creating collection

**Solution**: Ensure all required fields in schema:

```typescript
// Check generated schema
import { meetingSchema } from '@recoverysky-org/common/lib/models/rxdb/meeting.rxdb';
console.log(meetingSchema.required); // Should list all required fields
```

## Performance Optimization

### Incremental Builds
For faster development, run only affected steps:

```bash
# Model change → regenerate all
pnpm make

# Script change → run just that script
pnpm ts:schema  # Only if ts-to-schema.ts changed
```

### Parallel Generation
The pipeline steps are sequential by design (each depends on previous), but you can parallelize across multiple models:

```bash
# Process multiple models in parallel (advanced)
# Modify scripts to accept model name as argument
pnpm tsx src/scripts/ts-to-json.ts meeting &
pnpm tsx src/scripts/ts-to-json.ts schedule &
wait
```

## Best Practices

### ✅ Do
- Run `pnpm make` after any model changes
- Commit all generated files to version control
- Review generated schemas before committing
- Add migration files to git
- Test schemas in both RxDB and Drizzle

### ❌ Don't
- Don't manually edit generated files
- Don't skip schema generation steps
- Don't ignore TypeScript errors in models
- Don't use complex default values in models
- Don't modify tsconfig.schema.json without understanding impact

## Summary

The schema generation pipeline:
1. **Automates** tedious schema creation
2. **Validates** type safety across all layers
3. **Prevents** drift between client and server schemas
4. **Enables** single source of truth for data models
5. **Generates** migrations for database evolution

By understanding this pipeline, you can confidently modify models knowing all schemas will stay in sync.
