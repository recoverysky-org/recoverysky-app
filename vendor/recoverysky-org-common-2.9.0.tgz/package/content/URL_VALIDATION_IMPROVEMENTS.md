# Zoom URL Validation Improvements

## Overview

Enhanced the `meeting.url` Zod validation to be Zoom-specific instead of allowing any valid URL. This ensures data integrity and prevents storing non-Zoom URLs in meeting records.

## Changes Made

### Updated File: `src/models/zod/meeting.zod.ts` (Line 101-108)

**Before:**
```typescript
url: z.string().url("Must be a valid URL").describe("Zoom meeting URL"),
```

**After:**
```typescript
url: z
  .string()
  .url("Must be a valid URL")
  .regex(
    /^https?:\/\/(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)*zoom\.(us|com\.cn)\/(j|my)\/[\w.-]+(?:\?.*)?$/i,
    "Must be a valid Zoom meeting URL (e.g., https://zoom.us/j/123456789 or https://zoom.us/my/username)"
  )
  .describe("Zoom meeting URL"),
```

## Regex Pattern Breakdown

The new validation pattern enforces:

| Component | Pattern | Description |
|-----------|---------|-------------|
| **Protocol** | `https?://` | HTTP or HTTPS (case-insensitive) |
| **Subdomain** | `(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)*` | Optional subdomains (e.g., us02web, company) - proper hyphen rules |
| **Domain** | `zoom\.(us\|com\.cn)` | Only zoom.us or zoom.com.cn |
| **Path** | `\/(j\|my)\/` | Either /j/ (meeting ID) or /my/ (personal room) |
| **ID/Username** | `[\w.-]+` | Alphanumeric, underscores, dots, hyphens |
| **Query Params** | `(?:\?.*)?` | Optional query string (pwd, t, etc.) |

## Supported URL Formats

### ✅ Valid Examples

```
https://zoom.us/j/123456789
https://zoom.us/j/92390071234?pwd=TTBwSjVkNFN6VVZxUUtCRjZhUjIzdz09
https://us02web.zoom.us/j/123456789
https://company.zoom.us/j/123456789
https://umn-private.zoom.us/j/123456789
https://zoom.us/my/username
https://zoom.us/my/john.doe.smith
https://company.zoom.us/my/user.name
http://zoom.us/j/123456789
https://zoom.com.cn/j/123456789
```

### ❌ Invalid Examples

```
https://zoom.us/j/                    # Missing ID
https://example.com/j/123456789       # Wrong domain
https://zoom.io/j/123456789           # Wrong TLD
https://zoom.com.br/j/123456789       # Unsupported TLD
https://zoom.us/meeting/123456789     # Wrong path
zoom.us/j/123456789                   # Missing protocol
```

## Test Coverage

Created comprehensive test files to verify the validation:

1. **`src/models/__tests__/zoom-url-validation.test.ts`**
   - Tests 5 different regex patterns
   - Validates against 14 valid URLs and 9 invalid URLs
   - Demonstrates pattern progression and trade-offs

2. **`src/models/__tests__/zoom-url-improved.test.ts`**
   - Tests recommended patterns
   - Real-world scenario validation
   - Extraction pattern examples
   - Integration with Zod schemas

3. **`src/models/__tests__/meeting.url-validation.test.ts`**
   - Direct integration tests with `meetingZodSchema`
   - Full meeting validation with URLs
   - Edge cases (special characters, hyphenations, etc.)
   - Error message verification

### Test Results

✅ **12/12 tests passing** in meeting.url-validation.test.ts
- Valid Zoom URLs accepted ✓
- Invalid Zoom URLs rejected ✓
- Clear error messages provided ✓
- Special characters in passwords handled ✓
- Multiple query parameters supported ✓
- Personal room URLs with dots work ✓
- Hyphenated subdomains work ✓
- Chinese domain (zoom.com.cn) supported ✓

## Build Status

✅ **Build passes** with `pnpm build`
- TypeScript compilation successful
- No type errors
- All exports generated correctly

## Design Decisions

### Why Only zoom.us and zoom.com.cn?

The chosen pattern restricts to known Zoom domains:
- **Pros**: Conservative, predictable, secure
- **Cons**: Doesn't support other regional Zoom domains (zoom.co.jp, zoom.co.in, etc.)

**Alternative Permissive Pattern** (if needed):
```typescript
/^https?:\/\/(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)*zoom\.[a-z.]+\/(j|my)\/[\w.-]+(?:\?.*)?$/i
```
This allows any Zoom TLD but is less restrictive.

### Why Both /j/ and /my/?

- `/j/` - Standard meeting ID URLs (numeric or alphanumeric)
- `/my/` - Personal meeting room URLs (usernames, often with dots)

Supporting both enables flexibility for different Zoom account types.

## Migration Notes

### For New Code

Use the improved validation automatically - no changes needed.

### For Existing Data

The new validation is applied on write operations:
1. Creating new meetings → Must use valid Zoom URLs
2. Updating meetings → URLs must be valid Zoom URLs
3. Reading existing meetings → No changes (validation not applied retroactively)

If you have existing non-Zoom URLs in your database:
- They will not validate during updates
- Migration script may be needed to clean or flag these records

## Error Messages

When a URL fails validation, users see:
```
Must be a valid Zoom meeting URL (e.g., https://zoom.us/j/123456789 or https://zoom.us/my/username)
```

This clearly indicates:
- The requirement is Zoom-specific
- Examples of valid formats

## Future Enhancements

### Potential Improvements

1. **URL Normalization**: Strip/handle variations like:
   ```typescript
   "https://zoom.us/j/123456789?pwd=..." → store components separately
   ```

2. **Meeting ID Extraction**: Add utility to extract IDs:
   ```typescript
   extractZoomMeetingId("https://zoom.us/j/123456789") // → "123456789"
   ```

3. **Regional Domain Support**: If needed, expand to:
   ```typescript
   zoom\.(us|com\.cn|co\.jp|co\.in|etc)
   ```

4. **Validation Tiers**:
   - Strict: Only zoom.us (current)
   - Moderate: zoom.us, zoom.com.cn
   - Permissive: Any zoom domain

## References

- **Zod Documentation**: https://zod.dev
- **IANA Regex Reference**: Used for subdomain validation rules
- **Zoom URL Documentation**: Common Zoom meeting URL formats

## Testing Commands

```bash
# Run URL validation tests
pnpm test -- src/models/__tests__/meeting.url-validation.test.ts

# Run all validation tests
pnpm test -- src/models/__tests__/zoom-url*

# Full build with validation
pnpm build
```

## Maintenance

The regex pattern is stable and unlikely to change unless:
1. Zoom adds new TLDs
2. URL format changes significantly
3. New path types introduced (/webinar/, /instant/, etc.)

Monitor Zoom API changes for any structural updates.
