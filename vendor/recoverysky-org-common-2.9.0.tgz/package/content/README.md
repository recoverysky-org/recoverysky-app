# Documentation Contents

This directory contains comprehensive documentation for `@recoverysky-org/common` library consumers.

## Available Documentation

### [Consumer Guide](./consumer-guide.md)
**For**: Library users implementing features
**Contains**:
- Quick start and installation
- Understanding exports and naming conventions
- Common use cases (RxDB, Drizzle, That70sDateTime)
- Type safety patterns (Result<T, E>)
- Advanced patterns (batch operations, conversions)
- Troubleshooting guide
- Best practices

**Start here if**: You're building an application using this library.

### [Architecture Guide](./architecture.md)
**For**: Developers who want to understand the design
**Contains**:
- The three-layer pattern (Models → Classes → Schemas)
- Why this architecture exists
- How it solves dual-ORM requirements
- Design principles and rationale
- Common pitfalls to avoid
- Extension points for customization
- Performance considerations

**Start here if**: You want to understand why things are designed this way, or you're contributing to the library.

### [Schema Generation](./schema-generation.md)
**For**: Developers working with the build pipeline
**Contains**:
- Complete pipeline overview (5 transformation steps)
- Step-by-step breakdown of each script
- Configuration and customization options
- Running the pipeline
- Adding new models
- Troubleshooting schema generation
- Performance optimization tips

**Start here if**: You're modifying models, debugging schema issues, or extending the pipeline.

## Quick Reference

### When to Use What?

| What You Need | Which Doc | Section |
|---------------|-----------|---------|
| Create a meeting instance | Consumer Guide | Creating New Meeting Instances |
| Use with RxDB | Consumer Guide | Working with RxDB |
| Use with Drizzle | Consumer Guide | Working with Drizzle ORM |
| Understand models vs classes | Architecture Guide | The Three-Layer Pattern |
| Add a new model | Schema Generation | Adding New Models |
| Debug schema errors | Schema Generation | Troubleshooting |
| Convert plain data to class | Consumer Guide | Converting Between Layers |
| Understand That70sDateTime | Consumer Guide | Using That70sDateTime |

## Documentation Philosophy

This library's documentation follows these principles:

1. **Consumer-First**: Most consumers just need the Consumer Guide
2. **Progressive Disclosure**: Start simple, dive deeper as needed
3. **Examples Over Explanation**: Show working code first
4. **Clear Comparisons**: Use ✅/❌ patterns to show right vs wrong
5. **Cross-References**: Link between related concepts

## Getting Help

1. **Read the docs**: Start with Consumer Guide
2. **Check JSDoc**: All classes have detailed inline documentation
3. **Review examples**: See working code in each guide
4. **API Reference**: Check TypeDoc generated docs in `../docs/`
5. **Ask questions**: Open GitHub discussions/issues

## Contributing to Documentation

### Markdown Guides
Edit files in this directory:
- `consumer-guide.md` - Usage examples and patterns
- `architecture.md` - Design rationale
- `schema-generation.md` - Build pipeline details

### JSDoc Comments
Edit source code comments in:
- `src/models/` - Plain data models
- `src/classes/` - Business logic classes
- `src/utils/` - Utility functions

### API Reference
Generated automatically from JSDoc:
```bash
pnpm docs  # Generate to ../docs/
```

## Documentation Structure

```
@recoverysky-org/common/
├── DOCUMENTATION.md          # Main documentation index (start here)
├── README.md                 # Quick start guide
├── content/                  # Detailed guides (this directory)
│   ├── README.md            # This file
│   ├── consumer-guide.md    # Usage guide
│   ├── architecture.md      # Design guide
│   └── schema-generation.md # Pipeline guide
└── docs/                     # Generated API reference (HTML)
    └── index.html           # TypeDoc output
```

## Viewing Documentation

### In NPM Package
After installing:
```bash
# View markdown docs
cat node_modules/@recoverysky-org/common/DOCUMENTATION.md
cat node_modules/@recoverysky-org/common/content/consumer-guide.md

# Open API reference
open node_modules/@recoverysky-org/common/docs/index.html
```

### From Package.json
```bash
pnpm docs:read  # Lists all available documentation
```

### In Repository
```bash
# Generate API docs
pnpm docs

# Serve API docs locally
pnpm docs:serve  # Opens http://localhost:8080

# Watch for changes
pnpm docs:watch
```

## Last Updated

**Date**: 2025-01-23
**Version**: 0.3.0
**Maintained By**: RecoverySky Org
