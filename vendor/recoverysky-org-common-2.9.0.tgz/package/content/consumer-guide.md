# Consumer Guide

## Quick Start

### Installation
```bash
npm install @recoverysky-org/common
# or
pnpm add @recoverysky-org/common
```

### Basic Usage
```typescript
import { Meeting } from '@recoverysky-org/common';

// Create a new meeting
const result = Meeting.create();
if (result.ok) {
    const meeting = result.value;
    meeting.name = 'Monday Night Big Book';
    meeting.fellowship = 'AA';
    await meeting.update();
}
```

## Understanding Exports

### The Naming Convention

This library follows a strict naming convention to distinguish between data types and business logic:

| Export Type | Case | Example | Purpose |
|-------------|------|---------|---------|
| Model (data) | lowercase | `meeting` | Type annotations, plain data |
| Class (logic) | Uppercase | `Meeting` | Creating instances, methods |
| Table (SQL) | plural | `meetings` | Drizzle ORM queries |

### Models vs Classes: When to Use What?

#### Use Models (lowercase) for:
✅ Type annotations in function signatures
✅ Defining types for variables
✅ Working with plain JSON data
✅ RxDB document types
✅ Drizzle query result types

```typescript
import { meeting } from '@recoverysky-org/common/models';

// Type annotation
function processMeeting(data: meeting): void {
    console.log(data.name);
}

// Variable type
const plainData: meeting = {
    id: '123',
    name: 'Test Meeting',
    // ... all required fields
};
```

#### Use Classes (Uppercase) for:
✅ Creating new instances
✅ Calling business logic methods
✅ Factory patterns
✅ Hash generation and validation
✅ Computed properties

```typescript
import { Meeting } from '@recoverysky-org/common';

// Factory creation
const meeting = Meeting.create().unwrap();

// Business logic
await meeting.update(); // Generates SHA256 hash
console.log(meeting.isStale()); // Checks if >24h old
```

## Common Use Cases

### 1. Creating New Meeting Instances

```typescript
import { Meeting } from '@recoverysky-org/common';
import { DateTime } from 'luxon';

const result = Meeting.create();
if (!result.ok) {
    console.error('Failed to create meeting:', result.error);
    return;
}

const meeting = result.value;
meeting.name = 'Monday Night Big Book';
meeting.fellowship = 'AA';
meeting.meetingTypes = ['C', 'B'];
meeting.language = 'en';
meeting.zid = '123456789';
meeting.url = 'https://zoom.us/j/123456789';
meeting.duration = 3600000; // 1 hour in ms
meeting.timezone = 'America/New_York';

// Generate UID and SHA256 hash
await meeting.update();

console.log('Meeting ID:', meeting.id);
console.log('Meeting hash:', meeting.sha256);
```

### 2. Working with RxDB (Client-Side)

#### Setup RxDB Collection
```typescript
import { createRxDatabase } from 'rxdb';
import { getRxStorageDexie } from 'rxdb/plugins/storage-dexie';
import { meetingSchema } from '@recoverysky-org/common/lib/models/rxdb/meeting.rxdb';

const db = await createRxDatabase({
    name: 'mydb',
    storage: getRxStorageDexie()
});

await db.addCollections({
    meetings: {
        schema: meetingSchema
    }
});
```

#### Query and Convert to Class
```typescript
import { meetingDocType } from '@recoverysky-org/common/lib/models/rxdb/meeting.rxdb';
import { Meeting } from '@recoverysky-org/common';

// Query returns plain data
const docs: meetingDocType[] = await db.meetings
    .find()
    .where('fellowship').eq('AA')
    .exec();

// Convert to class for business logic
const meetings = docs.map(doc => Object.assign(new Meeting(), doc));

// Use business logic
for (const meeting of meetings) {
    if (meeting.isStale()) {
        console.log(`Stale meeting: ${meeting.name}`);
    }
}
```

#### Insert New Document
```typescript
import { Meeting } from '@recoverysky-org/common';

const meeting = Meeting.create().unwrap();
meeting.name = 'New Meeting';
meeting.fellowship = 'NA';
await meeting.update();

// Insert into RxDB (convert to plain object)
await db.meetings.insert(JSON.parse(JSON.stringify(meeting)));
```

### 3. Working with Drizzle ORM (Server-Side)

#### Setup Drizzle
```typescript
import { drizzle } from 'drizzle-orm/node-postgres';
import { meetings } from '@recoverysky-org/common/lib/models/drizzle/meetings.drizzle';
import pg from 'pg';

const pool = new pg.Pool({
    host: 'localhost',
    port: 5432,
    user: 'user',
    password: 'password',
    database: 'mydb'
});

const db = drizzle(pool);
```

#### Query and Convert to Class
```typescript
import { meetings } from '@recoverysky-org/common/lib/models/drizzle/meetings.drizzle';
import { Meeting } from '@recoverysky-org/common';
import { eq } from 'drizzle-orm';

// Query returns plain data
const rows = await db
    .select()
    .from(meetings)
    .where(eq(meetings.fellowship, 'AA'));

// Convert to class
const meetingInstances = rows.map(row => Object.assign(new Meeting(), row));

// Use business logic
for (const meeting of meetingInstances) {
    if (meeting.isStale()) {
        // Update stale meeting
        await meeting.update();
        await db
            .update(meetings)
            .set({ updated: meeting.updated, sha256: meeting.sha256 })
            .where(eq(meetings.id, meeting.id));
    }
}
```

#### Insert New Record
```typescript
import { Meeting } from '@recoverysky-org/common';
import { meetings } from '@recoverysky-org/common/lib/models/drizzle/meetings.drizzle';

const meeting = Meeting.create().unwrap();
meeting.name = 'New Meeting';
meeting.fellowship = 'AA';
await meeting.update();

// Insert into PostgreSQL
await db.insert(meetings).values({
    id: meeting.id,
    name: meeting.name,
    fellowship: meeting.fellowship,
    // ... all other fields
    sha256: meeting.sha256,
    updated: meeting.updated
});
```

### 4. Using That70sDateTime

The `That70sDateTime` class helps manage recurring meeting times by normalizing all occurrences to the first week of 1970 (epoch week).

#### Converting to 70s Time
```typescript
import { makeThat70sDateTime } from '@recoverysky-org/common';
import { DateTime } from 'luxon';

// Current time: Monday 3pm EST
const now = DateTime.fromObject(
    { weekday: 1, hour: 15, minute: 0 },
    { zone: 'America/New_York' }
);

// Convert to 70s equivalent (always first week of 1970)
const seventies = makeThat70sDateTime({
    DateTime: now,
    millis: now.toMillis()
});

console.log(seventies.toMillis()); // UTC millis in range 0-604800000

// Store this value in meeting.millis70s
const meeting = Meeting.create().unwrap();
meeting.millis70s = seventies.toMillis();
meeting.timezone = 'America/New_York';
```

#### Converting Back to Current Time
```typescript
import { hydrateSeventies } from '@recoverysky-org/common';

// Get 70s time from database
const meeting = { millis70s: 54000000, timezone: 'America/New_York' };

// Convert to current week
const currentTime = hydrateSeventies(meeting.millis70s, meeting.timezone);

console.log(currentTime.toLocaleString(DateTime.DATETIME_FULL));
// Outputs current week's Monday 3pm EST
```

## Type Safety Patterns

### Result Pattern
This library uses the Result<T, E> pattern from `@jenova-marie/ts-rust-result`:

```typescript
import { Meeting } from '@recoverysky-org/common';

const result = Meeting.create();

// Pattern 1: Check ok property
if (result.ok) {
    const meeting = result.value;
    // Use meeting
} else {
    console.error('Error:', result.error.message);
}

// Pattern 2: Use unwrap (throws on error)
try {
    const meeting = result.unwrap();
    // Use meeting
} catch (error) {
    console.error('Error:', error);
}

// Pattern 3: Use unwrapOr (fallback value)
const meeting = result.unwrapOr(new Meeting());
```

### Async Results
```typescript
const meeting = Meeting.create().unwrap();
meeting.zid = '123';
meeting.millis70s = Date.now();

const updateResult = await meeting.update();

if (updateResult.ok) {
    console.log('Updated successfully');
    console.log('New hash:', meeting.sha256);
} else {
    console.error('Update failed:', updateResult.error.message);
}
```

## Advanced Patterns

### Converting Between Plain Data and Classes

#### Plain → Class
```typescript
import { Meeting } from '@recoverysky-org/common';
import { meeting } from '@recoverysky-org/common/models';

const plainData: meeting = {
    id: '123',
    name: 'Test',
    // ... all fields
};

// Zero-copy conversion
const meetingInstance = Object.assign(new Meeting(), plainData);

// Now has methods
console.log(meetingInstance.isStale());
```

#### Class → Plain
```typescript
import { Meeting } from '@recoverysky-org/common';

const meetingInstance = Meeting.create().unwrap();

// Serialize to plain data
const plainData = JSON.parse(JSON.stringify(meetingInstance));

// Or use object spread (keeps non-enumerable properties)
const plainData2 = { ...meetingInstance };
```

### Batch Operations

#### RxDB Batch Insert
```typescript
import { Meeting } from '@recoverysky-org/common';

const meetings = Array.from({ length: 100 }, (_, i) => {
    const m = Meeting.create().unwrap();
    m.name = `Meeting ${i}`;
    m.fellowship = 'AA';
    return m;
});

// Update all (generates hashes)
await Promise.all(meetings.map(m => m.update()));

// Batch insert
await db.meetings.bulkInsert(
    meetings.map(m => JSON.parse(JSON.stringify(m)))
);
```

#### Drizzle Batch Insert
```typescript
import { Meeting } from '@recoverysky-org/common';
import { meetings } from '@recoverysky-org/common/lib/models/drizzle/meetings.drizzle';

const newMeetings = Array.from({ length: 100 }, (_, i) => {
    const m = Meeting.create().unwrap();
    m.name = `Meeting ${i}`;
    m.fellowship = 'NA';
    return m;
});

await Promise.all(newMeetings.map(m => m.update()));

await db.insert(meetings).values(
    newMeetings.map(m => JSON.parse(JSON.stringify(m)))
);
```

## Troubleshooting

### Issue: "Method doesn't exist on type"
```typescript
// ❌ Problem
import { meeting } from '@recoverysky-org/common/models';
const m = new meeting();
m.update(); // ERROR: Property 'update' does not exist

// ✅ Solution
import { Meeting } from '@recoverysky-org/common';
const m = Meeting.create().unwrap();
await m.update(); // Works!
```

### Issue: "Static method doesn't exist"
```typescript
// ❌ Problem
import { meeting } from '@recoverysky-org/common/models';
const m = meeting.create(); // ERROR: Property 'create' does not exist

// ✅ Solution
import { Meeting } from '@recoverysky-org/common';
const m = Meeting.create(); // Works!
```

### Issue: "Cannot find module"
```typescript
// ❌ Problem
import { meetingSchema } from '@recoverysky-org/common';
// ERROR: Module not found

// ✅ Solution
import { meetingSchema } from '@recoverysky-org/common/lib/models/rxdb/meeting.rxdb';
```

### Issue: Type mismatch with ORM
```typescript
// ❌ Problem
import { Meeting } from '@recoverysky-org/common';
const docs: Meeting[] = await db.meetings.find().exec();
// ERROR: Type mismatch

// ✅ Solution
import { meetingDocType } from '@recoverysky-org/common/lib/models/rxdb/meeting.rxdb';
import { Meeting } from '@recoverysky-org/common';

const docs: meetingDocType[] = await db.meetings.find().exec();
const meetings = docs.map(d => Object.assign(new Meeting(), d));
```

## Best Practices

### ✅ Do
- Use `Meeting.create()` for new instances
- Call `await meeting.update()` before saving to database
- Use Result pattern for error handling
- Import from barrel exports (`@recoverysky-org/common`)
- Use classes for business logic, models for type annotations

### ❌ Don't
- Don't use `new Meeting()` directly (use factory)
- Don't skip calling `update()` before database operations
- Don't modify generated schema files
- Don't mix lowercase/uppercase imports
- Don't store class instances directly in database (serialize first)

## Next Steps

- Read [Architecture Guide](./architecture.md) for deep dive
- Explore [Schema Generation](./schema-generation.md) for pipeline details
- Check [API Documentation](../docs/index.html) for complete reference
- Review [Examples](./examples/) for working code samples
