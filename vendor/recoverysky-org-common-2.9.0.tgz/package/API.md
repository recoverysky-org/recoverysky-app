# @recoverysky-org/common - API Reference

**Quick-Start Guide for LLM Agents and Developers**

This is the entry point for understanding how to use this library correctly. Read this first, then reference the detailed documentation.

## 🎯 Library Overview

`@recoverysky-org/common` is a shared TypeScript library for the RecoverySky organization that provides:

- **Data Models**: Plain data types for meetings, schedules, system prompts, and TREX (lowercase `meeting`, `schedule`, `system_prompt`, `trex`)
- **Business Logic Classes**: Classes extending models with methods (uppercase `Meeting`, `Schedule`)
- **Zod Validation**: Runtime validation schemas for meetings, schedules, system prompts, and TREX
- **Deterministic Hashing**: SHA256 change detection with sorted keys (includes TREX data)
- **Error Handling**: Domain-specific Result types using ts-rust-result pattern
- **Database Integration**: Drizzle ORM schemas and migrations for PostgreSQL
- **Repositories**: Database access layer (MeetingRepository, ScheduleRepository, SystemPromptRepository, TrexRepository)
- **Utilities**: JWT/crypto operations, frequency calculation
- **Browser Exports**: Browser-compatible entry point via `@recoverysky-org/common/browser`

---

## 📚 Documentation Index

**Start with these based on your task:**

### For Implementing Validation (⚠️ Most Important - Non-Obvious!)
1. **`VALIDATION_QUICK_REFERENCE.md`** ← START HERE
   - What's exported and how to use it
   - Two approaches: helper functions vs Zod schemas
   - Which schema for different scenarios
   - Error code reference
   - 5-minute read

2. **`HOW_VALIDATION_WORKS.md`**
   - Comprehensive walkthrough with examples
   - Real-world patterns (scraping, APIs, forms)
   - Batch validation
   - 15-minute read

3. **`content/VALIDATION.md`**
   - Deep dive into Zod schemas
   - All validation rules documented
   - Schema definitions explained

### For Architecture & Design
4. **`content/architecture.md`**
   - System design overview
   - Core classes and their relationships
   - TREX time expression system
   - RxDB decorators

5. **`content/schema-generation.md`**
   - How schemas are auto-generated
   - TypeScript → JSON Schema → RxDB → Drizzle pipeline
   - When to run `pnpm make`

6. **`content/consumer-guide.md`**
   - How sibling projects consume this library
   - Installation and usage patterns
   - Distribution model (tarball-based)

### For Database & ORM
7. **Drizzle Integration** (See "Using Drizzle ORM" section below)
   - PostgreSQL table definitions
   - Indexes and migrations
   - Type safety with Drizzle

### For TypeDoc Generated Docs
8. **`docs/`** (TypeDoc HTML)
   - Generated from JSDoc comments
   - Browse at: Open `docs/index.html` in browser
   - Contains all exported types, classes, functions

### Reference Files
- **`CLAUDE.md`** - Project-specific Claude Code instructions
- **`README.md`** - General project overview
- **`CHANGELOG.md`** - Version history
- **`TODO.md`** - Known issues and planned work

---

## ⚡ The Three Key Concepts

### 1. Models (lowercase) vs Classes (uppercase)

This is **critical** - getting this wrong is the most common mistake:

#### Plain Data Model (`meeting`, `schedule`, `trex`)
```typescript
import { meeting, trex } from '@recoverysky-org/common/models';

// ✅ USE FOR: Type annotations and data structure
function processMeeting(data: meeting): void {
  console.log(data.name); // Type-safe property access
}

function processTrex(data: trex): void {
  console.log(data.timezone); // Type-safe property access
}

// ✅ USE FOR: RxDB/Drizzle query results (already plain data)
const docs: meeting[] = await db.meetings.find().exec();

// ❌ NEVER DO: Creating instances (has no methods)
const m = new meeting(); // Compile error - not a class
```

#### Business Logic Class (`Meeting`, `Schedule`)
```typescript
import { Meeting } from '@recoverysky-org/common';

// ✅ USE FOR: Creating new instances (without TREX)
const result = Meeting.create();
if (result.ok) {
  const meeting = result.value;
  await meeting.update(); // Validates and generates SHA256 hash
}

// ✅ USE FOR: Creating meetings with TREX time expression
const meetingWithTrex = Meeting.create(
  { name: 'Weekly Meeting', fellowship: 'AA', zid: '123456789' },
  { id: 'trex-123', coordinate: 259200000, timezone: 'America/New_York', periodicity: 1 }
);
if (meetingWithTrex.ok) {
  const meeting = meetingWithTrex.value;
  await meeting.update(); // SHA256 includes meeting + trex data
  console.log(meeting.trex?.timezone); // TREX attached to meeting
}

// ✅ USE FOR: Converting plain data to instances
const plainData = await db.meetings.find();
const meetings = plainData.map(d => Object.assign(new Meeting(), d));

// ❌ NEVER DO: Type annotations (use lowercase instead)
function process(m: Meeting): void { } // Wrong - use meeting
```

**Quick Decision Tree:**
- Annotating a function parameter? → Use `meeting` (lowercase)
- Creating a new instance? → Use `Meeting.create()` (class)
- Receiving data from database? → Use `meeting` (lowercase) initially, convert if needed
- Need to call methods like `update()` or `isStale()`? → Use `Meeting` (class)

### 2. Zod Validation is NOT Automatic ⚠️

**Critical insight that many developers miss:**

```typescript
// ❌ WRONG: Just having a schema file doesn't validate
import { meeting } from '@recoverysky-org/common/models';
const untrustedData = await fetch('/api/meeting').then(r => r.json());
// untrustedData is NOT validated yet!

// ✅ CORRECT: Explicitly call validation
import { validateMeeting } from '@recoverysky-org/common';
const result = validateMeeting(untrustedData);
if (result.ok) {
  // Now it's validated and type-safe
  const validated = result.value; // type: meeting
}
```

**Two Validation Approaches:**

**Option A: Helper Functions (Recommended)**
```typescript
import {
  validateMeeting, validateMeetings,
  validateTrex, validateTrexes,
  validateSchedule, validateSchedules
} from '@recoverysky-org/common';

// Single item
const result = validateMeeting(data);
result.match(
  (valid) => saveMeeting(valid),
  (error) => console.error(error.issues)
);

// Multiple items (batch)
const batchResult = validateMeetings(dataArray);
if (batchResult.ok) {
  const { valid, invalid } = batchResult.value;
  // Process both separately
}

// TREX validation
const trexResult = validateTrex({
  id: 'trex-123',
  coordinate: 259200000,
  timezone: 'America/New_York',
  periodicity: 1  // WEEKLY
});
if (trexResult.ok) {
  console.log('Valid TREX:', trexResult.value);
}

// Batch TREX validation
const trexBatchResult = validateTrexes(trexArray);
```

**Option B: Direct Zod Schemas**
```typescript
import { meetingCreateSchema, trexCreateSchema } from '@recoverysky-org/common';

const result = meetingCreateSchema.safeParse(data);
if (result.success) {
  console.log('Valid:', result.data);
}

// TREX schemas
const trexResult = trexCreateSchema.safeParse(trexData);
```

**When to validate:**
- ✅ Data from APIs
- ✅ Data from web scraping
- ✅ User input before saving
- ✅ CSV/file imports
- ❌ Data from your own database (already validated)
- ❌ In tight loops (validate at entry point)

**Schema Types:**

| Schema | Use | Required Fields |
|--------|-----|-----------------|
| `meetingZodSchema` | Full validation | ALL fields |
| `meetingCreateSchema` | User input (creation) | zid, name, fellowship, millis70s, periodicity, endMillis70s |
| `meetingUpdateSchema` | Partial updates | zid, millis70s (minimal) |
| `trexZodSchema` | Full TREX validation | ALL fields + coordinate range validation |
| `trexCreateSchema` | TREX creation | id, coordinate, timezone, periodicity |

### 3. Error Handling with ts-rust-result

The library uses the Result pattern from `@jenova-marie/ts-rust-result`:

```typescript
import { ok, err, type RecoverySkyResult } from '@recoverysky-org/common';

// Functions return Result<T, E> - never throw!
function doSomething(): RecoverySkyResult<Data> {
  if (error) {
    return err(someError); // Return error as value
  }
  return ok(data); // Return success value
}

// Consume with .match() (functional style)
const result = doSomething();
result.match(
  (data) => console.log('Success:', data),
  (error) => console.error('Error:', error)
);

// Or use .ok property
if (result.ok) {
  console.log(result.value);
} else {
  console.error(result.error);
}
```

**Domain-Specific Result Types:**
```typescript
import type {
  RecoverySkyResult,    // General purpose
  DateTimeResult,       // DateTime operations
  MeetingResult,        // Meeting methods
  ScheduleResult,       // Schedule methods
  JWKResult,           // Crypto operations
} from '@recoverysky-org/common';
```

**Key Rules:**
- ✅ Import `ok`/`err` from `../errors/results.js` (NOT base library)
- ✅ Use `ok(value)` and `err(error)` - no type parameters needed
- ✅ Never `return Ok()` or `return Err()` (capitalized - these are types, not functions)
- ✅ Wrap third-party library calls: `tryResult(() => external.call())`
- ✅ Own functions return Result directly: `return ok(data)`

---

## 🗂️ Project Structure

```
src/
├── classes/              # Business logic classes
│   ├── Meeting/         # Meeting class (SHA256, TREX support)
│   └── Schedule/        # Schedule class with methods
├── models/              # Plain data models (lowercase)
│   ├── meeting.ts       # Plain meeting data structure
│   ├── schedule.ts      # Plain schedule data structure
│   ├── system_prompt.ts # System prompt model
│   ├── trex.ts          # TREX time expression model
│   ├── zod/             # Zod validation schemas
│   │   ├── meeting.zod.ts   # Meeting validation rules
│   │   ├── schedule.zod.ts  # Schedule validation rules
│   │   ├── system_prompt.zod.ts  # System prompt validation
│   │   └── trex.zod.ts      # TREX validation rules
│   ├── drizzle/         # Drizzle ORM table definitions
│   │   ├── meetings.drizzle.ts
│   │   ├── schedules.drizzle.ts
│   │   ├── system_prompts.drizzle.ts
│   │   └── trexes.drizzle.ts
│   ├── json/            # JSON Schema (auto-generated)
│   ├── schema/          # TypeScript schemas (auto-generated)
│   └── migrations/      # SQL migrations (auto-generated)
├── repositories/        # Database access layer
│   ├── MeetingRepository.ts       # CRUD for meetings
│   ├── ScheduleRepository.ts      # CRUD for schedules
│   ├── SystemPromptRepository.ts  # CRUD for system prompts
│   └── TrexRepository.ts          # CRUD for TREX
├── enums/               # Enum types (status, verified, Periodicity, etc.)
├── types/               # Custom types (Occurrence, MeetingNotes, etc.)
├── utils/               # Utility functions
│   ├── validation.ts    # validateMeeting, validateTrex, etc.
│   ├── createNewJWK.ts  # JWT key generation
│   └── ...
├── errors/              # Error handling
│   ├── results.ts       # Domain-specific Result helpers
│   ├── types.ts         # Error type definitions
│   └── index.ts         # Exports
├── decorators/          # Class decorators (@RxModel, @Log, etc.)
├── index.ts             # Main barrel export
└── browser.ts           # Browser-compatible exports (no Node.js deps)

content/
├── README.md            # Overview of documentation
├── VALIDATION.md        # Deep dive on validation
├── HOW_VALIDATION_WORKS.md # Practical validation guide
├── VALIDATION_QUICK_REFERENCE.md # Quick lookup
├── architecture.md      # System design
├── schema-generation.md # Pipeline explanation
└── consumer-guide.md    # How to consume this library

docs/                    # TypeDoc generated HTML documentation
```

---

## 🔧 Using Drizzle ORM

Drizzle tables are auto-generated from JSON schemas. **Never edit `*.drizzle.ts` files manually.**

### Query Examples

```typescript
import { meetings, schedules } from '@recoverysky-org/common/lib/models/drizzle/meetings.drizzle';
import { db } from './db'; // Your Drizzle DB instance

// SELECT
const rows = await db.select().from(meetings).where(eq(meetings.status, 'ACTIVE'));
// rows: meeting[] (plain data type)

// For business logic, convert to class
import { Meeting } from '@recoverysky-org/common';
const instances = rows.map(r => Object.assign(new Meeting(), r));

// INSERT
await db.insert(meetings).values(meetingData);

// UPDATE
await db.update(meetings)
  .set({ name: 'New Name' })
  .where(eq(meetings.id, 'meeting-123'));

// DELETE
await db.delete(meetings).where(eq(meetings.status, 'DELETED'));
```

### Indexes

Indexes are defined in `src/indexes/` (not in generated `.drizzle.ts` files):

```
src/indexes/
├── meetings.indexes.ts   # Meeting indexes
├── schedules.indexes.ts  # Schedule indexes
└── README.md             # How to add indexes
```

When you modify indexes, run `pnpm make` to regenerate migrations.

### Migrations

Auto-generated SQL migrations are in `src/models/migrations/`:

```bash
# Generate new migrations after schema changes
pnpm drizzle:generate

# Apply migrations to local database
pnpm drizzle:migrate:local

# Apply to production
pnpm drizzle:migrate:prod
```

---

## 🔐 Error Handling (DRY Approach)

Don't create custom errors. Use domain-specific error types from `src/errors/`:

```typescript
// ✅ CORRECT: Use exported error types
import type { MeetingError } from '@recoverysky-org/common';
import { ok, err } from '@recoverysky-org/common';

function updateMeeting(data: unknown): MeetingResult<meeting> {
  // Use error helpers from ts-rust-result
  const validated = validateMeeting(data);
  if (!validated.ok) {
    return err(validated.error);
  }

  // Your logic
  return ok(validated.value);
}

// ❌ WRONG: Creating custom error classes
class MyCustomMeetingError extends Error { }
```

**Exported Error Types:**
```typescript
import type {
  RecoverySkyError,     // Base error type
  DateTimeError,        // DateTime operations
  MeetingError,         // Meeting operations
  ScheduleError,        // Schedule operations
  ValidationError,      // Validation failures
  DatabaseError,        // DB operations
  NetworkError,         // Network operations
  CryptoError,         // Encryption/signing
  JWKError,            // JSON Web Key operations
} from '@recoverysky-org/common';
```

---

## 📦 Quick Start Examples

### Example 1: Create and Save a Meeting with TREX

```typescript
import { Meeting, validateMeeting } from '@recoverysky-org/common';
import { db } from './database';

async function createMeeting() {
  // 1. Create meeting with TREX time expression
  const meetingResult = Meeting.create(
    {
      name: 'Monday Night Big Book',
      fellowship: 'AA',
      zid: '123456789',
      url: 'https://zoom.us/j/123456789'
    },
    {
      id: 'trex-123',
      coordinate: 259200000,       // Monday 00:00 UTC
      coordinate_end: 262800000,
      timezone: 'America/New_York',
      periodicity: 1,              // WEEKLY
      duration_ms: 3600000
    }
  );

  if (!meetingResult.ok) {
    console.error('Failed to create:', meetingResult.error);
    return;
  }

  const meeting = meetingResult.value;

  // 2. update() validates meeting + trex, generates deterministic SHA256
  const updateResult = await meeting.update();
  if (!updateResult.ok) {
    console.error('Validation failed:', updateResult.error.message);
    return;
  }

  // 3. Save to database (SHA256 now includes TREX data)
  console.log('Meeting hash:', meeting.sha256);
  console.log('TREX timezone:', meeting.trex?.timezone);
  await db.insert(meetings).values(meeting);
  console.log('Saved:', meeting.id);
}
```

### Example 2: Validate Scraped Data

```typescript
import { validateMeetings } from '@recoverysky-org/common';
import { db } from './database';

async function importMeetingsFromWebsite(scrapedData: unknown[]) {
  // Batch validate all scraped data
  const result = validateMeetings(scrapedData as any[]);

  if (!result.ok) {
    console.error('Validation failed:', result.error);
    return;
  }

  const { valid, invalid } = result.value;

  // Save valid meetings
  if (valid.length > 0) {
    await db.insert(meetings).values(valid);
    console.log(`Imported ${valid.length} meetings`);
  }

  // Report invalid ones
  invalid.forEach(({ index, data, errors }) => {
    console.warn(`Row ${index} (${data.name}): ${errors[0].message}`);
  });

  return { imported: valid.length, failed: invalid.length };
}
```

### Example 3: API Endpoint with Validation

```typescript
import { validateMeeting } from '@recoverysky-org/common';
import express from 'express';
import { db } from './database';

const app = express();

app.post('/api/meetings', async (req, res) => {
  const validation = validateMeeting(req.body);

  validation.match(
    async (meeting) => {
      try {
        await db.insert(meetings).values(meeting);
        res.json({ success: true, id: meeting.id });
      } catch (error) {
        res.status(500).json({ error: 'Database error' });
      }
    },
    (zodError) => {
      res.status(400).json({
        error: 'Validation failed',
        issues: zodError.issues.map(i => ({
          path: i.path.join('.'),
          message: i.message
        }))
      });
    }
  );
});
```

---

## 🧪 Running Tests

```bash
# Run all tests
pnpm test

# Run unit tests only (excludes integration tests)
pnpm test:unit

# Run integration tests (requires local database)
pnpm test:integration

# Run repository integration tests
pnpm test:repos

# Run specific test file
pnpm test -- src/utils/validation.test.ts

# Run specific test by name
pnpm vitest run -t "test name"

# Watch mode
pnpm test -- --watch

# Coverage
pnpm test:coverage
```

Integration tests use `.env.local` for database configuration:
```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=recoverysky
DB_USER=postgres
DB_PASSWORD=postgres
```

---

## 🏗️ Building and Distribution

```bash
# Full build and package
pnpm make              # Version bump + build + schemas + pack + tarball

# Individual steps
pnpm build             # Compile TypeScript
pnpm ts:schema         # Generate TypeScript schemas
pnpm json:schema       # Generate JSON schemas
pnpm rxdb:schema       # Generate RxDB schemas
pnpm drizzle:schema    # Generate Drizzle tables

# Quick pack for local development (no version bump)
pnpm pack:stable       # Creates recoverysky-common.tgz

# Distribution to sibling projects
pnpm distribute        # Packs and copies to recoverysky-zoom/
```

---

## 🎓 Learning Path

1. **Start here:** This file (API.md)
2. **Understand validation:** Read `VALIDATION_QUICK_REFERENCE.md`
3. **Deep dive:** Read `HOW_VALIDATION_WORKS.md`
4. **Architecture:** Read `content/architecture.md`
5. **Reference:** Browse TypeDoc at `docs/index.html`
6. **Implement:** Look at examples in this file
7. **Troubleshoot:** Check `content/VALIDATION.md` or search TypeDoc

---

## ❓ Frequently Asked Questions

**Q: When should I validate?**
A: Before saving to database, and for all external data (APIs, user input, imports). Not for data from your own database.

**Q: Can I skip validation for performance?**
A: No. Validate at entry points, not in loops. Zod is fast enough.

**Q: How do I handle validation errors?**
A: Use `result.error.issues` array - each issue has `path`, `message`, and `code`.

**Q: What's the difference between `meeting` and `Meeting`?**
A: `meeting` is plain data (type annotations), `Meeting` is a class (with methods).

**Q: Can I manually edit `.drizzle.ts` files?**
A: No. They're auto-generated. Edit indexes in `src/indexes/` instead.

**Q: How do I add a new field to meetings?**
A: Edit `src/models/meeting.ts`, then run `pnpm make` to regenerate everything.

**Q: Why does Schedule.create() fail with "zids required"?**
A: Schedules require at least one Zoom ID in the `zids` array (unless status is `ORPHANED`). Pass `{ zids: ['123456789'] }` in the schedule data.

**Q: When do I use `ok()`/`err()` vs throwing?**
A: Always return Results, never throw. The library uses the Result pattern throughout.

**Q: How do I create a meeting with TREX time data?**
A: Use `Meeting.create(meetingData, trexData)` - the second parameter is optional TREX data.

**Q: What's included in the SHA256 hash?**
A: All meeting fields (except id, version, updated, sha256) plus all TREX fields (except id). This ensures the hash is deterministic regardless of internal identifiers.

**Q: How do I validate TREX data separately?**
A: Use `validateTrex(data)` or `validateTrexes(dataArray)` from the library exports.

---

## 🌐 Browser Exports

The library provides a browser-compatible entry point that excludes Node.js-specific dependencies:

```typescript
// Browser-safe imports
import {
  meeting, schedule, trex, system_prompt,  // Models
  Periodicity,                              // Local enum (mirrors @trex-ts/core)
  validateMeeting, validateSchedule,        // Validation
  trexZodSchema, meetingZodSchema,          // Zod schemas
  MeetingStatus, Fellowship,                // Enums
  ok, err,                                  // Result helpers
} from '@recoverysky-org/common/browser';
```

**Excluded from browser bundle:**
- `Meeting` and `Schedule` classes (depend on @trex-ts/core Python executor)
- All repositories (require Drizzle ORM / PostgreSQL)
- `TREX` class re-exports from @trex-ts/core
- drizzle-orm re-exports

**Included in browser bundle:**
- All models (meeting, schedule, trex, system_prompt)
- All enums including local `Periodicity`
- All Zod validation schemas
- Decorators, types, error handling
- Browser-safe utilities (validation, createNewJWK, getNextFrequency)

---

## 🔗 External Dependencies

- **@trex-ts/core** - TREX time expression engine (server-side only)
- **zod** - Runtime validation and schema definition
- **@jenova-marie/ts-rust-result** - Result/Either pattern for error handling
- **drizzle-orm** - PostgreSQL ORM and type safety
- **bson-objectid** - ObjectID generation for unique IDs
- **luxon** - DateTime manipulation
- **jose** - JWT/JWK operations (uses Web Crypto API, browser-safe)

---

## 📖 Next Steps

- For validation: → Read `VALIDATION_QUICK_REFERENCE.md`
- For architecture: → Read `content/architecture.md`
- For specific APIs: → Open `docs/index.html` in browser
- For consumer usage: → Read `content/consumer-guide.md`
- For database: → Check Drizzle section above and `content/schema-generation.md`
