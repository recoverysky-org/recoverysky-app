export declare function logClass(target: any): void;
export declare function logMethod(target: any, propertyKey: string, descriptor: PropertyDescriptor): void;
export declare function logProperty(target: any, propertyKey: string): void;
export declare function logParameter(target: any, propertyKey: string, parameterIndex: number): void;
