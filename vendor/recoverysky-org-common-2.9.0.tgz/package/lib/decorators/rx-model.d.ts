export declare function RxModel(name: string): ClassDecorator;
export declare function getSchemaNameFromClass(instance: any): string | undefined;
