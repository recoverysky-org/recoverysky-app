/**
 * Config Cache Model
 *
 * Client-side single-row cache of the app's raw /config response, so the
 * app can cold-start from the encrypted SQLite DB without gating on a live
 * fetch after first launch. SQLite-only — this never syncs to PostgreSQL,
 * hence the pg skip below.
 *
 * Spec (app repo): docs/superpowers/specs/2026-08-14-config-cache-cold-start-design.md
 *
 * @pg skip
 */
export declare class config_cache {
    id: string;
    /** Raw /config response JSON, stringified verbatim */
    payload: string;
    /** Epoch ms of the successful fetch that produced payload */
    fetchedAt: number;
}
