import { z } from "zod";
import { ScheduleStatus } from "../../enums/index.js";
/**
 * Full schedule schema with cross-field refinements.
 * Use this for complete schedule validation.
 */
export declare const scheduleZodSchema: z.ZodObject<{
    id: z.ZodString;
    zids: z.ZodArray<z.ZodString>;
    mids: z.ZodArray<z.ZodString>;
    sha256: z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>;
    status: z.ZodEnum<typeof ScheduleStatus>;
    name: z.ZodString;
    fellowship: z.ZodDefault<z.ZodString>;
    minutes: z.ZodDefault<z.ZodNumber>;
    created: z.ZodNumber;
    updated: z.ZodNumber;
    version: z.ZodDefault<z.ZodNumber>;
}, z.core.$strip>;
/**
 * TypeScript type inferred from Zod schema.
 * Use this for type-safe validation results.
 */
export type ScheduleZod = z.infer<typeof scheduleZodSchema>;
/**
 * Partial schema for validating incomplete schedule data or updates.
 * All fields are optional. Uses base schema (without refinements) since
 * Zod doesn't support .partial() on refined schemas.
 *
 * @example
 * ```typescript
 * const updates = { name: 'New Schedule Name' };
 * const result = schedulePartialSchema.safeParse(updates);
 * ```
 */
export declare const schedulePartialSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    zids: z.ZodOptional<z.ZodArray<z.ZodString>>;
    mids: z.ZodOptional<z.ZodArray<z.ZodString>>;
    sha256: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>>;
    status: z.ZodOptional<z.ZodEnum<typeof ScheduleStatus>>;
    name: z.ZodOptional<z.ZodString>;
    fellowship: z.ZodOptional<z.ZodDefault<z.ZodString>>;
    minutes: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    created: z.ZodOptional<z.ZodNumber>;
    updated: z.ZodOptional<z.ZodNumber>;
    version: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
}, z.core.$strip>;
/**
 * Schema for creating new schedules.
 * Only requires essential fields, makes everything else optional.
 * Fields like id, created, updated, sha256 are typically populated programmatically.
 * Uses base schema (without refinements) since Zod doesn't support .partial() on refined schemas.
 */
export declare const scheduleCreateSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    zids: z.ZodNonOptional<z.ZodOptional<z.ZodArray<z.ZodString>>>;
    mids: z.ZodOptional<z.ZodArray<z.ZodString>>;
    sha256: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>>;
    status: z.ZodOptional<z.ZodEnum<typeof ScheduleStatus>>;
    name: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    fellowship: z.ZodOptional<z.ZodDefault<z.ZodString>>;
    minutes: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    created: z.ZodOptional<z.ZodNumber>;
    updated: z.ZodOptional<z.ZodNumber>;
    version: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
}, z.core.$strip>;
/**
 * Schema for validating schedule updates.
 * Requires critical fields but allows partial updates.
 * Uses base schema (without refinements) since Zod doesn't support .partial() on refined schemas.
 */
export declare const scheduleUpdateSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    zids: z.ZodNonOptional<z.ZodOptional<z.ZodArray<z.ZodString>>>;
    mids: z.ZodOptional<z.ZodArray<z.ZodString>>;
    sha256: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>>;
    status: z.ZodOptional<z.ZodEnum<typeof ScheduleStatus>>;
    name: z.ZodOptional<z.ZodString>;
    fellowship: z.ZodOptional<z.ZodDefault<z.ZodString>>;
    minutes: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    created: z.ZodOptional<z.ZodNumber>;
    updated: z.ZodOptional<z.ZodNumber>;
    version: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
}, z.core.$strip>;
