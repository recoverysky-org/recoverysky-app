import { z } from "zod";
/**
 * Full TREX schema with cross-field refinements.
 * Use this for complete TREX validation.
 */
export declare const trexZodSchema: z.ZodObject<{
    id: z.ZodString;
    coordinate: z.ZodNumber;
    timezone: z.ZodString;
    periodicity: z.ZodNumber;
    coordinate_end: z.ZodNumber;
    duration_ms: z.ZodNumber;
    dtstart: z.ZodString;
    dtend: z.ZodNullable<z.ZodString>;
    rrule_str: z.ZodString;
    rrule_json: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    hour: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    minute: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    dow: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    dom: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    month: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
}, z.core.$strip>;
/**
 * TypeScript type inferred from Zod schema.
 * Use this for type-safe validation results.
 */
export type TrexZod = z.infer<typeof trexZodSchema>;
/**
 * Partial schema for validating incomplete TREX data or updates.
 * All fields are optional. Uses base schema (without refinements) since
 * Zod doesn't support .partial() on refined schemas.
 *
 * @example
 * ```typescript
 * const updates = { timezone: 'Europe/London' };
 * const result = trexPartialSchema.safeParse(updates);
 * ```
 */
export declare const trexPartialSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    coordinate: z.ZodOptional<z.ZodNumber>;
    timezone: z.ZodOptional<z.ZodString>;
    periodicity: z.ZodOptional<z.ZodNumber>;
    coordinate_end: z.ZodOptional<z.ZodNumber>;
    duration_ms: z.ZodOptional<z.ZodNumber>;
    dtstart: z.ZodOptional<z.ZodString>;
    dtend: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    rrule_str: z.ZodOptional<z.ZodString>;
    rrule_json: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    hour: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
    minute: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
    dow: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
    dom: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
    month: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
}, z.core.$strip>;
/**
 * Schema for creating new TREX events.
 * Requires all fields from TREXJSON interface.
 * Uses base schema (without refinements) since Zod doesn't support .partial() on refined schemas.
 */
export declare const trexCreateSchema: z.ZodObject<{
    id: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    coordinate: z.ZodNonOptional<z.ZodOptional<z.ZodNumber>>;
    timezone: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    periodicity: z.ZodNonOptional<z.ZodOptional<z.ZodNumber>>;
    coordinate_end: z.ZodNonOptional<z.ZodOptional<z.ZodNumber>>;
    duration_ms: z.ZodNonOptional<z.ZodOptional<z.ZodNumber>>;
    dtstart: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    dtend: z.ZodNonOptional<z.ZodOptional<z.ZodNullable<z.ZodString>>>;
    rrule_str: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    rrule_json: z.ZodNonOptional<z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
    hour: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
    minute: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
    dow: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
    dom: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
    month: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
}, z.core.$strip>;
/**
 * Schema for validating TREX updates.
 * Requires id but allows partial updates to other fields.
 * Uses base schema (without refinements) since Zod doesn't support .partial() on refined schemas.
 */
export declare const trexUpdateSchema: z.ZodObject<{
    id: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    coordinate: z.ZodOptional<z.ZodNumber>;
    timezone: z.ZodOptional<z.ZodString>;
    periodicity: z.ZodOptional<z.ZodNumber>;
    coordinate_end: z.ZodOptional<z.ZodNumber>;
    duration_ms: z.ZodOptional<z.ZodNumber>;
    dtstart: z.ZodOptional<z.ZodString>;
    dtend: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    rrule_str: z.ZodOptional<z.ZodString>;
    rrule_json: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    hour: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
    minute: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
    dow: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
    dom: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
    month: z.ZodOptional<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
}, z.core.$strip>;
