import { z } from "zod";
/**
 * Room-or-listing key format, shared by `meeting.zid` and `schedule.zids`.
 *
 * Two accepted shapes:
 * - A Zoom meeting ID: 9-11 digits.
 * - A `p:<host>:<source-key>` in-person key, where the host namespaces the
 *   source key (AA: venue location_id; NA: BMLT listing id_bigint). Source
 *   keys are only unique within their own server, so the host is part of
 *   the identity, not decoration.
 *
 * A schedule's zids ARE the keys of its member meetings, so the two fields
 * must accept exactly the same strings. They did not: schedules required
 * `/^\d+$/`, which silently rejected every in-person key. Because
 * `Schedule.create()` drops invalid records rather than throwing, a merge
 * of 21,009 in-person schedules reported `+0` and read as a clean no-op.
 * Sharing one schema is what keeps them from drifting apart again.
 */
export declare const ZID_REGEX: RegExp;
/** Human-readable rule, reused as the validation message on both fields. */
export declare const ZID_MESSAGE = "Must be a Zoom meeting ID (9-11 digits) or a p:-namespaced in-person key";
/** Schema for a single room-or-listing key. */
export declare const zidSchema: z.ZodString;
