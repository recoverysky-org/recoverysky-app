import { z } from "zod";
/**
 * Full push_token schema.
 */
export declare const pushTokenZodSchema: z.ZodObject<{
    id: z.ZodString;
    uid: z.ZodString;
    did: z.ZodString;
    token: z.ZodString;
    platform: z.ZodEnum<{
        ios: "ios";
        android: "android";
    }>;
    created: z.ZodNumber;
    updated: z.ZodNumber;
}, z.core.$strip>;
/**
 * TypeScript type inferred from Zod schema.
 */
export type PushTokenZod = z.infer<typeof pushTokenZodSchema>;
/**
 * Partial schema for validating updates.
 */
export declare const pushTokenPartialSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    uid: z.ZodOptional<z.ZodString>;
    did: z.ZodOptional<z.ZodString>;
    token: z.ZodOptional<z.ZodString>;
    platform: z.ZodOptional<z.ZodEnum<{
        ios: "ios";
        android: "android";
    }>>;
    created: z.ZodOptional<z.ZodNumber>;
    updated: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
/**
 * Schema for upserting push tokens.
 * Requires uid, did, token, and platform.
 */
export declare const pushTokenUpsertSchema: z.ZodObject<{
    uid: z.ZodString;
    platform: z.ZodEnum<{
        ios: "ios";
        android: "android";
    }>;
    did: z.ZodString;
    token: z.ZodString;
}, z.core.$strip>;
/**
 * Schema for updating push tokens.
 * Requires uid and did for identification.
 */
export declare const pushTokenUpdateSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    uid: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    did: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    token: z.ZodOptional<z.ZodString>;
    platform: z.ZodOptional<z.ZodEnum<{
        ios: "ios";
        android: "android";
    }>>;
    created: z.ZodOptional<z.ZodNumber>;
    updated: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
