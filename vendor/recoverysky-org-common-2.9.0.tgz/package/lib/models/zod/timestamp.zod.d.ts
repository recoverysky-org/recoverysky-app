import { z } from "zod";
/**
 * Schema for UTC millisecond timestamps (Date.now() values).
 *
 * Validates that the value is a non-negative integer representing
 * milliseconds since Unix epoch. Zero is allowed as a default/unset value.
 */
export declare const timestampSchema: z.ZodNumber;
/**
 * Schema for created timestamp field (UTC millis).
 */
export declare const createdTimestampSchema: z.ZodNumber;
/**
 * Schema for updated timestamp field (UTC millis).
 */
export declare const updatedTimestampSchema: z.ZodNumber;
