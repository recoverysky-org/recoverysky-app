import { z } from "zod";
/**
 * Full system prompt schema with refinements.
 */
export declare const systemPromptZodSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    content: z.ZodString;
    variables: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    active: z.ZodDefault<z.ZodBoolean>;
    created: z.ZodNumber;
    updated: z.ZodNumber;
}, z.core.$strip>;
/**
 * TypeScript type inferred from Zod schema.
 * Use this for type-safe validation results.
 */
export type SystemPromptZod = z.infer<typeof systemPromptZodSchema>;
/**
 * Partial schema for validating incomplete system prompt data or updates.
 * All fields are optional.
 *
 * @example
 * ```typescript
 * const updates = { content: 'Updated prompt content' };
 * const result = systemPromptPartialSchema.safeParse(updates);
 * ```
 */
export declare const systemPromptPartialSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    name: z.ZodOptional<z.ZodString>;
    content: z.ZodOptional<z.ZodString>;
    variables: z.ZodOptional<z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
    active: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
    created: z.ZodOptional<z.ZodNumber>;
    updated: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
/**
 * Schema for creating new system prompts.
 * Only requires essential fields, makes everything else optional.
 * Fields like id, created, updated are typically populated programmatically.
 */
export declare const systemPromptCreateSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    name: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    content: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    variables: z.ZodOptional<z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
    active: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
    created: z.ZodOptional<z.ZodNumber>;
    updated: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
/**
 * Schema for validating system prompt updates.
 * Requires name for identification but allows partial updates.
 */
export declare const systemPromptUpdateSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    name: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    content: z.ZodOptional<z.ZodString>;
    variables: z.ZodOptional<z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
    active: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
    created: z.ZodOptional<z.ZodNumber>;
    updated: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
