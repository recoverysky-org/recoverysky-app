import { z } from "zod";
import { UnsubscribeSource } from "../../enums/index.js";
/**
 * Full unsubscribe schema.
 */
export declare const unsubscribeZodSchema: z.ZodObject<{
    id: z.ZodString;
    email: z.ZodString;
    uid: z.ZodString;
    source: z.ZodEnum<typeof UnsubscribeSource>;
    reason: z.ZodString;
    created: z.ZodNumber;
    updated: z.ZodNumber;
}, z.core.$strip>;
/**
 * TypeScript type inferred from Zod schema.
 */
export type UnsubscribeZod = z.infer<typeof unsubscribeZodSchema>;
/**
 * Partial schema for validating updates.
 */
export declare const unsubscribePartialSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    email: z.ZodOptional<z.ZodString>;
    uid: z.ZodOptional<z.ZodString>;
    source: z.ZodOptional<z.ZodEnum<typeof UnsubscribeSource>>;
    reason: z.ZodOptional<z.ZodString>;
    created: z.ZodOptional<z.ZodNumber>;
    updated: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
/**
 * Schema for adding an address to the suppression list.
 *
 * Only `email` is required — `source` defaults to MANUAL and the rest are
 * optional, so a webhook handler that only knows the address can call
 * straight through.
 */
export declare const unsubscribeCreateSchema: z.ZodObject<{
    uid: z.ZodOptional<z.ZodString>;
    email: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    source: z.ZodOptional<z.ZodEnum<typeof UnsubscribeSource>>;
    reason: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
