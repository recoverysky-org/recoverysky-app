import { z } from "zod";
/**
 * Full news schema.
 */
export declare const newsZodSchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodString;
    body: z.ZodString;
    start: z.ZodNumber;
    end: z.ZodNumber;
}, z.core.$strip>;
/**
 * TypeScript type inferred from Zod schema.
 */
export type NewsZod = z.infer<typeof newsZodSchema>;
/**
 * Schema for creating a news item (all fields required).
 */
export declare const newsCreateSchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodString;
    body: z.ZodString;
    start: z.ZodNumber;
    end: z.ZodNumber;
}, z.core.$strip>;
/**
 * Partial schema for validating updates.
 */
export declare const newsUpdateSchema: z.ZodObject<{
    id: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    title: z.ZodOptional<z.ZodString>;
    body: z.ZodOptional<z.ZodString>;
    start: z.ZodOptional<z.ZodNumber>;
    end: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
