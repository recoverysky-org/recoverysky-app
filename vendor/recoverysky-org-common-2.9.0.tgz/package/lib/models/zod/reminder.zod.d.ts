import { z } from "zod";
/**
 * Full reminder schema with refinements.
 */
export declare const reminderZodSchema: z.ZodObject<{
    id: z.ZodString;
    uid: z.ZodString;
    did: z.ZodDefault<z.ZodString>;
    sid: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    mid: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    scope: z.ZodDefault<z.ZodEnum<{
        row: "row";
        single: "single";
        all: "all";
    }>>;
    dow: z.ZodDefault<z.ZodNumber>;
    time: z.ZodDefault<z.ZodNumber>;
    name: z.ZodDefault<z.ZodString>;
    timezone: z.ZodDefault<z.ZodString>;
    minutes_before: z.ZodDefault<z.ZodNumber>;
    at_start: z.ZodDefault<z.ZodBoolean>;
    enabled: z.ZodDefault<z.ZodBoolean>;
    created: z.ZodNumber;
    updated: z.ZodNumber;
}, z.core.$strip>;
/**
 * TypeScript type inferred from Zod schema.
 */
export type ReminderZod = z.infer<typeof reminderZodSchema>;
/**
 * Partial schema for validating updates.
 */
export declare const reminderPartialSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    uid: z.ZodOptional<z.ZodString>;
    did: z.ZodOptional<z.ZodDefault<z.ZodString>>;
    sid: z.ZodOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
    mid: z.ZodOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
    scope: z.ZodOptional<z.ZodDefault<z.ZodEnum<{
        row: "row";
        single: "single";
        all: "all";
    }>>>;
    dow: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    time: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    name: z.ZodOptional<z.ZodDefault<z.ZodString>>;
    timezone: z.ZodOptional<z.ZodDefault<z.ZodString>>;
    minutes_before: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    at_start: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
    enabled: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
    created: z.ZodOptional<z.ZodNumber>;
    updated: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
/**
 * Schema for creating new reminders.
 * Requires uid and did; other fields have defaults.
 */
export declare const reminderCreateSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    uid: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    did: z.ZodNonOptional<z.ZodOptional<z.ZodDefault<z.ZodString>>>;
    sid: z.ZodOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
    mid: z.ZodOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
    scope: z.ZodOptional<z.ZodDefault<z.ZodEnum<{
        row: "row";
        single: "single";
        all: "all";
    }>>>;
    dow: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    time: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    name: z.ZodOptional<z.ZodDefault<z.ZodString>>;
    timezone: z.ZodOptional<z.ZodDefault<z.ZodString>>;
    minutes_before: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    at_start: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
    enabled: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
    created: z.ZodOptional<z.ZodNumber>;
    updated: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
/**
 * Schema for updating reminders.
 * Requires id for identification.
 */
export declare const reminderUpdateSchema: z.ZodObject<{
    id: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    uid: z.ZodOptional<z.ZodString>;
    did: z.ZodOptional<z.ZodDefault<z.ZodString>>;
    sid: z.ZodOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
    mid: z.ZodOptional<z.ZodDefault<z.ZodNullable<z.ZodString>>>;
    scope: z.ZodOptional<z.ZodDefault<z.ZodEnum<{
        row: "row";
        single: "single";
        all: "all";
    }>>>;
    dow: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    time: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    name: z.ZodOptional<z.ZodDefault<z.ZodString>>;
    timezone: z.ZodOptional<z.ZodDefault<z.ZodString>>;
    minutes_before: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    at_start: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
    enabled: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
    created: z.ZodOptional<z.ZodNumber>;
    updated: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
