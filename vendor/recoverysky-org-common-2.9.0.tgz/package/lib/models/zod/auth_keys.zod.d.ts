import { z } from "zod";
/**
 * Zod validation schema for auth_keys model.
 *
 * Provides runtime validation for authentication key data.
 *
 * @example
 * ```typescript
 * import { authKeysZodSchema } from '@recoverysky-org/common';
 *
 * const authKey = {
 *   id: 'key-123',
 *   uuid: '550e8400-e29b-41d4-a716-446655440000',
 *   key: 'sk_live_abc123...',
 * };
 *
 * const result = authKeysZodSchema.safeParse(authKey);
 * if (result.success) {
 *   console.log('Valid auth key:', result.data);
 * }
 * ```
 */
export declare const authKeysZodSchema: z.ZodObject<{
    id: z.ZodString;
    uuid: z.ZodString;
    key: z.ZodString;
}, z.core.$strip>;
/**
 * TypeScript type inferred from Zod schema.
 */
export type AuthKeysZod = z.infer<typeof authKeysZodSchema>;
/**
 * Partial schema for validating incomplete auth key data or updates.
 */
export declare const authKeysPartialSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    uuid: z.ZodOptional<z.ZodString>;
    key: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
/**
 * Schema for creating new auth keys.
 * All fields required.
 */
export declare const authKeysCreateSchema: z.ZodObject<{
    id: z.ZodString;
    uuid: z.ZodString;
    key: z.ZodString;
}, z.core.$strip>;
/**
 * Schema for validating auth key updates.
 * Requires id for identification.
 */
export declare const authKeysUpdateSchema: z.ZodObject<{
    id: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    uuid: z.ZodOptional<z.ZodString>;
    key: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
