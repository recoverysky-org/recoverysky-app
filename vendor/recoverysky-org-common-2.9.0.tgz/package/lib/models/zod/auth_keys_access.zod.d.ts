import { z } from "zod";
/**
 * Zod validation schema for auth_keys_access model.
 *
 * Provides runtime validation for authentication key access logs.
 */
export declare const authKeysAccessZodSchema: z.ZodObject<{
    id: z.ZodString;
    uuid: z.ZodString;
    timestamp: z.ZodNumber;
    ip: z.ZodString;
}, z.core.$strip>;
export type AuthKeysAccessZod = z.infer<typeof authKeysAccessZodSchema>;
export declare const authKeysAccessPartialSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    uuid: z.ZodOptional<z.ZodString>;
    timestamp: z.ZodOptional<z.ZodNumber>;
    ip: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export declare const authKeysAccessCreateSchema: z.ZodObject<{
    id: z.ZodString;
    uuid: z.ZodString;
    timestamp: z.ZodNumber;
    ip: z.ZodString;
}, z.core.$strip>;
export declare const authKeysAccessUpdateSchema: z.ZodObject<{
    id: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    uuid: z.ZodOptional<z.ZodString>;
    timestamp: z.ZodOptional<z.ZodNumber>;
    ip: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
