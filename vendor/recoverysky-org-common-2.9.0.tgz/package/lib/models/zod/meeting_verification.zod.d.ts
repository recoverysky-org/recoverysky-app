import { z } from "zod";
import { VerifiedStatus } from "../../enums/index.js";
/**
 * Every count is individually optional — hugo sends whichever aggregates its
 * SDK build can derive, and that set changes between hugo releases. An
 * omitted count persists as NULL ("not observed"), which is distinct from 0
 * ("observed and none"), so a partial block is meaningful data, not an error.
 *
 * An entirely empty block is rejected: it says nothing a missing `data` key
 * doesn't already say, and letting it through would write a row of NULLs
 * that looks like a joined probe.
 */
export declare const verificationDataSchema: z.ZodObject<{
    coHostCount: z.ZodOptional<z.ZodNumber>;
    guestCount: z.ZodOptional<z.ZodNumber>;
    botCount: z.ZodOptional<z.ZodNumber>;
    videoOnCount: z.ZodOptional<z.ZodNumber>;
    audioJoinedCount: z.ZodOptional<z.ZodNumber>;
    phoneUserCount: z.ZodOptional<z.ZodNumber>;
    unmutedCount: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
export declare const verificationReportSchema: z.ZodObject<{
    id: z.ZodString;
    status: z.ZodEnum<typeof VerifiedStatus>;
    participantCount: z.ZodNumber;
    validatedAt: z.ZodNumber;
    errorCode: z.ZodOptional<z.ZodNumber>;
    errorMessage: z.ZodOptional<z.ZodString>;
    data: z.ZodOptional<z.ZodObject<{
        coHostCount: z.ZodOptional<z.ZodNumber>;
        guestCount: z.ZodOptional<z.ZodNumber>;
        botCount: z.ZodOptional<z.ZodNumber>;
        videoOnCount: z.ZodOptional<z.ZodNumber>;
        audioJoinedCount: z.ZodOptional<z.ZodNumber>;
        phoneUserCount: z.ZodOptional<z.ZodNumber>;
        unmutedCount: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type VerificationReportZod = z.infer<typeof verificationReportSchema>;
export type VerificationDataZod = z.infer<typeof verificationDataSchema>;
