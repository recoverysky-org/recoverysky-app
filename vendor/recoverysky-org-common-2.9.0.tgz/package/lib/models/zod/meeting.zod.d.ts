import { z } from "zod";
import { MeetingStatus, VerifiedStatus } from "../../enums/index.js";
/**
 * Full meeting schema with cross-field refinements.
 * Use this for complete meeting validation.
 */
export declare const meetingZodSchema: z.ZodObject<{
    id: z.ZodString;
    sid: z.ZodString;
    iid: z.ZodNullable<z.ZodString>;
    uid: z.ZodString;
    zid: z.ZodString;
    status: z.ZodEnum<typeof MeetingStatus>;
    created: z.ZodNumber;
    updated: z.ZodNumber;
    version: z.ZodDefault<z.ZodNumber>;
    verified: z.ZodDefault<z.ZodEnum<typeof VerifiedStatus>>;
    verified_retry: z.ZodDefault<z.ZodNumber>;
    verified_on: z.ZodDefault<z.ZodNumber>;
    url: z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>;
    password: z.ZodString;
    passwordEnc: z.ZodString;
    continuous: z.ZodDefault<z.ZodBoolean>;
    fellowship: z.ZodString;
    meetingTypes: z.ZodArray<z.ZodString>;
    language: z.ZodString;
    closed: z.ZodBoolean;
    requiresLogin: z.ZodBoolean;
    restricted: z.ZodBoolean;
    restrictedDescription: z.ZodString;
    trex: z.ZodOptional<z.ZodObject<{
        id: z.ZodDefault<z.ZodString>;
        coordinate: z.ZodDefault<z.ZodNumber>;
        coordinate_end: z.ZodOptional<z.ZodNumber>;
        timezone: z.ZodDefault<z.ZodString>;
        periodicity: z.ZodDefault<z.ZodNumber>;
        duration_ms: z.ZodOptional<z.ZodNumber>;
        dtstart: z.ZodString;
        dtend: z.ZodNullable<z.ZodString>;
        rrule_str: z.ZodString;
        rrule_json: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        hour: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        minute: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        dow: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        dom: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        month: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strip>>;
    description: z.ZodString;
    email: z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>;
    name: z.ZodString;
    phone: z.ZodString;
    website: z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>;
    conferencePhone: z.ZodString;
    tags: z.ZodArray<z.ZodString>;
    location: z.ZodString;
    venueType: z.ZodEnum<{
        "": "";
        in_person: "in_person";
        online: "online";
    }>;
    hybrid: z.ZodBoolean;
    venueName: z.ZodString;
    street: z.ZodString;
    city: z.ZodString;
    state: z.ZodString;
    postalCode: z.ZodString;
    country: z.ZodString;
    formattedAddress: z.ZodString;
    locationInfo: z.ZodString;
    region: z.ZodString;
    latitude: z.ZodNumber;
    longitude: z.ZodNumber;
    approximate: z.ZodBoolean;
    sourceHost: z.ZodString;
    sourceEntity: z.ZodString;
    sourceEntityId: z.ZodString;
    locationId: z.ZodString;
    groupId: z.ZodString;
    sourceFormats: z.ZodArray<z.ZodString>;
    contacts: z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            person: "person";
            entity: "entity";
            helpline: "helpline";
        }>;
        name: z.ZodString;
        phone: z.ZodString;
        email: z.ZodString;
    }, z.core.$strip>>;
    sha256: z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>;
}, z.core.$strip>;
/**
 * TypeScript type inferred from Zod schema.
 * Use this for type-safe validation results.
 */
export type MeetingZod = z.infer<typeof meetingZodSchema>;
/**
 * Partial schema for validating incomplete meeting data or updates.
 * All fields are optional. Uses base schema (without refinements) since
 * Zod doesn't support .partial() on refined schemas.
 *
 * @example
 * ```typescript
 * const updates = { name: 'New Meeting Name', duration: 3600000 };
 * const result = meetingPartialSchema.safeParse(updates);
 * ```
 */
export declare const meetingPartialSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    sid: z.ZodOptional<z.ZodString>;
    iid: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    uid: z.ZodOptional<z.ZodString>;
    zid: z.ZodOptional<z.ZodString>;
    status: z.ZodOptional<z.ZodEnum<typeof MeetingStatus>>;
    created: z.ZodOptional<z.ZodNumber>;
    updated: z.ZodOptional<z.ZodNumber>;
    version: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    verified: z.ZodOptional<z.ZodDefault<z.ZodEnum<typeof VerifiedStatus>>>;
    verified_retry: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    verified_on: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    url: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>>;
    password: z.ZodOptional<z.ZodString>;
    passwordEnc: z.ZodOptional<z.ZodString>;
    continuous: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
    fellowship: z.ZodOptional<z.ZodString>;
    meetingTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
    language: z.ZodOptional<z.ZodString>;
    closed: z.ZodOptional<z.ZodBoolean>;
    requiresLogin: z.ZodOptional<z.ZodBoolean>;
    restricted: z.ZodOptional<z.ZodBoolean>;
    restrictedDescription: z.ZodOptional<z.ZodString>;
    trex: z.ZodOptional<z.ZodOptional<z.ZodObject<{
        id: z.ZodDefault<z.ZodString>;
        coordinate: z.ZodDefault<z.ZodNumber>;
        coordinate_end: z.ZodOptional<z.ZodNumber>;
        timezone: z.ZodDefault<z.ZodString>;
        periodicity: z.ZodDefault<z.ZodNumber>;
        duration_ms: z.ZodOptional<z.ZodNumber>;
        dtstart: z.ZodString;
        dtend: z.ZodNullable<z.ZodString>;
        rrule_str: z.ZodString;
        rrule_json: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        hour: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        minute: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        dow: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        dom: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        month: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strip>>>;
    description: z.ZodOptional<z.ZodString>;
    email: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>>;
    name: z.ZodOptional<z.ZodString>;
    phone: z.ZodOptional<z.ZodString>;
    website: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>>;
    conferencePhone: z.ZodOptional<z.ZodString>;
    tags: z.ZodOptional<z.ZodArray<z.ZodString>>;
    location: z.ZodOptional<z.ZodString>;
    venueType: z.ZodOptional<z.ZodEnum<{
        "": "";
        in_person: "in_person";
        online: "online";
    }>>;
    hybrid: z.ZodOptional<z.ZodBoolean>;
    venueName: z.ZodOptional<z.ZodString>;
    street: z.ZodOptional<z.ZodString>;
    city: z.ZodOptional<z.ZodString>;
    state: z.ZodOptional<z.ZodString>;
    postalCode: z.ZodOptional<z.ZodString>;
    country: z.ZodOptional<z.ZodString>;
    formattedAddress: z.ZodOptional<z.ZodString>;
    locationInfo: z.ZodOptional<z.ZodString>;
    region: z.ZodOptional<z.ZodString>;
    latitude: z.ZodOptional<z.ZodNumber>;
    longitude: z.ZodOptional<z.ZodNumber>;
    approximate: z.ZodOptional<z.ZodBoolean>;
    sourceHost: z.ZodOptional<z.ZodString>;
    sourceEntity: z.ZodOptional<z.ZodString>;
    sourceEntityId: z.ZodOptional<z.ZodString>;
    locationId: z.ZodOptional<z.ZodString>;
    groupId: z.ZodOptional<z.ZodString>;
    sourceFormats: z.ZodOptional<z.ZodArray<z.ZodString>>;
    contacts: z.ZodOptional<z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            person: "person";
            entity: "entity";
            helpline: "helpline";
        }>;
        name: z.ZodString;
        phone: z.ZodString;
        email: z.ZodString;
    }, z.core.$strip>>>;
    sha256: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>>;
}, z.core.$strip>;
/**
 * Schema for creating new meetings.
 * Only requires essential fields, makes everything else optional.
 * Fields like id, uid, sid, created, updated, sha256 are typically populated programmatically.
 * Uses base schema (without refinements) since Zod doesn't support .partial() on refined schemas.
 */
export declare const meetingCreateSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    sid: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    iid: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    uid: z.ZodOptional<z.ZodString>;
    zid: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    status: z.ZodOptional<z.ZodEnum<typeof MeetingStatus>>;
    created: z.ZodOptional<z.ZodNumber>;
    updated: z.ZodOptional<z.ZodNumber>;
    version: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    verified: z.ZodOptional<z.ZodDefault<z.ZodEnum<typeof VerifiedStatus>>>;
    verified_retry: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    verified_on: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    url: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>>;
    password: z.ZodOptional<z.ZodString>;
    passwordEnc: z.ZodOptional<z.ZodString>;
    continuous: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
    fellowship: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    meetingTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
    language: z.ZodOptional<z.ZodString>;
    closed: z.ZodOptional<z.ZodBoolean>;
    requiresLogin: z.ZodOptional<z.ZodBoolean>;
    restricted: z.ZodOptional<z.ZodBoolean>;
    restrictedDescription: z.ZodOptional<z.ZodString>;
    trex: z.ZodOptional<z.ZodOptional<z.ZodObject<{
        id: z.ZodDefault<z.ZodString>;
        coordinate: z.ZodDefault<z.ZodNumber>;
        coordinate_end: z.ZodOptional<z.ZodNumber>;
        timezone: z.ZodDefault<z.ZodString>;
        periodicity: z.ZodDefault<z.ZodNumber>;
        duration_ms: z.ZodOptional<z.ZodNumber>;
        dtstart: z.ZodString;
        dtend: z.ZodNullable<z.ZodString>;
        rrule_str: z.ZodString;
        rrule_json: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        hour: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        minute: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        dow: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        dom: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        month: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strip>>>;
    description: z.ZodOptional<z.ZodString>;
    email: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>>;
    name: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    phone: z.ZodOptional<z.ZodString>;
    website: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>>;
    conferencePhone: z.ZodOptional<z.ZodString>;
    tags: z.ZodOptional<z.ZodArray<z.ZodString>>;
    location: z.ZodOptional<z.ZodString>;
    venueType: z.ZodOptional<z.ZodEnum<{
        "": "";
        in_person: "in_person";
        online: "online";
    }>>;
    hybrid: z.ZodOptional<z.ZodBoolean>;
    venueName: z.ZodOptional<z.ZodString>;
    street: z.ZodOptional<z.ZodString>;
    city: z.ZodOptional<z.ZodString>;
    state: z.ZodOptional<z.ZodString>;
    postalCode: z.ZodOptional<z.ZodString>;
    country: z.ZodOptional<z.ZodString>;
    formattedAddress: z.ZodOptional<z.ZodString>;
    locationInfo: z.ZodOptional<z.ZodString>;
    region: z.ZodOptional<z.ZodString>;
    latitude: z.ZodOptional<z.ZodNumber>;
    longitude: z.ZodOptional<z.ZodNumber>;
    approximate: z.ZodOptional<z.ZodBoolean>;
    sourceHost: z.ZodOptional<z.ZodString>;
    sourceEntity: z.ZodOptional<z.ZodString>;
    sourceEntityId: z.ZodOptional<z.ZodString>;
    locationId: z.ZodOptional<z.ZodString>;
    groupId: z.ZodOptional<z.ZodString>;
    sourceFormats: z.ZodOptional<z.ZodArray<z.ZodString>>;
    contacts: z.ZodOptional<z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            person: "person";
            entity: "entity";
            helpline: "helpline";
        }>;
        name: z.ZodString;
        phone: z.ZodString;
        email: z.ZodString;
    }, z.core.$strip>>>;
    sha256: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>>;
}, z.core.$strip>;
/**
 * Schema for validating meeting updates.
 * Requires critical fields but allows partial updates.
 * Uses base schema (without refinements) since Zod doesn't support .partial() on refined schemas.
 */
export declare const meetingUpdateSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    sid: z.ZodOptional<z.ZodString>;
    iid: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    uid: z.ZodOptional<z.ZodString>;
    zid: z.ZodNonOptional<z.ZodOptional<z.ZodString>>;
    status: z.ZodOptional<z.ZodEnum<typeof MeetingStatus>>;
    created: z.ZodOptional<z.ZodNumber>;
    updated: z.ZodOptional<z.ZodNumber>;
    version: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    verified: z.ZodOptional<z.ZodDefault<z.ZodEnum<typeof VerifiedStatus>>>;
    verified_retry: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    verified_on: z.ZodOptional<z.ZodDefault<z.ZodNumber>>;
    url: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>>;
    password: z.ZodOptional<z.ZodString>;
    passwordEnc: z.ZodOptional<z.ZodString>;
    continuous: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
    fellowship: z.ZodOptional<z.ZodString>;
    meetingTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
    language: z.ZodOptional<z.ZodString>;
    closed: z.ZodOptional<z.ZodBoolean>;
    requiresLogin: z.ZodOptional<z.ZodBoolean>;
    restricted: z.ZodOptional<z.ZodBoolean>;
    restrictedDescription: z.ZodOptional<z.ZodString>;
    trex: z.ZodOptional<z.ZodOptional<z.ZodObject<{
        id: z.ZodDefault<z.ZodString>;
        coordinate: z.ZodDefault<z.ZodNumber>;
        coordinate_end: z.ZodOptional<z.ZodNumber>;
        timezone: z.ZodDefault<z.ZodString>;
        periodicity: z.ZodDefault<z.ZodNumber>;
        duration_ms: z.ZodOptional<z.ZodNumber>;
        dtstart: z.ZodString;
        dtend: z.ZodNullable<z.ZodString>;
        rrule_str: z.ZodString;
        rrule_json: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        hour: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        minute: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        dow: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        dom: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        month: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strip>>>;
    description: z.ZodOptional<z.ZodString>;
    email: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>>;
    name: z.ZodOptional<z.ZodString>;
    phone: z.ZodOptional<z.ZodString>;
    website: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>>;
    conferencePhone: z.ZodOptional<z.ZodString>;
    tags: z.ZodOptional<z.ZodArray<z.ZodString>>;
    location: z.ZodOptional<z.ZodString>;
    venueType: z.ZodOptional<z.ZodEnum<{
        "": "";
        in_person: "in_person";
        online: "online";
    }>>;
    hybrid: z.ZodOptional<z.ZodBoolean>;
    venueName: z.ZodOptional<z.ZodString>;
    street: z.ZodOptional<z.ZodString>;
    city: z.ZodOptional<z.ZodString>;
    state: z.ZodOptional<z.ZodString>;
    postalCode: z.ZodOptional<z.ZodString>;
    country: z.ZodOptional<z.ZodString>;
    formattedAddress: z.ZodOptional<z.ZodString>;
    locationInfo: z.ZodOptional<z.ZodString>;
    region: z.ZodOptional<z.ZodString>;
    latitude: z.ZodOptional<z.ZodNumber>;
    longitude: z.ZodOptional<z.ZodNumber>;
    approximate: z.ZodOptional<z.ZodBoolean>;
    sourceHost: z.ZodOptional<z.ZodString>;
    sourceEntity: z.ZodOptional<z.ZodString>;
    sourceEntityId: z.ZodOptional<z.ZodString>;
    locationId: z.ZodOptional<z.ZodString>;
    groupId: z.ZodOptional<z.ZodString>;
    sourceFormats: z.ZodOptional<z.ZodArray<z.ZodString>>;
    contacts: z.ZodOptional<z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            person: "person";
            entity: "entity";
            helpline: "helpline";
        }>;
        name: z.ZodString;
        phone: z.ZodString;
        email: z.ZodString;
    }, z.core.$strip>>>;
    sha256: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodLiteral<"">]>>;
}, z.core.$strip>;
