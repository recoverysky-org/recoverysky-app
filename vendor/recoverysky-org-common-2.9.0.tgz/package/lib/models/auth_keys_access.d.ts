/**
 * Auth Keys Access Model
 *
 * Tracks access logs for authentication keys.
 */
export declare class auth_keys_access {
    id: string;
    uuid: string;
    timestamp: number;
    ip: string;
}
