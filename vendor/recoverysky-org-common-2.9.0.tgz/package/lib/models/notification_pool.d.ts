/**
 * A named set of rotating messages (e.g. "Daily Affirmations").
 *
 * @sqlite skip
 */
export declare class notification_pool {
    /** UUID */
    id: string;
    /** Admin-facing name */
    name: string;
    /** Selection strategy: "sequential" | "random" | "day_of_year" */
    strategy: string;
    /** Creation timestamp (UTC millis) */
    /** @format bigint */
    created: number;
}
