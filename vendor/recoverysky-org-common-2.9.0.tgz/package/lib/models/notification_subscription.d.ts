/**
 * A user's opt-in to a notification type on one device.
 * Per-device by design: a phone and a tablet are configured separately.
 *
 * @index uid
 * @index did
 * @index type_id
 * @sqlite skip
 */
export declare class notification_subscription {
    /** UUID */
    id: string;
    /** User profile ID */
    uid: string;
    /** Device ID */
    did: string;
    /** FK to notification_types.id */
    type_id: string;
    /** IANA timezone snapshot of the device at enable time */
    timezone: string;
    /** Per-type params validated against type.params_schema.
     * clean_time: { "recovery_date": "2019-03-04" } */
    params: Record<string, unknown>;
    /** Whether active */
    enabled: boolean;
    /** Creation timestamp (UTC millis) */
    /** @format bigint */
    created: number;
    /** Last updated timestamp (UTC millis) */
    /** @format bigint */
    updated: number;
}
