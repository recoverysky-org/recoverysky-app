/**
 * Join: which schedules (times) a subscription fires at.
 * "Encouragement 3x a day" = three rows.
 *
 * @index subscription_id
 * @index schedule_id
 * @sqlite skip
 */
export declare class notification_subscription_time {
    /** FK to notification_subscriptions.id */
    subscription_id: string;
    /** FK to notification_schedules.id */
    schedule_id: string;
}
