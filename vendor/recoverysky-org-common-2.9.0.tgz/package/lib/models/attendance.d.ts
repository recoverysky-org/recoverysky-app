export interface AttendanceEvent {
    timestamp: number;
    message: string;
    json: string;
}
/**
 * This is the attendance record - the gold that this app produces.  Customers pay for attendance records.
 *
 * When I user joins a meeting we will create an attendance record and populate events with all event messsages
 * that come out of the SDK.  This will include the join event the in meeting event any in meeting events
 * and the left meeting event.  On the left meeting event we will then process() the record as such
 *
 * public async process() {
    try {
      // determine start from records[]
      // start = millis
      // determine end from records[]
      // end = mills
      // credit = end - start
      // sttus = AttendanceStatus.PROCESSED
      // processed = now().millis
      // if credit > MIN_CREDIT valid = true
    } catch (error) {}
  }

  * We will then persist the attendance record to sqlite
 */
export declare class attendance {
    id: string;
    iid: string;
    uid: string;
    mid: string;
    zid: string;
    /** @format bigint */
    created: number;
    valid: boolean;
    uzid: string;
    zpid: string;
    zuid: string;
    meetingHost: string;
    meetingName: string;
    meetingTopic: string;
    archived: boolean;
    events: AttendanceEvent[];
    /** @format bigint */
    processed: number;
    /** @format bigint */
    start: number;
    /** @format bigint */
    end: number;
    credit: number;
    /** @format bigint */
    produced: number;
    arid: string;
    /** @format bigint */
    updated: number;
    deleted: boolean;
}
