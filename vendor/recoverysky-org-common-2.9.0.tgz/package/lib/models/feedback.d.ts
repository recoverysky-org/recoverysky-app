/**
 * User feedback for a meeting
 * Tracks user preferences and engagement metrics per meeting
 * Primary key is the meeting id (mid) - one feedback record per meeting per user
 */
export declare class feedback {
    mid: string;
    loves: boolean;
    rates: number;
    joins: number;
    lastJoin: number;
}
