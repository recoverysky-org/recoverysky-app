/**
 * Binds a deviceId to the App Attest key that most recently attested it.
 *
 * POST /attest takes deviceId from the request body and signs it into the
 * device JWT. App Attest proves "a genuine instance of this app on real Apple
 * hardware" — it does NOT bind that proof to a particular deviceId. This row
 * is what lets POST /attest/assert verify a later assertion: the stored
 * public key checks the signature, the stored counter defeats replay.
 *
 * CHANGED 2026-09-09: was first-writer-wins ("claim"). A valid full
 * attestation now rebinds unconditionally — attestation already proves a
 * genuine app on genuine hardware, and a reinstall legitimately arrives with
 * a new key. Assertions with a key other than the bound one are rejected;
 * that is the property that matters. Spec:
 * app/docs/superpowers/specs/2026-09-09-app-attest-assertions-and-jwt-persistence-design.md
 *
 * iOS: `key_id` and `public_key` come from the App Attest attestation
 * object; `assert_counter` is the last accepted assertion counter.
 *
 * Android: Play Integrity returns verdicts and no per-install key, so
 * `key_id` and `public_key` are empty and these rows carry NO cryptographic
 * guarantee. They exist for observability only.
 *
 * @index platform
 * @sqlite skip
 */
export declare class device_attestation {
    /** The deviceId the client presented — the primary key */
    device_id: string;
    /** "ios" | "android" */
    platform: string;
    /** iOS App Attest key id. Empty on Android — see the class doc. */
    key_id: string;
    /**
     * PEM (SPKI) public key extracted from the App Attest attestation
     * certificate. Empty on Android. Used by POST /attest/assert.
     */
    public_key: string;
    /**
     * Last accepted App Attest assertion counter. Reset to 0 on every full
     * attestation; each accepted assertion must present a strictly greater
     * value (Apple's replay protection).
     */
    assert_counter: number;
    /** UTC millis of the first successful attestation for this device_id */
    /** @format bigint */
    first_seen: number;
    /** UTC millis of the most recent successful attestation or assertion */
    /** @format bigint */
    last_seen: number;
    /** Successful full attestations recorded for this device_id */
    attest_count: number;
}
