import { Fellowship } from "../enums/Fellowship.js";
import { MeetingStatus, VerifiedStatus } from "../enums/index.js";
import { VenueType } from "../enums/VenueType.js";
import { Contact } from "../types/Contact.js";
/**
 * Plain data model for recovery meetings (AA, NA, etc.).
 *
 * **IMPORTANT FOR CONSUMERS**: This is a plain data type with no business logic methods.
 *
 * ## When to Use This (lowercase `meeting`)
 *
 * ✅ **Use for**:
 * - Type annotations in function signatures
 * - Defining types for plain data variables
 * - RxDB document types (`meetingDocType`)
 * - Drizzle query result types
 * - JSON serialization/deserialization
 *
 * ❌ **Don't use for**:
 * - Creating new instances (use `Meeting.create()` instead)
 * - Business logic operations (use `Meeting` class)
 * - Methods like `update()`, `isStale()` (use `Meeting` class)
 *
 * ## Relationship to Meeting Class
 *
 * This model is the **data shape** that the `Meeting` class extends.
 * The uppercase `Meeting` class adds business logic methods on top of this structure.
 *
 * ```typescript
 * // ❌ WRONG: Using model for instance creation
 * import { meeting } from '@recoverysky-org/common/models';
 * const m = new meeting(); // No methods available
 *
 * // ✅ CORRECT: Using class for instance creation
 * import { Meeting } from '@recoverysky-org/common';
 * const m = Meeting.create().unwrap(); // Has update(), isStale() methods
 *
 * // ✅ CORRECT: Using model for type annotation
 * import { meeting } from '@recoverysky-org/common/models';
 * function processMeeting(data: meeting): void { ... }
 * ```
 *
 * ## Usage with RxDB
 *
 * ```typescript
 * import { meetingDocType } from '@recoverysky-org/common/lib/models/rxdb/meeting.rxdb';
 * import { Meeting } from '@recoverysky-org/common';
 *
 * // Query returns plain data (meetingDocType, based on this model)
 * const docs: meetingDocType[] = await db.meetings.find().exec();
 *
 * // Convert to class for business logic
 * const meetings = docs.map(doc => Object.assign(new Meeting(), doc));
 * ```
 *
 * ## Usage with Drizzle
 *
 * ```typescript
 * import { meetings } from '@recoverysky-org/common/lib/models/drizzle/meetings.drizzle';
 * import { meeting } from '@recoverysky-org/common/models';
 * import { Meeting } from '@recoverysky-org/common';
 *
 * // Query returns plain data (meeting type)
 * const rows: meeting[] = await db.select().from(meetings);
 *
 * // Convert to class for business logic
 * const meetingInstances = rows.map(row => Object.assign(new Meeting(), row));
 * ```
 *
 * ## Schema Generation
 *
 * This model is the source for all schema generation:
 * - TypeScript schemas (`models/schema/meeting.schema.ts`)
 * - JSON schemas (`models/json/meeting.json`)
 * - RxDB schemas (`models/rxdb/meeting.rxdb.ts`)
 * - Drizzle tables (`models/drizzle/meetings.drizzle.ts`)
 *
 * After modifying this file, run `pnpm make` to regenerate all schemas.
 *
 * @see {@link Meeting} - Business logic class that extends this model
 * @see {@link https://github.com/recoverysky-org/recoverysky-common/blob/main/content/consumer-guide.md} - Consumer Guide
 * @see {@link https://github.com/recoverysky-org/recoverysky-common/blob/main/content/architecture.md} - Architecture Guide
 */
export declare class meeting {
    /**
     * Unique identifier for the meeting
     * @example "507f1f77bcf86cd799439011"
     */
    id: string;
    /**
     * Import ID from the original data source (if available)
     * @example "aa-intergroup-12345"
     */
    iid: string;
    /**
     * Unique composite identifier combining Zoom ID and trex.cooridinate
     * @format `{zid}:{cooridinate}`
     * @example "123456789:259200000"
     */
    uid: string;
    /**
     * Zoom meeting ID
     * @example "123456789"
     */
    zid: string;
    /**
     * Schedule ID that this meeting belongs to (FK to schedules.id)
     * Required - every meeting must belong to a schedule
     * @example "00000000-0000-0000-0000-000000000000"
     */
    sid: string;
    /**
     * Meeting status
     * @see {@link MeetingStatus}
     * @default MeetingStatus.ACTIVE
     */
    status: MeetingStatus;
    /**
     * Meeting verified status
     * @see {@link VerifiedStatus}
     * @default VerifiedStatus.NONE
     */
    verified: VerifiedStatus;
    /**
     * Verified retry counter
     */
    verified_retry: number;
    /**
     * Millis last verification performed on
     * @format bigint
     */
    verified_on: number;
    /**
     * Participant count at the last verification, including hugo itself.
     *
     * Cached from the newest meeting_verifications row, which is the source
     * of truth. The roster counts on meeting_verifications exclude hugo —
     * this field does not. Excluded from sha256: observational metadata,
     * hashing it would churn the hash on every probe and cause the scraper
     * merge to emit phantom UPDATEs.
     *
     * @default 0
     */
    participants: number;
    /**
     * @deprecated Never implemented. The merge path at
     * `scraper/src/cli/commands/operations.ts:588-610` does not carry this
     * forward from the cloud record, and nothing checks it to skip an update.
     *
     * Not needed: removal requests propagate through the normal refresh path —
     * when a source drops data, sha256 changes and merge emits an UPDATE.
     *
     * The column is retained deliberately. Dropping it would also drop
     * `meeting_histories.locked` and break the hand-written triggers in
     * `src/triggers/meetings.triggers.ts`, which reference OLD.locked/NEW.locked.
     * Those are applied by apply-triggers.sh, and `migrate:prod` runs
     * `drizzle-kit push` BEFORE apply-triggers.sh — so a drop leaves a window
     * where every write to `meetings` throws.
     *
     * @default false
     */
    locked: boolean;
    /**
     * Timestamp when the meeting was created (ISO 8601)
     * @format bigint
     * @example "2023-01-01T00:00:00.000Z"
     */
    created: number;
    /**
     * Timestamp when the meeting was last updated (ISO 8601)
     * @format bigint
     * @example "2023-01-01T00:00:00.000Z"
     */
    updated: number;
    /**
     * Version count of updates
     * @example 8
     */
    version: number;
    /**
     * Full Zoom meeting URL
     * @example "https://zoom.us/j/123456789?pwd=abc123"
     */
    url: string;
    /**
     * Plain text password for the Zoom meeting
     * @example "password123"
     */
    password: string;
    /**
     * Encrypted password extracted from the Zoom URL
     * @example "abc123def456"
     */
    passwordEnc: string;
    /**
     * Continuous meeting flag
     */
    continuous: boolean;
    /**
     * Fellowship/organization type
     * @example "AA" | "NA" | "CA" | "OA"
     */
    fellowship: Fellowship;
    /**
     * Array of meeting type codes
     * @example ["O", "BB", "D"] // Open, Big Book, Discussion
     */
    meetingTypes: string[];
    /**
     * Primary language of the meeting (ISO 639-1 code)
     * @example "en" | "es" | "fr"
     */
    language: string;
    /**
     * Indicates if the meeting is closed (members only)
     * @default false
     */
    closed: boolean;
    /**
     * Indicates if Zoom login is required to join
     * @default false
     */
    requiresLogin: boolean;
    /**
     * Indicates if there are attendance restrictions
     * @see {@link restrictedDescription}
     * @default false
     */
    restricted: boolean;
    /**
     * Description of attendance restrictions
     * @example "Women Only" | "LGBTQ+ Focus" | "Men Only"
     */
    restrictedDescription: string;
    /**
     * Full description of the meeting
     * @maxLength 5000
     */
    description: string;
    /**
     * Contact email address
     * @example "contact@meeting.org"
     */
    email: string;
    /**
     * Meeting name/title
     * @example "Monday Night Big Book Study"
     */
    name: string;
    /**
     * Contact phone number
     * @example "+1-555-123-4567"
     */
    phone: string;
    /**
     * Meeting or group website URL
     * @example "https://www.meeting.org"
     */
    website: string;
    /**
     * Conference phone number for dial-in access
     * @example "+1-555-123-4567"
     */
    conferencePhone: string;
    /**
     * Array of custom tags for categorization
     * @example ["beginner-friendly", "literature-study", "step-work"]
     */
    tags: string[];
    /**
     * Physical location description (if in-person)
     * @example "123 Main St, New York, NY 10001"
     */
    location: string;
    /**
     * How this meeting is attended.
     *
     * Values mirror TSML `attendance_option`. BMLT `venue_type` maps in:
     * 1 → in_person, 2 → online. BMLT 3 (hybrid) is not a value — see
     * {@link hybrid}.
     *
     * @example "in_person"
     */
    venueType: VenueType;
    /**
     * True when this meeting also meets the other way (online ↔ in-person).
     *
     * A hybrid meeting yields two records: one from the online source keyed by
     * Zoom ID (`venueType = online`), one from the in-person source keyed by
     * venue (`venueType = in_person`). Both carry `hybrid = true`.
     *
     * @example true
     */
    hybrid: boolean;
    /**
     * Name of the venue or building.
     * @example "Alano Club of Orange County"
     */
    venueName: string;
    /**
     * Street line of the venue address.
     *
     * For BMLT this comes directly from `location_street`. For TSML there are no
     * address components at all — only `formatted_address` — so this is parsed,
     * best-effort. A parse failure costs display quality, never identity, because
     * AA's venue key is the source's `location_id`.
     *
     * @example "1920 E Katella Ave"
     */
    street: string;
    /**
     * City / municipality.
     * @example "Orange"
     */
    city: string;
    /**
     * State or province.
     * @example "CA"
     */
    state: string;
    /**
     * Postal code.
     * @example "92867"
     */
    postalCode: string;
    /**
     * ISO country code.
     *
     * Derived from coordinates, NOT from BMLT's `location_nation`, which carries
     * four spellings of the United States plus 13,632 blanks.
     *
     * @example "US"
     */
    country: string;
    /**
     * Full single-line address as published by the source.
     * @example "1920 E Katella Ave, Orange, CA 92867, USA"
     */
    formattedAddress: string;
    /**
     * Room number, entrance, or directions within the venue.
     * @example "Room 3, side entrance off the parking lot"
     */
    locationInfo: string;
    /**
     * Source-defined region or neighbourhood.
     * @example "ORANGE"
     */
    region: string;
    /**
     * Venue latitude in decimal degrees.
     *
     * Highest-signal input to future duplicate clustering. Captured even though
     * the venue key does not use it, because it is free at ingest and would
     * otherwise require re-crawling every source to reconstruct.
     *
     * @format decimal
     * @precision 10
     * @scale 7
     * @example 33.8082996
     */
    latitude: number;
    /**
     * Venue longitude in decimal degrees.
     *
     * @format decimal
     * @precision 10
     * @scale 7
     * @example -117.8336485
     */
    longitude: number;
    /**
     * True when the source flags its geocode as approximate.
     *
     * TSML publishes this as the string "no"/"yes"; normalizers coerce it.
     *
     * @default false
     */
    approximate: boolean;
    /**
     * Hostname of the feed this record came from.
     *
     * Part of the p: key, so it participates in meeting identity. If a service
     * body changes domains, its meetings churn — detectable as a mass
     * DELETE + INSERT confined to one host.
     *
     * @example "oc-aa.org"
     */
    sourceHost: string;
    /**
     * Publishing service body or intergroup.
     * @example "Orange County Intergroup Association"
     */
    sourceEntity: string;
    /**
     * The source's own identifier for the publishing entity.
     * @example "1107"
     */
    sourceEntityId: string;
    /**
     * The source's raw venue identifier, unprefixed.
     *
     * TSML supplies this as `location_id`, and its prefixed form is what appears
     * in `zid` for AA. BMLT has no location entity, so it is empty for NA
     * records — NA identity uses the listing PK `id_bigint`, carried in `zid`,
     * and NA venue grouping derives from the address.
     *
     * @example "4471"
     */
    locationId: string;
    /**
     * Home group identifier from the source (BMLT `worldid_mixed`).
     *
     * NOT a key. One value appears 52 times on a single server across 41 distinct
     * weekday/time combinations, and the literal string "x" appears 748 times.
     * Useful for home-group association and NAWS joins only.
     *
     * @example "G00107701"
     */
    groupId: string;
    /**
     * Raw, unmapped meeting-format codes exactly as published.
     *
     * Retained because these codes are server-local and collide across sources:
     * `C` means CLOSED on one BMLT server and SPEAKER on another; `F` can mean
     * CLOSED, LANGUAGE, TOPIC, or WOMEN. 309 distinct code strings map to only 40
     * canonical concepts. Storing only the mapped output would make a mapping bug
     * cost a full re-crawl to correct.
     *
     * Sorted before hashing — source order carries no meaning.
     *
     * @example ["O", "CS", "WC"]
     */
    sourceFormats: string[];
    /**
     * Published contacts for this meeting.
     *
     * Intentionally-published data, retained rather than stripped: service bodies
     * publish contacts so that someone seeking help can reach a human being.
     *
     * Sorted before hashing — sources do not guarantee ordering.
     *
     * @example [{ kind: "entity", name: "OC Intergroup", phone: "17145564555", email: "manager@oc-aa.org" }]
     */
    contacts: Contact[];
    /**
     * SHA-256 hash of meeting data for change detection
     * Calculated in Meeting.update()
     * @example "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3"
     */
    sha256: string;
}
