/**
 * TREX event registry for notification slots. One row per (slot, timezone,
 * periodicity), created lazily when the first user in a zone picks the slot.
 * Bounded by slots x timezones, not by users.
 *
 * The row id IS the TREX event id (caller-supplied at engine insert).
 *
 * @index slot_id
 * @index timezone
 * @sqlite skip
 */
export declare class notification_schedule {
    /** UUID — also the TREX event id in the engine */
    id: string;
    /** FK to notification_slots.id */
    slot_id: string;
    /** IANA timezone */
    timezone: string;
    /** TREX periodicity (1 = DAILY) */
    periodicity: number;
    /** Denormalized TREX coordinate; the engine is source of truth */
    /** @format bigint */
    coordinate: number;
    /** Creation timestamp (UTC millis) */
    /** @format bigint */
    created: number;
}
