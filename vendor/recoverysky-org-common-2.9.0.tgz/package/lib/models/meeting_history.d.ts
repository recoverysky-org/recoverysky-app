import type { meeting } from "./meeting.js";
/**
 * Audit/history table for meetings
 *
 * Automatically tracks all changes to the meetings table via database trigger.
 * Contains full snapshot of meeting data at each change point, plus audit metadata.
 *
 * Design decisions:
 * - Full row snapshots (not diffs) for easy temporal queries
 * - changed_fields array tracks which fields changed (UPDATE only)
 * - Preserves original 'id' field name (FK to meetings.id)
 * - 'hid' is the primary key of this history table
 *
 * @see src/triggers/meetings.triggers.ts for trigger definition
 * @see https://www.cybertec-postgresql.com/en/row-change-auditing-options-for-postgresql/
 */
export interface meeting_history extends meeting {
    /**
     * Original meeting.id (non PK)
     * Copied from source meeting.id
     */
    mid: string;
    /**
     * Type of operation that created this history record
     * - INSERT: New meeting created
     * - UPDATE: Meeting modified (stores OLD state before change)
     * - DELETE: Meeting deleted (stores final state before deletion)
     */
    operation: "INSERT" | "UPDATE" | "DELETE";
    /**
     * Array of field names that changed (UPDATE operations only)
     * Example: ['status', 'name', 'updated']
     * Empty array for INSERT/DELETE operations
     */
    changed_fields: string[];
    /**
     * User/session identifier who made the change
     * Set via: SET LOCAL app.current_user = 'user_id'
     * Undefined if not set in transaction
     */
    changed_by?: string;
    /**
     * Timestamp when change occurred (Unix milliseconds)
     * Automatically set by trigger: EXTRACT(EPOCH FROM NOW()) * 1000
     * @format bigint
     */
    changed_at: number;
}
