import { VerifiedStatus } from "../enums/index.js";
/**
 * One hugo verifier probe result. Insert-only event log — rows are never
 * updated, so there is no `updated`/`version`/`sha256`.
 *
 * Source of truth for meeting attendance history. The newest row per `mid`
 * is cached onto `meeting.{verified, verified_on, participants}` by
 * MeetingVerificationRepository.record().
 *
 * COUNT SEMANTICS — read before writing analytics:
 * - `participants` INCLUDES hugo (a probe of an "empty" meeting reads 1).
 * - Every roster count below (`cohost_count` … `unmuted_count`) EXCLUDES hugo.
 * - Roster counts are null when hugo never joined (failed probe). Null is
 *   "not observed"; 0 is "observed and none". Never conflate them.
 *
 * @sqlite skip
 */
export declare class meeting_verification {
    /**
     * Unique identifier for this probe result
     * @example "3f2b8c1e-9d4a-4f6b-8a2e-1c5d7e9f0a3b"
     */
    id: string;
    /**
     * Meeting this probe targeted (FK to meetings.id, CASCADE on delete)
     * @example "507f1f77bcf86cd799439011"
     */
    mid: string;
    /**
     * When the probe completed (hugo's validatedAt), UTC millis
     * @format bigint
     */
    observed_at: number;
    /**
     * Probe outcome
     * @see {@link VerifiedStatus}
     * @default VerifiedStatus.NONE
     */
    verified: VerifiedStatus;
    /**
     * Headcount at probe time, INCLUDING hugo itself.
     * EMPTY status corresponds to participants == 1 (only hugo).
     */
    participants: number;
    /**
     * Hugo error code; 0 = no error
     */
    error_code: number;
    /**
     * Hugo error message; "" = no error
     */
    error_message: string;
    /** Co-hosts in the roster (excludes hugo) */
    cohost_count?: number | null;
    /** Guests in the roster (excludes hugo) */
    guest_count?: number | null;
    /** Detected bots in the roster (excludes hugo) */
    bot_count?: number | null;
    /** Attendees with video on (excludes hugo) */
    video_on_count?: number | null;
    /** Attendees joined to audio (excludes hugo) */
    audio_joined_count?: number | null;
    /** Attendees dialed in by phone (excludes hugo) */
    phone_user_count?: number | null;
    /** Attendees currently unmuted (excludes hugo) */
    unmuted_count?: number | null;
}
