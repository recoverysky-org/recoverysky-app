/**
 * Reminder for a scheduled meeting.
 * Allows users to set notifications for upcoming meetings.
 */
export declare class reminder {
    /** Unique identifier */
    id: string;
    /** User profile ID (FK to user_profiles.id) */
    uid: string;
    /** Unique device identifier */
    did: string;
    /** Schedule ID (FK to schedules.id)
     *
     * Nullable
     *
     * Depends on value of mid.  If sid set and mid not, the entire schedule
     * is set for reminders if mid is set, the meeting will have a start time
     * at which all meetings in the schedule at that start time will be reminded.
     */
    sid: string | null;
    /** Meeting ID (FK to meetings.id)
     *
     * If sid is not set, this points to the individual meeting in the schedule
     *  which will be reminded If sid is set, this will point to a meeting time
     * and all meetings at that time in the schedule will be reminded.
     */
    mid: string | null;
    /** Reminder scope
     * - "single": remind for one specific meeting
     * - "row": remind for all meetings at the same time in the schedule
     * - "all": remind for all meetings in the schedule
     */
    scope: string;
    /** Day of Week
     * ISO dow Mon = 1
     * Has no meaning when scop !== single
     */
    dow: number;
    /** Time of Day Meeting starts (reference point for minutes_before)
     * min past 00:00
     */
    time: number;
    /** Reminder name/label */
    name: string;
    /** User's timezone (IANA) */
    timezone: string;
    /** Minutes before meeting to send reminder */
    minutes_before: number;
    /** Also notify at meeting start time */
    at_start: boolean;
    /** Whether the reminder is enabled */
    enabled: boolean;
    /** Creation timestamp (UTC millis) */
    /** @format bigint */
    created: number;
    /** Last updated timestamp (UTC millis) */
    /** @format bigint */
    updated: number;
}
