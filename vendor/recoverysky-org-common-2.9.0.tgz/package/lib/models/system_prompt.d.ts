/**
 * SystemPrompt model
 *
 * Stores versioned system prompts with variable templating support.
 * Only one prompt per name can be active at a time.
 */
export declare class system_prompt {
    /** Unique identifier */
    id: string;
    /** Prompt name/identifier, e.g., 'recovery-agent' */
    name: string;
    /** The actual prompt text content */
    content: string;
    /** Variable definitions for templating */
    variables: Record<string, unknown>;
    /** Only one active prompt per name */
    active: boolean;
    /**
     * Creation timestamp (millis)
     * @format bigint
     */
    created: number;
    /**
     * Last update timestamp (millis)
     * @format bigint
     */
    updated: number;
}
