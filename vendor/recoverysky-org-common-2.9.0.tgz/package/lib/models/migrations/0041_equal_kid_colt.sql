CREATE TABLE "scheduled_reminders" (
	"created" bigint DEFAULT 0 NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"occurrence_id" text DEFAULT '' NOT NULL,
	"onesignal_id" text DEFAULT '' NOT NULL,
	"reminder_id" text DEFAULT '' NOT NULL,
	"send_at_utc" bigint DEFAULT 0 NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL
);
--> statement-breakpoint
ALTER TABLE "reminders" ADD COLUMN "last_processed" bigint DEFAULT 0 NOT NULL;--> statement-breakpoint
CREATE INDEX "scheduled_reminders_reminder_id_idx" ON "scheduled_reminders" USING btree ("reminder_id");--> statement-breakpoint
CREATE INDEX "scheduled_reminders_status_idx" ON "scheduled_reminders" USING btree ("status");--> statement-breakpoint
CREATE INDEX "scheduled_reminders_send_at_utc_idx" ON "scheduled_reminders" USING btree ("send_at_utc");