CREATE TABLE "newses" (
	"body" text DEFAULT '' NOT NULL,
	"end" bigint DEFAULT 0 NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"start" bigint DEFAULT 0 NOT NULL,
	"title" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE INDEX "newses_start_idx" ON "newses" USING btree ("start");--> statement-breakpoint
CREATE INDEX "newses_end_idx" ON "newses" USING btree ("end");--> statement-breakpoint
CREATE INDEX "attendance_reports_messageId_idx" ON "attendance_reports" USING btree ("messageId");--> statement-breakpoint
CREATE INDEX "attendance_reports_uid_idx" ON "attendance_reports" USING btree ("uid");