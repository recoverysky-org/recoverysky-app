CREATE INDEX "attendance_reports_mid_idx" ON "attendance_reports" USING btree ("mid");--> statement-breakpoint
CREATE INDEX "attendance_reports_uid_idx" ON "attendance_reports" USING btree ("uid");