CREATE TABLE "auth_keys" (
	"id" text PRIMARY KEY NOT NULL,
	"uuid" text NOT NULL,
	"key" text NOT NULL
);
