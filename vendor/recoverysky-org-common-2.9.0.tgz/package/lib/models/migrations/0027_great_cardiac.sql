ALTER TABLE "meeting_verifications" RENAME COLUMN "error" TO "status";--> statement-breakpoint
ALTER TABLE "meeting_verifications" ALTER COLUMN "success" SET DEFAULT true;