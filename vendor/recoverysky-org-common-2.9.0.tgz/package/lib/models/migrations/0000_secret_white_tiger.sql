CREATE TABLE "meeting_histories" (
	"changed_at" bigint NOT NULL,
	"changed_by" text,
	"changed_fields" jsonb NOT NULL,
	"closed" boolean DEFAULT false NOT NULL,
	"conferencePhone" text DEFAULT '' NOT NULL,
	"created" timestamp with time zone NOT NULL,
	"description" varchar(5000) DEFAULT '' NOT NULL,
	"email" text DEFAULT '' NOT NULL,
	"fellowship" text NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"iid" text DEFAULT '' NOT NULL,
	"language" text DEFAULT '' NOT NULL,
	"location" text DEFAULT '' NOT NULL,
	"locked" boolean DEFAULT false NOT NULL,
	"meetingTypes" jsonb NOT NULL,
	"mid" text NOT NULL,
	"name" text DEFAULT '' NOT NULL,
	"operation" text NOT NULL,
	"password" text DEFAULT '' NOT NULL,
	"passwordEnc" text DEFAULT '' NOT NULL,
	"phone" text DEFAULT '' NOT NULL,
	"requiresLogin" boolean DEFAULT false NOT NULL,
	"restricted" boolean DEFAULT false NOT NULL,
	"restrictedDescription" text DEFAULT '' NOT NULL,
	"sha256" text DEFAULT '' NOT NULL,
	"sid" text DEFAULT '' NOT NULL,
	"status" text NOT NULL,
	"tags" jsonb NOT NULL,
	"uid" text DEFAULT '' NOT NULL,
	"updated" timestamp with time zone NOT NULL,
	"url" text DEFAULT '' NOT NULL,
	"verified" text NOT NULL,
	"version" integer DEFAULT 0 NOT NULL,
	"website" text DEFAULT '' NOT NULL,
	"zid" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "meetings" (
	"closed" boolean DEFAULT false NOT NULL,
	"conferencePhone" text DEFAULT '' NOT NULL,
	"created" timestamp with time zone NOT NULL,
	"description" varchar(5000) DEFAULT '' NOT NULL,
	"email" text DEFAULT '' NOT NULL,
	"fellowship" text NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"iid" text DEFAULT '' NOT NULL,
	"language" text DEFAULT '' NOT NULL,
	"location" text DEFAULT '' NOT NULL,
	"locked" boolean DEFAULT false NOT NULL,
	"meetingTypes" jsonb NOT NULL,
	"name" text DEFAULT '' NOT NULL,
	"password" text DEFAULT '' NOT NULL,
	"passwordEnc" text DEFAULT '' NOT NULL,
	"phone" text DEFAULT '' NOT NULL,
	"requiresLogin" boolean DEFAULT false NOT NULL,
	"restricted" boolean DEFAULT false NOT NULL,
	"restrictedDescription" text DEFAULT '' NOT NULL,
	"sha256" text DEFAULT '' NOT NULL,
	"sid" text DEFAULT '' NOT NULL,
	"status" text NOT NULL,
	"tags" jsonb NOT NULL,
	"uid" text DEFAULT '' NOT NULL,
	"updated" timestamp with time zone NOT NULL,
	"url" text DEFAULT '' NOT NULL,
	"verified" text NOT NULL,
	"version" integer DEFAULT 0 NOT NULL,
	"website" text DEFAULT '' NOT NULL,
	"zid" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "schedules" (
	"created" timestamp with time zone NOT NULL,
	"fellowship" text NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"mids" jsonb NOT NULL,
	"name" text DEFAULT '' NOT NULL,
	"sha256" text DEFAULT '' NOT NULL,
	"status" text NOT NULL,
	"updated" timestamp with time zone NOT NULL,
	"version" integer DEFAULT 0 NOT NULL,
	"zids" jsonb NOT NULL
);
--> statement-breakpoint
CREATE TABLE "system_prompts" (
	"active" boolean DEFAULT false NOT NULL,
	"content" text DEFAULT '' NOT NULL,
	"created" timestamp with time zone NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"name" text DEFAULT '' NOT NULL,
	"updated" timestamp with time zone NOT NULL,
	"variables" jsonb NOT NULL
);
--> statement-breakpoint
CREATE TABLE "trexes" (
	"coordinate" integer DEFAULT 0 NOT NULL,
	"coordinate_end" integer DEFAULT 0 NOT NULL,
	"dom" integer,
	"dow" integer,
	"dtend" text,
	"dtstart" text DEFAULT '' NOT NULL,
	"duration_ms" integer DEFAULT 0 NOT NULL,
	"hour" integer,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"minute" integer,
	"month" integer,
	"periodicity" integer NOT NULL,
	"rrule_json" jsonb NOT NULL,
	"rrule_str" text DEFAULT '' NOT NULL,
	"timezone" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE INDEX "meetings_name_idx" ON "meetings" USING btree ("name");--> statement-breakpoint
CREATE INDEX "meetings_status_idx" ON "meetings" USING btree ("status");--> statement-breakpoint
CREATE INDEX "meetings_fellowship_idx" ON "meetings" USING btree ("fellowship");--> statement-breakpoint
CREATE UNIQUE INDEX "meetings_uid_idx" ON "meetings" USING btree ("uid");--> statement-breakpoint
CREATE INDEX "meetings_iid_idx" ON "meetings" USING btree ("iid");--> statement-breakpoint
CREATE INDEX "meetings_verified_idx" ON "meetings" USING btree ("verified");--> statement-breakpoint
CREATE INDEX "meetings_status_uid_idx" ON "meetings" USING btree ("status","uid");--> statement-breakpoint
CREATE INDEX "meetings_sid_idx" ON "meetings" USING btree ("sid");--> statement-breakpoint
CREATE INDEX "schedules_name_idx" ON "schedules" USING btree ("name");--> statement-breakpoint
CREATE INDEX "schedules_status_idx" ON "schedules" USING btree ("status");--> statement-breakpoint
CREATE INDEX "schedules_mids_gin_idx" ON "schedules" USING gin ("mids");--> statement-breakpoint
CREATE INDEX "schedules_zids_gin_idx" ON "schedules" USING gin ("zids");--> statement-breakpoint
CREATE INDEX "idx_prompts_name" ON "system_prompts" USING btree ("name");--> statement-breakpoint
CREATE UNIQUE INDEX "idx_prompts_active_unique" ON "system_prompts" USING btree ("name") WHERE active = true;--> statement-breakpoint
CREATE INDEX "trex_coordinate_idx" ON "trexes" USING btree ("coordinate");--> statement-breakpoint
CREATE INDEX "trex_timezone_idx" ON "trexes" USING btree ("timezone");--> statement-breakpoint
CREATE INDEX "trex_periodicity_idx" ON "trexes" USING btree ("periodicity");--> statement-breakpoint
CREATE INDEX "trex_coord_periodicity_tz_idx" ON "trexes" USING btree ("coordinate","periodicity","timezone");--> statement-breakpoint
CREATE INDEX "trex_coord_end_periodicity_tz_idx" ON "trexes" USING btree ("coordinate_end","periodicity","timezone");