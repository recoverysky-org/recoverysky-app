ALTER TABLE "attendances" ALTER COLUMN "events" SET DEFAULT '[]'::jsonb;--> statement-breakpoint
ALTER TABLE "meeting_histories" ALTER COLUMN "fellowship" SET DEFAULT '';--> statement-breakpoint
ALTER TABLE "meeting_histories" ALTER COLUMN "meetingTypes" SET DEFAULT '[]'::jsonb;--> statement-breakpoint
ALTER TABLE "meeting_histories" ALTER COLUMN "tags" SET DEFAULT '[]'::jsonb;--> statement-breakpoint
ALTER TABLE "meetings" ALTER COLUMN "fellowship" SET DEFAULT '';--> statement-breakpoint
ALTER TABLE "meetings" ALTER COLUMN "meetingTypes" SET DEFAULT '[]'::jsonb;--> statement-breakpoint
ALTER TABLE "meetings" ALTER COLUMN "tags" SET DEFAULT '[]'::jsonb;--> statement-breakpoint
ALTER TABLE "schedules" ALTER COLUMN "fellowship" SET DEFAULT '';--> statement-breakpoint
ALTER TABLE "schedules" ALTER COLUMN "mids" SET DEFAULT '[]'::jsonb;--> statement-breakpoint
ALTER TABLE "schedules" ALTER COLUMN "zids" SET DEFAULT '[]'::jsonb;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "approximate" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "city" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "contacts" jsonb DEFAULT '[]'::jsonb NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "country" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "formattedAddress" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "groupId" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "latitude" numeric(10, 7) DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "locationId" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "locationInfo" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "longitude" numeric(10, 7) DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "postalCode" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "region" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "sourceEntity" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "sourceEntityId" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "sourceFormats" jsonb DEFAULT '[]'::jsonb NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "sourceHost" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "state" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "street" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "venueName" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "venueType" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "approximate" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "city" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "contacts" jsonb DEFAULT '[]'::jsonb NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "country" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "formattedAddress" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "groupId" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "latitude" numeric(10, 7) DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "locationId" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "locationInfo" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "longitude" numeric(10, 7) DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "postalCode" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "region" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "sourceEntity" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "sourceEntityId" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "sourceFormats" jsonb DEFAULT '[]'::jsonb NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "sourceHost" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "state" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "street" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "venueName" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "venueType" text DEFAULT '' NOT NULL;