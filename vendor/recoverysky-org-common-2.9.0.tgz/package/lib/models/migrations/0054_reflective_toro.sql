CREATE TABLE "meeting_verifications" (
	"audio_joined_count" integer,
	"bot_count" integer,
	"cohost_count" integer,
	"error_code" integer DEFAULT 0 NOT NULL,
	"error_message" text DEFAULT '' NOT NULL,
	"guest_count" integer,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"mid" text DEFAULT '' NOT NULL,
	"observed_at" bigint DEFAULT 0 NOT NULL,
	"participants" integer DEFAULT 0 NOT NULL,
	"phone_user_count" integer,
	"unmuted_count" integer,
	"verified" text DEFAULT 'NONE' NOT NULL,
	"video_on_count" integer
);
--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "participants" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "participants" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
CREATE INDEX "meeting_verifications_mid_observed_idx" ON "meeting_verifications" USING btree ("mid","observed_at");