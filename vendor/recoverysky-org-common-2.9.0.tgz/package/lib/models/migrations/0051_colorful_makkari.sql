ALTER TABLE "attendance_reports" ADD COLUMN "deleted" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "attendance_reports" ADD COLUMN "updated" bigint DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "attendances" ADD COLUMN "deleted" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "attendances" ADD COLUMN "updated" bigint DEFAULT 0 NOT NULL;--> statement-breakpoint
CREATE INDEX "attendance_reports_uid_updated_idx" ON "attendance_reports" USING btree ("uid","updated");--> statement-breakpoint
CREATE INDEX "attendances_uid_updated_idx" ON "attendances" USING btree ("uid","updated");