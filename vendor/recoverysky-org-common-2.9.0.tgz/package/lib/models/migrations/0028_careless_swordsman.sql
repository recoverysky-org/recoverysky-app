DROP INDEX "meetings_verified_idx";--> statement-breakpoint
ALTER TABLE "meeting_verifications" ALTER COLUMN "status" DROP DEFAULT;--> statement-breakpoint
ALTER TABLE "meeting_histories" DROP COLUMN "verified";--> statement-breakpoint
ALTER TABLE "meetings" DROP COLUMN "verified";