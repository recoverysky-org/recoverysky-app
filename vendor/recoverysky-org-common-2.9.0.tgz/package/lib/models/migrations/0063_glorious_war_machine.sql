ALTER TABLE "device_attestations" ADD COLUMN "assert_counter" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "device_attestations" ADD COLUMN "public_key" text DEFAULT '' NOT NULL;