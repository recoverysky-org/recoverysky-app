CREATE INDEX "reminders_uid_idx" ON "reminders" USING btree ("uid");--> statement-breakpoint
CREATE INDEX "reminders_sid_idx" ON "reminders" USING btree ("sid");--> statement-breakpoint
CREATE INDEX "reminders_mid_idx" ON "reminders" USING btree ("mid");--> statement-breakpoint
CREATE INDEX "reminders_enabled_idx" ON "reminders" USING btree ("enabled");--> statement-breakpoint
CREATE INDEX "reminders_uid_enabled_idx" ON "reminders" USING btree ("uid","enabled");