ALTER TABLE "attendance_reports" ALTER COLUMN "updated" SET DEFAULT 1;--> statement-breakpoint
ALTER TABLE "attendances" ALTER COLUMN "updated" SET DEFAULT 1;--> statement-breakpoint
UPDATE "attendances" SET "updated" = 1 WHERE "updated" = 0;--> statement-breakpoint
UPDATE "attendance_reports" SET "updated" = 1 WHERE "updated" = 0;