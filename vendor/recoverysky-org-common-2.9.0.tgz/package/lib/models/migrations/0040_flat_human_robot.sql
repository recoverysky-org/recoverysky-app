ALTER TABLE "meeting_histories" ADD COLUMN "continuous" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "continuous" boolean DEFAULT false NOT NULL;