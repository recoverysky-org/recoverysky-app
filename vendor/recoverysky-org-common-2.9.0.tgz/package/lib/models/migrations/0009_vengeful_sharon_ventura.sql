CREATE TABLE "attendance_reports" (
	"email" text DEFAULT '' NOT NULL,
	"emailConfirmation" text DEFAULT '' NOT NULL,
	"emailSent" integer DEFAULT 0 NOT NULL,
	"generated" integer DEFAULT 0 NOT NULL,
	"html" text DEFAULT '' NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"uid" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
ALTER TABLE "attendances" ADD COLUMN "archived" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "attendances" ADD COLUMN "meetingName" text DEFAULT '' NOT NULL;