ALTER TABLE "meeting_histories" ALTER COLUMN "created" SET DATA TYPE bigint USING (extract(epoch from "created") * 1000)::bigint;--> statement-breakpoint
ALTER TABLE "meeting_histories" ALTER COLUMN "updated" SET DATA TYPE bigint USING (extract(epoch from "updated") * 1000)::bigint;--> statement-breakpoint
ALTER TABLE "meetings" ALTER COLUMN "created" SET DATA TYPE bigint USING (extract(epoch from "created") * 1000)::bigint;--> statement-breakpoint
ALTER TABLE "meetings" ALTER COLUMN "updated" SET DATA TYPE bigint USING (extract(epoch from "updated") * 1000)::bigint;--> statement-breakpoint
ALTER TABLE "schedules" ALTER COLUMN "created" SET DATA TYPE bigint USING (extract(epoch from "created") * 1000)::bigint;--> statement-breakpoint
ALTER TABLE "schedules" ALTER COLUMN "updated" SET DATA TYPE bigint USING (extract(epoch from "updated") * 1000)::bigint;--> statement-breakpoint
ALTER TABLE "system_prompts" ALTER COLUMN "created" SET DATA TYPE bigint USING (extract(epoch from "created") * 1000)::bigint;--> statement-breakpoint
ALTER TABLE "system_prompts" ALTER COLUMN "updated" SET DATA TYPE bigint USING (extract(epoch from "updated") * 1000)::bigint;