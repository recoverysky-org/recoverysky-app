CREATE TABLE "chat_messages" (
	"createdAt" integer DEFAULT 0 NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"metadata" text,
	"parts" text DEFAULT '' NOT NULL,
	"role" text DEFAULT '' NOT NULL,
	"updatedAt" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
ALTER TABLE "auth_keys_accesses" DISABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "auth_keyses" DISABLE ROW LEVEL SECURITY;--> statement-breakpoint
DROP TABLE "auth_keys_accesses" CASCADE;--> statement-breakpoint
DROP TABLE "auth_keyses" CASCADE;--> statement-breakpoint
ALTER TABLE "auth_keys" DROP CONSTRAINT "auth_keys_uuid_unique";--> statement-breakpoint
ALTER TABLE "auth_keys_access" ALTER COLUMN "id" SET DEFAULT '';--> statement-breakpoint
ALTER TABLE "auth_keys_access" ALTER COLUMN "uuid" SET DEFAULT '';--> statement-breakpoint
ALTER TABLE "auth_keys_access" ALTER COLUMN "timestamp" SET DEFAULT 0;--> statement-breakpoint
ALTER TABLE "auth_keys_access" ALTER COLUMN "ip" SET DEFAULT '';--> statement-breakpoint
ALTER TABLE "auth_keys" ALTER COLUMN "id" SET DEFAULT '';--> statement-breakpoint
ALTER TABLE "auth_keys" ALTER COLUMN "uuid" SET DEFAULT '';--> statement-breakpoint
ALTER TABLE "auth_keys" ALTER COLUMN "key" SET DEFAULT '';