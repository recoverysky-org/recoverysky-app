ALTER TABLE "meeting_histories" ALTER COLUMN "verified_on" SET DATA TYPE bigint;--> statement-breakpoint
ALTER TABLE "meetings" ALTER COLUMN "verified_on" SET DATA TYPE bigint;