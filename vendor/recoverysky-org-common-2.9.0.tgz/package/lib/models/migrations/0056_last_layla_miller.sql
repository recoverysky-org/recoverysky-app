DROP INDEX "notification_deliveries_source_occurrence_uniq_idx";--> statement-breakpoint
DROP INDEX "notification_schedules_slot_tz_period_uniq_idx";--> statement-breakpoint
DROP INDEX "notification_subscriptions_uid_did_type_uniq_idx";--> statement-breakpoint
ALTER TABLE "notification_subscription_times" DROP CONSTRAINT "notification_subscription_times_subscription_id_schedule_id_pk";--> statement-breakpoint
ALTER TABLE "notification_types" ALTER COLUMN "params_schema" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "hybrid" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "hybrid" boolean DEFAULT false NOT NULL;