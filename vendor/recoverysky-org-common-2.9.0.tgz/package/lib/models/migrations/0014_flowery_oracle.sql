ALTER TABLE "attendance_reports" ALTER COLUMN "confirmed" SET DATA TYPE bigint;--> statement-breakpoint
ALTER TABLE "attendance_reports" ALTER COLUMN "generated" SET DATA TYPE bigint;--> statement-breakpoint
ALTER TABLE "attendances" ALTER COLUMN "created" SET DATA TYPE bigint;--> statement-breakpoint
ALTER TABLE "attendances" ALTER COLUMN "end" SET DATA TYPE bigint;--> statement-breakpoint
ALTER TABLE "attendances" ALTER COLUMN "processed" SET DATA TYPE bigint;--> statement-breakpoint
ALTER TABLE "attendances" ALTER COLUMN "produced" SET DATA TYPE bigint;--> statement-breakpoint
ALTER TABLE "attendances" ALTER COLUMN "start" SET DATA TYPE bigint;--> statement-breakpoint
ALTER TABLE "chat_messages" ALTER COLUMN "createdAt" SET DATA TYPE bigint;--> statement-breakpoint
ALTER TABLE "chat_messages" ALTER COLUMN "updatedAt" SET DATA TYPE bigint;--> statement-breakpoint
ALTER TABLE "trexes" ALTER COLUMN "coordinate" SET DATA TYPE bigint;--> statement-breakpoint
ALTER TABLE "trexes" ALTER COLUMN "coordinate_end" SET DATA TYPE bigint;