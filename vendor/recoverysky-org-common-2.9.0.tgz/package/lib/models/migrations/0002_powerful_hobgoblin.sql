CREATE TABLE "feedbacks" (
	"joins" integer DEFAULT 0 NOT NULL,
	"lastJoin" integer DEFAULT 0 NOT NULL,
	"loves" boolean DEFAULT false NOT NULL,
	"mid" text PRIMARY KEY DEFAULT '' NOT NULL,
	"rates" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "user_profiles" (
	"id" text PRIMARY KEY DEFAULT 'default' NOT NULL,
	"short_name" text DEFAULT '' NOT NULL,
	"pronouns" text,
	"recovery_date" text,
	"fellowship" text DEFAULT 'AA' NOT NULL,
	"language" text DEFAULT '' NOT NULL
);
