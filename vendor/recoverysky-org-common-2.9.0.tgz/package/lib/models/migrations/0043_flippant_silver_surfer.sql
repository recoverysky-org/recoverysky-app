CREATE TABLE "push_tokens" (
	"created" bigint DEFAULT 0 NOT NULL,
	"did" text DEFAULT '' NOT NULL,
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"platform" text DEFAULT '' NOT NULL,
	"token" text DEFAULT '' NOT NULL,
	"uid" uuid NOT NULL,
	"updated" bigint DEFAULT 0 NOT NULL
);
--> statement-breakpoint
ALTER TABLE "reminders" ALTER COLUMN "mid" DROP DEFAULT;--> statement-breakpoint
ALTER TABLE "reminders" ALTER COLUMN "mid" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "reminders" ALTER COLUMN "sid" DROP DEFAULT;--> statement-breakpoint
ALTER TABLE "reminders" ALTER COLUMN "sid" DROP NOT NULL;--> statement-breakpoint
CREATE INDEX "push_tokens_uid_idx" ON "push_tokens" USING btree ("uid");--> statement-breakpoint
CREATE UNIQUE INDEX "push_tokens_uid_did_uniq_idx" ON "push_tokens" USING btree ("uid","did");--> statement-breakpoint
CREATE UNIQUE INDEX "scheduled_reminders_reminder_occurrence_uniq_idx" ON "scheduled_reminders" USING btree ("reminder_id","occurrence_id");