ALTER TABLE "meetings" ALTER COLUMN "status" SET DEFAULT 'ACTIVE';--> statement-breakpoint
ALTER TABLE "meetings" ALTER COLUMN "verified" SET DEFAULT 'NONE';--> statement-breakpoint
ALTER TABLE "schedules" ALTER COLUMN "status" SET DEFAULT 'ACTIVE';