ALTER TABLE "meeting_histories" ALTER COLUMN "status" SET DEFAULT 'ACTIVE';--> statement-breakpoint
ALTER TABLE "meeting_histories" ALTER COLUMN "verified" SET DEFAULT 'NONE';