CREATE TABLE "auth_keys_accesses" (
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"ip" text DEFAULT '' NOT NULL,
	"timestamp" integer DEFAULT 0 NOT NULL,
	"uuid" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "auth_keyses" (
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"key" text DEFAULT '' NOT NULL,
	"uuid" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
ALTER TABLE "user_profiles" RENAME COLUMN "short_name" TO "shortName";--> statement-breakpoint
ALTER TABLE "schedules" ADD COLUMN "json" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "user_profiles" ADD COLUMN "recoveryDate" text;--> statement-breakpoint
ALTER TABLE "user_profiles" DROP COLUMN "recovery_date";