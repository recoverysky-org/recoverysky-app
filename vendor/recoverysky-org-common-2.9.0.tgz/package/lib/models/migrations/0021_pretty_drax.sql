ALTER TABLE "attendance_reports" ADD COLUMN "name" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "attendance_reports" ADD COLUMN "userEmail" text DEFAULT '' NOT NULL;