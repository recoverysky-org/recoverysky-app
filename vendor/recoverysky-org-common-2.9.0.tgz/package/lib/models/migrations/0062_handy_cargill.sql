CREATE TABLE "unsubscribes" (
	"created" bigint DEFAULT 0 NOT NULL,
	"email" text DEFAULT '' NOT NULL,
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"reason" text DEFAULT '' NOT NULL,
	"source" text DEFAULT 'MANUAL' NOT NULL,
	"uid" text DEFAULT '' NOT NULL,
	"updated" bigint DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE INDEX "unsubscribes_uid_idx" ON "unsubscribes" USING btree ("uid");--> statement-breakpoint
CREATE UNIQUE INDEX "unsubscribes_email_uniq_idx" ON "unsubscribes" USING btree ("email");