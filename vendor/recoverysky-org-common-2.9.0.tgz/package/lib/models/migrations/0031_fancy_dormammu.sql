DROP TABLE "meeting_verifications" CASCADE;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "verified_on" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "meeting_histories" ADD COLUMN "verified_retry" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "verified_on" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "verified_retry" integer DEFAULT 0 NOT NULL;