CREATE TABLE `meeting_verifications` (
	`error` text DEFAULT '' NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`mid` text DEFAULT '' NOT NULL,
	`retry_count` integer DEFAULT 0 NOT NULL,
	`success` integer DEFAULT 0 NOT NULL,
	`updated` integer DEFAULT 0 NOT NULL
);
