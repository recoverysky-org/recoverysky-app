ALTER TABLE `meeting_histories` ADD `verified_on` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `meeting_histories` ADD `verified_retry` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `meetings` ADD `verified_on` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `meetings` ADD `verified_retry` integer DEFAULT 0 NOT NULL;