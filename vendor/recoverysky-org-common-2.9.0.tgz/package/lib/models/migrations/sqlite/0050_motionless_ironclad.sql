PRAGMA foreign_keys=OFF;--> statement-breakpoint
CREATE TABLE `__new_attendance_reports` (
	`confirmation` text DEFAULT '' NOT NULL,
	`confirmed` integer DEFAULT 0 NOT NULL,
	`credit` integer DEFAULT 0 NOT NULL,
	`deleted` integer DEFAULT 0 NOT NULL,
	`email` text DEFAULT '' NOT NULL,
	`error` integer DEFAULT 0 NOT NULL,
	`fid` text DEFAULT '' NOT NULL,
	`generated` integer DEFAULT 0 NOT NULL,
	`html` text DEFAULT '' NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`iid` text DEFAULT '' NOT NULL,
	`messageId` text DEFAULT '' NOT NULL,
	`name` text DEFAULT '' NOT NULL,
	`retry` integer DEFAULT 0 NOT NULL,
	`text` text DEFAULT '' NOT NULL,
	`timezone` text DEFAULT '' NOT NULL,
	`uid` text DEFAULT '' NOT NULL,
	`updated` integer DEFAULT 1 NOT NULL,
	`userEmail` text DEFAULT '' NOT NULL,
	`userIdNum` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
INSERT INTO `__new_attendance_reports`("confirmation", "confirmed", "credit", "deleted", "email", "error", "fid", "generated", "html", "id", "iid", "messageId", "name", "retry", "text", "timezone", "uid", "updated", "userEmail", "userIdNum") SELECT "confirmation", "confirmed", "credit", "deleted", "email", "error", "fid", "generated", "html", "id", "iid", "messageId", "name", "retry", "text", "timezone", "uid", "updated", "userEmail", "userIdNum" FROM `attendance_reports`;--> statement-breakpoint
DROP TABLE `attendance_reports`;--> statement-breakpoint
ALTER TABLE `__new_attendance_reports` RENAME TO `attendance_reports`;--> statement-breakpoint
PRAGMA foreign_keys=ON;--> statement-breakpoint
CREATE INDEX `attendance_reports_messageId_idx` ON `attendance_reports` (`messageId`);--> statement-breakpoint
CREATE INDEX `attendance_reports_uid_idx` ON `attendance_reports` (`uid`);--> statement-breakpoint
CREATE TABLE `__new_attendances` (
	`archived` integer DEFAULT 0 NOT NULL,
	`arid` text DEFAULT '' NOT NULL,
	`created` integer DEFAULT 0 NOT NULL,
	`credit` integer DEFAULT 0 NOT NULL,
	`deleted` integer DEFAULT 0 NOT NULL,
	`end` integer DEFAULT 0 NOT NULL,
	`events` text NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`iid` text DEFAULT '' NOT NULL,
	`meetingHost` text DEFAULT '' NOT NULL,
	`meetingName` text DEFAULT '' NOT NULL,
	`meetingTopic` text DEFAULT '' NOT NULL,
	`mid` text DEFAULT '' NOT NULL,
	`processed` integer DEFAULT 0 NOT NULL,
	`produced` integer DEFAULT 0 NOT NULL,
	`start` integer DEFAULT 0 NOT NULL,
	`uid` text DEFAULT '' NOT NULL,
	`updated` integer DEFAULT 1 NOT NULL,
	`uzid` text DEFAULT '' NOT NULL,
	`valid` integer DEFAULT 0 NOT NULL,
	`zid` text DEFAULT '' NOT NULL,
	`zpid` text DEFAULT '' NOT NULL,
	`zuid` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
INSERT INTO `__new_attendances`("archived", "arid", "created", "credit", "deleted", "end", "events", "id", "iid", "meetingHost", "meetingName", "meetingTopic", "mid", "processed", "produced", "start", "uid", "updated", "uzid", "valid", "zid", "zpid", "zuid") SELECT "archived", "arid", "created", "credit", "deleted", "end", "events", "id", "iid", "meetingHost", "meetingName", "meetingTopic", "mid", "processed", "produced", "start", "uid", "updated", "uzid", "valid", "zid", "zpid", "zuid" FROM `attendances`;--> statement-breakpoint
DROP TABLE `attendances`;--> statement-breakpoint
ALTER TABLE `__new_attendances` RENAME TO `attendances`;