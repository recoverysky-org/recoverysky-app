CREATE TABLE `user_profiles` (
	`id` text PRIMARY KEY DEFAULT 'default' NOT NULL,
	`short_name` text DEFAULT '' NOT NULL,
	`pronouns` text,
	`recovery_date` text,
	`fellowship` text DEFAULT 'AA' NOT NULL,
	`language` text DEFAULT '' NOT NULL
);
