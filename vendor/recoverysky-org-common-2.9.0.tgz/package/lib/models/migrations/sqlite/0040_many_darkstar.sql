CREATE TABLE `scheduled_reminders` (
	`created` integer DEFAULT 0 NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`occurrence_id` text DEFAULT '' NOT NULL,
	`onesignal_id` text DEFAULT '' NOT NULL,
	`reminder_id` text DEFAULT '' NOT NULL,
	`send_at_utc` integer DEFAULT 0 NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL
);
--> statement-breakpoint
CREATE INDEX `scheduled_reminders_reminder_id_idx` ON `scheduled_reminders` (`reminder_id`);--> statement-breakpoint
CREATE INDEX `scheduled_reminders_status_idx` ON `scheduled_reminders` (`status`);--> statement-breakpoint
CREATE INDEX `scheduled_reminders_send_at_utc_idx` ON `scheduled_reminders` (`send_at_utc`);--> statement-breakpoint
ALTER TABLE `reminders` ADD `last_processed` integer DEFAULT 0 NOT NULL;