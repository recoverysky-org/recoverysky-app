ALTER TABLE `meeting_histories` ADD `participants` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `meetings` ADD `participants` integer DEFAULT 0 NOT NULL;