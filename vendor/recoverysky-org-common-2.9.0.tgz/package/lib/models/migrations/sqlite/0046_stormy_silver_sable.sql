CREATE TABLE `news` (
	`body` text DEFAULT '' NOT NULL,
	`end` integer DEFAULT 0 NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`start` integer DEFAULT 0 NOT NULL,
	`title` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE INDEX `news_start_idx` ON `news` (`start`);--> statement-breakpoint
CREATE INDEX `news_end_idx` ON `news` (`end`);