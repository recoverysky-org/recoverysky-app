ALTER TABLE `reminders` ADD `dow` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `reminders` ADD `time` integer DEFAULT 0 NOT NULL;