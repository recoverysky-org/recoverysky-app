PRAGMA foreign_keys=OFF;--> statement-breakpoint
CREATE TABLE `__new_meeting_histories` (
	`changed_at` integer NOT NULL,
	`changed_by` text,
	`changed_fields` text NOT NULL,
	`closed` integer DEFAULT 0 NOT NULL,
	`conferencePhone` text DEFAULT '' NOT NULL,
	`created` integer DEFAULT 0 NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`email` text DEFAULT '' NOT NULL,
	`fellowship` text NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`iid` text DEFAULT '' NOT NULL,
	`language` text DEFAULT '' NOT NULL,
	`location` text DEFAULT '' NOT NULL,
	`locked` integer DEFAULT 0 NOT NULL,
	`mid` text NOT NULL,
	`name` text DEFAULT '' NOT NULL,
	`operation` text NOT NULL,
	`password` text DEFAULT '' NOT NULL,
	`passwordEnc` text DEFAULT '' NOT NULL,
	`phone` text DEFAULT '' NOT NULL,
	`requiresLogin` integer DEFAULT 0 NOT NULL,
	`restricted` integer DEFAULT 0 NOT NULL,
	`restrictedDescription` text DEFAULT '' NOT NULL,
	`sha256` text DEFAULT '' NOT NULL,
	`sid` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'ACTIVE' NOT NULL,
	`uid` text DEFAULT '' NOT NULL,
	`updated` integer DEFAULT 0 NOT NULL,
	`url` text DEFAULT '' NOT NULL,
	`verified` text DEFAULT 'NONE' NOT NULL,
	`verified_on` integer DEFAULT 0 NOT NULL,
	`verified_retry` integer DEFAULT 0 NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	`website` text DEFAULT '' NOT NULL,
	`zid` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
INSERT INTO `__new_meeting_histories`("changed_at", "changed_by", "changed_fields", "closed", "conferencePhone", "created", "description", "email", "fellowship", "id", "iid", "language", "location", "locked", "mid", "name", "operation", "password", "passwordEnc", "phone", "requiresLogin", "restricted", "restrictedDescription", "sha256", "sid", "status", "uid", "updated", "url", "verified", "verified_on", "verified_retry", "version", "website", "zid") SELECT "changed_at", "changed_by", "changed_fields", "closed", "conferencePhone", "created", "description", "email", "fellowship", "id", "iid", "language", "location", "locked", "mid", "name", "operation", "password", "passwordEnc", "phone", "requiresLogin", "restricted", "restrictedDescription", "sha256", "sid", "status", "uid", "updated", "url", "verified", "verified_on", "verified_retry", "version", "website", "zid" FROM `meeting_histories`;--> statement-breakpoint
DROP TABLE `meeting_histories`;--> statement-breakpoint
ALTER TABLE `__new_meeting_histories` RENAME TO `meeting_histories`;--> statement-breakpoint
PRAGMA foreign_keys=ON;