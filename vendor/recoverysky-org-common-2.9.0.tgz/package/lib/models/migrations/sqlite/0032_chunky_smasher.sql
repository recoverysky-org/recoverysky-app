ALTER TABLE `meeting_histories` ADD `verified` text NOT NULL;--> statement-breakpoint
ALTER TABLE `meetings` ADD `verified` text NOT NULL;