ALTER TABLE `attendance_reports` ADD `deleted` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `attendance_reports` ADD `updated` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `attendances` ADD `deleted` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `attendances` ADD `updated` integer DEFAULT 0 NOT NULL;