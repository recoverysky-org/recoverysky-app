DROP INDEX `attendance_reports_messageId_idx`;--> statement-breakpoint
DROP INDEX `attendance_reports_uid_idx`;