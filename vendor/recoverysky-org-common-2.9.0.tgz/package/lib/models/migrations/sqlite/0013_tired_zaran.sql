CREATE TABLE `attendance_reports` (
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`uid` text DEFAULT '' NOT NULL,
	`email` text DEFAULT '' NOT NULL,
	`html` text DEFAULT '' NOT NULL,
	`generated` integer DEFAULT 0 NOT NULL,
	`emailConfirmation` text DEFAULT '' NOT NULL,
	`emailSent` integer DEFAULT 0 NOT NULL
);
