CREATE TABLE `chat_messages` (
	`createdAt` integer DEFAULT 0 NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`metadata` text,
	`parts` text DEFAULT '' NOT NULL,
	`role` text DEFAULT '' NOT NULL,
	`updatedAt` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
DROP TABLE `auth_keys_accesses`;--> statement-breakpoint
DROP TABLE `auth_keyses`;--> statement-breakpoint
PRAGMA foreign_keys=OFF;--> statement-breakpoint
CREATE TABLE `__new_auth_keys` (
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`key` text DEFAULT '' NOT NULL,
	`uuid` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
INSERT INTO `__new_auth_keys`("id", "key", "uuid") SELECT "id", "key", "uuid" FROM `auth_keys`;--> statement-breakpoint
DROP TABLE `auth_keys`;--> statement-breakpoint
ALTER TABLE `__new_auth_keys` RENAME TO `auth_keys`;--> statement-breakpoint
PRAGMA foreign_keys=ON;--> statement-breakpoint
CREATE TABLE `__new_auth_keys_access` (
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`ip` text DEFAULT '' NOT NULL,
	`timestamp` integer DEFAULT 0 NOT NULL,
	`uuid` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
INSERT INTO `__new_auth_keys_access`("id", "ip", "timestamp", "uuid") SELECT "id", "ip", "timestamp", "uuid" FROM `auth_keys_access`;--> statement-breakpoint
DROP TABLE `auth_keys_access`;--> statement-breakpoint
ALTER TABLE `__new_auth_keys_access` RENAME TO `auth_keys_access`;