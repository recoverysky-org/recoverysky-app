CREATE TABLE `auth_keys_access` (
	`id` text PRIMARY KEY NOT NULL,
	`timestamp` integer NOT NULL,
	`ip` text NOT NULL
);
