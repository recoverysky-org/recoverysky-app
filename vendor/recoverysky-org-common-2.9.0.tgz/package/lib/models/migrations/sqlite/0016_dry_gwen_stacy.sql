ALTER TABLE `attendance_reports` ADD `retry` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `attendance_reports` ADD `text` text DEFAULT '' NOT NULL;