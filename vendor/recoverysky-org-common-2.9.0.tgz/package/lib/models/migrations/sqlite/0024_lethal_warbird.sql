ALTER TABLE `attendance_reports` ADD `name` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `attendance_reports` ADD `userEmail` text DEFAULT '' NOT NULL;