CREATE TABLE `meeting_histories` (
	`changed_at` integer NOT NULL,
	`changed_by` text,
	`changed_fields` text NOT NULL,
	`closed` integer DEFAULT 0 NOT NULL,
	`conferencePhone` text DEFAULT '' NOT NULL,
	`created` text DEFAULT '' NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`email` text DEFAULT '' NOT NULL,
	`fellowship` text NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`iid` text DEFAULT '' NOT NULL,
	`language` text DEFAULT '' NOT NULL,
	`location` text DEFAULT '' NOT NULL,
	`locked` integer DEFAULT 0 NOT NULL,
	`mid` text NOT NULL,
	`name` text DEFAULT '' NOT NULL,
	`operation` text NOT NULL,
	`password` text DEFAULT '' NOT NULL,
	`passwordEnc` text DEFAULT '' NOT NULL,
	`phone` text DEFAULT '' NOT NULL,
	`requiresLogin` integer DEFAULT 0 NOT NULL,
	`restricted` integer DEFAULT 0 NOT NULL,
	`restrictedDescription` text DEFAULT '' NOT NULL,
	`sha256` text DEFAULT '' NOT NULL,
	`sid` text DEFAULT '' NOT NULL,
	`status` text NOT NULL,
	`uid` text DEFAULT '' NOT NULL,
	`updated` text DEFAULT '' NOT NULL,
	`url` text DEFAULT '' NOT NULL,
	`verified` text NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	`website` text DEFAULT '' NOT NULL,
	`zid` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE `meeting_tags` (
	`meeting_id` text NOT NULL,
	`tag` text NOT NULL,
	PRIMARY KEY(`meeting_id`, `tag`),
	FOREIGN KEY (`meeting_id`) REFERENCES `meetings`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `meeting_types` (
	`meeting_id` text NOT NULL,
	`type` text NOT NULL,
	PRIMARY KEY(`meeting_id`, `type`),
	FOREIGN KEY (`meeting_id`) REFERENCES `meetings`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `meetings` (
	`closed` integer DEFAULT 0 NOT NULL,
	`conferencePhone` text DEFAULT '' NOT NULL,
	`created` text DEFAULT '' NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`email` text DEFAULT '' NOT NULL,
	`fellowship` text NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`iid` text DEFAULT '' NOT NULL,
	`language` text DEFAULT '' NOT NULL,
	`location` text DEFAULT '' NOT NULL,
	`locked` integer DEFAULT 0 NOT NULL,
	`name` text DEFAULT '' NOT NULL,
	`password` text DEFAULT '' NOT NULL,
	`passwordEnc` text DEFAULT '' NOT NULL,
	`phone` text DEFAULT '' NOT NULL,
	`requiresLogin` integer DEFAULT 0 NOT NULL,
	`restricted` integer DEFAULT 0 NOT NULL,
	`restrictedDescription` text DEFAULT '' NOT NULL,
	`sha256` text DEFAULT '' NOT NULL,
	`sid` text DEFAULT '' NOT NULL,
	`status` text NOT NULL,
	`uid` text DEFAULT '' NOT NULL,
	`updated` text DEFAULT '' NOT NULL,
	`url` text DEFAULT '' NOT NULL,
	`verified` text NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	`website` text DEFAULT '' NOT NULL,
	`zid` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE `schedule_meetings` (
	`schedule_id` text NOT NULL,
	`meeting_id` text NOT NULL,
	PRIMARY KEY(`schedule_id`, `meeting_id`),
	FOREIGN KEY (`schedule_id`) REFERENCES `schedules`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`meeting_id`) REFERENCES `meetings`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `schedules` (
	`created` text DEFAULT '' NOT NULL,
	`fellowship` text NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`name` text DEFAULT '' NOT NULL,
	`sha256` text DEFAULT '' NOT NULL,
	`status` text NOT NULL,
	`updated` text DEFAULT '' NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	`zids` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `sync_queue` (
	`id` text PRIMARY KEY NOT NULL,
	`table_name` text NOT NULL,
	`record_id` text NOT NULL,
	`operation` text NOT NULL,
	`payload` text,
	`created_at` text NOT NULL,
	`synced_at` text,
	`status` text DEFAULT 'pending' NOT NULL,
	`error_message` text,
	`retry_count` integer DEFAULT 0
);
--> statement-breakpoint
CREATE TABLE `system_prompts` (
	`active` integer DEFAULT 0 NOT NULL,
	`content` text DEFAULT '' NOT NULL,
	`created` text DEFAULT '' NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`name` text DEFAULT '' NOT NULL,
	`updated` text DEFAULT '' NOT NULL,
	`variables` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `trexes` (
	`coordinate` integer DEFAULT 0 NOT NULL,
	`coordinate_end` integer DEFAULT 0 NOT NULL,
	`dom` integer,
	`dow` integer,
	`dtend` text,
	`dtstart` text DEFAULT '' NOT NULL,
	`duration_ms` integer DEFAULT 0 NOT NULL,
	`hour` integer,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`minute` integer,
	`month` integer,
	`periodicity` integer NOT NULL,
	`rrule_json` text NOT NULL,
	`rrule_str` text DEFAULT '' NOT NULL,
	`timezone` text DEFAULT '' NOT NULL
);
