PRAGMA foreign_keys=OFF;--> statement-breakpoint
CREATE TABLE `__new_reminders` (
	`at_start` integer DEFAULT 0 NOT NULL,
	`created` integer DEFAULT 0 NOT NULL,
	`dow` integer DEFAULT 0 NOT NULL,
	`enabled` integer DEFAULT 1 NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`mid` text,
	`minutes_before` integer DEFAULT 15 NOT NULL,
	`name` text DEFAULT '' NOT NULL,
	`scope` text DEFAULT 'single' NOT NULL,
	`sid` text,
	`time` integer DEFAULT 0 NOT NULL,
	`timezone` text DEFAULT '' NOT NULL,
	`uid` text DEFAULT '' NOT NULL,
	`updated` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
INSERT INTO `__new_reminders`("at_start", "created", "dow", "enabled", "id", "mid", "minutes_before", "name", "scope", "sid", "time", "timezone", "uid", "updated") SELECT "at_start", "created", "dow", "enabled", "id", "mid", "minutes_before", "name", "scope", "sid", "time", "timezone", "uid", "updated" FROM `reminders`;--> statement-breakpoint
DROP TABLE `reminders`;--> statement-breakpoint
ALTER TABLE `__new_reminders` RENAME TO `reminders`;--> statement-breakpoint
PRAGMA foreign_keys=ON;