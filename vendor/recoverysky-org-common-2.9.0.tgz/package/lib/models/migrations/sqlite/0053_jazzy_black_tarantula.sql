ALTER TABLE `meeting_histories` ADD `hybrid` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `meetings` ADD `hybrid` integer DEFAULT 0 NOT NULL;