ALTER TABLE `attendance_reports` RENAME COLUMN "emailConfirmation" TO "confirmation";--> statement-breakpoint
ALTER TABLE `attendance_reports` RENAME COLUMN "emailSent" TO "confirmed";