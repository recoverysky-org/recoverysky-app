PRAGMA foreign_keys=OFF;--> statement-breakpoint
CREATE TABLE `__new_meeting_histories` (
	`changed_at` integer NOT NULL,
	`changed_by` text,
	`changed_fields` text NOT NULL,
	`closed` integer DEFAULT 0 NOT NULL,
	`conferencePhone` text DEFAULT '' NOT NULL,
	`created` integer DEFAULT 0 NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`email` text DEFAULT '' NOT NULL,
	`fellowship` text NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`iid` text DEFAULT '' NOT NULL,
	`language` text DEFAULT '' NOT NULL,
	`location` text DEFAULT '' NOT NULL,
	`locked` integer DEFAULT 0 NOT NULL,
	`mid` text NOT NULL,
	`name` text DEFAULT '' NOT NULL,
	`operation` text NOT NULL,
	`password` text DEFAULT '' NOT NULL,
	`passwordEnc` text DEFAULT '' NOT NULL,
	`phone` text DEFAULT '' NOT NULL,
	`requiresLogin` integer DEFAULT 0 NOT NULL,
	`restricted` integer DEFAULT 0 NOT NULL,
	`restrictedDescription` text DEFAULT '' NOT NULL,
	`sha256` text DEFAULT '' NOT NULL,
	`sid` text DEFAULT '' NOT NULL,
	`status` text NOT NULL,
	`uid` text DEFAULT '' NOT NULL,
	`updated` integer DEFAULT 0 NOT NULL,
	`url` text DEFAULT '' NOT NULL,
	`verified` text NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	`website` text DEFAULT '' NOT NULL,
	`zid` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
INSERT INTO `__new_meeting_histories`("changed_at", "changed_by", "changed_fields", "closed", "conferencePhone", "created", "description", "email", "fellowship", "id", "iid", "language", "location", "locked", "mid", "name", "operation", "password", "passwordEnc", "phone", "requiresLogin", "restricted", "restrictedDescription", "sha256", "sid", "status", "uid", "updated", "url", "verified", "version", "website", "zid") SELECT "changed_at", "changed_by", "changed_fields", "closed", "conferencePhone", "created", "description", "email", "fellowship", "id", "iid", "language", "location", "locked", "mid", "name", "operation", "password", "passwordEnc", "phone", "requiresLogin", "restricted", "restrictedDescription", "sha256", "sid", "status", "uid", "updated", "url", "verified", "version", "website", "zid" FROM `meeting_histories`;--> statement-breakpoint
DROP TABLE `meeting_histories`;--> statement-breakpoint
ALTER TABLE `__new_meeting_histories` RENAME TO `meeting_histories`;--> statement-breakpoint
PRAGMA foreign_keys=ON;--> statement-breakpoint
CREATE TABLE `__new_meetings` (
	`closed` integer DEFAULT 0 NOT NULL,
	`conferencePhone` text DEFAULT '' NOT NULL,
	`created` integer DEFAULT 0 NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`email` text DEFAULT '' NOT NULL,
	`fellowship` text NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`iid` text DEFAULT '' NOT NULL,
	`language` text DEFAULT '' NOT NULL,
	`location` text DEFAULT '' NOT NULL,
	`locked` integer DEFAULT 0 NOT NULL,
	`name` text DEFAULT '' NOT NULL,
	`password` text DEFAULT '' NOT NULL,
	`passwordEnc` text DEFAULT '' NOT NULL,
	`phone` text DEFAULT '' NOT NULL,
	`requiresLogin` integer DEFAULT 0 NOT NULL,
	`restricted` integer DEFAULT 0 NOT NULL,
	`restrictedDescription` text DEFAULT '' NOT NULL,
	`sha256` text DEFAULT '' NOT NULL,
	`sid` text DEFAULT '' NOT NULL,
	`status` text NOT NULL,
	`uid` text DEFAULT '' NOT NULL,
	`updated` integer DEFAULT 0 NOT NULL,
	`url` text DEFAULT '' NOT NULL,
	`verified` text NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	`website` text DEFAULT '' NOT NULL,
	`zid` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
INSERT INTO `__new_meetings`("closed", "conferencePhone", "created", "description", "email", "fellowship", "id", "iid", "language", "location", "locked", "name", "password", "passwordEnc", "phone", "requiresLogin", "restricted", "restrictedDescription", "sha256", "sid", "status", "uid", "updated", "url", "verified", "version", "website", "zid") SELECT "closed", "conferencePhone", "created", "description", "email", "fellowship", "id", "iid", "language", "location", "locked", "name", "password", "passwordEnc", "phone", "requiresLogin", "restricted", "restrictedDescription", "sha256", "sid", "status", "uid", "updated", "url", "verified", "version", "website", "zid" FROM `meetings`;--> statement-breakpoint
DROP TABLE `meetings`;--> statement-breakpoint
ALTER TABLE `__new_meetings` RENAME TO `meetings`;--> statement-breakpoint
CREATE TABLE `__new_schedules` (
	`created` integer DEFAULT 0 NOT NULL,
	`fellowship` text NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`json` text DEFAULT '' NOT NULL,
	`name` text DEFAULT '' NOT NULL,
	`sha256` text DEFAULT '' NOT NULL,
	`status` text NOT NULL,
	`updated` integer DEFAULT 0 NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	`zids` text NOT NULL
);
--> statement-breakpoint
INSERT INTO `__new_schedules`("created", "fellowship", "id", "json", "name", "sha256", "status", "updated", "version", "zids") SELECT "created", "fellowship", "id", "json", "name", "sha256", "status", "updated", "version", "zids" FROM `schedules`;--> statement-breakpoint
DROP TABLE `schedules`;--> statement-breakpoint
ALTER TABLE `__new_schedules` RENAME TO `schedules`;--> statement-breakpoint
CREATE TABLE `__new_system_prompts` (
	`active` integer DEFAULT 0 NOT NULL,
	`content` text DEFAULT '' NOT NULL,
	`created` integer DEFAULT 0 NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`name` text DEFAULT '' NOT NULL,
	`updated` integer DEFAULT 0 NOT NULL,
	`variables` text NOT NULL
);
--> statement-breakpoint
INSERT INTO `__new_system_prompts`("active", "content", "created", "id", "name", "updated", "variables") SELECT "active", "content", "created", "id", "name", "updated", "variables" FROM `system_prompts`;--> statement-breakpoint
DROP TABLE `system_prompts`;--> statement-breakpoint
ALTER TABLE `__new_system_prompts` RENAME TO `system_prompts`;