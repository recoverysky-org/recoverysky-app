CREATE TABLE `zoom_auths` (
	`id` text PRIMARY KEY NOT NULL,
	`access_token` text NOT NULL,
	`refresh_token` text NOT NULL,
	`zoom_user_id` text NOT NULL,
	`zoom_email` text DEFAULT '' NOT NULL,
	`zoom_display_name` text DEFAULT '' NOT NULL,
	`expires_at` integer NOT NULL,
	`connected_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
