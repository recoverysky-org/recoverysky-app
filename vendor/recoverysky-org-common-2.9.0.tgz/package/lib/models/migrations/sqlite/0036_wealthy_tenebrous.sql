CREATE TABLE `reminders` (
	`at_start` integer DEFAULT 0 NOT NULL,
	`created` integer DEFAULT 0 NOT NULL,
	`enabled` integer DEFAULT 1 NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`mid` text DEFAULT '' NOT NULL,
	`minutes_before` integer DEFAULT 15 NOT NULL,
	`name` text DEFAULT '' NOT NULL,
	`sid` text DEFAULT '' NOT NULL,
	`timezone` text DEFAULT '' NOT NULL,
	`uid` text DEFAULT '' NOT NULL,
	`updated` integer DEFAULT 0 NOT NULL
);
