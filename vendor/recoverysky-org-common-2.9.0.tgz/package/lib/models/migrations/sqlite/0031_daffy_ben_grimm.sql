ALTER TABLE `meeting_histories` DROP COLUMN `verified`;--> statement-breakpoint
ALTER TABLE `meetings` DROP COLUMN `verified`;