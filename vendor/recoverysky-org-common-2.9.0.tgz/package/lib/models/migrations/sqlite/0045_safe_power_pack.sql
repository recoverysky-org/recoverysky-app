CREATE TABLE `newses` (
	`body` text DEFAULT '' NOT NULL,
	`end` integer DEFAULT 0 NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`start` integer DEFAULT 0 NOT NULL,
	`title` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE INDEX `newses_start_idx` ON `newses` (`start`);--> statement-breakpoint
CREATE INDEX `newses_end_idx` ON `newses` (`end`);--> statement-breakpoint
CREATE INDEX `attendance_reports_messageId_idx` ON `attendance_reports` (`messageId`);--> statement-breakpoint
CREATE INDEX `attendance_reports_uid_idx` ON `attendance_reports` (`uid`);