CREATE TABLE `feedbacks` (
	`joins` integer DEFAULT 0 NOT NULL,
	`lastJoin` integer DEFAULT 0 NOT NULL,
	`loves` integer DEFAULT 0 NOT NULL,
	`mid` text PRIMARY KEY DEFAULT '' NOT NULL,
	`rates` integer DEFAULT 0 NOT NULL
);
