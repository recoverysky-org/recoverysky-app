CREATE TABLE `attendances` (
	`arid` text DEFAULT '' NOT NULL,
	`created` integer DEFAULT 0 NOT NULL,
	`credit` integer DEFAULT 0 NOT NULL,
	`end` integer DEFAULT 0 NOT NULL,
	`events` text NOT NULL,
	`id` text PRIMARY KEY DEFAULT '' NOT NULL,
	`meetingHost` text DEFAULT '' NOT NULL,
	`mid` text DEFAULT '' NOT NULL,
	`processed` integer DEFAULT 0 NOT NULL,
	`produced` integer DEFAULT 0 NOT NULL,
	`start` integer DEFAULT 0 NOT NULL,
	`uid` text DEFAULT '' NOT NULL,
	`uzid` text DEFAULT '' NOT NULL,
	`valid` integer DEFAULT 0 NOT NULL,
	`zid` text DEFAULT '' NOT NULL,
	`zpid` text DEFAULT '' NOT NULL,
	`zuid` text DEFAULT '' NOT NULL
);
