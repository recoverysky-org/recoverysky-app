CREATE TABLE `config_caches` (
	`fetchedAt` integer DEFAULT 0 NOT NULL,
	`id` text PRIMARY KEY DEFAULT 'default' NOT NULL,
	`payload` text DEFAULT '' NOT NULL
);
