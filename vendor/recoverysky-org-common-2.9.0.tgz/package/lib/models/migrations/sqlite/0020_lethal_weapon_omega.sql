CREATE INDEX `attendance_reports_mid_idx` ON `attendance_reports` (`mid`);--> statement-breakpoint
CREATE INDEX `attendance_reports_uid_idx` ON `attendance_reports` (`uid`);