ALTER TABLE `meeting_histories` ADD `continuous` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `meetings` ADD `continuous` integer DEFAULT 0 NOT NULL;