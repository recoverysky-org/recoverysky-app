CREATE TABLE "reminders" (
	"at_start" boolean DEFAULT false NOT NULL,
	"created" bigint DEFAULT 0 NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"mid" text DEFAULT '' NOT NULL,
	"minutes_before" integer DEFAULT 15 NOT NULL,
	"name" text DEFAULT '' NOT NULL,
	"sid" text DEFAULT '' NOT NULL,
	"timezone" text DEFAULT '' NOT NULL,
	"uid" text DEFAULT '' NOT NULL,
	"updated" bigint DEFAULT 0 NOT NULL
);
