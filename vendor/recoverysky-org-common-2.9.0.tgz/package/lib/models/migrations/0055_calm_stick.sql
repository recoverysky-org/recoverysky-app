CREATE TABLE "notification_contents" (
	"body" text DEFAULT '' NOT NULL,
	"created" bigint DEFAULT 0 NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"language" text DEFAULT '' NOT NULL,
	"pool_id" text DEFAULT '' NOT NULL,
	"position" integer DEFAULT 0 NOT NULL,
	"title" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "notification_deliveries" (
	"body" text DEFAULT '' NOT NULL,
	"content_id" text,
	"created" bigint DEFAULT 0 NOT NULL,
	"delivered_at" bigint DEFAULT 0 NOT NULL,
	"did" text DEFAULT '' NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"occurrence_id" text DEFAULT '' NOT NULL,
	"opened_at" bigint DEFAULT 0 NOT NULL,
	"receipt_error" text DEFAULT '' NOT NULL,
	"receipt_status" text DEFAULT 'pending' NOT NULL,
	"schedule_id" text,
	"send_at_utc" bigint DEFAULT 0 NOT NULL,
	"sent_at" bigint DEFAULT 0 NOT NULL,
	"source" text DEFAULT 'subscription' NOT NULL,
	"source_id" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"ticket_id" text DEFAULT '' NOT NULL,
	"title" text DEFAULT '' NOT NULL,
	"type_id" text DEFAULT '' NOT NULL,
	"uid" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "notification_pools" (
	"created" bigint DEFAULT 0 NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"name" text DEFAULT '' NOT NULL,
	"strategy" text DEFAULT 'sequential' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "notification_schedules" (
	"coordinate" bigint DEFAULT 0 NOT NULL,
	"created" bigint DEFAULT 0 NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"periodicity" integer DEFAULT 1 NOT NULL,
	"slot_id" text DEFAULT '' NOT NULL,
	"timezone" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "notification_slots" (
	"enabled" boolean DEFAULT true NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"label" text DEFAULT '' NOT NULL,
	"minutes" integer DEFAULT 0 NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "notification_subscription_times" (
	"schedule_id" text DEFAULT '' NOT NULL,
	"subscription_id" text DEFAULT '' NOT NULL,
	CONSTRAINT "notification_subscription_times_subscription_id_schedule_id_pk" PRIMARY KEY("subscription_id","schedule_id")
);
--> statement-breakpoint
CREATE TABLE "notification_subscriptions" (
	"created" bigint DEFAULT 0 NOT NULL,
	"did" text DEFAULT '' NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"params" jsonb NOT NULL,
	"timezone" text DEFAULT '' NOT NULL,
	"type_id" text DEFAULT '' NOT NULL,
	"uid" text DEFAULT '' NOT NULL,
	"updated" bigint DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "notification_types" (
	"action" text DEFAULT 'open_app' NOT NULL,
	"action_payload" jsonb NOT NULL,
	"allows_multiple_times" boolean DEFAULT false NOT NULL,
	"body" text DEFAULT '' NOT NULL,
	"channel_id" text DEFAULT 'notifications' NOT NULL,
	"created" bigint DEFAULT 0 NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"label" text DEFAULT '' NOT NULL,
	"params_schema" jsonb,
	"periodicity" integer DEFAULT 1 NOT NULL,
	"pool_id" text,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"title" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
ALTER TABLE "push_tokens" ADD COLUMN "language" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "push_tokens" ADD COLUMN "timezone" text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE INDEX "notification_contents_pool_id_idx" ON "notification_contents" USING btree ("pool_id");--> statement-breakpoint
CREATE INDEX "notification_deliveries_status_idx" ON "notification_deliveries" USING btree ("status");--> statement-breakpoint
CREATE INDEX "notification_deliveries_send_at_utc_idx" ON "notification_deliveries" USING btree ("send_at_utc");--> statement-breakpoint
CREATE INDEX "notification_deliveries_source_id_idx" ON "notification_deliveries" USING btree ("source_id");--> statement-breakpoint
CREATE UNIQUE INDEX "notification_deliveries_source_occurrence_uniq_idx" ON "notification_deliveries" USING btree ("source","source_id","occurrence_id");--> statement-breakpoint
CREATE INDEX "notification_schedules_slot_id_idx" ON "notification_schedules" USING btree ("slot_id");--> statement-breakpoint
CREATE INDEX "notification_schedules_timezone_idx" ON "notification_schedules" USING btree ("timezone");--> statement-breakpoint
CREATE UNIQUE INDEX "notification_schedules_slot_tz_period_uniq_idx" ON "notification_schedules" USING btree ("slot_id","timezone","periodicity");--> statement-breakpoint
CREATE INDEX "notification_slots_enabled_idx" ON "notification_slots" USING btree ("enabled");--> statement-breakpoint
CREATE INDEX "notification_subscription_times_subscription_id_idx" ON "notification_subscription_times" USING btree ("subscription_id");--> statement-breakpoint
CREATE INDEX "notification_subscription_times_schedule_id_idx" ON "notification_subscription_times" USING btree ("schedule_id");--> statement-breakpoint
CREATE INDEX "notification_subscriptions_uid_idx" ON "notification_subscriptions" USING btree ("uid");--> statement-breakpoint
CREATE INDEX "notification_subscriptions_did_idx" ON "notification_subscriptions" USING btree ("did");--> statement-breakpoint
CREATE INDEX "notification_subscriptions_type_id_idx" ON "notification_subscriptions" USING btree ("type_id");--> statement-breakpoint
CREATE UNIQUE INDEX "notification_subscriptions_uid_did_type_uniq_idx" ON "notification_subscriptions" USING btree ("uid","did","type_id");--> statement-breakpoint
CREATE INDEX "notification_types_enabled_idx" ON "notification_types" USING btree ("enabled");