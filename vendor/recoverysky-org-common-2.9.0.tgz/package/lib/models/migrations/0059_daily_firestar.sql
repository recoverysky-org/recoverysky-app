CREATE TABLE "device_attestations" (
	"attest_count" integer DEFAULT 0 NOT NULL,
	"device_id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"first_seen" bigint DEFAULT 0 NOT NULL,
	"key_id" text DEFAULT '' NOT NULL,
	"last_seen" bigint DEFAULT 0 NOT NULL,
	"platform" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE INDEX "device_attestations_platform_idx" ON "device_attestations" USING btree ("platform");--> statement-breakpoint
CREATE INDEX "device_attestations_key_id_idx" ON "device_attestations" USING btree ("key_id");