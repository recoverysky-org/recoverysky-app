ALTER TABLE "attendance_reports" RENAME COLUMN "mid" TO "messageId";--> statement-breakpoint
DROP INDEX "attendance_reports_mid_idx";--> statement-breakpoint
CREATE INDEX "attendance_reports_messageId_idx" ON "attendance_reports" USING btree ("messageId");