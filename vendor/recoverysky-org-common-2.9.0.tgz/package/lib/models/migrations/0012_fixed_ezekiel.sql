ALTER TABLE "attendance_reports" ADD COLUMN "retry" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "attendance_reports" ADD COLUMN "text" text DEFAULT '' NOT NULL;