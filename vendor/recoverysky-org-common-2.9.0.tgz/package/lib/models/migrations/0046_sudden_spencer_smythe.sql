DROP INDEX "attendance_reports_messageId_idx";--> statement-breakpoint
DROP INDEX "attendance_reports_uid_idx";--> statement-breakpoint
ALTER TABLE "push_tokens" ALTER COLUMN "uid" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "push_tokens" ALTER COLUMN "uid" SET DEFAULT '';