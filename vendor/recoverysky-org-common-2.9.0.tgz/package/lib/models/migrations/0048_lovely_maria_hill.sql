CREATE TABLE "news" (
	"body" text DEFAULT '' NOT NULL,
	"end" bigint DEFAULT 0 NOT NULL,
	"id" text PRIMARY KEY DEFAULT '' NOT NULL,
	"start" bigint DEFAULT 0 NOT NULL,
	"title" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE INDEX "news_start_idx" ON "news" USING btree ("start");--> statement-breakpoint
CREATE INDEX "news_end_idx" ON "news" USING btree ("end");