ALTER TABLE "reminders" ADD COLUMN "dow" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "reminders" ADD COLUMN "time" integer DEFAULT 0 NOT NULL;