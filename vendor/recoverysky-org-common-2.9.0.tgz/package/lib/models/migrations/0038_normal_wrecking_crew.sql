CREATE INDEX "attendance_reports_confirmed_error_idx" ON "attendance_reports" USING btree ("confirmed","error");--> statement-breakpoint
CREATE INDEX "attendances_arid_idx" ON "attendances" USING btree ("arid");--> statement-breakpoint
CREATE INDEX "attendances_uid_idx" ON "attendances" USING btree ("uid");--> statement-breakpoint
CREATE INDEX "auth_keys_access_ip_idx" ON "auth_keys_access" USING btree ("ip");--> statement-breakpoint
CREATE UNIQUE INDEX "auth_keys_uuid_idx" ON "auth_keys" USING btree ("uuid");--> statement-breakpoint
CREATE UNIQUE INDEX "auth_keys_key_idx" ON "auth_keys" USING btree ("key");--> statement-breakpoint
CREATE INDEX "meetings_verified_idx" ON "meetings" USING btree ("verified");--> statement-breakpoint
CREATE INDEX "schedules_fellowship_idx" ON "schedules" USING btree ("fellowship");--> statement-breakpoint
CREATE INDEX "trex_dow_idx" ON "trexes" USING btree ("dow");