ALTER TABLE "meeting_histories" ADD COLUMN "verified" text NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "verified" text NOT NULL;