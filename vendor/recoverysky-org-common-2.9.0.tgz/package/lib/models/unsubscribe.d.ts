import { UnsubscribeSource } from "../enums/index.js";
/**
 * Email suppression list — addresses that must not receive attendance reports
 * or other bulk mail.
 *
 * The presence of a row IS the suppression; resubscribing deletes the row.
 * There is no tombstone, so every read path is a plain existence check.
 *
 * Keyed on the bare email address rather than a `uid` because report
 * recipients are frequently third parties — a probation officer, a court, a
 * sponsor — who have no account here. `uid` is filled in opportunistically
 * when the address does map to a known user, but is never required.
 *
 * Postmark bounce and spam-complaint webhooks write here too. A hard bounce is
 * functionally an unsubscribe: continuing to mail a dead address burns sender
 * reputation for every other recipient on the domain.
 *
 * Account-critical mail (password reset, security notices) must NOT consult
 * this table. That exclusion is a decision at the call site — there is
 * deliberately no scope column.
 *
 * @index uid
 * @sqlite skip
 */
export declare class unsubscribe {
    /** @format uuid */
    id: string;
    /**
     * Suppressed address, stored normalized (lowercased, trimmed) via
     * `normalizeEmail`. Carries a unique index — see
     * `src/indexes/unsubscribes.indexes.ts`.
     */
    email: string;
    /** Account id when the address maps to a known user; empty string otherwise. */
    uid: string;
    /** How the suppression arose. */
    source: UnsubscribeSource;
    /** Free-text detail — bounce description, Postmark record type, staff note. */
    reason: string;
    /**
     * utc millis when the address was first suppressed
     * @format bigint
     */
    created: number;
    /**
     * utc millis when the row was last touched (a re-suppression refreshes this)
     * @format bigint
     */
    updated: number;
}
