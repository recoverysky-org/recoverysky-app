/**
 * Scheduled Reminder - individual notification instance for a reminder.
 *
 * Each scheduled_reminder represents a single push notification to be sent
 * via OneSignal for a specific occurrence of a recurring meeting reminder.
 *
 * Relationship: 1 reminder -> many scheduled_reminders (one per occurrence)
 *
 * @index reminder_id
 * @index status
 * @index send_at_utc
 */
export declare class scheduled_reminder {
    /** Unique identifier (UUID) */
    id: string;
    /** FK to reminders.id */
    reminder_id: string;
    /** TREX occurrence identifier */
    occurrence_id: string;
    /** UTC timestamp (millis) when the notification should be sent */
    /** @format bigint */
    send_at_utc: number;
    /** OneSignal notification ID, set after successful API call */
    onesignal_id: string;
    /** Notification status: pending, scheduled, sent, failed */
    status: string;
    /** Creation timestamp (UTC millis) */
    /** @format bigint */
    created: number;
}
