/**
 * Friendly time-of-day slots ("early", "brunch", "noonish").
 * Retunable server-side; changing minutes requires re-minting schedules (admin op).
 *
 * @index enabled
 * @sqlite skip
 */
export declare class notification_slot {
    /** Slug PK: "early" | "morning" | "brunch" | "noonish" | "afternoon" | "evening" | "night" | "midnight" */
    id: string;
    /** Display label ("Brunch") */
    label: string;
    /** Minutes past local midnight (0-1439) */
    minutes: number;
    /** Picker ordering */
    sort_order: number;
    /** Whether offered in the picker */
    enabled: boolean;
}
