/**
 * Delivery ledger: one row per notification sent (or to be sent) to a device.
 * An occurrence IS a delivery — subscriptions are per-device, so no separate
 * occurrence table. Tracks the sent -> delivered -> opened funnel plus Expo
 * receipts.
 *
 * uid/did are denormalized from the subscription so the sender and receipt
 * poller never need a join to act on a row.
 *
 * @index status
 * @index send_at_utc
 * @index source_id
 * @sqlite skip
 */
export declare class notification_delivery {
    /** UUID */
    id: string;
    /** Discriminator: "subscription" (Phase 2 adds "reminder") */
    source: string;
    /** FK by discriminator: notification_subscriptions.id when source="subscription" */
    source_id: string;
    /** Denormalized user id */
    uid: string;
    /** Denormalized device id */
    did: string;
    /** Denormalized notification_types.id — for the app payload and analytics */
    type_id: string;
    /** FK to notification_schedules.id (null for non-scheduled sources) */
    schedule_id: string | null;
    /** Dedup key: "{localDate}:{coordinate}", local date in the schedule timezone */
    occurrence_id: string;
    /** UTC millis when this should be sent */
    /** @format bigint */
    send_at_utc: number;
    /** notification_contents.id selected at materialization (null = inline type content) */
    content_id: string | null;
    /** Rendered title as actually sent (audit trail; empty until sent) */
    title: string;
    /** Rendered body as actually sent (audit trail; empty until sent) */
    body: string;
    /** "pending" | "sending" | "sent" | "failed" | "cancelled" */
    status: string;
    /**
     * UTC millis when the sender claimed this row (status -> "sending"), 0 when
     * unclaimed. There is no other timestamp that can carry this: sent_at means
     * "Expo accepted it", and a row claimed by a process that then died would be
     * indistinguishable from one still in flight without this field.
     */
    /** @format bigint */
    sending_at: number;
    /** Expo push ticket id */
    ticket_id: string;
    /** "pending" | "ok" | "error" */
    receipt_status: string;
    /** Expo receipt error detail, if any */
    receipt_error: string;
    /** UTC millis actually sent */
    /** @format bigint */
    sent_at: number;
    /** UTC millis Expo receipt confirmed delivery (0 = not yet) */
    /** @format bigint */
    delivered_at: number;
    /** UTC millis the app reported the user opened it (0 = not yet) */
    /** @format bigint */
    opened_at: number;
    /** Creation timestamp (UTC millis) */
    /** @format bigint */
    created: number;
}
