import { Fellowship } from "../enums/Fellowship.js";
import { ScheduleStatus } from "../enums/index.js";
/**
 * Plain data model for meeting schedules.
 *
 * **IMPORTANT FOR CONSUMERS**: This is a plain data type with no business logic methods.
 *
 * ## When to Use This (lowercase `schedule`)
 *
 * ✅ **Use for**:
 * - Type annotations in function signatures
 * - Defining types for plain data variables
 * - RxDB document types (`scheduleDocType`)
 * - Drizzle query result types
 * - JSON serialization/deserialization
 *
 * ❌ **Don't use for**:
 * - Creating new instances (use `Schedule.create()` instead)
 * - Business logic operations (use `Schedule` class)
 *
 * ## Relationship to Schedule Class
 *
 * This model is the **data shape** that the `Schedule` class extends.
 * The uppercase `Schedule` class adds business logic methods on top of this structure.
 *
 * ```typescript
 * // ❌ WRONG: Using model for instance creation
 * import { schedule } from '@recoverysky-org/common/models';
 * const s = new schedule(); // No methods available
 *
 * // ✅ CORRECT: Using class for instance creation
 * import { Schedule } from '@recoverysky-org/common';
 * const s = Schedule.create().unwrap(); // Has business logic methods
 *
 * // ✅ CORRECT: Using model for type annotation
 * import { schedule } from '@recoverysky-org/common/models';
 * function processSchedule(data: schedule): void { ... }
 * ```
 *
 * ## Usage with RxDB
 *
 * ```typescript
 * import { scheduleDocType } from '@recoverysky-org/common/lib/models/rxdb/schedule.rxdb';
 * import { Schedule } from '@recoverysky-org/common';
 *
 * // Query returns plain data (scheduleDocType, based on this model)
 * const docs: scheduleDocType[] = await db.schedules.find().exec();
 *
 * // Convert to class for business logic
 * const schedules = docs.map(doc => Object.assign(new Schedule(), doc));
 * ```
 *
 * ## Usage with Drizzle
 *
 * ```typescript
 * import { schedules } from '@recoverysky-org/common/lib/models/drizzle/schedules.drizzle';
 * import { schedule } from '@recoverysky-org/common/models';
 * import { Schedule } from '@recoverysky-org/common';
 *
 * // Query returns plain data (schedule type)
 * const rows: schedule[] = await db.select().from(schedules);
 *
 * // Convert to class for business logic
 * const scheduleInstances = rows.map(row => Object.assign(new Schedule(), row));
 * ```
 *
 * ## Schema Generation
 *
 * This model is the source for all schema generation:
 * - TypeScript schemas (`models/schema/schedule.schema.ts`)
 * - JSON schemas (`models/json/schedule.json`)
 * - RxDB schemas (`models/rxdb/schedule.rxdb.ts`)
 * - Drizzle tables (`models/drizzle/schedules.drizzle.ts`)
 *
 * After modifying this file, run `pnpm make` to regenerate all schemas.
 *
 * @see {@link Schedule} - Business logic class that extends this model
 * @see {@link https://github.com/recoverysky-org/recoverysky-common/blob/main/content/consumer-guide.md} - Consumer Guide
 * @see {@link https://github.com/recoverysky-org/recoverysky-common/blob/main/content/architecture.md} - Architecture Guide
 */
export declare class schedule {
    id: string;
    status: ScheduleStatus;
    zids: string[];
    mids: string[];
    name: string;
    fellowship: Fellowship;
    json: string;
    minutes: number;
    /** @format bigint */
    created: number;
    /** @format bigint */
    updated: number;
    version: number;
    sha256: string;
}
