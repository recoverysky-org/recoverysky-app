import { Periodicity } from "../enums/Periodicity.js";
/**
 * Plain data model for TREX (Temporal Recurring Event indeX) events.
 *
 * Represents a recurring event with wall-clock time preserved across DST transitions.
 * This model maps directly to the TREXJSON interface from @trex-ts/core.
 *
 * **IMPORTANT FOR CONSUMERS**: This is a plain data type with no business logic methods.
 *
 * ## When to Use This (lowercase `trex`)
 *
 * ✅ **Use for**:
 * - Type annotations in function signatures
 * - Defining types for plain data variables
 * - RxDB document types
 * - Drizzle query result types
 * - JSON serialization/deserialization
 * - Passing data to/from @trex-ts/core functions
 *
 * ❌ **Don't use for**:
 * - Creating new instances with business logic
 * - Methods requiring DST-aware calculations (use @trex-ts/core instead)
 *
 * ## Usage with @trex-ts/core
 *
 * ```typescript
 * import { TREX, Periodicity } from '@trex-ts/core';
 * import { trex } from '@recoverysky-org/common/models';
 *
 * // Create from datetime
 * const result = TREX.fromDateTime(zonedDateTime, Periodicity.WEEKLY);
 * if (result.ok) {
 *   const event: trex = result.value.toJSON();
 *   await db.insert(trexes).values(event);
 * }
 *
 * // Load from database and convert back
 * const data: trex = await db.select().from(trexes).where(eq(trexes.id, '...'));
 * const eventResult = TREX.fromJSON(data);
 * ```
 *
 * ## Schema Generation
 *
 * This model is the source for all schema generation:
 * - TypeScript schemas (`models/schema/trex.schema.ts`)
 * - JSON schemas (`models/json/trex.json`)
 * - RxDB schemas (`models/rxdb/trex.rxdb.ts`)
 * - Drizzle tables (`models/drizzle/trexes.drizzle.ts`)
 *
 * After modifying this file, run `pnpm make` to regenerate all schemas.
 *
 * @see {@link https://github.com/recoverysky-org/recoverysky-common/blob/main/content/TREX.md} - TREX Documentation
 * @see {@link https://github.com/jenova-marie/trex-ts} - @trex-ts/core source
 */
export declare class trex {
    /**
     * Unique identifier for the TREX event
     * @example "507f1f77bcf86cd799439011"
     */
    id: string;
    /**
     * Milliseconds within reference frame for the event start time.
     *
     * Encodes wall-clock time in a normalized way that preserves the local time
     * across DST transitions. The reference frame varies by periodicity:
     * - CONTINUOUS: Fixed at COORDINATE_MAX (31,622,400,000 ms)
     * - DAILY: 0-86,399,999 ms (Jan 1, 1970)
     * - WEEKLY: 0-604,799,999 ms (Jan 1-7, 1970)
     * - MONTHLY: 0-2,678,399,999 ms (Jan 1-31, 1970)
     * - YEARLY: 0-31,622,399,999 ms (Jan 1-Dec 31, 1972, leap year)
     *
     * @example 259200000 // Thursday 00:00 in WEEKLY
     * @format bigint
     */
    coordinate: number;
    /**
     * IANA timezone identifier where the event occurs.
     *
     * Used with coordinate to determine the actual local time across DST transitions.
     *
     * @pattern ^[A-Za-z_]+(?:/[A-Za-z_]+)*$
     * @example "America/New_York"
     * @example "Europe/London"
     * @example "Asia/Tokyo"
     */
    timezone: string;
    /**
     * Recurrence frequency for this event.
     *
     * Determines the reference frame for coordinate interpretation:
     * - CONTINUOUS (0): 24/7 always-active events
     * - DAILY (1): Daily recurring events
     * - WEEKLY (2): Weekly recurring events (default for meetings)
     * - MONTHLY (3): Monthly recurring events
     * - YEARLY (4): Yearly recurring events
     *
     * @example Periodicity.WEEKLY (or 2)
     */
    periodicity: Periodicity;
    /**
     * End coordinate (start + duration with periodicity wrapping).
     *
     * For events with duration, this coordinate marks the end time.
     * May wrap to next period if duration extends past period boundary.
     *
     * @example 259203600000 // Thursday 01:00 in WEEKLY (1 hour after start)
     * @format bigint
     */
    coordinate_end: number;
    /**
     * Event duration in milliseconds.
     *
     * The time span from coordinate to coordinate_end.
     * 0 indicates an instant event (no duration).
     *
     * @example 3600000 // 1 hour
     * @example 1800000 // 30 minutes
     */
    duration_ms: number;
    /**
     * Start of recurrence series (when event begins recurring).
     *
     * ISO 8601 datetime string representing when this recurring event starts.
     * Used with rrule_str to define bounded recurrence patterns.
     *
     * @example "2025-01-15T09:00:00-05:00"
     */
    dtstart: string;
    /**
     * End of recurrence series.
     *
     * ISO 8601 datetime string representing when this recurring event ends.
     * null indicates infinite recurrence (no end date).
     *
     * @example "2025-12-31T23:59:59-05:00"
     */
    dtend: string | null;
    /**
     * RFC 5545 RRULE string for dateutil/export compatibility.
     *
     * Standard iCalendar recurrence rule format for interoperability
     * with calendar applications and libraries.
     *
     * @example "FREQ=WEEKLY;BYDAY=MO,WE,FR"
     * @example "FREQ=MONTHLY;BYMONTHDAY=15"
     */
    rrule_str: string;
    /**
     * RRULE components as JSON for SQL queries.
     *
     * Parsed RRULE components stored as JSON for efficient database querying
     * without string parsing. Contains fields like freq, interval, byday, etc.
     *
     * @example { freq: "WEEKLY", byday: ["MO", "WE", "FR"] }
     */
    rrule_json: Record<string, unknown>;
    /**
     * Wall-clock hour of day (0-23).
     *
     * Extracted from coordinate for convenient indexing.
     * Recomputed if coordinate changes.
     *
     * @minimum 0
     * @maximum 23
     * @example 14
     */
    hour?: number | null;
    /**
     * Wall-clock minute of hour (0-59).
     *
     * Extracted from coordinate for convenient indexing.
     * Recomputed if coordinate changes.
     *
     * @minimum 0
     * @maximum 59
     * @example 30
     */
    minute?: number | null;
    /**
     * ISO 8601 day of week (1-7).
     *
     * Only meaningful for WEEKLY events (null for non-WEEKLY).
     * 1 = Monday, 7 = Sunday
     *
     * @minimum 1
     * @maximum 7
     * @example 4 // Thursday
     */
    dow?: number | null;
    /**
     * Day of month (1-31).
     *
     * Meaningful for MONTHLY and YEARLY events (null for DAILY/WEEKLY).
     *
     * @minimum 1
     * @maximum 31
     * @example 15
     */
    dom?: number | null;
    /**
     * Month of year (1-12).
     *
     * Only meaningful for YEARLY events (null for non-YEARLY).
     *
     * @minimum 1
     * @maximum 12
     * @example 6 // June
     */
    month?: number | null;
}
