/**
 * News model
 *
 * Represents a news item with a display window defined by start/end timestamps.
 *
 * @index start
 * @index end
 */
export declare class news {
    /** Unique identifier */
    id: string;
    /** News title */
    title: string;
    /** News body content */
    body: string;
    /**
     * Start timestamp (millis) - when the news becomes visible
     * @format bigint
     */
    start: number;
    /**
     * End timestamp (millis) - when the news expires
     * @format bigint
     */
    end: number;
}
