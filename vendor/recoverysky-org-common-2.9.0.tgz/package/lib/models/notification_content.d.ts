/**
 * One message in a pool. Bodies are Handlebars templates.
 *
 * @index pool_id
 * @sqlite skip
 */
export declare class notification_content {
    /** UUID */
    id: string;
    /** FK to notification_pools.id */
    pool_id: string;
    /** Position within the pool (drives sequential / day_of_year selection) */
    position: number;
    /** Title template (Handlebars) */
    title: string;
    /** Body template (Handlebars) */
    body: string;
    /** BCP-47 language tag. Empty string = default/fallback language. */
    language: string;
    /** Whether selectable */
    enabled: boolean;
    /** Creation timestamp (UTC millis) */
    /** @format bigint */
    created: number;
}
