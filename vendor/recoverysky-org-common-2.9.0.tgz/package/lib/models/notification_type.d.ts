/**
 * Notification type catalog. The app codes its tap-handling against the slug id.
 * Adding a notification type is a data insert, not a code change.
 *
 * @index enabled
 * @sqlite skip
 */
export declare class notification_type {
    /** Slug PK: "encouragement" | "clean_time" | "daily_tip" */
    id: string;
    /** Display label for the app settings screen */
    label: string;
    /** Longer description for the app settings screen */
    description: string;
    /** Android notification channel id */
    channel_id: string;
    /** Tap action: "open_app" | "screen" | "url" */
    action: string;
    /** Action payload, e.g. { "screen": "Meetings" } */
    action_payload: Record<string, unknown>;
    /** Inline title (Handlebars). Ignored when pool_id is set. */
    title: string;
    /** Inline body (Handlebars). Ignored when pool_id is set. */
    body: string;
    /** FK to notification_pools.id — rotating content. Null = inline title/body. */
    pool_id: string | null;
    /** TREX periodicity for this type's schedules. 1 = DAILY. Never 0 (CONTINUOUS). */
    periodicity: number;
    /** Whether a subscription may attach more than one slot */
    allows_multiple_times: boolean;
    /** JSON Schema (draft 2020-12) validating subscription.params. Null = params must be {} */
    params_schema: Record<string, unknown> | null;
    /** Whether this type is offered at all */
    enabled: boolean;
    /** Settings-screen ordering */
    sort_order: number;
    /** Creation timestamp (UTC millis) */
    /** @format bigint */
    created: number;
}
