/**
 * Auth Keys Model
 *
 * Stores authentication keys for API access.
 */
export declare class auth_keys {
    id: string;
    uuid: string;
    key: string;
}
