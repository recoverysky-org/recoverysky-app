/**
 * Push notification token for a user's device.
 * Stores Expo/APNs/FCM push tokens to deliver notifications.
 *
 * @index uid
 * @sqlite skip
 */
export declare class push_token {
    /** @format uuid */
    id: string;
    /** User ID */
    uid: string;
    /** Unique device identifier */
    did: string;
    /** Push notification token (Expo/APNs/FCM) */
    token: string;
    /** Device platform: 'ios' | 'android' */
    platform: string;
    /** IANA timezone reported by the device (e.g. "America/New_York").
     * Required for slot-based notification scheduling. Empty = unknown. */
    timezone: string;
    /** BCP-47 language tag reported by the device (e.g. "en-US"). Empty = default. */
    language: string;
    /**
     * Timestamp when the push_token was created (ISO 8601)
     * @format bigint
     * @example "2023-01-01T00:00:00.000Z"
     */
    created: number;
    /**
     * Timestamp when the push_token was updated (ISO 8601)
     * @format bigint
     * @example "2023-01-01T00:00:00.000Z"
     */
    updated: number;
}
