/**
 * Attendance Report - a generated report containing a collection of attendance records.
 *
 * When attendance records are produced into a report and emailed to the user,
 * this record tracks the report metadata: when it was generated, who it was
 * sent to, and email delivery confirmation.
 *
 * Relationship: 1 report → many attendances (via attendance.arid)
 *
 * @index messageId
 * @index uid
 */
export declare class attendance_report {
    id: string;
    iid: string;
    uid: string;
    fid: string;
    error: boolean;
    retry: number;
    /** @format bigint */
    generated: number;
    messageId: string;
    /** @format bigint */
    confirmed: number;
    confirmation: string;
    name: string;
    userEmail: string;
    userIdNum: string;
    timezone: string;
    email: string;
    html: string;
    text: string;
    credit: number;
    /** @format bigint */
    updated: number;
    deleted: boolean;
}
