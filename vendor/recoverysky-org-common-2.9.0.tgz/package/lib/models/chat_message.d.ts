/**
 * Chat message for AI agent conversation persistence
 *
 * Stores complete messages from Vercel AI SDK's useChat() after streaming completes.
 * Parts are serialized as JSON to preserve tool invocations and structured content.
 * SQLite-only model for local device storage.
 *
 * @example
 * // Message with text only
 * { id: 'msg-1', role: 'user', parts: '[{"type":"text","text":"Hello"}]' }
 *
 * // Message with tool invocation
 * { id: 'msg-2', role: 'assistant', parts: '[{"type":"text","text":"Found 3 meetings"},{"type":"tool-invocation",...}]' }
 */
export declare class chat_message {
    /** UUID for the message (from AI SDK) */
    id: string;
    /** Message role: 'user' | 'assistant' | 'system' */
    role: string;
    /**
     * Serialized JSON array of UIMessagePart[]
     * Contains: text, reasoning, tool invocations, files, etc.
     * We store the full parts array to preserve all message data for conversation continuity.
     */
    parts: string;
    /**
     * Optional message metadata (JSON)
     * For future extensibility (e.g., model info, token counts)
     */
    metadata: string | null;
    /** Created timestamp (Unix ms) */
    /** @format bigint */
    createdAt: number;
    /** Updated timestamp (Unix ms) - for future edit support */
    /** @format bigint */
    updatedAt: number;
}
