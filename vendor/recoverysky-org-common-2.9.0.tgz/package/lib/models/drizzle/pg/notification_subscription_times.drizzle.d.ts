export declare const notification_subscription_times: import("drizzle-orm/pg-core").PgTableWithColumns<{
    name: "notification_subscription_times";
    schema: undefined;
    columns: {
        schedule_id: import("drizzle-orm/pg-core").PgColumn<{
            name: "schedule_id";
            tableName: "notification_subscription_times";
            dataType: "string";
            columnType: "PgText";
            data: string;
            driverParam: string;
            notNull: true;
            hasDefault: true;
            isPrimaryKey: false;
            isAutoincrement: false;
            hasRuntimeDefault: false;
            enumValues: [string, ...string[]];
            baseColumn: never;
            identity: undefined;
            generated: undefined;
        }, {}, {}>;
        subscription_id: import("drizzle-orm/pg-core").PgColumn<{
            name: "subscription_id";
            tableName: "notification_subscription_times";
            dataType: "string";
            columnType: "PgText";
            data: string;
            driverParam: string;
            notNull: true;
            hasDefault: true;
            isPrimaryKey: false;
            isAutoincrement: false;
            hasRuntimeDefault: false;
            enumValues: [string, ...string[]];
            baseColumn: never;
            identity: undefined;
            generated: undefined;
        }, {}, {}>;
    };
    dialect: "pg";
}>;
