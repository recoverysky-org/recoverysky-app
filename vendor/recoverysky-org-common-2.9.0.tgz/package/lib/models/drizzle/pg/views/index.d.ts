/**
 * Drizzle ORM Views
 *
 * Database views for denormalized queries across related tables.
 */
export { meetingFullView, type MeetingFullView } from "./meeting_full.view.js";
