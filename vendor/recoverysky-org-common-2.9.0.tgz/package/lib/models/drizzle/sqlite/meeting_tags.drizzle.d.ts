/**
 * Junction table for meetings.tags array
 * Normalizes the tags[] array into a separate table
 */
export declare const meetingTags: import("drizzle-orm/sqlite-core").SQLiteTableWithColumns<{
    name: "meeting_tags";
    schema: undefined;
    columns: {
        meeting_id: import("drizzle-orm/sqlite-core").SQLiteColumn<{
            name: "meeting_id";
            tableName: "meeting_tags";
            dataType: "string";
            columnType: "SQLiteText";
            data: string;
            driverParam: string;
            notNull: true;
            hasDefault: false;
            isPrimaryKey: false;
            isAutoincrement: false;
            hasRuntimeDefault: false;
            enumValues: [string, ...string[]];
            baseColumn: never;
            identity: undefined;
            generated: undefined;
        }, {}, {
            length: number | undefined;
        }>;
        tag: import("drizzle-orm/sqlite-core").SQLiteColumn<{
            name: "tag";
            tableName: "meeting_tags";
            dataType: "string";
            columnType: "SQLiteText";
            data: string;
            driverParam: string;
            notNull: true;
            hasDefault: false;
            isPrimaryKey: false;
            isAutoincrement: false;
            hasRuntimeDefault: false;
            enumValues: [string, ...string[]];
            baseColumn: never;
            identity: undefined;
            generated: undefined;
        }, {}, {
            length: number | undefined;
        }>;
    };
    dialect: "sqlite";
}>;
