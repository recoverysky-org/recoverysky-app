/**
 * Junction table for schedule -> meetings relationship (mids array)
 * Normalizes the mids[] array from schedules table
 */
export declare const scheduleMeetings: import("drizzle-orm/sqlite-core").SQLiteTableWithColumns<{
    name: "schedule_meetings";
    schema: undefined;
    columns: {
        scheduleId: import("drizzle-orm/sqlite-core").SQLiteColumn<{
            name: "schedule_id";
            tableName: "schedule_meetings";
            dataType: "string";
            columnType: "SQLiteText";
            data: string;
            driverParam: string;
            notNull: true;
            hasDefault: false;
            isPrimaryKey: false;
            isAutoincrement: false;
            hasRuntimeDefault: false;
            enumValues: [string, ...string[]];
            baseColumn: never;
            identity: undefined;
            generated: undefined;
        }, {}, {
            length: number | undefined;
        }>;
        meetingId: import("drizzle-orm/sqlite-core").SQLiteColumn<{
            name: "meeting_id";
            tableName: "schedule_meetings";
            dataType: "string";
            columnType: "SQLiteText";
            data: string;
            driverParam: string;
            notNull: true;
            hasDefault: false;
            isPrimaryKey: false;
            isAutoincrement: false;
            hasRuntimeDefault: false;
            enumValues: [string, ...string[]];
            baseColumn: never;
            identity: undefined;
            generated: undefined;
        }, {}, {
            length: number | undefined;
        }>;
    };
    dialect: "sqlite";
}>;
