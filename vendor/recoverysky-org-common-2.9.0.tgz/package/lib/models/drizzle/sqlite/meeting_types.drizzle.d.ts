/**
 * Junction table for meetings.meetingTypes array
 * Normalizes the meetingTypes[] array into a separate table
 */
export declare const meetingTypes: import("drizzle-orm/sqlite-core").SQLiteTableWithColumns<{
    name: "meeting_types";
    schema: undefined;
    columns: {
        meeting_id: import("drizzle-orm/sqlite-core").SQLiteColumn<{
            name: "meeting_id";
            tableName: "meeting_types";
            dataType: "string";
            columnType: "SQLiteText";
            data: string;
            driverParam: string;
            notNull: true;
            hasDefault: false;
            isPrimaryKey: false;
            isAutoincrement: false;
            hasRuntimeDefault: false;
            enumValues: [string, ...string[]];
            baseColumn: never;
            identity: undefined;
            generated: undefined;
        }, {}, {
            length: number | undefined;
        }>;
        type: import("drizzle-orm/sqlite-core").SQLiteColumn<{
            name: "type";
            tableName: "meeting_types";
            dataType: "string";
            columnType: "SQLiteText";
            data: string;
            driverParam: string;
            notNull: true;
            hasDefault: false;
            isPrimaryKey: false;
            isAutoincrement: false;
            hasRuntimeDefault: false;
            enumValues: [string, ...string[]];
            baseColumn: never;
            identity: undefined;
            generated: undefined;
        }, {}, {
            length: number | undefined;
        }>;
    };
    dialect: "sqlite";
}>;
