/**
 * User Profile Model
 *
 * Stores user preferences and recovery information.
 * This is a client-side only table (SQLite) with optional server sync (PostgreSQL).
 */
export declare class user_profile {
    id: string;
    shortName: string;
    pronouns: string | null;
    recoveryDate: string | null;
    fellowship: string;
    userIdNum: string | null;
    language: string;
}
