/**
 * Inline every `$ref` in a generated schema's properties and drop `definitions`.
 *
 * RxDB does not support `$ref`, and the downstream drizzle generator reads
 * `prop.type` — a surviving `$ref` leaves it undefined and the column silently
 * falls back to `text`.
 *
 * A nullable mapped type (`Record<string, unknown> | null`) is emitted as an
 * `anyOf` whose non-null branch is the `$ref`, not as a bare `$ref`, so the
 * branches have to be walked too. Missing that is how
 * notification_types.params_schema became a text column.
 *
 * Exported for testing.
 */
export declare const inlineDefinitions: (schema: any) => void;
