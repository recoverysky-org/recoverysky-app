export declare const getSpatialColumnParts: (tableName: string) => {
    customTypeDecl: string;
    column: string;
    index: string;
} | null;
export declare const getColumnDefinition: (key: string, prop: any, required: string[], tableName: string, definitions?: Record<string, any>) => string;
