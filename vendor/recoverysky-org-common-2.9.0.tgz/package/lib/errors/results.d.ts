/**
 * RecoverySky Domain-Specific Result Helpers
 *
 * This module provides domain-specific `ok()` and `err()` functions using
 * ts-rust-result v2.2.0's `createDomainResult()` pattern.
 *
 * **Key Benefits:**
 * - ZERO type assertions needed throughout the codebase
 * - No more `err<E>()` generics or `as Result<T, E>` casts
 * - Clean recursive error propagation
 * - Better IDE autocomplete
 *
 * **Usage:**
 * Always import `ok` and `err` from this module instead of the base library.
 *
 * @module errors/results
 * @see https://github.com/jenova-marie/ts-rust-result
 *
 * @example
 * ```typescript
 * // ✅ CORRECT - Import from domain helpers
 * import { ok, err } from './results.js'
 * import { invalidFieldValue } from '@jenova-marie/ts-rust-result/errors'
 *
 * function validate(x: number): RecoverySkyResult<number> {
 *   if (x < 0) {
 *     return err(invalidFieldValue('x', x, 'positive number'))  // ✨ No cast!
 *   }
 *   return ok(x)  // ✨ Perfectly typed!
 * }
 * ```
 *
 * @example
 * ```typescript
 * // ❌ WRONG - Don't import from base library
 * import { ok, err } from '@jenova-marie/ts-rust-result'  // NO!
 * ```
 */
import type { Result } from '@jenova-marie/ts-rust-result';
import type { RecoverySkyError } from './types.js';
/**
 * Domain-specific `ok()` and `err()` functions for RecoverySky.
 *
 * These functions are bound to the `RecoverySkyError` type, eliminating
 * the need for type assertions throughout the codebase.
 *
 * @constant
 */
export declare const ok: <T>(value: T) => Result<T, RecoverySkyError>, err: (error: RecoverySkyError) => Result<never, RecoverySkyError>;
/**
 * Standard Result type for RecoverySky operations.
 *
 * Use this as the return type for functions that can return any RecoverySky error.
 *
 * @template T - The success value type
 *
 * @example
 * ```typescript
 * function doSomething(): RecoverySkyResult<Data> {
 *   if (error) return err(someError)
 *   return ok(data)
 * }
 * ```
 */
export type RecoverySkyResult<T> = Result<T, RecoverySkyError>;
/**
 * DateTime-specific Result type.
 *
 * Use for That70sDateTime utilities and time conversion functions.
 * Uses RecoverySkyError for compatibility with domain helpers.
 *
 * @template T - The success value type
 *
 * @example
 * ```typescript
 * import { ok, err, type DateTimeResult } from './results.js'
 *
 * function makeThat70sDateTime(...): DateTimeResult<DateTime> {
 *   if (!dt.isValid) {
 *     return err(invalidFieldValue('dateTime', dt, 'valid DateTime'))
 *   }
 *   return ok(that70sDateTime)
 * }
 * ```
 */
export type DateTimeResult<T> = Result<T, RecoverySkyError>;
/**
 * Meeting-specific Result type.
 *
 * Use for Meeting class methods and meeting operations.
 * Uses RecoverySkyError for compatibility with domain helpers.
 *
 * @template T - The success value type
 *
 * @example
 * ```typescript
 * import { ok, err, type MeetingResult } from './results.js'
 *
 * public async update(): Promise<MeetingResult<void>> {
 *   if (!this.zid) {
 *     return err(requiredFieldMissing('zid'))
 *   }
 *   return ok(undefined)
 * }
 * ```
 */
export type MeetingResult<T> = Result<T, RecoverySkyError>;
/**
 * JWK generation Result type.
 *
 * Use for JSON Web Key generation and cryptographic key operations.
 * Uses RecoverySkyError for compatibility with domain helpers.
 *
 * @template T - The success value type
 *
 * @example
 * ```typescript
 * import { ok, err, type JWKResult } from './results.js'
 *
 * export async function createNewJWK(...): Promise<JWKResult<JWKData>> {
 *   if (!type) {
 *     return err(requiredFieldMissing('type'))
 *   }
 *   return ok(jwkData)
 * }
 * ```
 */
export type JWKResult<T> = Result<T, RecoverySkyError>;
/**
 * Crypto operations Result type.
 *
 * Use for hashing, encryption, and other cryptographic operations.
 * Uses RecoverySkyError for compatibility with domain helpers.
 *
 * @template T - The success value type
 *
 * @example
 * ```typescript
 * import { ok, err, type CryptoResult } from './results.js'
 *
 * async function generateHash(data: string): Promise<CryptoResult<string>> {
 *   const result = await tryResult(() => crypto.subtle.digest(...))
 *   if (!result.ok) {
 *     return err(unexpected('Hash generation failed', result.error))
 *   }
 *   return ok(hash)
 * }
 * ```
 */
export type CryptoResult<T> = Result<T, RecoverySkyError>;
/**
 * Schedule-specific Result type.
 *
 * Use for Schedule class methods and schedule operations.
 * Uses RecoverySkyError for compatibility with domain helpers.
 *
 * @template T - The success value type
 *
 * @example
 * ```typescript
 * import { ok, err, type ScheduleResult } from './results.js'
 *
 * function validateSchedule(schedule: Schedule): ScheduleResult<Schedule> {
 *   if (!schedule.meetings.length) {
 *     return err(invalidFieldValue('meetings', [], 'non-empty array'))
 *   }
 *   return ok(schedule)
 * }
 * ```
 */
export type ScheduleResult<T> = Result<T, RecoverySkyError>;
