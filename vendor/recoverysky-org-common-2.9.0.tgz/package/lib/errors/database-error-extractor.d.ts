/**
 * Database Error Extractor - Extracts detailed error information from PostgreSQL errors
 *
 * PostgreSQL and postgres.js libraries provide rich error details including:
 * - Error codes (e.g., "23505" for unique constraint violation)
 * - Schema and table information
 * - Column names for constraint violations
 * - Detailed error messages and hints
 *
 * This utility extracts that information and provides structured error details
 * for better debugging of database operations.
 *
 * @module errors/database-error-extractor
 */
/**
 * Extracted database error details from a PostgreSQL error
 */
export interface ExtractedDatabaseError {
    /** PostgreSQL error code (e.g., "23505" = unique violation, "23503" = FK violation) */
    code?: string;
    /** The table that caused the error */
    table?: string;
    /** The column involved in the error (for constraint violations) */
    column?: string;
    /** The constraint name that was violated */
    constraint?: string;
    /** Detailed error message from PostgreSQL */
    message: string;
    /** Additional detail from PostgreSQL */
    detail?: string;
    /** PostgreSQL's suggested-fix hint, distinct from `detail` (e.g. "Perhaps you meant to reference the column \"foo\".") */
    hint?: string;
    /** The SQL query that failed (if available) */
    query?: string;
    /** The operation that failed (e.g., "bulkInsert", "bulkUpsert") */
    operation?: string;
    /**
     * The underlying driver/connection error's own message (e.g. "Connection
     * terminated unexpectedly"), when the top-level error is a wrapper (like
     * drizzle-orm's "Failed query: ..." message) around a `.cause`. Without
     * this, connection-level failures (as opposed to SQL-level errors, which
     * populate `code`/`table`/`column`/`constraint`/`detail`) leave `message`
     * as just the generic wrapper text with no indication of what actually
     * failed underneath.
     */
    causeMessage?: string;
}
/**
 * Extract detailed error information from a PostgreSQL error
 *
 * Handles errors from both drizzle-orm and postgres.js libraries
 *
 * @param error - The error object (typically from Drizzle or postgres.js)
 * @param operation - The name of the operation that failed (optional)
 * @returns Extracted error details with PostgreSQL-specific information
 */
export declare function extractDatabaseErrorDetails(error: any, operation?: string): ExtractedDatabaseError;
/**
 * Format extracted error details into a readable error message for logs/debugging
 *
 * @param details - Extracted database error details
 * @returns Formatted error message
 */
export declare function formatDatabaseError(details: ExtractedDatabaseError): string;
