/**
 * RecoverySky Common Error Types
 *
 * This module defines the domain-specific error taxonomy for RecoverySky.
 * All errors are based on ts-rust-result's standard DomainError categories.
 *
 * @module errors/types
 * @see https://github.com/jenova-marie/ts-rust-result
 */
import type { ValidationError, UnexpectedError, DatabaseError } from "@jenova-marie/ts-rust-result/errors";
/**
 * RecoverySky domain error union type.
 *
 * This represents all possible error types that can occur in RecoverySky Common.
 *
 * **Current Categories:**
 * - `ValidationError` - DateTime/Meeting/Schedule validation failures
 * - `UnexpectedError` - Crypto operations, third-party library errors
 * - `DatabaseError` - Database operations (Drizzle ORM, PostgreSQL)
 *
 * **Future Categories (uncomment when needed):**
 * - `FileSystemError` - File I/O operations
 * - `NetworkError` - API calls, HTTP requests
 *
 * @example
 * ```typescript
 * import { err } from './results.js'
 * import { invalidFieldValue } from '@jenova-marie/ts-rust-result/errors'
 *
 * function validate(x: number): Result<number, RecoverySkyError> {
 *   if (x < 0) {
 *     return err(invalidFieldValue('x', x, 'positive number'))
 *   }
 *   return ok(x)
 * }
 * ```
 */
export type RecoverySkyError = ValidationError | UnexpectedError | DatabaseError;
/**
 * DateTime-specific errors.
 *
 * Used by That70sDateTime utilities for:
 * - Invalid DateTime objects (ValidationError)
 * - Invalid ISO weekday values (ValidationError)
 * - Invalid time conversions (ValidationError)
 * - Invalid frequency calculations (ValidationError)
 * - Unexpected errors during processing (UnexpectedError)
 */
export type DateTimeError = ValidationError | UnexpectedError;
/**
 * Meeting-specific errors.
 *
 * Used by Meeting class for:
 * - Required field validation (zid, millis70s)
 * - Hash generation failures (SHA256)
 * - ObjectID generation errors
 */
export type MeetingError = ValidationError | UnexpectedError;
/**
 * JWK generation errors.
 *
 * Used by createNewJWK for:
 * - Missing required parameters
 * - Key pair generation failures
 * - Key export failures
 */
export type JWKError = ValidationError | UnexpectedError;
/**
 * Crypto operation errors.
 *
 * Used for:
 * - Hash generation (SHA256, etc.)
 * - Encryption/decryption
 * - Random value generation
 */
export type CryptoError = UnexpectedError;
/**
 * Schedule-specific errors.
 *
 * Used by Schedule class for:
 * - Schedule validation
 * - Meeting collection operations
 */
export type ScheduleError = ValidationError | UnexpectedError;
export type { ValidationError, UnexpectedError, FileSystemError, NetworkError, DatabaseError, DomainError, } from "@jenova-marie/ts-rust-result/errors";
