/**
 * RecoverySky Error Handling Module
 *
 * This module exports domain-specific error types and Result helpers.
 *
 * @module errors
 */
export { ok, err } from './results.js';
export type { RecoverySkyResult, DateTimeResult, MeetingResult, JWKResult, CryptoResult, ScheduleResult, } from './results.js';
export type { RecoverySkyError, DateTimeError, MeetingError, JWKError, CryptoError, ScheduleError, ValidationError, UnexpectedError, FileSystemError, NetworkError, DatabaseError, DomainError, } from './types.js';
export { extractDatabaseErrorDetails, formatDatabaseError, type ExtractedDatabaseError, } from './database-error-extractor.js';
