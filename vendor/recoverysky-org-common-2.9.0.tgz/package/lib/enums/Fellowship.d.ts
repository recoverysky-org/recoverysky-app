export declare enum Fellowship {
    NONE = "",
    AA = "AA",
    NA = "NA",
    CMA = "CMA",
    MA = "MA",
    RD = "RD"
}
/** Fellowships available for user selection (excludes NONE) */
export declare const SELECTABLE_FELLOWSHIPS: readonly [Fellowship.AA, Fellowship.NA, Fellowship.CMA, Fellowship.MA, Fellowship.RD];
