/**
 * How a meeting is attended.
 *
 * Values mirror the TSML `attendance_option` vocabulary so no mapping layer is
 * needed for AA feeds. BMLT's numeric `venue_type` maps in: 1 → IN_PERSON,
 * 2 → ONLINE. BMLT 3 (hybrid) has no value here — scrapers translate it into
 * an online and/or in-person record with `meeting.hybrid = true`.
 */
export declare enum VenueType {
    NONE = "",
    IN_PERSON = "in_person",
    ONLINE = "online"
}
