export declare enum MeetingStatus {
    NONE = "NONE",// Default
    ACTIVE = "ACTIVE",// Active meetings
    PAUSED = "PAUSED",// Paused possibly from failed validation or manual temp removal
    DELETED = "DELETED",// Deleted meetings
    MISSING = "MISSING"
}
