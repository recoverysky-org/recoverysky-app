export declare enum ScheduleStatus {
    NONE = "NONE",// Use in sha256
    ERROR = "ERROR",// The schedule encountered an error during processing
    ACTIVE = "ACTIVE",// In service
    PAUSED = "PAUSED",// Paused out of service (default for all schedules)
    DELETED = "DELETED",// Removed from service
    ORPHANED = "ORPHANED"
}
