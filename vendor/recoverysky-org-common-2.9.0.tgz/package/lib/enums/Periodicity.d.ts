/**
 * Recurrence periodicity for TREX events.
 *
 * Mirrors the Periodicity enum from @trex-ts/core for browser compatibility.
 * This local copy avoids importing from @trex-ts/core which uses Node.js APIs.
 *
 * @see {@link https://github.com/jenova-marie/trex-ts} - @trex-ts/core source
 */
export declare enum Periodicity {
    /** 24/7 always-active events */
    CONTINUOUS = 0,
    /** Daily recurring events */
    DAILY = 1,
    /** Weekly recurring events (default for meetings) */
    WEEKLY = 2,
    /** Monthly recurring events */
    MONTHLY = 3,
    /** Yearly recurring events */
    YEARLY = 4
}
