export declare enum VerifiedStatus {
    SUCCESS = "SUCCESS",// yei!
    DENIED = "DENIED",// kicked out or denied entry from waiting room
    FAILED = "FAILED",// quick-fail - invalid zoom meeting id, etc.
    PASSWORD = "PASSWORD",// password required or wrong
    WAITING = "WAITING",// waiting room timeout
    NO_HOST = "NO_HOST",// waiting for host to join
    EMPTY = "EMPTY",// success but meeting was empty
    NONE = "NONE",// default value
    REVERIFY = "REVERIFY"
}
