/**
 * How an address came to be on the email suppression list.
 *
 * Recorded for compliance and for debugging "why did this person stop getting
 * reports" — it never affects whether the suppression applies. A row is a row.
 */
export declare enum UnsubscribeSource {
    LINK = "LINK",// recipient clicked the unsubscribe link in an email footer
    BOUNCE = "BOUNCE",// Postmark hard bounce — the mailbox does not exist
    COMPLAINT = "COMPLAINT",// Postmark spam complaint — recipient hit "junk"
    MANUAL = "MANUAL"
}
