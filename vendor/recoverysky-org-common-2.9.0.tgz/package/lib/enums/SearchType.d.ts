export declare enum SearchType {
    'search' = "search",
    'live' = "live",
    'upcoming' = "upcoming",
    'owned' = "owned",
    'favorite' = "favorite"
}
