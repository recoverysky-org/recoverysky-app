export declare enum SpecificDay {
    'any' = 0,// flag 0 any
    'Monday' = 1,// 1 ISO Monday
    'Tuesday' = 2,
    'Wednesday' = 3,
    'Thursday' = 4,
    'Friday' = 5,
    'Saturday' = 6,
    'Sunday' = 7,// 7 ISO Sunday
    'today' = 8
}
