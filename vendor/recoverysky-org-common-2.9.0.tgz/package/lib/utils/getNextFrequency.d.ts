import type { DateTime as DateTimeType } from 'luxon';
import { type DateTimeResult } from '../errors/results.js';
/**
 * Calculates the next frequency time in milliseconds based on a given interval.
 *
 * Algorithm:
 * - Advances time to the next minute boundary
 * - Continues advancing until minutes are evenly divisible by frequency
 * - Returns the resulting time in milliseconds
 *
 * @param fromWhen - Starting time in milliseconds
 * @param frequency - Frequency interval in minutes (must be > 0)
 * @param DateTime - Luxon DateTime class
 * @returns Result containing the next frequency time in milliseconds, or error if invalid
 *
 * @example
 * const result = getNextFrequency(Date.now(), 5, DateTime);
 * if (result.ok) {
 *   console.log(result.value); // next 5-minute mark
 * } else {
 *   console.error(result.error.message);
 * }
 */
export declare const getNextFrequency: (fromWhen: number, frequency: number, DateTime: typeof DateTimeType) => DateTimeResult<number>;
