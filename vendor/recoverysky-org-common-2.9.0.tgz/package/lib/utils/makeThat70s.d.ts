import { DateTime } from "luxon";
import { type DateTimeResult } from "../errors/results.js";
export declare const iso_weekday_2_70s_dow: {
    Monday: number;
    "1": number;
    Tuesday: number;
    "2": number;
    Wednesday: number;
    "3": number;
    Thursday: number;
    "4": number;
    Friday: number;
    "5": number;
    Saturday: number;
    "6": number;
    Sunday: number;
    "7": number;
};
export declare const _70s_dow_2_iso_weekday: {
    Thursday: number;
    "1": number;
    Friday: number;
    "2": number;
    Saturday: number;
    "3": number;
    Sunday: number;
    "4": number;
    Monday: number;
    "5": number;
    Tuesday: number;
    "6": number;
    Wednesday: number;
    "7": number;
};
export declare const weekdays: string[];
export declare const oneDayMillis: number;
export declare const oneWeekMillis: number;
export declare const time12to24h: (time12: any) => string;
/**
 * Options for makeThat70sDateTimeResult function.
 */
export interface MakeThat70sDateTimeOptions {
    /** Timezone for the time value (defaults to 'local' or DateTime's zone) */
    timezone?: string;
    /** ISO weekday (1-7) or weekday name to use (overrides input's weekday) */
    weekday?: number | string;
}
/**
 * Options for makeThat70sTimeResult function.
 */
export interface MakeThat70sTimeOptions {
    /** Timezone for the time value (defaults to 'local') */
    timezone?: string;
}
/**
 * Converts various time formats to a That70s DateTime (normalized to 1970 epoch week).
 *
 * This is the master function for creating That70s DateTimes with day-of-week awareness.
 * It handles multiple input formats and allows weekday override for recurring meeting patterns.
 *
 * @param time - Time input in various formats:
 *   - undefined: Use current time
 *   - DateTime: Luxon DateTime object
 *   - "HH:MM": 24-hour time string (requires options.timezone)
 *   - number: Milliseconds since epoch
 * @param options - Configuration options
 * @param options.timezone - Timezone to use for conversion (defaults to 'local' or DateTime's zone)
 * @param options.weekday - ISO weekday (1-7) or weekday name to override the input's weekday
 * @returns Result containing That70s DateTime, or error if conversion fails
 *
 * @example
 * // From DateTime object
 * const dt = DateTime.fromObject({ year: 2024, month: 6, day: 13, hour: 14, minute: 30 });
 * const result1 = makeThat70sDateTimeResult(dt);
 *
 * // From "HH:MM" string with timezone and weekday
 * const result2 = makeThat70sDateTimeResult('14:30', {
 *   timezone: 'America/New_York',
 *   weekday: 'Thursday'
 * });
 *
 * // From milliseconds with weekday override
 * const result3 = makeThat70sDateTimeResult(Date.now(), {
 *   timezone: 'UTC',
 *   weekday: 1  // Monday
 * });
 *
 * if (result2.ok) {
 *   console.log(result2.value.toMillis()); // That70s millis on Thursday
 * }
 */
export declare function makeThat70sDateTimeResult(time?: DateTime | string | number, optionsOrWeekday?: MakeThat70sDateTimeOptions | number): DateTimeResult<DateTime>;
/**
 * Converts various time formats to a That70s DateTime on Thursday, Jan 1, 1970.
 *
 * This function creates times specifically on the epoch day (Thursday) by extracting
 * the hour/minute from the input and creating a That70s DateTime at that time on
 * January 1, 1970 (which was a Thursday).
 *
 * All input formats are converted to the specified timezone before extracting the
 * hour/minute components to ensure consistent behavior across different time sources.
 *
 * @param time - Time input in various formats:
 *   - undefined: Use current time
 *   - "HH:MM": 24-hour time string (e.g., "14:30")
 *   - ISO string: Full ISO datetime string
 *   - number: Milliseconds since epoch
 *   - DateTime: Luxon DateTime object
 * @param options - Configuration options
 * @param options.timezone - Timezone to use for conversion (defaults to 'local')
 * @returns Result containing That70s DateTime on Thursday, Jan 1, 1970, or error if conversion fails
 *
 * @example
 * // Current time on Thursday
 * const result1 = makeThat70sTimeResult();
 *
 * // Specific time on Thursday
 * const result2 = makeThat70sTimeResult('14:30', { timezone: 'America/New_York' });
 *
 * // From milliseconds
 * const result3 = makeThat70sTimeResult(Date.now(), { timezone: 'UTC' });
 *
 * if (result2.ok) {
 *   console.log(result2.value.toMillis()); // That70s millis on Thursday
 *   console.log(result2.value.day); // 1 (Thursday in That70s)
 * }
 */
export declare function makeThat70sTimeResult(time?: string | number | DateTime, options?: MakeThat70sTimeOptions): DateTimeResult<DateTime>;
