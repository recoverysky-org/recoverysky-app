/**
 * Deterministic JSON stringify with sorted keys.
 * Ensures consistent serialization for SHA256 hashing regardless of property insertion order.
 */
export declare function deterministicStringify(obj: unknown): string;
