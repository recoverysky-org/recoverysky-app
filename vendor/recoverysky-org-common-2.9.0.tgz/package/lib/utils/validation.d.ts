import type { Result } from "@jenova-marie/ts-rust-result";
import { z } from "zod";
import { meeting } from "../models/meeting.js";
import { schedule } from "../models/schedule.js";
import { trex } from "../models/trex.js";
/**
 * Represents a validation failure for a single item in batch validation.
 */
export interface BatchValidationError<T> {
    /** Index of the invalid item in the original array */
    index: number;
    /** The original data that failed validation */
    data: T;
    /** Zod validation errors */
    errors: z.ZodIssue[];
}
/**
 * Result type for batch validation operations.
 */
export interface BatchValidationResult<T> {
    /** Array of successfully validated items */
    valid: T[];
    /** Array of validation errors with context */
    invalid: BatchValidationError<Partial<T>>[];
}
/**
 * Validates a single meeting using the Zod meetingCreateSchema.
 *
 * This function performs comprehensive runtime validation of meeting data,
 * checking all constraints defined in the Zod schema including:
 * - Required fields (zid, name, fellowship, millis70s)
 * - Field formats (email, URL, timezone, etc.)
 * - Value ranges (timestamps, durations, etc.)
 * - Cross-field validations
 *
 * @param data - Partial meeting data to validate
 * @returns Result containing validated meeting or error
 *
 * @example
 * ```typescript
 * import { validateMeeting } from '@recoverysky-org/common';
 *
 * const meetingData = {
 *   zid: '123456789',
 *   name: 'Monday Night Big Book',
 *   fellowship: 'AA',
 *   millis70s: 259200000, // Thursday 00:00 in That70s format
 *   duration: 3600000, // 1 hour
 *   timezone: 'America/New_York',
 *   time: '19:00',
 *   hour: 19,
 *   minute: 0,
 *   // ... other fields
 * };
 *
 * const result = validateMeeting(meetingData);
 * if (result.ok) {
 *   console.log('Valid meeting:', result.value);
 *   // Use the validated meeting
 * } else {
 *   console.error('Validation failed:', result.error);
 *   // Handle validation errors
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Handling validation errors
 * const result = validateMeeting(invalidData);
 * result.match(
 *   (validMeeting) => {
 *     // Success path
 *     saveMeeting(validMeeting);
 *   },
 *   (error) => {
 *     // Error path
 *     if (error instanceof z.ZodError) {
 *       error.issues.forEach(issue => {
 *         console.error(`${issue.path.join('.')}: ${issue.message}`);
 *       });
 *     }
 *   }
 * );
 * ```
 */
export declare function validateMeeting(data: Partial<meeting>): Result<meeting, z.ZodError>;
/**
 * Validates multiple meetings in batch, collecting both valid and invalid results.
 *
 * This function processes an array of meetings, validating each one independently.
 * Unlike sequential validation that stops at the first error, batch validation
 * continues processing all items and categorizes them into valid and invalid groups.
 *
 * This is useful for:
 * - Importing multiple meetings from external sources
 * - Bulk validation of scraped meeting data
 * - Identifying which items in a batch need correction
 *
 * @param meetings - Array of partial meeting data to validate
 * @returns Result containing batch validation results
 *
 * @example
 * ```typescript
 * import { validateMeetings } from '@recoverysky-org/common';
 *
 * const meetingsToValidate = [
 *   {
 *     zid: '123456789',
 *     name: 'Valid Meeting',
 *     fellowship: 'AA',
 *     millis70s: 259200000,
 *     // ... complete valid data
 *   },
 *   {
 *     zid: 'invalid', // Invalid: neither a Zoom ID nor a p:<host>:<key>
 *     name: 'Invalid Meeting',
 *     // ... missing required fields
 *   },
 *   {
 *     zid: '987654321',
 *     name: 'Another Valid Meeting',
 *     fellowship: 'NA',
 *     millis70s: 345600000,
 *     // ... complete valid data
 *   }
 * ];
 *
 * const result = validateMeetings(meetingsToValidate);
 * if (result.ok) {
 *   const { valid, invalid } = result.value;
 *   console.log(`Successfully validated ${valid.length} meetings`);
 *   console.log(`Failed to validate ${invalid.length} meetings`);
 *
 *   // Process valid meetings
 *   valid.forEach(meeting => saveMeeting(meeting));
 *
 *   // Report invalid meetings
 *   invalid.forEach(({ index, data, errors }) => {
 *     console.error(`Meeting at index ${index} failed validation:`, {
 *       name: data.name,
 *       errors: errors.map(e => `${e.path.join('.')}: ${e.message}`)
 *     });
 *   });
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Using with Result pattern matching
 * const result = validateMeetings(scrapedMeetings);
 * result.match(
 *   ({ valid, invalid }) => {
 *     if (invalid.length > 0) {
 *       console.warn(`${invalid.length} meetings need attention`);
 *       generateValidationReport(invalid);
 *     }
 *     return importMeetings(valid);
 *   },
 *   (error) => {
 *     console.error('Batch validation error:', error);
 *   }
 * );
 * ```
 */
export declare function validateMeetings(meetings: Partial<meeting>[]): Result<BatchValidationResult<meeting>, Error>;
/**
 * Validates a single schedule using the Zod scheduleCreateSchema.
 *
 * This function performs comprehensive runtime validation of schedule data,
 * checking all constraints defined in the Zod schema including:
 * - Required fields (zid, name)
 * - Field formats and constraints
 * - Array validations (mids, uids, occurrences)
 * - Cross-field validations (timestamp ordering, array length matching)
 *
 * @param data - Partial schedule data to validate
 * @returns Result containing validated schedule or error
 *
 * @example
 * ```typescript
 * import { validateSchedule } from '@recoverysky-org/common';
 *
 * const scheduleData = {
 *   zid: '123456789',
 *   name: 'Weekly AA Meetings',
 *   mids: ['mid1', 'mid2', 'mid3'],
 *   uids: ['uid1', 'uid2', 'uid3'],
 *   occurrences: [
 *     {
 *       mid: 'mid1',
 *       dayOfWeek: 'Monday',
 *       millis70s: 259200000,
 *       duration: 3600000
 *     }
 *   ],
 *   dailyStartDateTime: -1,
 * };
 *
 * const result = validateSchedule(scheduleData);
 * if (result.ok) {
 *   console.log('Valid schedule:', result.value);
 * } else {
 *   console.error('Validation failed:', result.error);
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Using with Result helpers
 * const result = validateSchedule(scheduleData);
 * const schedule = result.unwrapOr(null);
 * if (schedule) {
 *   // Use validated schedule
 *   await saveSchedule(schedule);
 * }
 * ```
 */
export declare function validateSchedule(data: Partial<schedule>): Result<schedule, z.ZodError>;
/**
 * Validates multiple schedules in batch, collecting both valid and invalid results.
 *
 * This function processes an array of schedules, validating each one independently.
 * Batch validation continues processing all items and categorizes them into
 * valid and invalid groups, allowing you to identify exactly which schedules
 * need correction.
 *
 * This is useful for:
 * - Importing schedules from external sources
 * - Bulk validation of schedule data
 * - Migration validation
 *
 * @param schedules - Array of partial schedule data to validate
 * @returns Result containing batch validation results
 *
 * @example
 * ```typescript
 * import { validateSchedules } from '@recoverysky-org/common';
 *
 * const schedulesToValidate = [
 *   {
 *     zid: '123456789',
 *     name: 'Valid Schedule',
 *     mids: ['mid1'],
 *     uids: ['uid1'],
 *   },
 *   {
 *     zid: 'invalid',
 *     name: 'Invalid Schedule',
 *     // Invalid zid format
 *   },
 * ];
 *
 * const result = validateSchedules(schedulesToValidate);
 * if (result.ok) {
 *   const { valid, invalid } = result.value;
 *   console.log(`Valid: ${valid.length}, Invalid: ${invalid.length}`);
 *
 *   // Process valid schedules
 *   await Promise.all(valid.map(s => saveSchedule(s)));
 *
 *   // Generate error report
 *   if (invalid.length > 0) {
 *     generateErrorReport(invalid);
 *   }
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Detailed error handling
 * const result = validateSchedules(importedSchedules);
 * result.match(
 *   ({ valid, invalid }) => {
 *     invalid.forEach(({ index, data, errors }) => {
 *       console.error(`Schedule "${data.name}" at index ${index}:`);
 *       errors.forEach(err => {
 *         console.error(`  - ${err.path.join('.')}: ${err.message}`);
 *       });
 *     });
 *     return processSchedules(valid);
 *   },
 *   (error) => console.error('Validation error:', error)
 * );
 * ```
 */
export declare function validateSchedules(schedules: Partial<schedule>[]): Result<BatchValidationResult<schedule>, Error>;
/**
 * Validates a single TREX event using the Zod trexCreateSchema.
 *
 * This function performs comprehensive runtime validation of TREX data,
 * checking all constraints defined in the Zod schema including:
 * - Required fields (id, coordinate, timezone, periodicity)
 * - Coordinate ranges based on periodicity
 * - IANA timezone format
 * - Denormalized field constraints (hour, minute, dow, day, month)
 *
 * @param data - Partial TREX data to validate
 * @returns Result containing validated TREX or error
 *
 * @example
 * ```typescript
 * import { validateTrex } from '@recoverysky-org/common';
 * import { TREX, Periodicity } from '@trex-ts/core';
 *
 * // Create from @trex-ts/core and validate
 * const createResult = TREX.fromDateTime(zonedDateTime, Periodicity.WEEKLY);
 * if (createResult.ok) {
 *   const trexData = createResult.value.toJSON();
 *   const validationResult = validateTrex(trexData);
 *
 *   if (validationResult.ok) {
 *     console.log('Valid TREX:', validationResult.value);
 *     await db.insert(trexes).values(validationResult.value);
 *   } else {
 *     console.error('Validation failed:', validationResult.error);
 *   }
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Handling validation errors
 * const result = validateTrex(trexData);
 * result.match(
 *   (validTrex) => {
 *     saveTrex(validTrex);
 *   },
 *   (error) => {
 *     if (error instanceof z.ZodError) {
 *       error.issues.forEach(issue => {
 *         console.error(`${issue.path.join('.')}: ${issue.message}`);
 *       });
 *     }
 *   }
 * );
 * ```
 */
export declare function validateTrex(data: Partial<trex>): Result<trex, z.ZodError>;
/**
 * Validates multiple TREX events in batch, collecting both valid and invalid results.
 *
 * This function processes an array of TREX events, validating each one independently.
 * Unlike sequential validation that stops at the first error, batch validation
 * continues processing all items and categorizes them into valid and invalid groups.
 *
 * This is useful for:
 * - Importing TREX events from external sources
 * - Bulk validation of recurring event data
 * - Migration validation
 *
 * @param trexes - Array of partial TREX data to validate
 * @returns Result containing batch validation results
 *
 * @example
 * ```typescript
 * import { validateTrexes } from '@recoverysky-org/common';
 *
 * const trexesToValidate = [
 *   {
 *     id: '507f1f77bcf86cd799439011',
 *     coordinate: 259200000,
 *     timezone: 'America/New_York',
 *     periodicity: 1, // WEEKLY
 *   },
 *   {
 *     id: '507f1f77bcf86cd799439012',
 *     coordinate: -1, // Invalid: negative coordinate
 *     timezone: 'Invalid/Zone',
 *     periodicity: 5, // Invalid: out of range
 *   },
 * ];
 *
 * const result = validateTrexes(trexesToValidate);
 * if (result.ok) {
 *   const { valid, invalid } = result.value;
 *   console.log(`Valid: ${valid.length}, Invalid: ${invalid.length}`);
 *
 *   // Process valid TREX events
 *   await Promise.all(valid.map(t => saveTrex(t)));
 *
 *   // Report invalid events
 *   invalid.forEach(({ index, data, errors }) => {
 *     console.error(`TREX at index ${index} failed validation:`, {
 *       id: data.id,
 *       errors: errors.map(e => `${e.path.join('.')}: ${e.message}`)
 *     });
 *   });
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Using with Result pattern matching
 * const result = validateTrexes(importedTrexes);
 * result.match(
 *   ({ valid, invalid }) => {
 *     if (invalid.length > 0) {
 *       console.warn(`${invalid.length} TREX events need attention`);
 *       generateValidationReport(invalid);
 *     }
 *     return importTrexes(valid);
 *   },
 *   (error) => {
 *     console.error('Batch validation error:', error);
 *   }
 * );
 * ```
 */
export declare function validateTrexes(trexes: Partial<trex>[]): Result<BatchValidationResult<trex>, Error>;
