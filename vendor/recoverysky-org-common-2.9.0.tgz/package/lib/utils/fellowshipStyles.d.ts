import { Fellowship } from "../enums/index.js";
/**
 * Fellowship display colors (hex values for cross-platform use)
 */
export declare const FELLOWSHIP_COLORS: Record<Fellowship, string>;
/**
 * Fellowship filter options for UI dropdowns
 */
export declare const FELLOWSHIP_OPTIONS: readonly ["ALL", "AA", "NA", "CMA", "MA", "RD"];
export type FellowshipFilter = (typeof FELLOWSHIP_OPTIONS)[number];
