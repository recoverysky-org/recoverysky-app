/**
 * Normalizes an email address into the canonical form used as the suppression
 * list key.
 *
 * Every read and write against `unsubscribes` passes through this function.
 * The unique index on `unsubscribes.email` stores the normalized form, so a
 * lookup that skipped normalization would miss a row that is genuinely there
 * and the send would proceed — suppression fails open, which is the worst
 * outcome this feature has. Callers outside the repository (an API handler
 * hashing an address into an unsubscribe link, say) must use this same
 * function rather than their own `.toLowerCase()`.
 *
 * Folds only what is safe to fold: the domain is case-insensitive per RFC 5321,
 * and while the local part is technically case-sensitive, no mail provider in
 * practice treats `Bob@` and `bob@` as different mailboxes. Dots and `+` tags
 * are left alone — Gmail treats them as aliases but most providers do not, so
 * stripping them would suppress addresses the recipient never asked us to stop
 * mailing.
 *
 * @param email - Raw address, possibly with stray case or whitespace
 * @returns The normalized address, or `""` for empty/nullish input
 *
 * @example
 * normalizeEmail("  Bob@Example.COM ") // "bob@example.com"
 */
export declare const normalizeEmail: (email: string) => string;
