/**
 * Audit log query utilities
 *
 * Helper functions for querying meeting_history table with Result<T, E> pattern.
 * All functions return RecoverySkyResult for type-safe error handling.
 *
 * @example
 * ```typescript
 * import { getMeetingHistory, restoreMeetingVersion } from '@recoverysky-org/common';
 * import { db } from './db.js';
 *
 * // Get full history
 * const historyResult = await getMeetingHistory(db, 'meeting-id-123');
 * historyResult.match(
 *   (records) => console.log(`Found ${records.length} history records`),
 *   (error) => console.error('Failed to fetch history:', error)
 * );
 *
 * // Restore previous version
 * const restoreResult = await restoreMeetingVersion(db, 'meeting-id-123', 'history-id-456', 'user-789');
 * ```
 */
import type { NodePgDatabase } from 'drizzle-orm/node-postgres';
import type { RecoverySkyResult } from '../errors/results.js';
import type { meeting_history } from '../models/meeting_history.js';
import type { meeting } from '../models/meeting.js';
/**
 * Get full history for a specific meeting, ordered by most recent first
 *
 * @param db - Drizzle database instance
 * @param meetingId - The meeting ID to query history for
 * @returns Result containing array of history records
 */
export declare function getMeetingHistory(db: NodePgDatabase<any>, meetingId: string): Promise<RecoverySkyResult<meeting_history[]>>;
/**
 * Get history for a meeting within a specific date range
 *
 * @param db - Drizzle database instance
 * @param meetingId - The meeting ID to query history for
 * @param startTimestamp - Start of date range (Unix milliseconds)
 * @param endTimestamp - End of date range (Unix milliseconds)
 * @returns Result containing array of history records in date range
 */
export declare function getMeetingHistoryInRange(db: NodePgDatabase<any>, meetingId: string, startTimestamp: number, endTimestamp: number): Promise<RecoverySkyResult<meeting_history[]>>;
/**
 * Get history filtered by operation type (INSERT, UPDATE, DELETE)
 *
 * @param db - Drizzle database instance
 * @param meetingId - The meeting ID to query history for
 * @param operations - Array of operation types to filter by
 * @returns Result containing filtered history records
 */
export declare function getMeetingHistoryByOperation(db: NodePgDatabase<any>, meetingId: string, operations: Array<'INSERT' | 'UPDATE' | 'DELETE'>): Promise<RecoverySkyResult<meeting_history[]>>;
/**
 * Get history records where specific fields changed
 *
 * Useful for tracking changes to specific fields like status, verified, name, etc.
 *
 * @param db - Drizzle database instance
 * @param meetingId - The meeting ID to query history for
 * @param fieldNames - Array of field names to search for in changed_fields
 * @returns Result containing history records where any of the specified fields changed
 *
 * @example
 * ```typescript
 * // Get all times the status or verified fields changed
 * const result = await getHistoryByChangedFields(db, 'meeting-123', ['status', 'verified']);
 * ```
 */
export declare function getHistoryByChangedFields(db: NodePgDatabase<any>, meetingId: string, fieldNames: string[]): Promise<RecoverySkyResult<meeting_history[]>>;
/**
 * Get the state of a meeting at a specific point in time
 *
 * Finds the most recent history record before or at the specified timestamp.
 *
 * @param db - Drizzle database instance
 * @param meetingId - The meeting ID to query
 * @param timestamp - Point in time (Unix milliseconds)
 * @returns Result containing the meeting state at that time, or undefined if no record exists
 */
export declare function getMeetingStateAt(db: NodePgDatabase<any>, meetingId: string, timestamp: number): Promise<RecoverySkyResult<meeting_history | undefined>>;
/**
 * Restore a meeting to a previous version from history
 *
 * Copies the historical data back to the main meetings table.
 * Creates a new history record with operation='UPDATE' to track the restoration.
 *
 * @param db - Drizzle database instance
 * @param meetingId - The meeting ID to restore
 * @param historyId - The hid of the history record to restore from
 * @param userId - User ID performing the restoration (for audit trail)
 * @returns Result containing the restored meeting data
 *
 * @example
 * ```typescript
 * // Restore meeting to state from history record
 * const result = await restoreMeetingVersion(db, 'meeting-123', 'history-456', 'user-789');
 * result.match(
 *   (restored) => console.log('Restored meeting:', restored.name),
 *   (error) => console.error('Restore failed:', error)
 * );
 * ```
 */
export declare function restoreMeetingVersion(db: NodePgDatabase<any>, meetingId: string, historyId: string, userId?: string): Promise<RecoverySkyResult<meeting>>;
/**
 * Get statistics about changes to a meeting
 *
 * Returns counts of operations, most frequently changed fields, and change velocity.
 *
 * @param db - Drizzle database instance
 * @param meetingId - The meeting ID to analyze
 * @returns Result containing change statistics
 */
export declare function getMeetingChangeStats(db: NodePgDatabase<any>, meetingId: string): Promise<RecoverySkyResult<{
    totalChanges: number;
    insertCount: number;
    updateCount: number;
    deleteCount: number;
    mostChangedFields: Array<{
        field: string;
        changeCount: number;
    }>;
    firstChange: number;
    lastChange: number;
}>>;
