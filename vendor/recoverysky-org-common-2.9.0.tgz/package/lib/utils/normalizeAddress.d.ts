/**
 * Normalizes a street line into a stable key fragment for venue grouping.
 *
 * NA meeting identity uses the source's listing PK; this function serves the
 * derived layer — grouping meetings by venue for schedule extraction, and as
 * dedup evidence. BMLT has no location entity, so the grouping key derives
 * from the address. Address text is hand-maintained and varies — this folds
 * the variation that is demonstrably noise (case, punctuation, spacing, suffix
 * abbreviations, spelled ordinals, unit markers) while leaving genuine
 * differences intact.
 *
 * Deliberately does NOT correct real typos. "evans" and "evens" stay distinct:
 * silently merging two different addresses is worse than splitting one venue.
 *
 * Measured on 768 coordinate clusters across three live BMLT servers, these
 * rules reduce venue fragmentation from 5.9% to 2.2%.
 *
 * @param street the raw street line, e.g. BMLT `location_street`
 * @returns a lowercased, whitespace-free normalized form for grouping, or ""
 *          for empty input
 *
 * @example
 * normalizeAddress("2218 First Ave S")  // "22181stavs"
 * normalizeAddress("2218 1st Av S")     // "22181stavs"  — same key
 */
export declare function normalizeAddress(street: string): string;
