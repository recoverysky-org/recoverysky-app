import { DateTime } from "@trex-ts/core/browser";
import type { trex } from "../models/trex.js";
/** Day names for schedule grid display */
export declare const DAYS: readonly ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
/**
 * Hydrate meetings and build time-keyed grid for schedule display.
 *
 * Returns Map<timeKey, [Mon, Tue, Wed, Thu, Fri, Sat, Sun]>
 * where timeKey is "HH:mm" format and each slot is Luxon DateTime or null.
 * All times are converted to the browser's local timezone.
 *
 * @example
 * const grid = hydrateScheduleGrid(meetings);
 * // Map { "09:00" => [DateTime, null, null, null, null, null, null] }
 */
export declare function hydrateScheduleGrid<T extends {
    trex?: trex | null;
}>(meetings: T[]): Map<string, Array<DateTime | null>>;
