import { type JWKResult } from '../errors/results.js';
/**
 * Generates a new JSON Web Key (JWK) pair for signing.
 *
 * Algorithm:
 * - Generates a cryptographic key pair using the specified algorithm
 * - Exports both public and private keys as JWK format
 * - Adds signing metadata (use, kid) to private key
 * - Returns keys with creation timestamp
 *
 * @param type - Key algorithm type (e.g., 'RS256', 'ES256')
 * @param options - Optional key generation parameters
 * @returns Result containing the JWK pair with timestamp, or error if generation fails
 *
 * @example
 * const result = await createNewJWK('RS256', { modulusLength: 2048 });
 * if (result.ok) {
 *   const { created, privateJwk, publicJwk } = result.value;
 *   console.log('Key generated at:', created);
 * } else {
 *   console.error('Key generation failed:', result.error.message);
 * }
 */
export declare function createNewJWK(type: string, options?: any): Promise<JWKResult<{
    created: number;
    privateJwk: any;
    publicJwk: any;
}>>;
