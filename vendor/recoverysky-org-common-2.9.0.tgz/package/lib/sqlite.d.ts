/**
 * SQLite exports for React Native / Expo apps
 *
 * This entry point provides browser-compatible SQLite schema exports
 * for use with Drizzle ORM and expo-sqlite.
 *
 * ## Schema Usage
 * ```typescript
 * import {
 *   meetings,
 *   schedules,
 *   meetingTypes,
 *   meetingTags,
 *   syncQueue,
 * } from '@recoverysky-org/common/sqlite';
 * ```
 *
 * ## Migrations Usage
 * ```typescript
 * import { drizzle } from 'drizzle-orm/expo-sqlite';
 * import { useMigrations } from 'drizzle-orm/expo-sqlite/migrator';
 * import { openDatabaseSync } from 'expo-sqlite';
 * import { migrations } from '@recoverysky-org/common/sqlite';
 *
 * const expoDb = openDatabaseSync('recoverysky.db');
 * const db = drizzle(expoDb);
 *
 * // In a component:
 * const { success, error } = useMigrations(db, migrations);
 * ```
 *
 * This export is designed to work with:
 * - expo-sqlite
 * - drizzle-orm/expo-sqlite driver
 * - React Native / Expo bundlers (Metro)
 */
export * from './models/drizzle/sqlite/index.js';
export { default as migrations } from './models/migrations/sqlite/migrations.js';
export { eq, ne, gt, gte, lt, lte, and, or, not, inArray, notInArray, isNull, isNotNull, like, sql, type SQL, type SQLWrapper, } from 'drizzle-orm';
export * from './enums/index.js';
export * from './types/index.js';
export { meeting } from './models/meeting.js';
export { schedule } from './models/schedule.js';
export { trex } from './models/trex.js';
export { news } from './models/news.js';
export { system_prompt } from './models/system_prompt.js';
export * from './models/zod/meeting.zod.js';
export * from './models/zod/schedule.zod.js';
export * from './models/zod/trex.zod.js';
export * from './models/zod/news.zod.js';
export * from './models/zod/system_prompt.zod.js';
export * from './utils/validation.js';
export * from './errors/index.js';
export * from './repositories/sqlite/index.js';
export type { DrizzleSqliteDatabase } from './types/database.js';
