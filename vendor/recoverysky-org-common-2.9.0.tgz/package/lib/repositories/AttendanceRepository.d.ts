/**
 * AttendanceRepository - Data access layer for attendances table (PostgreSQL)
 *
 * Stores individual attendance records. Each attendance belongs to a user
 * and optionally to an attendance report (via attendance.arid).
 *
 * @example
 * import { AttendanceRepository } from '@recoverysky-org/common';
 * import { drizzle } from 'drizzle-orm/node-postgres';
 *
 * const db = drizzle(pool);
 * const repo = new AttendanceRepository(db);
 *
 * const result = await repo.findByReportId('report-id');
 * if (result.ok) {
 *   console.log('Attendances:', result.value.length);
 * }
 */
import type { DrizzleDatabase } from "../types/database.js";
import { attendance } from "../models/attendance.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class AttendanceRepository {
    readonly db: DrizzleDatabase;
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "attendances";
        schema: undefined;
        columns: {
            archived: import("drizzle-orm/pg-core").PgColumn<{
                name: "archived";
                tableName: "attendances";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            arid: import("drizzle-orm/pg-core").PgColumn<{
                name: "arid";
                tableName: "attendances";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            created: import("drizzle-orm/pg-core").PgColumn<{
                name: "created";
                tableName: "attendances";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            credit: import("drizzle-orm/pg-core").PgColumn<{
                name: "credit";
                tableName: "attendances";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            deleted: import("drizzle-orm/pg-core").PgColumn<{
                name: "deleted";
                tableName: "attendances";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            end: import("drizzle-orm/pg-core").PgColumn<{
                name: "end";
                tableName: "attendances";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            events: import("drizzle-orm/pg-core").PgColumn<{
                name: "events";
                tableName: "attendances";
                dataType: "json";
                columnType: "PgJsonb";
                data: unknown;
                driverParam: unknown;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "attendances";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            iid: import("drizzle-orm/pg-core").PgColumn<{
                name: "iid";
                tableName: "attendances";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            meetingHost: import("drizzle-orm/pg-core").PgColumn<{
                name: "meetingHost";
                tableName: "attendances";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            meetingName: import("drizzle-orm/pg-core").PgColumn<{
                name: "meetingName";
                tableName: "attendances";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            meetingTopic: import("drizzle-orm/pg-core").PgColumn<{
                name: "meetingTopic";
                tableName: "attendances";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            mid: import("drizzle-orm/pg-core").PgColumn<{
                name: "mid";
                tableName: "attendances";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            processed: import("drizzle-orm/pg-core").PgColumn<{
                name: "processed";
                tableName: "attendances";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            produced: import("drizzle-orm/pg-core").PgColumn<{
                name: "produced";
                tableName: "attendances";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            start: import("drizzle-orm/pg-core").PgColumn<{
                name: "start";
                tableName: "attendances";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            uid: import("drizzle-orm/pg-core").PgColumn<{
                name: "uid";
                tableName: "attendances";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            updated: import("drizzle-orm/pg-core").PgColumn<{
                name: "updated";
                tableName: "attendances";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            uzid: import("drizzle-orm/pg-core").PgColumn<{
                name: "uzid";
                tableName: "attendances";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            valid: import("drizzle-orm/pg-core").PgColumn<{
                name: "valid";
                tableName: "attendances";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            zid: import("drizzle-orm/pg-core").PgColumn<{
                name: "zid";
                tableName: "attendances";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            zpid: import("drizzle-orm/pg-core").PgColumn<{
                name: "zpid";
                tableName: "attendances";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            zuid: import("drizzle-orm/pg-core").PgColumn<{
                name: "zuid";
                tableName: "attendances";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Find attendance by ID
     */
    findById(id: string): Promise<RecoverySkyResult<attendance | null>>;
    /**
     * Find all attendances for a report, ordered by start time
     */
    findByReportId(arid: string): Promise<RecoverySkyResult<attendance[]>>;
    /**
     * Find all attendances for a user
     */
    findByUserId(uid: string): Promise<RecoverySkyResult<attendance[]>>;
    /**
     * Insert a single attendance record
     */
    create(data: attendance): Promise<RecoverySkyResult<attendance>>;
    /**
     * Insert multiple attendance records in a single statement
     */
    createMany(records: attendance[]): Promise<RecoverySkyResult<attendance[]>>;
    /**
     * Upsert multiple attendance records (last-write-wins on `updated`)
     *
     * `arid`/`produced` are preserved instead of blindly overwritten: a record
     * can be created by POST /reports (report-produced, `arid` + `produced`
     * already set) before the owning device ever pushes it through /sync. When
     * that device's push later arrives with a blank `arid`/zero `produced` (it
     * doesn't know about the report yet), we keep the already-known report
     * linkage rather than erasing it.
     */
    upsertMany(records: attendance[]): Promise<RecoverySkyResult<attendance[]>>;
    /**
     * Insert the attendance records produced by a report, linking any that
     * already exist to that report.
     *
     * A record can already exist because the owning device pushed it through
     * /sync (where it lands with a blank `arid`) before the report was
     * submitted. `arid` is what binds an attendance row to its report -
     * `findByReportId` reads it - so on conflict we must stamp the report
     * linkage (`arid`/`produced`) onto the existing row. Skipping the conflict
     * would leave `arid` blank and the report would render with zero records.
     *
     * Only the report-linkage columns are written on conflict; the rest of the
     * existing row (already synced from the same device) is left as-is.
     */
    createManyForReport(records: attendance[]): Promise<RecoverySkyResult<attendance[]>>;
    /**
     * Find records for a user changed strictly after `since`, ordered ascending, including tombstones
     */
    findChangedSince(uid: string, since: number, limit: number): Promise<RecoverySkyResult<attendance[]>>;
    /**
     * Delete an attendance by ID
     */
    delete(id: string): Promise<RecoverySkyResult<attendance | null>>;
    /**
     * Execute custom query with Result wrapper
     */
    search<T>(queryFn: (db: DrizzleDatabase) => Promise<T>, operation?: string): Promise<RecoverySkyResult<T>>;
}
