/**
 * NotificationPoolRepository - Data access layer for notification_pools and
 * notification_contents tables (PostgreSQL)
 *
 * A pool is a named set of rotating messages (e.g. "Daily Affirmations").
 * `findContentByPool` returns all rows for the pool regardless of
 * enabled/language — filtering happens later in the API's pure selection
 * helper, not here.
 *
 * @example
 * import { NotificationPoolRepository } from '@recoverysky-org/common';
 * import { drizzle } from 'drizzle-orm/node-postgres';
 *
 * const db = drizzle(pool);
 * const repo = new NotificationPoolRepository(db);
 *
 * const result = await repo.findContentByPool('daily-affirmations');
 * if (result.ok) {
 *   console.log('Content:', result.value);
 * }
 */
import type { DrizzleDatabase } from "../types/database.js";
import { notification_pool } from "../models/notification_pool.js";
import { notification_content } from "../models/notification_content.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class NotificationPoolRepository {
    readonly db: DrizzleDatabase;
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "notification_pools";
        schema: undefined;
        columns: {
            created: import("drizzle-orm/pg-core").PgColumn<{
                name: "created";
                tableName: "notification_pools";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "notification_pools";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            name: import("drizzle-orm/pg-core").PgColumn<{
                name: "name";
                tableName: "notification_pools";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            strategy: import("drizzle-orm/pg-core").PgColumn<{
                name: "strategy";
                tableName: "notification_pools";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Find a notification pool by ID
     */
    findById(id: string): Promise<RecoverySkyResult<notification_pool | null>>;
    /**
     * Find all content rows for a pool. Returns every row regardless of
     * enabled/language — filtering happens in the API's pure selection helper.
     */
    findContentByPool(pool_id: string): Promise<RecoverySkyResult<notification_content[]>>;
    /**
     * Find multiple content rows by IDs
     */
    findContentByIds(ids: string[]): Promise<RecoverySkyResult<notification_content[]>>;
}
