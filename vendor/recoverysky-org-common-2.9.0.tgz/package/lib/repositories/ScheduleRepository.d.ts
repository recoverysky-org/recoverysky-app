/**
 * ScheduleRepository - Data access layer for schedules table
 *
 * Provides efficient bulk operations using Drizzle ORM:
 * - Bulk insert (single query for multiple rows)
 * - Bulk update (transaction-based batch updates)
 * - Batch status updates
 * - Upsert operations (insert or update on conflict)
 *
 * ## Hybrid API Design
 *
 * This repository provides two ways to query data:
 *
 * 1. **Named Methods** (for common operations):
 *    - `bulkInsert()`, `bulkUpsert()`, `findById()`, etc.
 *    - Discoverable via IDE autocomplete
 *    - Well-documented with examples
 *
 * 2. **Generic search()** (for custom queries):
 *    - Pass any Drizzle query function
 *    - Automatic Result<T, E> wrapping
 *    - Maximum flexibility for complex queries
 *
 * @example
 * // Named method (common operation)
 * const schedule = await repo.findById('123');
 *
 * @example
 * // Custom query using repo.table
 * import { and, eq, gt } from 'drizzle-orm';
 *
 * const result = await repo.search(db =>
 *   db.select()
 *     .from(repo.table)
 *     .where(and(
 *       eq(repo.table.fellowship, 'AA'),
 *       gt(repo.table.updated, lastWeek)
 *     ))
 * );
 */
import type { DrizzleDatabase } from "../types/database.js";
import { schedule } from "../models/schedule.js";
import { ScheduleStatus } from "../enums/ScheduleStatus.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class ScheduleRepository {
    /**
     * Drizzle database instance - exposed for custom queries
     *
     * @example
     * import { and, eq, gt } from 'drizzle-orm';
     *
     * const rows = await repo.db.select()
     *   .from(repo.table)
     *   .where(and(
     *     eq(repo.table.fellowship, 'NA'),
     *     gt(repo.table.updated, Date.now() - 86400000)
     *   ));
     */
    readonly db: DrizzleDatabase;
    /**
     * Drizzle table schema - provides type-safe column access
     *
     * Use this to build custom queries without importing the schema separately.
     * All column names and types are accessible via `repo.table.columnName`.
     *
     * @example
     * import { eq } from 'drizzle-orm';
     *
     * // Type-safe column access
     * const result = await repo.search(db =>
     *   db.select()
     *     .from(repo.table)
     *     .where(eq(repo.table.status, ScheduleStatus.ACTIVE))
     * );
     *
     * @example
     * // Direct database queries (bypasses Result wrapping)
     * const rows = await repo.db
     *   .select()
     *   .from(repo.table)
     *   .where(eq(repo.table.fellowship, 'AA'));
     */
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "schedules";
        schema: undefined;
        columns: {
            created: import("drizzle-orm/pg-core").PgColumn<{
                name: "created";
                tableName: "schedules";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            fellowship: import("drizzle-orm/pg-core").PgColumn<{
                name: "fellowship";
                tableName: "schedules";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "schedules";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            json: import("drizzle-orm/pg-core").PgColumn<{
                name: "json";
                tableName: "schedules";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            mids: import("drizzle-orm/pg-core").PgColumn<{
                name: "mids";
                tableName: "schedules";
                dataType: "json";
                columnType: "PgJsonb";
                data: unknown;
                driverParam: unknown;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            minutes: import("drizzle-orm/pg-core").PgColumn<{
                name: "minutes";
                tableName: "schedules";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            name: import("drizzle-orm/pg-core").PgColumn<{
                name: "name";
                tableName: "schedules";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            sha256: import("drizzle-orm/pg-core").PgColumn<{
                name: "sha256";
                tableName: "schedules";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            status: import("drizzle-orm/pg-core").PgColumn<{
                name: "status";
                tableName: "schedules";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            updated: import("drizzle-orm/pg-core").PgColumn<{
                name: "updated";
                tableName: "schedules";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            version: import("drizzle-orm/pg-core").PgColumn<{
                name: "version";
                tableName: "schedules";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            zids: import("drizzle-orm/pg-core").PgColumn<{
                name: "zids";
                tableName: "schedules";
                dataType: "json";
                columnType: "PgJsonb";
                data: unknown;
                driverParam: unknown;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Execute custom query with Result<T, E> error handling
     *
     * Use this for complex queries not covered by named methods:
     * - Complex WHERE clauses with AND/OR/NOT
     * - JOINs with meetings table
     * - Subqueries and CTEs
     * - Aggregations (COUNT, SUM, etc.)
     * - Custom ORDER BY / LIMIT / OFFSET
     *
     * @param queryFn Function that receives db and returns Promise<T>
     * @returns Result<T> with automatic error wrapping
     *
     * @example
     * // Find schedules with >5 meetings
     * import { sql } from 'drizzle-orm';
     *
     * const result = await repo.search(db =>
     *   db.select({
     *     schedule: repo.table,
     *     meetingCount: sql<number>`array_length(${repo.table.mids}, 1)`
     *   })
     *   .from(repo.table)
     *   .where(sql`array_length(${repo.table.mids}, 1) > 5`)
     * );
     *
     * @example
     * // Count schedules by status
     * import { sql } from 'drizzle-orm';
     *
     * const result = await repo.search(db =>
     *   db.select({
     *     status: repo.table.status,
     *     count: sql<number>`count(*)`
     *   })
     *   .from(repo.table)
     *   .groupBy(repo.table.status)
     * );
     */
    search<T>(queryFn: (db: DrizzleDatabase) => Promise<T>): Promise<RecoverySkyResult<T>>;
    /**
     * Bulk insert multiple schedules in a single query
     * More efficient than individual inserts - uses single INSERT statement
     *
     * @example
     * const result = await repo.bulkInsert([schedule1, schedule2, schedule3]);
     * if (result.ok) {
     *   console.log(`Inserted ${result.value.length} schedules`);
     * }
     */
    bulkInsert(data: schedule[]): Promise<RecoverySkyResult<schedule[]>>;
    /**
     * Bulk upsert - insert or update on conflict
     * Uses ON CONFLICT DO UPDATE for efficient upserts
     *
     * @example
     * const result = await repo.bulkUpsert(scrapedSchedules);
     * // Inserts new schedules, updates existing by id
     */
    bulkUpsert(data: schedule[]): Promise<RecoverySkyResult<schedule[]>>;
    /**
     * Batch update multiple schedules in a transaction
     * All updates succeed or all fail (atomic)
     *
     * @example
     * const updates = [
     *   { id: 'id1', changes: { status: ScheduleStatus.ACTIVE } },
     *   { id: 'id2', changes: { name: 'Updated Name' } }
     * ];
     * const result = await repo.batchUpdate(updates);
     */
    batchUpdate(updates: Array<{
        id: string;
        changes: Partial<schedule>;
    }>): Promise<RecoverySkyResult<number>>;
    /**
     * Batch status update - efficiently update status for multiple schedules
     * Uses single UPDATE with WHERE IN clause
     *
     * @example
     * // Mark schedules as ORPHANED
     * const result = await repo.batchStatusUpdate(
     *   ['id1', 'id2', 'id3'],
     *   ScheduleStatus.ORPHANED
     * );
     */
    batchStatusUpdate(ids: string[], status: ScheduleStatus): Promise<RecoverySkyResult<number>>;
    /**
     * Find schedule by ID
     *
     * @example
     * const result = await repo.findById('schedule-123');
     * if (result.ok && result.value) {
     *   console.log('Found:', result.value.name);
     * }
     */
    findById(id: string): Promise<RecoverySkyResult<schedule | null>>;
    /**
     * Find schedules by multiple IDs
     *
     * @example
     * const result = await repo.findByIds(['id1', 'id2', 'id3']);
     */
    findByIds(ids: string[]): Promise<RecoverySkyResult<schedule[]>>;
    /**
     * Find schedules by status
     *
     * @example
     * // Find all ORPHANED schedules
     * const result = await repo.findByStatus(ScheduleStatus.ORPHANED);
     */
    findByStatus(status: ScheduleStatus): Promise<RecoverySkyResult<schedule[]>>;
    /**
     * Find all schedules (use with caution on large datasets)
     *
     * @example
     * const result = await repo.findAll();
     */
    findAll(): Promise<RecoverySkyResult<schedule[]>>;
}
