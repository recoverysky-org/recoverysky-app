/**
 * UserProfileRepository - Data access layer for user_profiles table
 *
 * Provides operations for user profile storage. Typically only one profile
 * exists per device (the "default" profile).
 *
 * @example
 * const result = await repo.findDefault();
 * if (result.ok && result.value) {
 *   console.log('Profile:', result.value.shortName);
 * }
 */
import type { DrizzleDatabase } from "../types/database.js";
import { user_profile } from "../models/user_profile.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class UserProfileRepository {
    readonly db: DrizzleDatabase;
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "user_profiles";
        schema: undefined;
        columns: {
            fellowship: import("drizzle-orm/pg-core").PgColumn<{
                name: "fellowship";
                tableName: "user_profiles";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "user_profiles";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            language: import("drizzle-orm/pg-core").PgColumn<{
                name: "language";
                tableName: "user_profiles";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            pronouns: import("drizzle-orm/pg-core").PgColumn<{
                name: "pronouns";
                tableName: "user_profiles";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            recoveryDate: import("drizzle-orm/pg-core").PgColumn<{
                name: "recoveryDate";
                tableName: "user_profiles";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            shortName: import("drizzle-orm/pg-core").PgColumn<{
                name: "shortName";
                tableName: "user_profiles";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            userIdNum: import("drizzle-orm/pg-core").PgColumn<{
                name: "userIdNum";
                tableName: "user_profiles";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Find the default profile (first record)
     *
     * @example
     * const result = await repo.findDefault();
     */
    findDefault(): Promise<RecoverySkyResult<user_profile | null>>;
    /**
     * Find profile by ID
     *
     * @example
     * const result = await repo.findById('default');
     */
    findById(id: string): Promise<RecoverySkyResult<user_profile | null>>;
    /**
     * Insert a new profile
     *
     * @example
     * const profile = new user_profile();
     * profile.shortName = 'John';
     * profile.fellowship = 'AA';
     * const result = await repo.insert(profile);
     */
    insert(data: user_profile): Promise<RecoverySkyResult<user_profile>>;
    /**
     * Update a profile by ID
     *
     * @example
     * const result = await repo.update('default', { shortName: 'Jane' });
     */
    update(id: string, changes: Partial<user_profile>): Promise<RecoverySkyResult<user_profile | null>>;
    /**
     * Upsert a profile (insert or update on conflict)
     *
     * @example
     * const result = await repo.upsert(profile);
     */
    upsert(data: user_profile): Promise<RecoverySkyResult<user_profile>>;
    /**
     * Delete a profile by ID
     *
     * @example
     * const result = await repo.delete('default');
     */
    delete(id: string): Promise<RecoverySkyResult<user_profile | null>>;
}
