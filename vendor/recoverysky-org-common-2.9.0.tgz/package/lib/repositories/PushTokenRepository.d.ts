/**
 * PushTokenRepository - Data access layer for push_tokens table (PostgreSQL)
 *
 * Stores push notification tokens per user/device.
 * Upsert on (uid, did) conflict refreshes the token, timezone, and language.
 * A blank (omitted) timezone/language on the incoming write never erases a
 * previously stored value — the stored value is preserved instead.
 *
 * @example
 * import { PushTokenRepository } from '@recoverysky-org/common';
 * import { drizzle } from 'drizzle-orm/node-postgres';
 *
 * const db = drizzle(pool);
 * const repo = new PushTokenRepository(db);
 *
 * // Register or update a push token
 * const result = await repo.upsert({
 *   uid: 'user-uuid',
 *   did: 'device-id',
 *   token: 'expo-push-token',
 *   platform: 'ios',
 *   timezone: 'America/New_York',
 * });
 */
import type { DrizzleDatabase } from "../types/database.js";
import type { push_token } from "../models/push_token.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class PushTokenRepository {
    readonly db: DrizzleDatabase;
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "push_tokens";
        schema: undefined;
        columns: {
            created: import("drizzle-orm/pg-core").PgColumn<{
                name: "created";
                tableName: "push_tokens";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            did: import("drizzle-orm/pg-core").PgColumn<{
                name: "did";
                tableName: "push_tokens";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "push_tokens";
                dataType: "string";
                columnType: "PgUUID";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            language: import("drizzle-orm/pg-core").PgColumn<{
                name: "language";
                tableName: "push_tokens";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            platform: import("drizzle-orm/pg-core").PgColumn<{
                name: "platform";
                tableName: "push_tokens";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            timezone: import("drizzle-orm/pg-core").PgColumn<{
                name: "timezone";
                tableName: "push_tokens";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            token: import("drizzle-orm/pg-core").PgColumn<{
                name: "token";
                tableName: "push_tokens";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            uid: import("drizzle-orm/pg-core").PgColumn<{
                name: "uid";
                tableName: "push_tokens";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            updated: import("drizzle-orm/pg-core").PgColumn<{
                name: "updated";
                tableName: "push_tokens";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Insert or update a push token.
     *
     * On conflict (uid, did), refreshes the token, timezone, language, and
     * updated timestamp. `timezone` and `language` are optional so callers
     * that only have the four original fields keep compiling unchanged — but
     * when a caller omits them (or the device hasn't reported them yet), the
     * previously stored value is preserved rather than blanked out. Both
     * columns are `NOT NULL DEFAULT ''`, so an omitted value inserts/updates
     * as `''`; the update only takes the incoming value when it's non-empty.
     */
    upsert(data: Pick<push_token, "uid" | "did" | "token" | "platform"> & Partial<Pick<push_token, "timezone" | "language">>): Promise<RecoverySkyResult<push_token>>;
    /**
     * Find a push token by user ID and device ID
     */
    findByUserAndDevice(uid: string, did: string): Promise<RecoverySkyResult<push_token | null>>;
    /**
     * Find all push tokens for a user
     */
    findByUserId(uid: string): Promise<RecoverySkyResult<push_token[]>>;
    /**
     * Delete a push token by user ID and device ID
     */
    deleteByUserAndDevice(uid: string, did: string): Promise<RecoverySkyResult<push_token | null>>;
    /**
     * Delete all push tokens for a user
     */
    deleteByUserId(uid: string): Promise<RecoverySkyResult<void>>;
    /**
     * Execute custom query with Result wrapper
     */
    search<T>(queryFn: (db: DrizzleDatabase) => Promise<T>, operation?: string): Promise<RecoverySkyResult<T>>;
}
