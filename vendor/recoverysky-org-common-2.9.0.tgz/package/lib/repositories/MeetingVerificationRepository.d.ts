/**
 * MeetingVerificationRepository - hugo verifier probe results (PostgreSQL)
 *
 * Insert-only time-series over meeting_verifications, plus maintenance of
 * the cached-latest fields on meetings. record() is the write path hugo
 * uses; MeetingRepository.updateVerification() remains for other callers.
 */
import type { DrizzleDatabase } from "../types/database.js";
import type { meeting_verification } from "../models/meeting_verification.js";
import type { VerificationReport } from "../types/VerificationReport.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class MeetingVerificationRepository {
    readonly db: DrizzleDatabase;
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "meeting_verifications";
        schema: undefined;
        columns: {
            audio_joined_count: import("drizzle-orm/pg-core").PgColumn<{
                name: "audio_joined_count";
                tableName: "meeting_verifications";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            bot_count: import("drizzle-orm/pg-core").PgColumn<{
                name: "bot_count";
                tableName: "meeting_verifications";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            cohost_count: import("drizzle-orm/pg-core").PgColumn<{
                name: "cohost_count";
                tableName: "meeting_verifications";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            error_code: import("drizzle-orm/pg-core").PgColumn<{
                name: "error_code";
                tableName: "meeting_verifications";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            error_message: import("drizzle-orm/pg-core").PgColumn<{
                name: "error_message";
                tableName: "meeting_verifications";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            guest_count: import("drizzle-orm/pg-core").PgColumn<{
                name: "guest_count";
                tableName: "meeting_verifications";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "meeting_verifications";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            mid: import("drizzle-orm/pg-core").PgColumn<{
                name: "mid";
                tableName: "meeting_verifications";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            observed_at: import("drizzle-orm/pg-core").PgColumn<{
                name: "observed_at";
                tableName: "meeting_verifications";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            participants: import("drizzle-orm/pg-core").PgColumn<{
                name: "participants";
                tableName: "meeting_verifications";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            phone_user_count: import("drizzle-orm/pg-core").PgColumn<{
                name: "phone_user_count";
                tableName: "meeting_verifications";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            unmuted_count: import("drizzle-orm/pg-core").PgColumn<{
                name: "unmuted_count";
                tableName: "meeting_verifications";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            verified: import("drizzle-orm/pg-core").PgColumn<{
                name: "verified";
                tableName: "meeting_verifications";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            video_on_count: import("drizzle-orm/pg-core").PgColumn<{
                name: "video_on_count";
                tableName: "meeting_verifications";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Record one probe result: insert the log row AND update the cached
     * meeting.{verified, verified_on, participants} in a single transaction,
     * so the cache can never drift from the log. Cache values come from the
     * report (status/validatedAt), not wall-clock time.
     */
    record(report: VerificationReport): Promise<RecoverySkyResult<meeting_verification>>;
    /**
     * Record many probe results. Sequential record() calls — each report gets
     * its own transaction so one bad report doesn't void the batch. Returns
     * the number recorded; fails only if every report failed.
     */
    bulkRecord(reports: VerificationReport[]): Promise<RecoverySkyResult<number>>;
    /**
     * Probe history for a meeting, newest first.
     */
    findByMeeting(mid: string, limit?: number): Promise<RecoverySkyResult<meeting_verification[]>>;
    /**
     * Newest probe result for a meeting, or null if never probed.
     */
    latest(mid: string): Promise<RecoverySkyResult<meeting_verification | null>>;
}
