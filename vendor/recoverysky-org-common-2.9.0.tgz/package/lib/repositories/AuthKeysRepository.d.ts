/**
 * AuthKeysRepository - Data access layer for auth_keys table
 *
 * Provides operations for authentication key storage.
 *
 * @example
 * const result = await repo.findByUuid('550e8400-e29b-41d4-a716-446655440000');
 * if (result.ok && result.value) {
 *   console.log('Auth key:', result.value.key);
 * }
 */
import type { DrizzleDatabase } from "../types/database.js";
import { auth_keys } from "../models/auth_keys.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class AuthKeysRepository {
    readonly db: DrizzleDatabase;
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "auth_keys";
        schema: undefined;
        columns: {
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "auth_keys";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            key: import("drizzle-orm/pg-core").PgColumn<{
                name: "key";
                tableName: "auth_keys";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            uuid: import("drizzle-orm/pg-core").PgColumn<{
                name: "uuid";
                tableName: "auth_keys";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Find auth key by ID
     *
     * @example
     * const result = await repo.findById('key-123');
     */
    findById(id: string): Promise<RecoverySkyResult<auth_keys | null>>;
    /**
     * Find auth key by UUID
     *
     * @example
     * const result = await repo.findByUuid('550e8400-e29b-41d4-a716-446655440000');
     */
    findByUuid(uuid: string): Promise<RecoverySkyResult<auth_keys | null>>;
    /**
     * Find auth key by key value
     *
     * @example
     * const result = await repo.findByKey('sk_live_abc123...');
     */
    findByKey(key: string): Promise<RecoverySkyResult<auth_keys | null>>;
    /**
     * Insert a new auth key
     *
     * @example
     * const authKey = new auth_keys();
     * authKey.id = 'key-123';
     * authKey.uuid = '550e8400-e29b-41d4-a716-446655440000';
     * authKey.key = 'sk_live_abc123...';
     * const result = await repo.insert(authKey);
     */
    insert(data: auth_keys): Promise<RecoverySkyResult<auth_keys>>;
    /**
     * Update an auth key by ID
     *
     * @example
     * const result = await repo.update('key-123', { key: 'new_key_value' });
     */
    update(id: string, changes: Partial<auth_keys>): Promise<RecoverySkyResult<auth_keys | null>>;
    /**
     * Upsert an auth key (insert or update on conflict)
     *
     * @example
     * const result = await repo.upsert(authKey);
     */
    upsert(data: auth_keys): Promise<RecoverySkyResult<auth_keys>>;
    /**
     * Delete an auth key by ID
     *
     * @example
     * const result = await repo.delete('key-123');
     */
    delete(id: string): Promise<RecoverySkyResult<auth_keys | null>>;
    /**
     * Get or create an auth key and log the access
     *
     * Single API entry point that:
     * 1. Finds existing key by uuid, or creates one with a crypto-generated key
     * 2. Logs the access to auth_keys_access
     * 3. Returns the key
     *
     * Calls PostgreSQL function get_or_create_auth_key() which uses
     * gen_random_bytes for secure key generation.
     *
     * @param uuid - The UUID to lookup/create
     * @param ip - The IP address of the requester
     * @returns The auth key string
     *
     * @example
     * const result = await repo.getOrCreateKey('550e8400-e29b-41d4-a716-446655440000', '192.168.1.1');
     * if (result.ok) {
     *   console.log('Key:', result.value);
     * }
     */
    getOrCreateKey(uuid: string, ip: string): Promise<RecoverySkyResult<string>>;
}
