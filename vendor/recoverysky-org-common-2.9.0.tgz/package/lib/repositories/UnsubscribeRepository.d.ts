/**
 * UnsubscribeRepository - Data access layer for the unsubscribes table (PostgreSQL)
 *
 * The email suppression list. Call `isSuppressed` before a single send and
 * `filterAllowed` before a batch; both normalize their input, so callers never
 * have to remember to lowercase an address first.
 *
 * @example
 * import { UnsubscribeRepository } from '@recoverysky-org/common';
 * import { drizzle } from 'drizzle-orm/node-postgres';
 *
 * const repo = new UnsubscribeRepository(drizzle(pool));
 *
 * // Guard a single report send
 * const check = await repo.isSuppressed(report.email);
 * if (check.ok && check.value) return; // do not mail
 *
 * // Guard a batch — one query, not one per recipient
 * const allowed = await repo.filterAllowed(reports.map((r) => r.email));
 *
 * // Postmark bounce webhook
 * await repo.add({
 *   email: payload.Email,
 *   source: UnsubscribeSource.BOUNCE,
 *   reason: payload.Description,
 * });
 */
import type { DrizzleDatabase } from "../types/database.js";
import type { unsubscribe } from "../models/unsubscribe.js";
import { UnsubscribeSource } from "../enums/UnsubscribeSource.js";
import { type RecoverySkyResult } from "../errors/results.js";
/** Input accepted by {@link UnsubscribeRepository.add}. */
export interface UnsubscribeInput {
    /** Address to suppress. Normalized before storage. */
    email: string;
    /** Account id, when the address maps to a known user. */
    uid?: string;
    /** How the suppression arose. Defaults to MANUAL. */
    source?: UnsubscribeSource;
    /** Free-text detail — bounce description, Postmark record type, staff note. */
    reason?: string;
}
export declare class UnsubscribeRepository {
    readonly db: DrizzleDatabase;
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "unsubscribes";
        schema: undefined;
        columns: {
            created: import("drizzle-orm/pg-core").PgColumn<{
                name: "created";
                tableName: "unsubscribes";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            email: import("drizzle-orm/pg-core").PgColumn<{
                name: "email";
                tableName: "unsubscribes";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "unsubscribes";
                dataType: "string";
                columnType: "PgUUID";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            reason: import("drizzle-orm/pg-core").PgColumn<{
                name: "reason";
                tableName: "unsubscribes";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            source: import("drizzle-orm/pg-core").PgColumn<{
                name: "source";
                tableName: "unsubscribes";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            uid: import("drizzle-orm/pg-core").PgColumn<{
                name: "uid";
                tableName: "unsubscribes";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            updated: import("drizzle-orm/pg-core").PgColumn<{
                name: "updated";
                tableName: "unsubscribes";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Add an address to the suppression list, or refresh it if already present.
     *
     * Upserts on the unique `email` index rather than inserting, because the
     * callers that write here are webhook handlers: Postmark redelivers on any
     * non-2xx, so a unique violation on the second delivery would become a
     * retry loop. Re-suppressing an address is a successful no-op.
     *
     * `created` is preserved across re-suppression so the row still answers
     * "when did this person first opt out". An omitted `uid` never blanks a
     * stored one — a bounce webhook knows the address but not the account, and
     * shouldn't erase the linkage a link-click established earlier.
     */
    add(data: UnsubscribeInput): Promise<RecoverySkyResult<unsubscribe>>;
    /**
     * Whether this address must not be mailed.
     *
     * An empty address is reported as not suppressed rather than as an error:
     * the caller is about to fail on the missing address anyway, and returning
     * `err` here would tempt call sites into treating a guard failure as
     * permission to send.
     */
    isSuppressed(email: string): Promise<RecoverySkyResult<boolean>>;
    /**
     * Narrow a list of recipients to those that may be mailed.
     *
     * One query for the whole batch — looping `isSuppressed` over a few hundred
     * report recipients would issue a round trip per address. Input is
     * normalized, blanks and duplicates are dropped, and the surviving addresses
     * come back normalized in first-seen order, so the result is directly usable
     * as the send list.
     */
    filterAllowed(emails: string[]): Promise<RecoverySkyResult<string[]>>;
    /**
     * Find the suppression row for an address, or null if it is not suppressed.
     */
    findByEmail(email: string): Promise<RecoverySkyResult<unsubscribe | null>>;
    /**
     * Find every suppressed address linked to a user id.
     *
     * A user may appear more than once — their own address plus any they had
     * reports forwarded to.
     */
    findByUserId(uid: string): Promise<RecoverySkyResult<unsubscribe[]>>;
    /**
     * Resubscribe — delete the suppression row.
     *
     * Returns the removed row, or null if the address was not suppressed.
     * Deleting an absent address is not an error; the caller's intent (this
     * address should be mailable) holds either way.
     */
    remove(email: string): Promise<RecoverySkyResult<unsubscribe | null>>;
    /**
     * Execute custom query with Result wrapper
     */
    search<T>(queryFn: (db: DrizzleDatabase) => Promise<T>, operation?: string): Promise<RecoverySkyResult<T>>;
}
