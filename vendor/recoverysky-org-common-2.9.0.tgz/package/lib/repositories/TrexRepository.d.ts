/**
 * TrexRepository - Data access layer for TREX events table
 *
 * Provides efficient bulk operations using Drizzle ORM:
 * - Bulk insert (single query for multiple rows)
 * - Bulk upsert (insert or update on conflict)
 * - Find operations (by ID, IDs, timezone, periodicity)
 *
 * ## Hybrid API Design
 *
 * This repository provides two ways to query data:
 *
 * 1. **Named Methods** (for common operations):
 *    - `bulkInsert()`, `bulkUpsert()`, `findById()`, etc.
 *    - Discoverable via IDE autocomplete
 *    - Well-documented with examples
 *
 * 2. **Generic search()** (for custom queries):
 *    - Pass any Drizzle query function
 *    - Automatic Result<T, E> wrapping
 *    - Maximum flexibility for complex queries
 *
 * @example
 * // Named method (common operation)
 * const event = await repo.findById('trex-123');
 *
 * @example
 * // Custom query using repo.table
 * import { and, eq, gt } from 'drizzle-orm';
 *
 * const result = await repo.search(db =>
 *   db.select()
 *     .from(repo.table)
 *     .where(and(
 *       eq(repo.table.timezone, 'America/New_York'),
 *       eq(repo.table.periodicity, Periodicity.WEEKLY)
 *     ))
 * );
 */
import type { DrizzleDatabase } from "../types/database.js";
import { trex } from "../models/trex.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class TrexRepository {
    /**
     * Drizzle database instance - exposed for custom queries
     *
     * @example
     * import { and, eq } from 'drizzle-orm';
     *
     * const rows = await repo.db.select()
     *   .from(repo.table)
     *   .where(eq(repo.table.timezone, 'America/New_York'));
     */
    readonly db: DrizzleDatabase;
    /**
     * Drizzle table schema - provides type-safe column access
     *
     * Use this to build custom queries without importing the schema separately.
     * All column names and types are accessible via `repo.table.columnName`.
     *
     * @example
     * import { eq } from 'drizzle-orm';
     *
     * // Type-safe column access
     * const result = await repo.search(db =>
     *   db.select()
     *     .from(repo.table)
     *     .where(eq(repo.table.timezone, 'America/New_York'))
     * );
     *
     * @example
     * // Direct database queries (bypasses Result wrapping)
     * const rows = await repo.db
     *   .select()
     *   .from(repo.table)
     *   .where(eq(repo.table.timezone, 'UTC'));
     */
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "trexes";
        schema: undefined;
        columns: {
            coordinate: import("drizzle-orm/pg-core").PgColumn<{
                name: "coordinate";
                tableName: "trexes";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            coordinate_end: import("drizzle-orm/pg-core").PgColumn<{
                name: "coordinate_end";
                tableName: "trexes";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            dom: import("drizzle-orm/pg-core").PgColumn<{
                name: "dom";
                tableName: "trexes";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            dow: import("drizzle-orm/pg-core").PgColumn<{
                name: "dow";
                tableName: "trexes";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            dtend: import("drizzle-orm/pg-core").PgColumn<{
                name: "dtend";
                tableName: "trexes";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            dtstart: import("drizzle-orm/pg-core").PgColumn<{
                name: "dtstart";
                tableName: "trexes";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            duration_ms: import("drizzle-orm/pg-core").PgColumn<{
                name: "duration_ms";
                tableName: "trexes";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            hour: import("drizzle-orm/pg-core").PgColumn<{
                name: "hour";
                tableName: "trexes";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "trexes";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            minute: import("drizzle-orm/pg-core").PgColumn<{
                name: "minute";
                tableName: "trexes";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            month: import("drizzle-orm/pg-core").PgColumn<{
                name: "month";
                tableName: "trexes";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            periodicity: import("drizzle-orm/pg-core").PgColumn<{
                name: "periodicity";
                tableName: "trexes";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            rrule_json: import("drizzle-orm/pg-core").PgColumn<{
                name: "rrule_json";
                tableName: "trexes";
                dataType: "json";
                columnType: "PgJsonb";
                data: unknown;
                driverParam: unknown;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            rrule_str: import("drizzle-orm/pg-core").PgColumn<{
                name: "rrule_str";
                tableName: "trexes";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            timezone: import("drizzle-orm/pg-core").PgColumn<{
                name: "timezone";
                tableName: "trexes";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Execute custom query with Result<T, E> error handling
     *
     * Use this for complex queries not covered by named methods:
     * - Complex WHERE clauses with AND/OR/NOT
     * - JOINs with other tables
     * - Subqueries and CTEs
     * - Aggregations (COUNT, SUM, etc.)
     * - Custom ORDER BY / LIMIT / OFFSET
     *
     * @param queryFn Function that receives db and returns Promise<T>
     * @returns Result<T> with automatic error wrapping
     *
     * @example
     * // Find WEEKLY events in a specific timezone
     * import { and, eq } from 'drizzle-orm';
     *
     * const result = await repo.search(db =>
     *   db.select()
     *     .from(repo.table)
     *     .where(and(
     *       eq(repo.table.timezone, 'America/New_York'),
     *       eq(repo.table.periodicity, Periodicity.WEEKLY)
     *     ))
     * );
     *
     * @example
     * // Count events by timezone
     * import { sql } from 'drizzle-orm';
     *
     * const result = await repo.search(db =>
     *   db.select({
     *     timezone: repo.table.timezone,
     *     count: sql<number>`count(*)`
     *   })
     *   .from(repo.table)
     *   .groupBy(repo.table.timezone)
     * );
     */
    search<T>(queryFn: (db: DrizzleDatabase) => Promise<T>): Promise<RecoverySkyResult<T>>;
    /**
     * Bulk insert multiple TREX events in a single query
     * More efficient than individual inserts - uses single INSERT statement
     *
     * @example
     * const result = await repo.bulkInsert([event1, event2, event3]);
     * if (result.ok) {
     *   console.log(`Inserted ${result.value.length} events`);
     * }
     */
    bulkInsert(data: trex[]): Promise<RecoverySkyResult<trex[]>>;
    /**
     * Bulk upsert - insert or update on conflict
     * Uses ON CONFLICT DO UPDATE for efficient upserts
     *
     * @example
     * const result = await repo.bulkUpsert(events);
     * // Inserts new events, updates existing by id
     */
    bulkUpsert(data: trex[]): Promise<RecoverySkyResult<trex[]>>;
    /**
     * Find TREX event by ID
     *
     * @example
     * const result = await repo.findById('trex-123');
     * if (result.ok && result.value) {
     *   console.log('Found:', result.value.timezone);
     * }
     */
    findById(id: string): Promise<RecoverySkyResult<trex | null>>;
    /**
     * Find TREX events by multiple IDs
     *
     * @example
     * const result = await repo.findByIds(['id1', 'id2', 'id3']);
     */
    findByIds(ids: string[]): Promise<RecoverySkyResult<trex[]>>;
    /**
     * Find TREX events by timezone
     *
     * @example
     * const result = await repo.findByTimezone('America/New_York');
     */
    findByTimezone(timezone: string): Promise<RecoverySkyResult<trex[]>>;
    /**
     * Find TREX events by periodicity
     *
     * @example
     * import { Periodicity } from '@trex-ts/core';
     * const result = await repo.findByPeriodicity(Periodicity.WEEKLY);
     */
    findByPeriodicity(periodicity: number): Promise<RecoverySkyResult<trex[]>>;
    /**
     * Delete a single TREX event by ID
     *
     * @param id - The ID of the TREX event to delete
     * @returns Result containing the deleted event, or null if not found
     *
     * @example
     * const result = await repo.deleteById('trex-123');
     * if (result.ok && result.value) {
     *   console.log('Deleted:', result.value.id);
     * } else if (result.ok && !result.value) {
     *   console.log('Event not found');
     * }
     */
    deleteById(id: string): Promise<RecoverySkyResult<trex | null>>;
    /**
     * Delete multiple TREX events by IDs
     *
     * @param ids - Array of IDs to delete
     * @returns Result containing array of deleted events
     *
     * @example
     * const result = await repo.bulkDelete(['id1', 'id2', 'id3']);
     * if (result.ok) {
     *   console.log(`Deleted ${result.value.length} events`);
     * }
     */
    bulkDelete(ids: string[]): Promise<RecoverySkyResult<trex[]>>;
    /**
     * Delete all TREX events matching a timezone
     *
     * @param timezone - IANA timezone identifier
     * @returns Result containing array of deleted events
     *
     * @example
     * const result = await repo.deleteByTimezone('America/New_York');
     * if (result.ok) {
     *   console.log(`Deleted ${result.value.length} events in NY timezone`);
     * }
     */
    deleteByTimezone(timezone: string): Promise<RecoverySkyResult<trex[]>>;
}
