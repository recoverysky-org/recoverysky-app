/**
 * NewsRepository - Data access layer for news table (PostgreSQL)
 *
 * Provides operations for news items with time-windowed visibility.
 * The findActive() method returns news where start <= ts <= end.
 */
import type { DrizzleDatabase } from "../types/database.js";
import type { news } from "../models/news.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class NewsRepository {
    readonly db: DrizzleDatabase;
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "news";
        schema: undefined;
        columns: {
            body: import("drizzle-orm/pg-core").PgColumn<{
                name: "body";
                tableName: "news";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            end: import("drizzle-orm/pg-core").PgColumn<{
                name: "end";
                tableName: "news";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "news";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            start: import("drizzle-orm/pg-core").PgColumn<{
                name: "start";
                tableName: "news";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            title: import("drizzle-orm/pg-core").PgColumn<{
                name: "title";
                tableName: "news";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Find news items active at a given timestamp.
     * Returns items where start <= ts AND end >= ts.
     */
    findActive(ts: number): Promise<RecoverySkyResult<news[]>>;
    /**
     * Find news item by ID
     */
    findById(id: string): Promise<RecoverySkyResult<news | null>>;
    /**
     * Insert a news item
     */
    insert(data: news): Promise<RecoverySkyResult<news>>;
    /**
     * Update a news item by ID
     */
    update(id: string, changes: Partial<news>): Promise<RecoverySkyResult<news | null>>;
    /**
     * Delete a news item by ID
     */
    delete(id: string): Promise<RecoverySkyResult<news | null>>;
    /**
     * Execute custom query with Result wrapper
     */
    search<T>(queryFn: (db: DrizzleDatabase) => Promise<T>, operation?: string): Promise<RecoverySkyResult<T>>;
}
