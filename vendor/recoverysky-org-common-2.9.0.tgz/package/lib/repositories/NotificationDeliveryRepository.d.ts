/**
 * NotificationDeliveryRepository - Data access layer for notification_deliveries table (PostgreSQL)
 *
 * notification_deliveries is the ledger every push notification flows
 * through: a scheduler sweep materializes rows, a sender sweep claims and
 * sends them, a receipt poller updates them, and the app reports opens
 * against them. An occurrence IS a delivery (subscriptions are per-device),
 * so dedup is keyed on (source, source_id, occurrence_id).
 *
 * @example
 * import { NotificationDeliveryRepository } from '@recoverysky-org/common';
 * import { drizzle } from 'drizzle-orm/node-postgres';
 *
 * const db = drizzle(pool);
 * const repo = new NotificationDeliveryRepository(db);
 *
 * const due = await repo.findPending(Date.now());
 * if (due.ok) {
 *   console.log('Deliveries due:', due.value);
 * }
 */
import type { DrizzleDatabase } from "../types/database.js";
import { notification_delivery } from "../models/notification_delivery.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class NotificationDeliveryRepository {
    readonly db: DrizzleDatabase;
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "notification_deliveries";
        schema: undefined;
        columns: {
            body: import("drizzle-orm/pg-core").PgColumn<{
                name: "body";
                tableName: "notification_deliveries";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            content_id: import("drizzle-orm/pg-core").PgColumn<{
                name: "content_id";
                tableName: "notification_deliveries";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            created: import("drizzle-orm/pg-core").PgColumn<{
                name: "created";
                tableName: "notification_deliveries";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            delivered_at: import("drizzle-orm/pg-core").PgColumn<{
                name: "delivered_at";
                tableName: "notification_deliveries";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            did: import("drizzle-orm/pg-core").PgColumn<{
                name: "did";
                tableName: "notification_deliveries";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "notification_deliveries";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            occurrence_id: import("drizzle-orm/pg-core").PgColumn<{
                name: "occurrence_id";
                tableName: "notification_deliveries";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            opened_at: import("drizzle-orm/pg-core").PgColumn<{
                name: "opened_at";
                tableName: "notification_deliveries";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            receipt_error: import("drizzle-orm/pg-core").PgColumn<{
                name: "receipt_error";
                tableName: "notification_deliveries";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            receipt_status: import("drizzle-orm/pg-core").PgColumn<{
                name: "receipt_status";
                tableName: "notification_deliveries";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            schedule_id: import("drizzle-orm/pg-core").PgColumn<{
                name: "schedule_id";
                tableName: "notification_deliveries";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            send_at_utc: import("drizzle-orm/pg-core").PgColumn<{
                name: "send_at_utc";
                tableName: "notification_deliveries";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            sending_at: import("drizzle-orm/pg-core").PgColumn<{
                name: "sending_at";
                tableName: "notification_deliveries";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            sent_at: import("drizzle-orm/pg-core").PgColumn<{
                name: "sent_at";
                tableName: "notification_deliveries";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            source: import("drizzle-orm/pg-core").PgColumn<{
                name: "source";
                tableName: "notification_deliveries";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            source_id: import("drizzle-orm/pg-core").PgColumn<{
                name: "source_id";
                tableName: "notification_deliveries";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            status: import("drizzle-orm/pg-core").PgColumn<{
                name: "status";
                tableName: "notification_deliveries";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            ticket_id: import("drizzle-orm/pg-core").PgColumn<{
                name: "ticket_id";
                tableName: "notification_deliveries";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            title: import("drizzle-orm/pg-core").PgColumn<{
                name: "title";
                tableName: "notification_deliveries";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            type_id: import("drizzle-orm/pg-core").PgColumn<{
                name: "type_id";
                tableName: "notification_deliveries";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            uid: import("drizzle-orm/pg-core").PgColumn<{
                name: "uid";
                tableName: "notification_deliveries";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /** Insert deliveries, ignoring rows whose (source, source_id, occurrence_id) already exists. */
    createMany(rows: notification_delivery[]): Promise<RecoverySkyResult<notification_delivery[]>>;
    /**
     * One delivery by id, or null.
     *
     * Exists so a caller can check ownership before acting on a delivery — the
     * api's open-tracking route had no way to load a row's uid.
     */
    findById(id: string): Promise<RecoverySkyResult<notification_delivery | null>>;
    /**
     * Find deliveries the sender should act on: still pending and past their
     * send_at_utc, oldest first.
     *
     * When `reclaimSendingBeforeMs` is given, rows stranded in `sending` with a
     * `sending_at` at or before that cutoff are returned as well. A sender killed
     * between markSending and markSent leaves such a row behind, and without a
     * reclaim path the notification is lost silently. Choose the cutoff so no live
     * sender could still be working: comfortably longer than one sweep.
     *
     * Omit the argument for the original behaviour — pending only.
     */
    findPending(nowMs: number, reclaimSendingBeforeMs?: number): Promise<RecoverySkyResult<notification_delivery[]>>;
    /**
     * Atomically claim a pending delivery for sending.
     *
     * The `status = 'pending'` predicate is what makes this a claim rather than a
     * write: a single UPDATE is atomic in Postgres, so of two senders racing for
     * the same row exactly one matches and the other updates zero rows.
     *
     * Resolves to `null` when the row was not claimable — already claimed, already
     * sent, cancelled, or nonexistent. That is the expected answer for the loser
     * of a race, not an error; callers skip the delivery and move on.
     */
    markSending(id: string, sendingAt: number): Promise<RecoverySkyResult<notification_delivery | null>>;
    /** Mark a delivery sent, recording the Expo ticket and the content actually rendered. */
    markSent(id: string, ticket_id: string, sent_at: number, title: string, body: string): Promise<RecoverySkyResult<notification_delivery | null>>;
    /** Mark a delivery failed (e.g. the Expo push send itself was rejected). */
    markFailed(id: string, receipt_error: string): Promise<RecoverySkyResult<notification_delivery | null>>;
    /** Mark a delivery cancelled (e.g. its subscription was disabled before send). */
    markCancelled(id: string, receipt_error: string): Promise<RecoverySkyResult<notification_delivery | null>>;
    /**
     * Find sent deliveries still awaiting an Expo receipt, sent before the
     * given cutoff.
     */
    findAwaitingReceipts(sentBeforeMs: number): Promise<RecoverySkyResult<notification_delivery[]>>;
    /** Update a delivery's Expo receipt outcome. */
    updateReceipt(id: string, receipt_status: string, receipt_error: string, delivered_at: number): Promise<RecoverySkyResult<notification_delivery | null>>;
    /** Record that the app reported the user opened this notification. */
    markOpened(id: string, opened_at: number): Promise<RecoverySkyResult<boolean>>;
}
