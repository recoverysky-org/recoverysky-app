/**
 * NotificationSubscriptionRepository - Data access layer for notification_subscriptions
 * and notification_subscription_times tables (PostgreSQL)
 *
 * A notification_subscription is a user's opt-in to a notification type on
 * one device, keyed uniquely by (uid, did, type_id). notification_subscription_times
 * is the join table recording which schedules (times) a subscription fires at.
 *
 * @example
 * import { NotificationSubscriptionRepository } from '@recoverysky-org/common';
 * import { drizzle } from 'drizzle-orm/node-postgres';
 *
 * const db = drizzle(pool);
 * const repo = new NotificationSubscriptionRepository(db);
 *
 * const result = await repo.upsert(subscription);
 * if (result.ok) {
 *   console.log('Subscription:', result.value);
 * }
 */
import type { DrizzleDatabase } from "../types/database.js";
import { notification_subscription } from "../models/notification_subscription.js";
import { notification_subscription_time } from "../models/notification_subscription_time.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class NotificationSubscriptionRepository {
    readonly db: DrizzleDatabase;
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "notification_subscriptions";
        schema: undefined;
        columns: {
            created: import("drizzle-orm/pg-core").PgColumn<{
                name: "created";
                tableName: "notification_subscriptions";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            did: import("drizzle-orm/pg-core").PgColumn<{
                name: "did";
                tableName: "notification_subscriptions";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            enabled: import("drizzle-orm/pg-core").PgColumn<{
                name: "enabled";
                tableName: "notification_subscriptions";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "notification_subscriptions";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            params: import("drizzle-orm/pg-core").PgColumn<{
                name: "params";
                tableName: "notification_subscriptions";
                dataType: "json";
                columnType: "PgJsonb";
                data: unknown;
                driverParam: unknown;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            timezone: import("drizzle-orm/pg-core").PgColumn<{
                name: "timezone";
                tableName: "notification_subscriptions";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            type_id: import("drizzle-orm/pg-core").PgColumn<{
                name: "type_id";
                tableName: "notification_subscriptions";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            uid: import("drizzle-orm/pg-core").PgColumn<{
                name: "uid";
                tableName: "notification_subscriptions";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            updated: import("drizzle-orm/pg-core").PgColumn<{
                name: "updated";
                tableName: "notification_subscriptions";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    readonly timesTable: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "notification_subscription_times";
        schema: undefined;
        columns: {
            schedule_id: import("drizzle-orm/pg-core").PgColumn<{
                name: "schedule_id";
                tableName: "notification_subscription_times";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            subscription_id: import("drizzle-orm/pg-core").PgColumn<{
                name: "subscription_id";
                tableName: "notification_subscription_times";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Insert a subscription, or update it if (uid, did, type_id) already exists
     */
    upsert(sub: notification_subscription): Promise<RecoverySkyResult<notification_subscription>>;
    /**
     * Find a subscription by ID
     */
    findById(id: string): Promise<RecoverySkyResult<notification_subscription | null>>;
    /**
     * Find all subscriptions for a user's device
     */
    findByDevice(uid: string, did: string): Promise<RecoverySkyResult<notification_subscription[]>>;
    /**
     * Find all enabled subscriptions among a set of IDs
     */
    findEnabledByIds(ids: string[]): Promise<RecoverySkyResult<notification_subscription[]>>;
    /**
     * Enable or disable a subscription
     */
    setEnabled(id: string, enabled: boolean): Promise<RecoverySkyResult<notification_subscription | null>>;
    /**
     * Update a subscription's params
     */
    updateParams(id: string, params: Record<string, unknown>): Promise<RecoverySkyResult<notification_subscription | null>>;
    /**
     * Update a subscription's timezone
     */
    updateTimezone(id: string, timezone: string): Promise<RecoverySkyResult<notification_subscription | null>>;
    /**
     * Delete a subscription by ID
     */
    deleteById(id: string): Promise<RecoverySkyResult<notification_subscription | null>>;
    /**
     * Replace the schedule set for a subscription (delete-then-insert), atomically.
     * Runs in a transaction so a bad schedule_ids array (e.g. a duplicate,
     * which violates the composite PK) rolls back the delete too, instead of
     * leaving the subscription with zero times. Returns the number inserted.
     */
    replaceTimes(subscription_id: string, schedule_ids: string[]): Promise<RecoverySkyResult<number>>;
    /**
     * Find all subscription-time rows for a set of schedule IDs
     */
    findTimesByScheduleIds(schedule_ids: string[]): Promise<RecoverySkyResult<notification_subscription_time[]>>;
    /**
     * Find all subscription-time rows for a subscription
     */
    findTimesBySubscriptionId(subscription_id: string): Promise<RecoverySkyResult<notification_subscription_time[]>>;
}
