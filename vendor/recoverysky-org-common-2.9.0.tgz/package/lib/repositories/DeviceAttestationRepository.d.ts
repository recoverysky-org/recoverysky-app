/**
 * DeviceAttestationRepository — the App Attest key currently bound to a deviceId.
 *
 * POST /attest signs a client-chosen deviceId into the device JWT. App Attest
 * proves "a genuine instance of this app on real Apple hardware", not "this
 * deviceId". This table stores the public key and assertion counter that let
 * POST /attest/assert verify later, cheap re-authentications without a fresh
 * Apple round trip.
 *
 * CHANGED 2026-09-09: `claim()` (first-writer-wins, conflict outcome) became
 * `bind()` (unconditional upsert). A valid full attestation always wins:
 * a reinstall legitimately shows up with a new key, and attestation already
 * proves genuine app + genuine hardware. Callers log `changed` swaps.
 *
 * @example
 * import { DeviceAttestationRepository } from '@recoverysky-org/common';
 *
 * const repo = new DeviceAttestationRepository(db);
 * const res = await repo.bind(deviceId, 'ios', keyId, publicKeyPem, Date.now());
 * if (res.ok && res.value.changed) {
 *   // A different key previously owned this deviceId — log it.
 * }
 */
import type { DrizzleDatabase } from "../types/database.js";
import { device_attestation } from "../models/device_attestation.js";
import { type RecoverySkyResult } from "../errors/results.js";
export interface BindOutcome {
    /** True when the row existed with a different key_id before this call. */
    changed: boolean;
    /** The key_id that was bound before this call, or null for a new row. */
    previousKeyId: string | null;
    row: device_attestation;
}
export declare class DeviceAttestationRepository {
    readonly db: DrizzleDatabase;
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "device_attestations";
        schema: undefined;
        columns: {
            assert_counter: import("drizzle-orm/pg-core").PgColumn<{
                name: "assert_counter";
                tableName: "device_attestations";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            attest_count: import("drizzle-orm/pg-core").PgColumn<{
                name: "attest_count";
                tableName: "device_attestations";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            device_id: import("drizzle-orm/pg-core").PgColumn<{
                name: "device_id";
                tableName: "device_attestations";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            first_seen: import("drizzle-orm/pg-core").PgColumn<{
                name: "first_seen";
                tableName: "device_attestations";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            key_id: import("drizzle-orm/pg-core").PgColumn<{
                name: "key_id";
                tableName: "device_attestations";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            last_seen: import("drizzle-orm/pg-core").PgColumn<{
                name: "last_seen";
                tableName: "device_attestations";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            platform: import("drizzle-orm/pg-core").PgColumn<{
                name: "platform";
                tableName: "device_attestations";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            public_key: import("drizzle-orm/pg-core").PgColumn<{
                name: "public_key";
                tableName: "device_attestations";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Record a successful full attestation, rebinding unconditionally.
     *
     * Two statements, not one: the read tells the caller whether the key
     * changed, which the single upsert cannot report. The row's final state is
     * always correct under a race — the upsert is atomic, so whichever bind
     * commits last owns the row, exactly as it would have sequentially.
     *
     * CHANGED 2026-09-09: `changed` / `previousKeyId` are a different story —
     * this is read-then-upsert, not read-then-upsert-atomically, so two
     * concurrent binds for the same deviceId with different keys can both read
     * the same `previousKeyId` before either writes. The loser can then return
     * `changed: false, previousKeyId: null` despite having just overwritten the
     * other key — under-reporting a rebind that genuinely happened. Accepted:
     * the only casualty is an observability log line (assertions presented
     * with the displaced key are still rejected, because the row holds the
     * winner's key/public key regardless of which bind "saw" the swap); the
     * app single-flights its /attest call, so two full attestations racing for
     * one deviceId is practically nil; and wrapping this in a
     * `SELECT ... FOR UPDATE` transaction would add a lock to the auth hot
     * path to protect a log line that almost never fires.
     *
     * `assert_counter` resets to 0 on every bind: a new key starts a new
     * Apple counter sequence, and re-attesting the same key restarts it too.
     */
    bind(deviceId: string, platform: string, keyId: string, publicKey: string, nowMs: number): Promise<RecoverySkyResult<BindOutcome>>;
    /**
     * Store the counter from an accepted assertion. The caller has already
     * verified that `counter` is strictly greater than the stored value; this
     * just persists it. Returns null when no row is bound to the deviceId.
     */
    recordAssertion(deviceId: string, counter: number, nowMs: number): Promise<RecoverySkyResult<device_attestation | null>>;
    /** One attestation record by the deviceId it binds, or null. */
    findByDeviceId(deviceId: string): Promise<RecoverySkyResult<device_attestation | null>>;
    /**
     * Every device_id a key has claimed. One key across several ids is the
     * signature of a client minting new ids to evade the binding — worth
     * alerting on. A genuine reinstall produces a NEW key, not a reused one.
     */
    findByKeyId(keyId: string): Promise<RecoverySkyResult<device_attestation[]>>;
}
