/**
 * SystemPromptRepository - Data access layer for system_prompts table
 *
 * Provides operations for versioned system prompts with variable templating.
 * Only one prompt per name can be active at a time (enforced by unique index).
 *
 * ## Hybrid API Design
 *
 * 1. **Named Methods** (for common operations):
 *    - `findById()`, `findByName()`, `findActive()`, `setActive()`
 *
 * 2. **Generic search()** (for custom queries):
 *    - Pass any Drizzle query function
 *    - Automatic Result<T, E> wrapping
 *
 * @example
 * // Get the active prompt for a name
 * const result = await repo.findActive('recovery-agent');
 * if (result.ok && result.value) {
 *   console.log('Active prompt:', result.value.content);
 * }
 *
 * @example
 * // Custom query using repo.table
 * import { like } from 'drizzle-orm';
 *
 * const result = await repo.search(db =>
 *   db.select()
 *     .from(repo.table)
 *     .where(like(repo.table.name, 'recovery-%'))
 * );
 */
import type { DrizzleDatabase } from "../types/database.js";
import { system_prompt } from "../models/system_prompt.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class SystemPromptRepository {
    /**
     * Drizzle database instance - exposed for custom queries
     */
    readonly db: DrizzleDatabase;
    /**
     * Drizzle table schema - provides type-safe column access
     *
     * @example
     * import { eq } from 'drizzle-orm';
     *
     * const result = await repo.search(db =>
     *   db.select()
     *     .from(repo.table)
     *     .where(eq(repo.table.active, true))
     * );
     */
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "system_prompts";
        schema: undefined;
        columns: {
            active: import("drizzle-orm/pg-core").PgColumn<{
                name: "active";
                tableName: "system_prompts";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            content: import("drizzle-orm/pg-core").PgColumn<{
                name: "content";
                tableName: "system_prompts";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            created: import("drizzle-orm/pg-core").PgColumn<{
                name: "created";
                tableName: "system_prompts";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "system_prompts";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            name: import("drizzle-orm/pg-core").PgColumn<{
                name: "name";
                tableName: "system_prompts";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            updated: import("drizzle-orm/pg-core").PgColumn<{
                name: "updated";
                tableName: "system_prompts";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            variables: import("drizzle-orm/pg-core").PgColumn<{
                name: "variables";
                tableName: "system_prompts";
                dataType: "json";
                columnType: "PgJsonb";
                data: unknown;
                driverParam: unknown;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Execute custom query with Result<T, E> error handling
     *
     * @param queryFn Function that receives db and returns Promise<T>
     * @param operation Optional operation name for error context
     * @returns Result<T> with automatic error wrapping
     *
     * @example
     * import { like, desc } from 'drizzle-orm';
     *
     * const result = await repo.search(db =>
     *   db.select()
     *     .from(repo.table)
     *     .where(like(repo.table.name, 'agent-%'))
     *     .orderBy(desc(repo.table.created))
     * );
     */
    search<T>(queryFn: (db: DrizzleDatabase) => Promise<T>, operation?: string): Promise<RecoverySkyResult<T>>;
    /**
     * Find system prompt by ID
     *
     * @example
     * const result = await repo.findById('prompt-123');
     */
    findById(id: string): Promise<RecoverySkyResult<system_prompt | null>>;
    /**
     * Find all prompts with a given name (all versions)
     *
     * @example
     * const result = await repo.findByName('recovery-agent');
     * if (result.ok) {
     *   console.log(`Found ${result.value.length} versions`);
     * }
     */
    findByName(name: string): Promise<RecoverySkyResult<system_prompt[]>>;
    /**
     * Find the active prompt for a given name
     *
     * Only one prompt per name can be active at a time.
     *
     * @example
     * const result = await repo.findActive('recovery-agent');
     * if (result.ok && result.value) {
     *   const content = result.value.content;
     *   // Use the prompt content
     * }
     */
    findActive(name: string): Promise<RecoverySkyResult<system_prompt | null>>;
    /**
     * Find all active prompts (one per name)
     *
     * @example
     * const result = await repo.findAllActive();
     */
    findAllActive(): Promise<RecoverySkyResult<system_prompt[]>>;
    /**
     * Set a prompt as active (deactivates other prompts with same name)
     *
     * Uses a transaction to ensure atomicity:
     * 1. Deactivate all prompts with the same name
     * 2. Activate the specified prompt
     *
     * @example
     * const result = await repo.setActive('prompt-123');
     * if (result.ok) {
     *   console.log('Prompt activated');
     * }
     */
    setActive(id: string): Promise<RecoverySkyResult<system_prompt>>;
    /**
     * Insert a new system prompt
     *
     * @example
     * const prompt = new system_prompt();
     * prompt.id = 'prompt-123';
     * prompt.name = 'recovery-agent';
     * prompt.content = 'You are a helpful assistant...';
     * prompt.active = false;
     *
     * const result = await repo.insert(prompt);
     */
    insert(data: system_prompt): Promise<RecoverySkyResult<system_prompt>>;
    /**
     * Bulk insert multiple system prompts
     *
     * @example
     * const result = await repo.bulkInsert([prompt1, prompt2]);
     */
    bulkInsert(data: system_prompt[]): Promise<RecoverySkyResult<system_prompt[]>>;
    /**
     * Update a system prompt by ID
     *
     * @example
     * const result = await repo.update('prompt-123', {
     *   content: 'Updated prompt content...',
     *   variables: { model: 'gpt-4' }
     * });
     */
    update(id: string, changes: Partial<system_prompt>): Promise<RecoverySkyResult<system_prompt | null>>;
    /**
     * Delete a system prompt by ID
     *
     * @example
     * const result = await repo.delete('prompt-123');
     * if (result.ok && result.value) {
     *   console.log('Deleted prompt:', result.value.name);
     * }
     */
    delete(id: string): Promise<RecoverySkyResult<system_prompt | null>>;
    /**
     * Upsert a system prompt (insert or update on conflict)
     *
     * @example
     * const result = await repo.upsert(prompt);
     */
    upsert(data: system_prompt): Promise<RecoverySkyResult<system_prompt>>;
}
