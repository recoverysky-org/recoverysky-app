/**
 * AttendanceReportRepository - Data access layer for attendance_reports table
 *
 * Stores report metadata for generated attendance reports. Each report
 * references many attendance records via attendance.arid = report.id.
 *
 * @example
 * import { AttendanceReportRepository } from '@recoverysky-org/common';
 * import { drizzle } from 'drizzle-orm/node-postgres';
 *
 * const db = drizzle(pool);
 * const repo = new AttendanceReportRepository(db);
 *
 * const result = await repo.findById('report-id');
 * if (result.ok && result.value) {
 *   console.log('Report:', result.value.email);
 * }
 */
import type { DrizzleDatabase } from "../types/database.js";
import { attendance_report } from "../models/attendance_report.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class AttendanceReportRepository {
    readonly db: DrizzleDatabase;
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "attendance_reports";
        schema: undefined;
        columns: {
            confirmation: import("drizzle-orm/pg-core").PgColumn<{
                name: "confirmation";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            confirmed: import("drizzle-orm/pg-core").PgColumn<{
                name: "confirmed";
                tableName: "attendance_reports";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            credit: import("drizzle-orm/pg-core").PgColumn<{
                name: "credit";
                tableName: "attendance_reports";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            deleted: import("drizzle-orm/pg-core").PgColumn<{
                name: "deleted";
                tableName: "attendance_reports";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            email: import("drizzle-orm/pg-core").PgColumn<{
                name: "email";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            error: import("drizzle-orm/pg-core").PgColumn<{
                name: "error";
                tableName: "attendance_reports";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            fid: import("drizzle-orm/pg-core").PgColumn<{
                name: "fid";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            generated: import("drizzle-orm/pg-core").PgColumn<{
                name: "generated";
                tableName: "attendance_reports";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            html: import("drizzle-orm/pg-core").PgColumn<{
                name: "html";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            iid: import("drizzle-orm/pg-core").PgColumn<{
                name: "iid";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            messageId: import("drizzle-orm/pg-core").PgColumn<{
                name: "messageId";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            name: import("drizzle-orm/pg-core").PgColumn<{
                name: "name";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            retry: import("drizzle-orm/pg-core").PgColumn<{
                name: "retry";
                tableName: "attendance_reports";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            text: import("drizzle-orm/pg-core").PgColumn<{
                name: "text";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            timezone: import("drizzle-orm/pg-core").PgColumn<{
                name: "timezone";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            uid: import("drizzle-orm/pg-core").PgColumn<{
                name: "uid";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            updated: import("drizzle-orm/pg-core").PgColumn<{
                name: "updated";
                tableName: "attendance_reports";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            userEmail: import("drizzle-orm/pg-core").PgColumn<{
                name: "userEmail";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            userIdNum: import("drizzle-orm/pg-core").PgColumn<{
                name: "userIdNum";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Find report by ID
     */
    findById(id: string): Promise<RecoverySkyResult<attendance_report | null>>;
    /**
     * Find all reports for a user, ordered by most recent first
     */
    findByUserId(uid: string): Promise<RecoverySkyResult<attendance_report[]>>;
    /**
     * Find unconfirmed, non-errored reports (candidates for email send/retry)
     */
    findUnconfirmed(limit?: number): Promise<RecoverySkyResult<attendance_report[]>>;
    /**
     * Find report by Postmark MessageID
     */
    findByMessageId(messageId: string): Promise<RecoverySkyResult<attendance_report | null>>;
    /**
     * Insert a new attendance report
     */
    create(data: attendance_report): Promise<RecoverySkyResult<attendance_report>>;
    /**
     * Upsert multiple attendance report records (last-write-wins on `updated`)
     */
    upsertMany(records: attendance_report[]): Promise<RecoverySkyResult<attendance_report[]>>;
    /**
     * Find records for a user changed strictly after `since`, ordered ascending
     */
    findChangedSince(uid: string, since: number, limit: number): Promise<RecoverySkyResult<attendance_report[]>>;
    /**
     * Update a report by ID
     */
    update(id: string, changes: Partial<attendance_report>): Promise<RecoverySkyResult<attendance_report | null>>;
    /**
     * Mark report as confirmed with mail provider confirmation ID
     */
    markConfirmed(id: string, confirmation: string, html: string, text: string): Promise<RecoverySkyResult<void>>;
    /**
     * Mark report as errored with error detail in confirmation field
     */
    markError(id: string, errorDetail: string): Promise<RecoverySkyResult<void>>;
    /**
     * Increment retry counter. Returns the new retry count.
     */
    incrementRetry(id: string): Promise<RecoverySkyResult<number>>;
    /**
     * Delete a report by ID
     */
    delete(id: string): Promise<RecoverySkyResult<attendance_report | null>>;
    /**
     * Execute custom query with Result wrapper
     */
    search<T>(queryFn: (db: DrizzleDatabase) => Promise<T>, operation?: string): Promise<RecoverySkyResult<T>>;
}
