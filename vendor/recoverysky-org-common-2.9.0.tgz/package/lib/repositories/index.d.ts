/**
 * Repository Layer - Data Access Objects
 *
 * Provides efficient bulk operations for PostgreSQL via Drizzle ORM:
 * - Bulk insert (single query for multiple rows)
 * - Bulk upsert (insert or update on conflict)
 * - Batch updates (transaction-based atomic updates)
 * - Batch status updates (single UPDATE with WHERE IN)
 * - Find operations (by ID, IDs, status, etc.)
 *
 * All methods return Result<T, E> for type-safe error handling.
 * Database triggers automatically handle audit logging.
 *
 * @example
 * import { MeetingRepository } from '@recoverysky-org/common';
 * import postgres from 'postgres';
 * import { drizzle } from 'drizzle-orm/postgres-js';
 *
 * const client = postgres(connectionString);
 * const db = drizzle(client);
 * const meetingRepo = new MeetingRepository(db);
 *
 * // Bulk insert
 * const result = await meetingRepo.bulkInsert(meetings);
 *
 * // Batch status update
 * const updated = await meetingRepo.batchStatusUpdate(
 *   ['id1', 'id2'],
 *   MeetingStatus.MISSING
 * );
 */
export { AttendanceReportRepository } from './AttendanceReportRepository.js';
export { AttendanceRepository } from './AttendanceRepository.js';
export { AuthKeysRepository } from './AuthKeysRepository.js';
export { AuthKeysAccessRepository } from './AuthKeysAccessRepository.js';
export { DeviceAttestationRepository, type BindOutcome } from './DeviceAttestationRepository.js';
export { MeetingRepository } from './MeetingRepository.js';
export { MeetingVerificationRepository } from './MeetingVerificationRepository.js';
export { NewsRepository } from './NewsRepository.js';
export { ScheduleRepository } from './ScheduleRepository.js';
export { SystemPromptRepository } from './SystemPromptRepository.js';
export { TrexRepository } from './TrexRepository.js';
export { UserProfileRepository } from './UserProfileRepository.js';
export { ReminderRepository } from './ReminderRepository.js';
export { ScheduledReminderRepository } from './ScheduledReminderRepository.js';
export { PushTokenRepository } from './PushTokenRepository.js';
export { NotificationScheduleRepository } from './NotificationScheduleRepository.js';
export { NotificationSubscriptionRepository } from './NotificationSubscriptionRepository.js';
export { NotificationDeliveryRepository } from './NotificationDeliveryRepository.js';
export { NotificationTypeRepository } from './NotificationTypeRepository.js';
export { NotificationSlotRepository } from './NotificationSlotRepository.js';
export { NotificationPoolRepository } from './NotificationPoolRepository.js';
export { UnsubscribeRepository, type UnsubscribeInput } from './UnsubscribeRepository.js';
