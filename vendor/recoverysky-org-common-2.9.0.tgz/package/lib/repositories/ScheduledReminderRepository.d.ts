/**
 * ScheduledReminderRepository - Data access layer for scheduled_reminders table (PostgreSQL)
 *
 * Stores individual push notification instances for reminders.
 * Each record represents a single OneSignal notification to be sent
 * for a specific occurrence of a recurring meeting.
 *
 * @example
 * import { ScheduledReminderRepository } from '@recoverysky-org/common';
 * import { drizzle } from 'drizzle-orm/node-postgres';
 *
 * const db = drizzle(pool);
 * const repo = new ScheduledReminderRepository(db);
 *
 * const result = await repo.findPending();
 * if (result.ok) {
 *   console.log('Pending notifications:', result.value.length);
 * }
 */
import type { DrizzleDatabase } from "../types/database.js";
import { scheduled_reminder } from "../models/scheduled_reminder.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class ScheduledReminderRepository {
    readonly db: DrizzleDatabase;
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "scheduled_reminders";
        schema: undefined;
        columns: {
            created: import("drizzle-orm/pg-core").PgColumn<{
                name: "created";
                tableName: "scheduled_reminders";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "scheduled_reminders";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            occurrence_id: import("drizzle-orm/pg-core").PgColumn<{
                name: "occurrence_id";
                tableName: "scheduled_reminders";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            onesignal_id: import("drizzle-orm/pg-core").PgColumn<{
                name: "onesignal_id";
                tableName: "scheduled_reminders";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            reminder_id: import("drizzle-orm/pg-core").PgColumn<{
                name: "reminder_id";
                tableName: "scheduled_reminders";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            send_at_utc: import("drizzle-orm/pg-core").PgColumn<{
                name: "send_at_utc";
                tableName: "scheduled_reminders";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            status: import("drizzle-orm/pg-core").PgColumn<{
                name: "status";
                tableName: "scheduled_reminders";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Find by ID
     */
    findById(id: string): Promise<RecoverySkyResult<scheduled_reminder | null>>;
    /**
     * Find all scheduled reminders for a reminder
     */
    findByReminderId(reminderId: string): Promise<RecoverySkyResult<scheduled_reminder[]>>;
    /**
     * Find all pending reminders ready to send (send_at_utc <= now)
     */
    findPending(nowUtcMillis?: number): Promise<RecoverySkyResult<scheduled_reminder[]>>;
    /**
     * Find by status
     */
    findByStatus(status: string): Promise<RecoverySkyResult<scheduled_reminder[]>>;
    /**
     * Insert a single scheduled reminder (idempotent via UNIQUE constraint).
     * Uses ON CONFLICT (reminder_id, occurrence_id) DO NOTHING.
     * Returns the row if inserted, null if it already existed.
     */
    create(data: scheduled_reminder): Promise<RecoverySkyResult<scheduled_reminder | null>>;
    /**
     * Insert multiple scheduled reminders (idempotent via UNIQUE constraint).
     * Uses ON CONFLICT (reminder_id, occurrence_id) DO NOTHING.
     * Returns only the newly inserted rows (duplicates silently skipped).
     */
    createMany(records: scheduled_reminder[]): Promise<RecoverySkyResult<scheduled_reminder[]>>;
    /**
     * Update status and optionally set onesignal_id
     */
    updateStatus(id: string, status: string, onesignalId?: string): Promise<RecoverySkyResult<scheduled_reminder | null>>;
    /**
     * Batch update status for multiple IDs
     */
    batchUpdateStatus(ids: string[], status: string): Promise<RecoverySkyResult<void>>;
    /**
     * Delete by ID
     */
    delete(id: string): Promise<RecoverySkyResult<scheduled_reminder | null>>;
    /**
     * Delete all scheduled reminders for a reminder
     */
    deleteByReminderId(reminderId: string): Promise<RecoverySkyResult<void>>;
    /**
     * Execute custom query with Result wrapper
     */
    search<T>(queryFn: (db: DrizzleDatabase) => Promise<T>, operation?: string): Promise<RecoverySkyResult<T>>;
}
