/**
 * Test Helpers for Repository Integration Tests
 *
 * Provides utilities for:
 * - Database connection setup
 * - Test data generation
 * - Cleanup after tests
 */
import { PostgresJsDatabase } from "drizzle-orm/postgres-js";
import { meeting } from "../../models/meeting.js";
import { schedule } from "../../models/schedule.js";
import { trex } from "../../models/trex.js";
/**
 * Database connection configuration for tests
 * Uses .env.local with DB_* variables (or TEST_DB_* as fallback for backward compatibility)
 */
export declare function getTestDbConfig(): {
    host: string;
    port: number;
    user: string;
    password: string;
    database: string;
    ssl: boolean | {
        rejectUnauthorized: boolean;
    };
};
/**
 * Create a test database connection
 */
export declare function createTestDb(): PostgresJsDatabase;
/**
 * Check if integration tests should be skipped
 */
export declare function shouldSkipIntegrationTests(): boolean;
/**
 * Check if test data should be kept after tests
 */
export declare function shouldKeepTestData(): boolean;
/**
 * Generate a unique test ID with prefix
 */
export declare function generateTestId(prefix: string): string;
/**
 * Shared parent schedule for test meetings.
 *
 * meetings.sid → schedules.id is FK-enforced (meetings_fk.sql), so every
 * test meeting needs a real schedule row. Tests that don't care about
 * schedules share this one; call ensureTestSchedule(db) in beforeAll.
 */
export declare const TEST_SCHEDULE_ID = "test-schedule-shared-fk-parent";
/**
 * Idempotently insert the shared parent schedule (safe to call from
 * multiple test files; concurrent-safe via ON CONFLICT DO NOTHING).
 * Deliberately never deleted — schedules CASCADE-delete their meetings.
 */
export declare function ensureTestSchedule(db: PostgresJsDatabase): Promise<void>;
/**
 * Create a test meeting with required fields
 */
export declare function createTestMeeting(overrides?: Partial<meeting>): meeting;
/**
 * Create multiple test meetings
 */
export declare function createTestMeetings(count: number): meeting[];
/**
 * Create a test schedule with required fields
 */
export declare function createTestSchedule(overrides?: Partial<schedule>): schedule;
/**
 * Create multiple test schedules
 */
export declare function createTestSchedules(count: number): schedule[];
/**
 * Create a test TREX event with required fields (aligned with TREXJSON)
 */
export declare function createTestTrex(overrides?: Partial<trex>): trex;
/**
 * Create multiple test TREX events
 */
export declare function createTestTrexes(count: number): trex[];
/**
 * Cleanup utility to track and delete test records
 */
export declare class TestCleanup {
    private meetingIds;
    private sids;
    private tids;
    trackMeeting(id: string): void;
    trackMeetings(ids: string[]): void;
    trackSchedule(id: string): void;
    trackSchedules(ids: string[]): void;
    trackTrex(id: string): void;
    trackTrexes(ids: string[]): void;
    getMeetingIds(): string[];
    getScheduleIds(): string[];
    getTrexIds(): string[];
    clear(): void;
}
