/**
 * AuthKeysAccessRepository - Data access layer for auth_keys_access table
 *
 * Provides operations for authentication key access logging.
 */
import type { DrizzleDatabase } from "../types/database.js";
import { auth_keys_access } from "../models/auth_keys_access.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class AuthKeysAccessRepository {
    readonly db: DrizzleDatabase;
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "auth_keys_access";
        schema: undefined;
        columns: {
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "auth_keys_access";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            ip: import("drizzle-orm/pg-core").PgColumn<{
                name: "ip";
                tableName: "auth_keys_access";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            timestamp: import("drizzle-orm/pg-core").PgColumn<{
                name: "timestamp";
                tableName: "auth_keys_access";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            uuid: import("drizzle-orm/pg-core").PgColumn<{
                name: "uuid";
                tableName: "auth_keys_access";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Find access log by ID
     */
    findById(id: string): Promise<RecoverySkyResult<auth_keys_access | null>>;
    /**
     * Find recent access logs by IP
     */
    findByIp(ip: string, limit?: number): Promise<RecoverySkyResult<auth_keys_access[]>>;
    /**
     * Insert a new access log
     */
    insert(data: auth_keys_access): Promise<RecoverySkyResult<auth_keys_access>>;
    /**
     * Delete an access log by ID
     */
    delete(id: string): Promise<RecoverySkyResult<auth_keys_access | null>>;
}
