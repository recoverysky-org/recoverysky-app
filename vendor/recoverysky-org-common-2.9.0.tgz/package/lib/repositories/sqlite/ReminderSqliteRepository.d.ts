/**
 * ReminderSqliteRepository - SQLite data access layer for user meeting reminders
 *
 * Stores user reminders for upcoming meetings with timezone-aware scheduling.
 *
 * @example
 * import { drizzle } from 'drizzle-orm/expo-sqlite';
 * import { openDatabaseSync } from 'expo-sqlite';
 * import { ReminderSqliteRepository } from '@recoverysky-org/common/sqlite';
 *
 * const expoDb = openDatabaseSync('recoverysky.db');
 * const db = drizzle(expoDb);
 * const repo = new ReminderSqliteRepository(db);
 *
 * const result = await repo.findByUserId('user-123');
 */
import type { DrizzleSqliteDatabase } from "../../types/database.js";
import { type RecoverySkyResult } from "../../errors/results.js";
/**
 * Reminder record with proper boolean types
 */
export interface ReminderRecord {
    id: string;
    uid: string;
    sid: string | null;
    mid: string | null;
    scope: string;
    dow: number;
    time: number;
    name: string;
    timezone: string;
    minutes_before: number;
    at_start: boolean;
    enabled: boolean;
    created: number;
    updated: number;
}
/**
 * Input for creating a reminder
 */
export interface ReminderCreateInput {
    id?: string;
    uid: string;
    sid?: string;
    mid?: string;
    scope?: string;
    dow?: number;
    time?: number;
    name?: string;
    timezone: string;
    minutes_before?: number;
    at_start?: boolean;
    enabled?: boolean;
}
/**
 * Input for updating a reminder
 */
export interface ReminderUpdateInput {
    sid?: string;
    mid?: string;
    scope?: string;
    dow?: number;
    time?: number;
    name?: string;
    timezone?: string;
    minutes_before?: number;
    at_start?: boolean;
    enabled?: boolean;
}
export declare class ReminderSqliteRepository {
    readonly db: DrizzleSqliteDatabase;
    readonly table: import("drizzle-orm/sqlite-core").SQLiteTableWithColumns<{
        name: "reminders";
        schema: undefined;
        columns: {
            at_start: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "at_start";
                tableName: "reminders";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            created: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "created";
                tableName: "reminders";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            did: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "did";
                tableName: "reminders";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            dow: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "dow";
                tableName: "reminders";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            enabled: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "enabled";
                tableName: "reminders";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "id";
                tableName: "reminders";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            mid: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "mid";
                tableName: "reminders";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            minutes_before: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "minutes_before";
                tableName: "reminders";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            name: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "name";
                tableName: "reminders";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            scope: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "scope";
                tableName: "reminders";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            sid: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "sid";
                tableName: "reminders";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            time: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "time";
                tableName: "reminders";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            timezone: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "timezone";
                tableName: "reminders";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            uid: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "uid";
                tableName: "reminders";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            updated: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "updated";
                tableName: "reminders";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "sqlite";
    }>;
    constructor(db: DrizzleSqliteDatabase);
    /**
     * Execute query with Result<T, E> error handling
     */
    private execute;
    /**
     * Convert database row to ReminderRecord
     */
    private toRecord;
    /**
     * Find reminder by ID
     */
    findById(id: string): Promise<RecoverySkyResult<ReminderRecord | null>>;
    /**
     * Find all reminders for a user
     */
    findByUserId(uid: string): Promise<RecoverySkyResult<ReminderRecord[]>>;
    /**
     * Find all reminders for a meeting
     */
    findByMeetingId(mid: string): Promise<RecoverySkyResult<ReminderRecord[]>>;
    /**
     * Find a user's reminder for a specific meeting
     */
    findByUserAndMeeting(uid: string, mid: string): Promise<RecoverySkyResult<ReminderRecord | null>>;
    /**
     * Find all enabled reminders for a user
     */
    findEnabledByUserId(uid: string): Promise<RecoverySkyResult<ReminderRecord[]>>;
    /**
     * Create a reminder
     */
    create(input: ReminderCreateInput): Promise<RecoverySkyResult<string>>;
    /**
     * Update a reminder by ID
     */
    update(id: string, input: ReminderUpdateInput): Promise<RecoverySkyResult<void>>;
    /**
     * Toggle enabled status for a reminder
     */
    toggleEnabled(id: string): Promise<RecoverySkyResult<boolean>>;
    /**
     * Delete a reminder by ID
     */
    delete(id: string): Promise<RecoverySkyResult<void>>;
    /**
     * Delete all reminders for a user
     */
    deleteByUserId(uid: string): Promise<RecoverySkyResult<void>>;
    /**
     * Execute custom query with Result wrapper
     */
    search<T>(queryFn: (db: DrizzleSqliteDatabase) => Promise<T>, operation?: string): Promise<RecoverySkyResult<T>>;
}
