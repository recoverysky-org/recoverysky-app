/**
 * ScheduleSqliteRepository - SQLite data access layer for schedules
 *
 * Handles normalized junction table for schedule -> meeting relationship (mids).
 * The zids field remains as JSON TEXT (not normalized).
 *
 * @example
 * import { drizzle } from 'drizzle-orm/expo-sqlite';
 * import { openDatabaseSync } from 'expo-sqlite';
 * import { ScheduleSqliteRepository } from '@recoverysky-org/common/sqlite';
 *
 * const expoDb = openDatabaseSync('recoverysky.db');
 * const db = drizzle(expoDb);
 * const repo = new ScheduleSqliteRepository(db);
 */
import type { DrizzleSqliteDatabase } from "../../types/database.js";
import { schedules } from "../../models/drizzle/sqlite/schedules.drizzle.js";
import type { schedule } from "../../models/schedule.js";
import { type RecoverySkyResult } from "../../errors/results.js";
/**
 * Schedule with resolved junction table arrays
 */
export interface ScheduleWithRelations {
    /** Core schedule data */
    schedule: typeof schedules.$inferSelect;
    /** Meeting IDs from junction table */
    meetingIds: string[];
    /** Zone IDs (JSON parsed from zids TEXT field) */
    zoneIds: string[];
}
/**
 * Input for creating a new schedule
 */
export interface ScheduleCreateInput extends Omit<schedule, "id" | "created" | "updated" | "mids" | "zids"> {
    id?: string;
    mids?: string[];
    zids?: string[];
}
/**
 * Input for updating a schedule
 */
export interface ScheduleUpdateInput extends Partial<Omit<schedule, "id" | "created" | "mids" | "zids">> {
    mids?: string[];
    zids?: string[];
}
export declare class ScheduleSqliteRepository {
    readonly db: DrizzleSqliteDatabase;
    readonly table: import("drizzle-orm/sqlite-core").SQLiteTableWithColumns<{
        name: "schedules";
        schema: undefined;
        columns: {
            created: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "created";
                tableName: "schedules";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            fellowship: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "fellowship";
                tableName: "schedules";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            id: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "id";
                tableName: "schedules";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            json: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "json";
                tableName: "schedules";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            minutes: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "minutes";
                tableName: "schedules";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            name: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "name";
                tableName: "schedules";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            sha256: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "sha256";
                tableName: "schedules";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            status: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "status";
                tableName: "schedules";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            updated: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "updated";
                tableName: "schedules";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            version: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "version";
                tableName: "schedules";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            zids: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "zids";
                tableName: "schedules";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
        };
        dialect: "sqlite";
    }>;
    readonly meetingsTable: import("drizzle-orm/sqlite-core").SQLiteTableWithColumns<{
        name: "schedule_meetings";
        schema: undefined;
        columns: {
            scheduleId: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "schedule_id";
                tableName: "schedule_meetings";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            meetingId: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "meeting_id";
                tableName: "schedule_meetings";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
        };
        dialect: "sqlite";
    }>;
    constructor(db: DrizzleSqliteDatabase);
    /**
     * Execute query with Result<T, E> error handling
     */
    private execute;
    /**
     * Parse zids JSON string to array
     */
    private parseZids;
    /**
     * Find schedule by ID with meeting IDs and zone IDs
     */
    findById(id: string): Promise<RecoverySkyResult<ScheduleWithRelations | null>>;
    /**
     * Find all schedules with relations
     */
    findAll(): Promise<RecoverySkyResult<ScheduleWithRelations[]>>;
    /**
     * Find schedules by fellowship
     */
    findByFellowship(fellowship: string): Promise<RecoverySkyResult<ScheduleWithRelations[]>>;
    /**
     * Create a new schedule with meeting relationships
     */
    create(input: ScheduleCreateInput): Promise<RecoverySkyResult<string>>;
    /**
     * Update a schedule and its meeting relationships
     */
    update(id: string, input: ScheduleUpdateInput): Promise<RecoverySkyResult<void>>;
    /**
     * Delete a schedule (cascade deletes meeting relationships via FK)
     */
    delete(id: string): Promise<RecoverySkyResult<void>>;
    /**
     * Add meetings to a schedule
     */
    addMeetings(scheduleId: string, meetingIds: string[]): Promise<RecoverySkyResult<void>>;
    /**
     * Remove meetings from a schedule
     */
    removeMeetings(scheduleId: string, meetingIds: string[]): Promise<RecoverySkyResult<void>>;
    /**
     * Execute custom query with Result wrapper
     */
    search<T>(queryFn: (db: DrizzleSqliteDatabase) => Promise<T>, operation?: string): Promise<RecoverySkyResult<T>>;
}
