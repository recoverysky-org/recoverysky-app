/**
 * ZoomAuthSqliteRepository - SQLite data access layer for Zoom OAuth tokens
 *
 * Stores encrypted OAuth tokens for Zoom account authentication.
 * Primary key is device ID - one Zoom account per device.
 *
 * Tokens are encrypted at the database level via SQLCipher.
 *
 * @example
 * import { drizzle } from 'drizzle-orm/expo-sqlite';
 * import { openDatabaseSync } from 'expo-sqlite';
 * import { ZoomAuthSqliteRepository } from '@recoverysky-org/common/sqlite';
 *
 * const expoDb = openDatabaseSync('recoverysky.db');
 * const db = drizzle(expoDb);
 * const repo = new ZoomAuthSqliteRepository(db);
 *
 * // Check if Zoom is connected
 * const auth = await repo.findById('device-123');
 */
import type { DrizzleSqliteDatabase } from "../../types/database.js";
import { type RecoverySkyResult } from "../../errors/results.js";
/**
 * Zoom auth record with all fields
 */
export interface ZoomAuthRecord {
    id: string;
    accessToken: string;
    refreshToken: string;
    zoomUserId: string;
    zoomEmail: string;
    zoomDisplayName: string;
    expiresAt: number;
    connectedAt: number;
    updatedAt: number;
}
/**
 * Input for creating Zoom auth record
 */
export interface ZoomAuthCreateInput {
    id: string;
    accessToken: string;
    refreshToken: string;
    zoomUserId: string;
    zoomEmail?: string;
    zoomDisplayName?: string;
    expiresAt: number;
}
/**
 * Input for updating Zoom auth record
 */
export interface ZoomAuthUpdateInput {
    accessToken?: string;
    refreshToken?: string;
    zoomEmail?: string;
    zoomDisplayName?: string;
    expiresAt?: number;
}
export declare class ZoomAuthSqliteRepository {
    readonly db: DrizzleSqliteDatabase;
    readonly table: import("drizzle-orm/sqlite-core").SQLiteTableWithColumns<{
        name: "zoom_auths";
        schema: undefined;
        columns: {
            id: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "id";
                tableName: "zoom_auths";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            accessToken: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "access_token";
                tableName: "zoom_auths";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            refreshToken: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "refresh_token";
                tableName: "zoom_auths";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            zoomUserId: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "zoom_user_id";
                tableName: "zoom_auths";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            zoomEmail: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "zoom_email";
                tableName: "zoom_auths";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            zoomDisplayName: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "zoom_display_name";
                tableName: "zoom_auths";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            expiresAt: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "expires_at";
                tableName: "zoom_auths";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            connectedAt: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "connected_at";
                tableName: "zoom_auths";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            updatedAt: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "updated_at";
                tableName: "zoom_auths";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "sqlite";
    }>;
    constructor(db: DrizzleSqliteDatabase);
    /**
     * Execute query with Result<T, E> error handling
     */
    private execute;
    /**
     * Convert database row to ZoomAuthRecord
     */
    private toRecord;
    /**
     * Find Zoom auth by device ID (primary key)
     */
    findById(id: string): Promise<RecoverySkyResult<ZoomAuthRecord | null>>;
    /**
     * Create new Zoom auth record
     */
    create(input: ZoomAuthCreateInput): Promise<RecoverySkyResult<ZoomAuthRecord>>;
    /**
     * Update existing Zoom auth record
     */
    update(id: string, input: ZoomAuthUpdateInput): Promise<RecoverySkyResult<void>>;
    /**
     * Create or update Zoom auth record (upsert)
     */
    upsert(input: ZoomAuthCreateInput): Promise<RecoverySkyResult<ZoomAuthRecord>>;
    /**
     * Delete Zoom auth record
     */
    delete(id: string): Promise<RecoverySkyResult<void>>;
    /**
     * Check if access token is expired (with 5 minute buffer)
     */
    isExpired(record: ZoomAuthRecord): boolean;
    /**
     * Execute custom query with Result wrapper
     */
    search<T>(queryFn: (db: DrizzleSqliteDatabase) => Promise<T>, operation?: string): Promise<RecoverySkyResult<T>>;
}
