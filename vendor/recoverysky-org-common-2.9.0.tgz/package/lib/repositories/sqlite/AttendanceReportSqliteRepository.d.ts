/**
 * AttendanceReportSqliteRepository - SQLite data access layer for attendance reports
 *
 * Stores report metadata for generated attendance reports. Each report
 * references many attendance records via attendance.arid = report.id.
 *
 * @example
 * import { drizzle } from 'drizzle-orm/expo-sqlite';
 * import { openDatabaseSync } from 'expo-sqlite';
 * import { AttendanceReportSqliteRepository } from '@recoverysky-org/common/sqlite';
 *
 * const expoDb = openDatabaseSync('recoverysky.db');
 * const db = drizzle(expoDb);
 * const repo = new AttendanceReportSqliteRepository(db);
 *
 * // Create a report and link attendances
 * const reportId = await repo.create({ uid: 'user-1', email: 'user@example.com' });
 * await attendanceRepo.markProduced(attendanceId, reportId);
 */
import type { DrizzleSqliteDatabase } from "../../types/database.js";
import { type RecoverySkyResult } from "../../errors/results.js";
/**
 * Attendance report record with all fields
 */
export interface AttendanceReportRecord {
    id: string;
    iid: string;
    uid: string;
    fid: string;
    error: boolean;
    retry: number;
    generated: number;
    confirmed: number;
    confirmation: string;
    messageId: string;
    name: string;
    userEmail: string;
    userIdNum: string;
    timezone: string;
    email: string;
    html: string;
    text: string;
    credit: number;
}
/**
 * Input for creating a new attendance report
 */
export interface AttendanceReportCreateInput {
    id?: string;
    iid?: string;
    uid: string;
    fid?: string;
    name?: string;
    userEmail?: string;
    userIdNum?: string;
    timezone?: string;
    email: string;
    error?: boolean;
    html?: string;
    text?: string;
    generated?: number;
    confirmed?: number;
    confirmation?: string;
    messageId?: string;
    credit?: number;
}
/**
 * Input for updating an attendance report
 */
export interface AttendanceReportUpdateInput {
    iid?: string;
    fid?: string;
    name?: string;
    userEmail?: string;
    userIdNum?: string;
    timezone?: string;
    email?: string;
    error?: boolean;
    retry?: number;
    html?: string;
    text?: string;
    confirmed?: number;
    confirmation?: string;
    messageId?: string;
    credit?: number;
}
export declare class AttendanceReportSqliteRepository {
    readonly db: DrizzleSqliteDatabase;
    readonly table: import("drizzle-orm/sqlite-core").SQLiteTableWithColumns<{
        name: "attendance_reports";
        schema: undefined;
        columns: {
            confirmation: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "confirmation";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            confirmed: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "confirmed";
                tableName: "attendance_reports";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            credit: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "credit";
                tableName: "attendance_reports";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            deleted: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "deleted";
                tableName: "attendance_reports";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            email: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "email";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            error: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "error";
                tableName: "attendance_reports";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            fid: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "fid";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            generated: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "generated";
                tableName: "attendance_reports";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            html: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "html";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            id: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "id";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            iid: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "iid";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            messageId: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "messageId";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            name: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "name";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            retry: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "retry";
                tableName: "attendance_reports";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            text: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "text";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            timezone: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "timezone";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            uid: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "uid";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            updated: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "updated";
                tableName: "attendance_reports";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            userEmail: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "userEmail";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            userIdNum: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "userIdNum";
                tableName: "attendance_reports";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
        };
        dialect: "sqlite";
    }>;
    constructor(db: DrizzleSqliteDatabase);
    /**
     * Execute query with Result<T, E> error handling
     */
    private execute;
    /**
     * Convert database row to AttendanceReportRecord
     */
    private toRecord;
    /**
     * Find report by ID
     */
    findById(id: string): Promise<RecoverySkyResult<AttendanceReportRecord | null>>;
    /**
     * Find all reports for a user
     */
    findByUserId(uid: string): Promise<RecoverySkyResult<AttendanceReportRecord[]>>;
    /**
     * Find all reports
     */
    findAll(): Promise<RecoverySkyResult<AttendanceReportRecord[]>>;
    /**
     * Create a new attendance report
     */
    create(input: AttendanceReportCreateInput): Promise<RecoverySkyResult<string>>;
    /**
     * Update an attendance report
     */
    update(id: string, input: AttendanceReportUpdateInput): Promise<RecoverySkyResult<void>>;
    /**
     * Mark report as confirmed sent with confirmation ID from mail provider
     */
    markConfirmed(id: string, confirmation: string): Promise<RecoverySkyResult<void>>;
    /**
     * Mark report as errored with error details in confirmation field
     */
    markError(id: string, errorDetail: string): Promise<RecoverySkyResult<void>>;
    /**
     * Delete an attendance report
     */
    delete(id: string): Promise<RecoverySkyResult<void>>;
    /**
     * Execute custom query with Result wrapper
     */
    search<T>(queryFn: (db: DrizzleSqliteDatabase) => Promise<T>, operation?: string): Promise<RecoverySkyResult<T>>;
}
