/**
 * FeedbackSqliteRepository - SQLite data access layer for user meeting feedback
 *
 * Tracks user preferences and engagement metrics per meeting.
 * Primary key is `mid` (meeting id) - one feedback record per meeting.
 *
 * @example
 * import { drizzle } from 'drizzle-orm/expo-sqlite';
 * import { openDatabaseSync } from 'expo-sqlite';
 * import { FeedbackSqliteRepository } from '@recoverysky-org/common/sqlite';
 *
 * const expoDb = openDatabaseSync('recoverysky.db');
 * const db = drizzle(expoDb);
 * const repo = new FeedbackSqliteRepository(db);
 *
 * // Get or create feedback for a meeting
 * const result = await repo.findByMid('meeting-123');
 */
import type { DrizzleSqliteDatabase } from "../../types/database.js";
import { type RecoverySkyResult } from "../../errors/results.js";
/**
 * Feedback record with boolean loves field
 */
export interface FeedbackRecord {
    mid: string;
    loves: boolean;
    rates: number;
    joins: number;
    lastJoin: number;
}
/**
 * Input for creating/updating feedback
 */
export interface FeedbackInput {
    mid: string;
    loves?: boolean;
    rates?: number;
    joins?: number;
    lastJoin?: number;
}
export declare class FeedbackSqliteRepository {
    readonly db: DrizzleSqliteDatabase;
    readonly table: import("drizzle-orm/sqlite-core").SQLiteTableWithColumns<{
        name: "feedbacks";
        schema: undefined;
        columns: {
            joins: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "joins";
                tableName: "feedbacks";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            lastJoin: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "lastJoin";
                tableName: "feedbacks";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            loves: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "loves";
                tableName: "feedbacks";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            mid: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "mid";
                tableName: "feedbacks";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            rates: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "rates";
                tableName: "feedbacks";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "sqlite";
    }>;
    constructor(db: DrizzleSqliteDatabase);
    /**
     * Execute query with Result<T, E> error handling
     */
    private execute;
    /**
     * Convert database row to FeedbackRecord
     */
    private toRecord;
    /**
     * Find feedback by meeting ID (primary key)
     */
    findByMid(mid: string): Promise<RecoverySkyResult<FeedbackRecord | null>>;
    /**
     * Find all feedback records
     */
    findAll(): Promise<RecoverySkyResult<FeedbackRecord[]>>;
    /**
     * Find feedback for multiple meetings
     */
    findByMids(mids: string[]): Promise<RecoverySkyResult<FeedbackRecord[]>>;
    /**
     * Find all loved meetings
     */
    findLoved(): Promise<RecoverySkyResult<FeedbackRecord[]>>;
    /**
     * Find meetings with rating >= threshold
     */
    findByMinRating(minRating: number): Promise<RecoverySkyResult<FeedbackRecord[]>>;
    /**
     * Find most recently joined meetings
     */
    findRecentlyJoined(limit?: number): Promise<RecoverySkyResult<FeedbackRecord[]>>;
    /**
     * Create or update feedback (upsert)
     */
    upsert(input: FeedbackInput): Promise<RecoverySkyResult<void>>;
    /**
     * Toggle loves status for a meeting
     */
    toggleLove(mid: string): Promise<RecoverySkyResult<boolean>>;
    /**
     * Set rating for a meeting
     */
    setRating(mid: string, rating: number): Promise<RecoverySkyResult<void>>;
    /**
     * Record a join event (increment joins, update lastJoin)
     */
    recordJoin(mid: string): Promise<RecoverySkyResult<void>>;
    /**
     * Delete feedback for a meeting
     */
    delete(mid: string): Promise<RecoverySkyResult<void>>;
    /**
     * Bulk upsert feedback records
     */
    bulkUpsert(items: FeedbackInput[]): Promise<RecoverySkyResult<void>>;
    /**
     * Execute custom query with Result wrapper
     */
    search<T>(queryFn: (db: DrizzleSqliteDatabase) => Promise<T>, operation?: string): Promise<RecoverySkyResult<T>>;
}
