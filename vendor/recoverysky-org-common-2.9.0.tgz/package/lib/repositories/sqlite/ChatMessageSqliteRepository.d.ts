/**
 * ChatMessageSqliteRepository - SQLite data access for chat message persistence
 *
 * Stores AI agent conversation messages for the single-conversation model.
 * Messages are stored after streaming completes to avoid partial saves.
 * Parts include tool invocations serialized as JSON for conversation continuity.
 *
 * @example
 * import { drizzle } from 'drizzle-orm/expo-sqlite';
 * import { openDatabaseSync } from 'expo-sqlite';
 * import { ChatMessageSqliteRepository } from '@recoverysky-org/common/sqlite';
 *
 * const expoDb = openDatabaseSync('recoverysky.db');
 * const db = drizzle(expoDb);
 * const repo = new ChatMessageSqliteRepository(db);
 *
 * // Load all messages on app start
 * const result = await repo.findAll();
 * if (result.ok) {
 *   setMessages(result.value);
 * }
 */
import type { DrizzleSqliteDatabase } from "../../types/database.js";
import { type RecoverySkyResult } from "../../errors/results.js";
/**
 * Stored chat message record (deserialized from SQLite)
 */
export interface ChatMessageRecord {
    id: string;
    role: "user" | "assistant" | "system";
    /** Parsed JSON array of UIMessagePart */
    parts: unknown[];
    /** Optional metadata object */
    metadata?: unknown;
    createdAt: number;
    updatedAt: number;
}
/**
 * Input for creating a chat message
 */
export interface ChatMessageInput {
    id: string;
    role: "user" | "assistant" | "system";
    /** UIMessagePart[] - will be JSON.stringify'd */
    parts: unknown[];
    /** Optional metadata - will be JSON.stringify'd */
    metadata?: unknown;
}
export declare class ChatMessageSqliteRepository {
    readonly db: DrizzleSqliteDatabase;
    readonly table: import("drizzle-orm/sqlite-core").SQLiteTableWithColumns<{
        name: "chat_messages";
        schema: undefined;
        columns: {
            createdAt: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "createdAt";
                tableName: "chat_messages";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "id";
                tableName: "chat_messages";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            metadata: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "metadata";
                tableName: "chat_messages";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            parts: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "parts";
                tableName: "chat_messages";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            role: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "role";
                tableName: "chat_messages";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            updatedAt: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "updatedAt";
                tableName: "chat_messages";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "sqlite";
    }>;
    constructor(db: DrizzleSqliteDatabase);
    /**
     * Execute query with Result<T, E> error handling
     */
    private execute;
    /**
     * Convert database row to ChatMessageRecord
     */
    private toRecord;
    /**
     * Find all messages ordered by createdAt ascending
     */
    findAll(): Promise<RecoverySkyResult<ChatMessageRecord[]>>;
    /**
     * Find message by ID
     */
    findById(id: string): Promise<RecoverySkyResult<ChatMessageRecord | null>>;
    /**
     * Create a new message
     */
    create(input: ChatMessageInput): Promise<RecoverySkyResult<void>>;
    /**
     * Create multiple messages (bulk insert)
     * Timestamps are staggered to maintain ordering
     */
    createMany(inputs: ChatMessageInput[]): Promise<RecoverySkyResult<void>>;
    /**
     * Clear all messages (delete conversation history)
     */
    clear(): Promise<RecoverySkyResult<void>>;
    /**
     * Delete messages older than a timestamp
     * @returns Number of deleted rows
     */
    deleteOlderThan(timestamp: number): Promise<RecoverySkyResult<number>>;
    /**
     * Delete a specific message by ID
     */
    delete(id: string): Promise<RecoverySkyResult<void>>;
    /**
     * Get message count
     */
    count(): Promise<RecoverySkyResult<number>>;
    /**
     * Execute custom query with Result wrapper
     */
    search<T>(queryFn: (db: DrizzleSqliteDatabase) => Promise<T>, operation?: string): Promise<RecoverySkyResult<T>>;
}
