/**
 * AttendanceSqliteRepository - SQLite data access layer for attendance records
 *
 * Handles JSON serialization for events array and boolean conversion for valid field.
 * Designed for offline-first mobile apps using expo-sqlite or better-sqlite3.
 *
 * @example
 * import { drizzle } from 'drizzle-orm/expo-sqlite';
 * import { openDatabaseSync } from 'expo-sqlite';
 * import { AttendanceSqliteRepository } from '@recoverysky-org/common/sqlite';
 *
 * const expoDb = openDatabaseSync('recoverysky.db');
 * const db = drizzle(expoDb);
 * const repo = new AttendanceSqliteRepository(db);
 *
 * // Find attendance by ID
 * const result = await repo.findById('attendance-123');
 */
import type { DrizzleSqliteDatabase } from "../../types/database.js";
import type { AttendanceEvent } from "../../models/attendance.js";
import { type RecoverySkyResult } from "../../errors/results.js";
/**
 * Attendance with parsed events array
 */
export interface AttendanceRecord {
    id: string;
    iid: string;
    uid: string;
    mid: string;
    zid: string;
    created: number;
    valid: boolean;
    events: AttendanceEvent[];
    uzid: string;
    zpid: string;
    zuid: string;
    meetingHost: string;
    meetingName: string;
    meetingTopic: string;
    archived: boolean;
    processed: number;
    start: number;
    end: number;
    credit: number;
    produced: number;
    arid: string;
}
/**
 * Input for creating a new attendance record
 */
export interface AttendanceCreateInput {
    id?: string;
    iid?: string;
    uid: string;
    mid: string;
    zid: string;
    created?: number;
    valid?: boolean;
    events?: AttendanceEvent[];
    uzid?: string;
    zpid?: string;
    zuid?: string;
    meetingHost?: string;
    meetingName?: string;
    meetingTopic?: string;
    archived?: boolean;
    processed?: number;
    start?: number;
    end?: number;
    credit?: number;
    produced?: number;
    arid?: string;
}
/**
 * Input for updating an attendance record
 */
export interface AttendanceUpdateInput {
    iid?: string;
    valid?: boolean;
    events?: AttendanceEvent[];
    uzid?: string;
    zpid?: string;
    zuid?: string;
    meetingHost?: string;
    meetingName?: string;
    meetingTopic?: string;
    archived?: boolean;
    processed?: number;
    start?: number;
    end?: number;
    credit?: number;
    produced?: number;
    arid?: string;
}
export declare class AttendanceSqliteRepository {
    readonly db: DrizzleSqliteDatabase;
    readonly table: import("drizzle-orm/sqlite-core").SQLiteTableWithColumns<{
        name: "attendances";
        schema: undefined;
        columns: {
            archived: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "archived";
                tableName: "attendances";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            arid: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "arid";
                tableName: "attendances";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            created: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "created";
                tableName: "attendances";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            credit: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "credit";
                tableName: "attendances";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            deleted: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "deleted";
                tableName: "attendances";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            end: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "end";
                tableName: "attendances";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            events: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "events";
                tableName: "attendances";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            id: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "id";
                tableName: "attendances";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            iid: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "iid";
                tableName: "attendances";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            meetingHost: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "meetingHost";
                tableName: "attendances";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            meetingName: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "meetingName";
                tableName: "attendances";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            meetingTopic: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "meetingTopic";
                tableName: "attendances";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            mid: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "mid";
                tableName: "attendances";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            processed: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "processed";
                tableName: "attendances";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            produced: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "produced";
                tableName: "attendances";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            start: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "start";
                tableName: "attendances";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            uid: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "uid";
                tableName: "attendances";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            updated: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "updated";
                tableName: "attendances";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            uzid: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "uzid";
                tableName: "attendances";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            valid: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "valid";
                tableName: "attendances";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            zid: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "zid";
                tableName: "attendances";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            zpid: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "zpid";
                tableName: "attendances";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            zuid: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "zuid";
                tableName: "attendances";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
        };
        dialect: "sqlite";
    }>;
    constructor(db: DrizzleSqliteDatabase);
    /**
     * Execute query with Result<T, E> error handling
     */
    private execute;
    /**
     * Convert database row to AttendanceRecord
     */
    private toRecord;
    /**
     * Find attendance by ID
     */
    findById(id: string): Promise<RecoverySkyResult<AttendanceRecord | null>>;
    /**
     * Find all attendance records
     */
    findAll(): Promise<RecoverySkyResult<AttendanceRecord[]>>;
    /**
     * Find attendance records by user ID
     */
    findByUserId(uid: string): Promise<RecoverySkyResult<AttendanceRecord[]>>;
    /**
     * Find attendance records by meeting ID
     */
    findByMeetingId(mid: string): Promise<RecoverySkyResult<AttendanceRecord[]>>;
    /**
     * Find attendance records by Zoom meeting ID
     */
    findByZoomId(zid: string): Promise<RecoverySkyResult<AttendanceRecord[]>>;
    /**
     * Find attendance records by user and meeting
     */
    findByUserAndMeeting(uid: string, mid: string): Promise<RecoverySkyResult<AttendanceRecord[]>>;
    /**
     * Find attendance records by date range (using created timestamp)
     */
    findByDateRange(startMs: number, endMs: number): Promise<RecoverySkyResult<AttendanceRecord[]>>;
    /**
     * Find valid attendance records for a user
     */
    findValidByUserId(uid: string): Promise<RecoverySkyResult<AttendanceRecord[]>>;
    /**
     * Find unprocessed attendance records
     */
    findUnprocessed(): Promise<RecoverySkyResult<AttendanceRecord[]>>;
    /**
     * Find unproduced attendance records (not yet included in a report, excluding archived)
     */
    findUnproduced(): Promise<RecoverySkyResult<AttendanceRecord[]>>;
    /**
     * Find archived attendance records
     */
    findArchived(): Promise<RecoverySkyResult<AttendanceRecord[]>>;
    /**
     * Mark attendance as archived
     */
    markArchived(id: string): Promise<RecoverySkyResult<void>>;
    /**
     * Find attendance records by report ID
     */
    findByReportId(arid: string): Promise<RecoverySkyResult<AttendanceRecord[]>>;
    /**
     * Find attendance by array of IDs
     */
    findByIds(ids: string[]): Promise<RecoverySkyResult<AttendanceRecord[]>>;
    /**
     * Create a new attendance record
     */
    create(input: AttendanceCreateInput): Promise<RecoverySkyResult<string>>;
    /**
     * Update an attendance record
     */
    update(id: string, input: AttendanceUpdateInput): Promise<RecoverySkyResult<void>>;
    /**
     * Add an event to an attendance record
     */
    addEvent(id: string, event: AttendanceEvent): Promise<RecoverySkyResult<void>>;
    /**
     * Mark attendance as processed with calculated values
     */
    markProcessed(id: string, data: {
        start: number;
        end: number;
        credit: number;
        valid: boolean;
    }): Promise<RecoverySkyResult<void>>;
    /**
     * Mark attendance as produced (included in a report)
     */
    markProduced(id: string, arid: string): Promise<RecoverySkyResult<void>>;
    /**
     * Delete an attendance record
     */
    delete(id: string): Promise<RecoverySkyResult<void>>;
    /**
     * Bulk insert attendance records
     */
    bulkInsert(items: AttendanceCreateInput[]): Promise<RecoverySkyResult<string[]>>;
    /**
     * Get total credit for a user (sum of all valid attendance credits)
     */
    getTotalCreditForUser(uid: string): Promise<RecoverySkyResult<number>>;
    /**
     * Execute custom query with Result wrapper
     */
    search<T>(queryFn: (db: DrizzleSqliteDatabase) => Promise<T>, operation?: string): Promise<RecoverySkyResult<T>>;
}
