/**
 * SyncQueueRepository - Manages offline sync queue for CRUD operations
 *
 * Stores pending create/update/delete operations when offline.
 * Syncs with server when connectivity is restored.
 *
 * @example
 * import { SyncQueueRepository } from '@recoverysky-org/common/sqlite';
 *
 * // Queue an offline operation
 * await repo.enqueue({
 *   tableName: 'meetings',
 *   recordId: 'meeting-123',
 *   operation: 'update',
 *   payload: JSON.stringify({ name: 'Updated Name' }),
 * });
 *
 * // Get pending items to sync
 * const pending = await repo.getPending();
 */
import type { DrizzleSqliteDatabase } from "../../types/database.js";
import { type RecoverySkyResult } from "../../errors/results.js";
/**
 * Sync queue operation type
 */
export type SyncOperation = "create" | "update" | "delete";
/**
 * Sync queue status
 */
export type SyncStatus = "pending" | "syncing" | "synced" | "failed";
/**
 * Sync queue item
 */
export interface SyncQueueItem {
    id: string;
    tableName: string;
    recordId: string;
    operation: SyncOperation;
    payload: string | null;
    createdAt: string;
    syncedAt: string | null;
    status: SyncStatus;
    errorMessage: string | null;
    retryCount: number;
}
/**
 * Input for creating a new sync queue item
 */
export interface SyncQueueInput {
    tableName: string;
    recordId: string;
    operation: SyncOperation;
    payload?: string;
}
export declare class SyncQueueRepository {
    readonly db: DrizzleSqliteDatabase;
    readonly table: import("drizzle-orm/sqlite-core").SQLiteTableWithColumns<{
        name: "sync_queue";
        schema: undefined;
        columns: {
            id: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "id";
                tableName: "sync_queue";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            tableName: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "table_name";
                tableName: "sync_queue";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            recordId: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "record_id";
                tableName: "sync_queue";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            operation: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "operation";
                tableName: "sync_queue";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            payload: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "payload";
                tableName: "sync_queue";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            createdAt: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "created_at";
                tableName: "sync_queue";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            syncedAt: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "synced_at";
                tableName: "sync_queue";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            status: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "status";
                tableName: "sync_queue";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            errorMessage: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "error_message";
                tableName: "sync_queue";
                dataType: "string";
                columnType: "SQLiteText";
                data: string;
                driverParam: string;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: number | undefined;
            }>;
            retryCount: import("drizzle-orm/sqlite-core").SQLiteColumn<{
                name: "retry_count";
                tableName: "sync_queue";
                dataType: "number";
                columnType: "SQLiteInteger";
                data: number;
                driverParam: number;
                notNull: false;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "sqlite";
    }>;
    constructor(db: DrizzleSqliteDatabase);
    /**
     * Execute query with Result<T, E> error handling
     */
    private execute;
    /**
     * Add an item to the sync queue
     */
    enqueue(input: SyncQueueInput): Promise<RecoverySkyResult<string>>;
    /**
     * Get all pending items (status = 'pending' or 'failed' with retries < max)
     * Ordered by creation time (FIFO)
     */
    getPending(maxRetries?: number): Promise<RecoverySkyResult<SyncQueueItem[]>>;
    /**
     * Get items currently syncing
     */
    getSyncing(): Promise<RecoverySkyResult<SyncQueueItem[]>>;
    /**
     * Mark an item as currently syncing
     */
    markSyncing(id: string): Promise<RecoverySkyResult<void>>;
    /**
     * Mark an item as successfully synced
     */
    markSynced(id: string): Promise<RecoverySkyResult<void>>;
    /**
     * Mark an item as failed with error message
     */
    markFailed(id: string, errorMessage: string): Promise<RecoverySkyResult<void>>;
    /**
     * Delete synced items older than specified days
     */
    clearSynced(olderThanDays?: number): Promise<RecoverySkyResult<number>>;
    /**
     * Get queue statistics
     */
    getStats(): Promise<RecoverySkyResult<{
        pending: number;
        syncing: number;
        synced: number;
        failed: number;
        total: number;
    }>>;
    /**
     * Find item by ID
     */
    findById(id: string): Promise<RecoverySkyResult<SyncQueueItem | null>>;
    /**
     * Find items by record ID (all operations for a specific record)
     */
    findByRecordId(tableName: string, recordId: string): Promise<RecoverySkyResult<SyncQueueItem[]>>;
    /**
     * Delete an item by ID
     */
    delete(id: string): Promise<RecoverySkyResult<void>>;
    /**
     * Reset failed items to pending (for retry)
     */
    resetFailed(): Promise<RecoverySkyResult<number>>;
}
