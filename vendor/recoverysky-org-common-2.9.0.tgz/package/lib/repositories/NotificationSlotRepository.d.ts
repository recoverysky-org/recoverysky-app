/**
 * NotificationSlotRepository - Data access layer for notification_slots table (PostgreSQL)
 *
 * Friendly time-of-day slots ("early", "brunch", "midnight") that a user picks
 * from in the notification settings screen. Retunable server-side; changing
 * minutes requires re-minting schedules (admin op).
 *
 * @example
 * import { NotificationSlotRepository } from '@recoverysky-org/common';
 * import { drizzle } from 'drizzle-orm/node-postgres';
 *
 * const db = drizzle(pool);
 * const repo = new NotificationSlotRepository(db);
 *
 * const result = await repo.findEnabled();
 * if (result.ok) {
 *   console.log('Slots:', result.value);
 * }
 */
import type { DrizzleDatabase } from "../types/database.js";
import { notification_slot } from "../models/notification_slot.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class NotificationSlotRepository {
    readonly db: DrizzleDatabase;
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "notification_slots";
        schema: undefined;
        columns: {
            enabled: import("drizzle-orm/pg-core").PgColumn<{
                name: "enabled";
                tableName: "notification_slots";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "notification_slots";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            label: import("drizzle-orm/pg-core").PgColumn<{
                name: "label";
                tableName: "notification_slots";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            minutes: import("drizzle-orm/pg-core").PgColumn<{
                name: "minutes";
                tableName: "notification_slots";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            sort_order: import("drizzle-orm/pg-core").PgColumn<{
                name: "sort_order";
                tableName: "notification_slots";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Find all enabled notification slots, ordered by sort_order
     */
    findEnabled(): Promise<RecoverySkyResult<notification_slot[]>>;
    /**
     * Find multiple notification slots by IDs
     */
    findByIds(ids: string[]): Promise<RecoverySkyResult<notification_slot[]>>;
}
