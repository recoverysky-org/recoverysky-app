/**
 * MeetingRepository - Data access layer for meetings table
 *
 * Provides efficient bulk operations using Drizzle ORM:
 * - Bulk insert (single query for multiple rows)
 * - Bulk update (transaction-based batch updates)
 * - Batch status updates
 * - Upsert operations (insert or update on conflict)
 *
 * Note: Database triggers automatically handle meetings_history audit logging
 *
 * ## Hybrid API Design
 *
 * This repository provides two ways to query data:
 *
 * 1. **Named Methods** (for common operations):
 *    - `bulkInsert()`, `bulkUpsert()`, `findById()`, etc.
 *    - Discoverable via IDE autocomplete
 *    - Well-documented with examples
 *
 * 2. **Generic search()** (for custom queries):
 *    - Pass any Drizzle query function
 *    - Automatic Result<T, E> wrapping
 *    - Maximum flexibility for complex queries
 *
 * @example
 * // Named method (common operation)
 * const meeting = await repo.findById('123');
 *
 * @example
 * // Custom query using repo.table
 * import { and, eq, gt } from 'drizzle-orm';
 *
 * const result = await repo.search(db =>
 *   db.select()
 *     .from(repo.table)
 *     .where(and(
 *       eq(repo.table.fellowship, 'AA'),
 *       gt(repo.table.created, weekAgo)
 *     ))
 * );
 */
import type { DrizzleDatabase } from "../types/database.js";
import { meeting } from "../models/meeting.js";
import { MeetingStatus } from "../enums/MeetingStatus.js";
import { VerifiedStatus } from "../enums/VerifiedStatus.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class MeetingRepository {
    /**
     * Drizzle database instance - exposed for custom queries
     *
     * @example
     * import { and, gt, like } from 'drizzle-orm';
     *
     * const rows = await repo.db.select()
     *   .from(repo.table)
     *   .where(and(
     *     like(repo.table.name, '%Big Book%'),
     *     gt(repo.table.created, Date.now() - 86400000)
     *   ));
     */
    readonly db: DrizzleDatabase;
    /**
     * Drizzle table schema - provides type-safe column access
     *
     * Use this to build custom queries without importing the schema separately.
     * All column names and types are accessible via `repo.table.columnName`.
     *
     * @example
     * import { eq } from 'drizzle-orm';
     *
     * // Type-safe column access
     * const result = await repo.search(db =>
     *   db.select()
     *     .from(repo.table)
     *     .where(eq(repo.table.status, MeetingStatus.ACTIVE))
     * );
     *
     * @example
     * // Direct database queries (bypasses Result wrapping)
     * const rows = await repo.db
     *   .select()
     *   .from(repo.table)
     *   .where(eq(repo.table.fellowship, 'AA'));
     */
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "meetings";
        schema: undefined;
        columns: {
            approximate: import("drizzle-orm/pg-core").PgColumn<{
                name: "approximate";
                tableName: "meetings";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            city: import("drizzle-orm/pg-core").PgColumn<{
                name: "city";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            closed: import("drizzle-orm/pg-core").PgColumn<{
                name: "closed";
                tableName: "meetings";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            conferencePhone: import("drizzle-orm/pg-core").PgColumn<{
                name: "conferencePhone";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            contacts: import("drizzle-orm/pg-core").PgColumn<{
                name: "contacts";
                tableName: "meetings";
                dataType: "json";
                columnType: "PgJsonb";
                data: unknown;
                driverParam: unknown;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            continuous: import("drizzle-orm/pg-core").PgColumn<{
                name: "continuous";
                tableName: "meetings";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            country: import("drizzle-orm/pg-core").PgColumn<{
                name: "country";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            created: import("drizzle-orm/pg-core").PgColumn<{
                name: "created";
                tableName: "meetings";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            description: import("drizzle-orm/pg-core").PgColumn<{
                name: "description";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgVarchar";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {
                length: 5000;
            }>;
            email: import("drizzle-orm/pg-core").PgColumn<{
                name: "email";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            fellowship: import("drizzle-orm/pg-core").PgColumn<{
                name: "fellowship";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            formattedAddress: import("drizzle-orm/pg-core").PgColumn<{
                name: "formattedAddress";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            groupId: import("drizzle-orm/pg-core").PgColumn<{
                name: "groupId";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            hybrid: import("drizzle-orm/pg-core").PgColumn<{
                name: "hybrid";
                tableName: "meetings";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            iid: import("drizzle-orm/pg-core").PgColumn<{
                name: "iid";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            language: import("drizzle-orm/pg-core").PgColumn<{
                name: "language";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            latitude: import("drizzle-orm/pg-core").PgColumn<{
                name: "latitude";
                tableName: "meetings";
                dataType: "number";
                columnType: "PgNumericNumber";
                data: number;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            location: import("drizzle-orm/pg-core").PgColumn<{
                name: "location";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            locationId: import("drizzle-orm/pg-core").PgColumn<{
                name: "locationId";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            locationInfo: import("drizzle-orm/pg-core").PgColumn<{
                name: "locationInfo";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            locked: import("drizzle-orm/pg-core").PgColumn<{
                name: "locked";
                tableName: "meetings";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            longitude: import("drizzle-orm/pg-core").PgColumn<{
                name: "longitude";
                tableName: "meetings";
                dataType: "number";
                columnType: "PgNumericNumber";
                data: number;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            meetingTypes: import("drizzle-orm/pg-core").PgColumn<{
                name: "meetingTypes";
                tableName: "meetings";
                dataType: "json";
                columnType: "PgJsonb";
                data: unknown;
                driverParam: unknown;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            name: import("drizzle-orm/pg-core").PgColumn<{
                name: "name";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            participants: import("drizzle-orm/pg-core").PgColumn<{
                name: "participants";
                tableName: "meetings";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            password: import("drizzle-orm/pg-core").PgColumn<{
                name: "password";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            passwordEnc: import("drizzle-orm/pg-core").PgColumn<{
                name: "passwordEnc";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            phone: import("drizzle-orm/pg-core").PgColumn<{
                name: "phone";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            postalCode: import("drizzle-orm/pg-core").PgColumn<{
                name: "postalCode";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            region: import("drizzle-orm/pg-core").PgColumn<{
                name: "region";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            requiresLogin: import("drizzle-orm/pg-core").PgColumn<{
                name: "requiresLogin";
                tableName: "meetings";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            restricted: import("drizzle-orm/pg-core").PgColumn<{
                name: "restricted";
                tableName: "meetings";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            restrictedDescription: import("drizzle-orm/pg-core").PgColumn<{
                name: "restrictedDescription";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            sha256: import("drizzle-orm/pg-core").PgColumn<{
                name: "sha256";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            sid: import("drizzle-orm/pg-core").PgColumn<{
                name: "sid";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            sourceEntity: import("drizzle-orm/pg-core").PgColumn<{
                name: "sourceEntity";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            sourceEntityId: import("drizzle-orm/pg-core").PgColumn<{
                name: "sourceEntityId";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            sourceFormats: import("drizzle-orm/pg-core").PgColumn<{
                name: "sourceFormats";
                tableName: "meetings";
                dataType: "json";
                columnType: "PgJsonb";
                data: unknown;
                driverParam: unknown;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            sourceHost: import("drizzle-orm/pg-core").PgColumn<{
                name: "sourceHost";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            state: import("drizzle-orm/pg-core").PgColumn<{
                name: "state";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            status: import("drizzle-orm/pg-core").PgColumn<{
                name: "status";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            street: import("drizzle-orm/pg-core").PgColumn<{
                name: "street";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            tags: import("drizzle-orm/pg-core").PgColumn<{
                name: "tags";
                tableName: "meetings";
                dataType: "json";
                columnType: "PgJsonb";
                data: unknown;
                driverParam: unknown;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            uid: import("drizzle-orm/pg-core").PgColumn<{
                name: "uid";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            updated: import("drizzle-orm/pg-core").PgColumn<{
                name: "updated";
                tableName: "meetings";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            url: import("drizzle-orm/pg-core").PgColumn<{
                name: "url";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            venueName: import("drizzle-orm/pg-core").PgColumn<{
                name: "venueName";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            venueType: import("drizzle-orm/pg-core").PgColumn<{
                name: "venueType";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            verified: import("drizzle-orm/pg-core").PgColumn<{
                name: "verified";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            verified_on: import("drizzle-orm/pg-core").PgColumn<{
                name: "verified_on";
                tableName: "meetings";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            verified_retry: import("drizzle-orm/pg-core").PgColumn<{
                name: "verified_retry";
                tableName: "meetings";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            version: import("drizzle-orm/pg-core").PgColumn<{
                name: "version";
                tableName: "meetings";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            website: import("drizzle-orm/pg-core").PgColumn<{
                name: "website";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            zid: import("drizzle-orm/pg-core").PgColumn<{
                name: "zid";
                tableName: "meetings";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            geom: import("drizzle-orm/pg-core").PgColumn<{
                name: "geom";
                tableName: "meetings";
                dataType: "custom";
                columnType: "PgCustomColumn";
                data: string;
                driverParam: unknown;
                notNull: false;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: {
                    type: "always";
                };
            }, {}, {
                pgColumnBuilderBrand: "PgCustomColumnBuilderBrand";
            }>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Strip the generated `geom` column (present on every raw row returned
     * by Drizzle now that it's part of the table schema) before a row is
     * cast to `meeting`. Without this, `geom` (WKB hex) rides along into
     * Meeting instances hydrated via `Object.assign`, leaking into
     * `toJSON()`/serialization and corrupting the deterministic SHA256 hash
     * (which never expected a `geom` key).
     *
     * @see Meeting.JSON_EXCLUDED_KEYS — belt-and-suspenders strip at the
     * Meeting class boundary for callers using repo.db/repo.table directly.
     */
    private static toMeeting;
    private static toMeetings;
    /**
     * Execute custom query with Result<T, E> error handling
     *
     * Use this for complex queries not covered by named methods:
     * - Complex WHERE clauses with AND/OR/NOT
     * - JOINs with other tables
     * - Subqueries and CTEs
     * - Aggregations (COUNT, SUM, etc.)
     * - Custom ORDER BY / LIMIT / OFFSET
     *
     * @param queryFn Function that receives db and returns Promise<T>
     * @returns Result<T> with automatic error wrapping
     *
     * @example
     * // Find AA meetings in NYC created this week
     * import { and, eq, gt, like } from 'drizzle-orm';
     *
     * const result = await repo.search(db =>
     *   db.select()
     *     .from(repo.table)
     *     .where(and(
     *       eq(repo.table.fellowship, 'AA'),
     *       like(repo.table.location, '%New York%'),
     *       gt(repo.table.created, Date.now() - 604800000),
     *       eq(repo.table.status, MeetingStatus.ACTIVE)
     *     ))
     *     .orderBy(repo.table.created)
     *     .limit(100)
     * );
     *
     * @example
     * // Count meetings by status
     * import { sql } from 'drizzle-orm';
     *
     * const result = await repo.search(db =>
     *   db.select({
     *     status: repo.table.status,
     *     count: sql<number>`count(*)`
     *   })
     *   .from(repo.table)
     *   .groupBy(repo.table.status)
     * );
     */
    search<T>(queryFn: (db: DrizzleDatabase) => Promise<T>, operation?: string): Promise<RecoverySkyResult<T>>;
    /**
     * Bulk insert multiple meetings in a single query
     * More efficient than individual inserts - uses single INSERT statement
     *
     * @example
     * const result = await repo.bulkInsert([meeting1, meeting2, meeting3]);
     * if (result.ok) {
     *   console.log(`Inserted ${result.value.length} meetings`);
     * }
     */
    bulkInsert(data: meeting[]): Promise<RecoverySkyResult<meeting[]>>;
    /**
     * Bulk upsert - insert or update on conflict
     * Uses ON CONFLICT DO UPDATE for efficient upserts
     *
     * @example
     * const result = await repo.bulkUpsert(scrapedMeetings);
     * // Inserts new meetings, updates existing by id
     */
    bulkUpsert(data: meeting[]): Promise<RecoverySkyResult<meeting[]>>;
    /**
     * Batch update multiple meetings in a transaction
     * All updates succeed or all fail (atomic)
     *
     * @example
     * const updates = [
     *   { id: 'id1', changes: { status: MeetingStatus.ACTIVE } },
     *   { id: 'id2', changes: { name: 'Updated Name' } }
     * ];
     * const result = await repo.batchUpdate(updates);
     */
    batchUpdate(updates: Array<{
        id: string;
        changes: Partial<meeting>;
    }>): Promise<RecoverySkyResult<number>>;
    /**
     * Batch status update - efficiently update status for multiple meetings
     * Uses single UPDATE with WHERE IN clause
     *
     * @example
     * // Mark all scraped meetings as MISSING
     * const result = await repo.batchStatusUpdate(
     *   ['id1', 'id2', 'id3'],
     *   MeetingStatus.MISSING
     * );
     */
    batchStatusUpdate(ids: string[], status: MeetingStatus): Promise<RecoverySkyResult<number>>;
    /**
     * Find meetings by schedule ID
     *
     * @example
     * const result = await repo.findByScheduleId('schedule-123');
     */
    findByScheduleId(sid: string): Promise<RecoverySkyResult<meeting[]>>;
    /**
     * Find meeting by ID
     *
     * @example
     * const result = await repo.findById('meeting-123');
     * if (result.ok && result.value) {
     *   console.log('Found:', result.value.name);
     * }
     */
    findById(id: string): Promise<RecoverySkyResult<meeting | null>>;
    /**
     * Find meetings by multiple IDs
     *
     * @example
     * const result = await repo.findByIds(['id1', 'id2', 'id3']);
     */
    findByIds(ids: string[]): Promise<RecoverySkyResult<meeting[]>>;
    /**
     * Find meetings within radiusMeters of a point, nearest first.
     * Uses the generated meetings.geom geography column + meetings_geom_gist
     * GiST index (see project/2026-08-02-postgis-geometry-design.md).
     *
     * @example
     * const result = await repo.findNearby(45.5231, -122.6765, 10_000);
     */
    findNearby(latitude: number, longitude: number, radiusMeters: number, limit?: number): Promise<RecoverySkyResult<meeting[]>>;
    /**
     * Find meetings by status
     *
     * @example
     * // Find all MISSING meetings
     * const result = await repo.findByStatus(MeetingStatus.MISSING);
     */
    findByStatus(status: MeetingStatus): Promise<RecoverySkyResult<meeting[]>>;
    /**
     * Find meetings by verified status
     *
     * @example
     * const result = await repo.findByVerified(VerifiedStatus.FAILED);
     */
    findByVerified(verified: VerifiedStatus): Promise<RecoverySkyResult<meeting[]>>;
    /**
     * Update verification fields on a meeting
     *
     * @example
     * const result = await repo.updateVerification('meeting-123', {
     *   verified: VerifiedStatus.SUCCESS,
     *   verified_on: Date.now(),
     * });
     */
    updateVerification(id: string, changes: {
        verified?: VerifiedStatus;
        verified_retry?: number;
        verified_on?: number;
    }): Promise<RecoverySkyResult<meeting | null>>;
    /**
     * Increment verified_retry counter. Returns the updated meeting.
     *
     * @example
     * const result = await repo.incrementVerifiedRetry('meeting-123');
     */
    incrementVerifiedRetry(id: string): Promise<RecoverySkyResult<meeting | null>>;
    /**
     * Batch update verification status for multiple meetings
     *
     * @example
     * const result = await repo.batchVerifiedUpdate(
     *   ['id1', 'id2'],
     *   VerifiedStatus.FAILED,
     * );
     */
    batchVerifiedUpdate(ids: string[], verified: VerifiedStatus): Promise<RecoverySkyResult<number>>;
}
