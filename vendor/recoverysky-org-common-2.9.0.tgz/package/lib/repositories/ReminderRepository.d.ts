/**
 * ReminderRepository - Data access layer for reminders table (PostgreSQL)
 *
 * Stores user reminders for meetings. Each reminder belongs to a user
 * and references a meeting (and optionally a schedule).
 *
 * @example
 * import { ReminderRepository } from '@recoverysky-org/common';
 * import { drizzle } from 'drizzle-orm/node-postgres';
 *
 * const db = drizzle(pool);
 * const repo = new ReminderRepository(db);
 *
 * const result = await repo.findByUserId('user-id');
 * if (result.ok) {
 *   console.log('Reminders:', result.value.length);
 * }
 */
import type { DrizzleDatabase } from "../types/database.js";
import { reminder } from "../models/reminder.js";
import { type RecoverySkyResult } from "../errors/results.js";
export declare class ReminderRepository {
    readonly db: DrizzleDatabase;
    readonly table: import("drizzle-orm/pg-core").PgTableWithColumns<{
        name: "reminders";
        schema: undefined;
        columns: {
            at_start: import("drizzle-orm/pg-core").PgColumn<{
                name: "at_start";
                tableName: "reminders";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            created: import("drizzle-orm/pg-core").PgColumn<{
                name: "created";
                tableName: "reminders";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            did: import("drizzle-orm/pg-core").PgColumn<{
                name: "did";
                tableName: "reminders";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            dow: import("drizzle-orm/pg-core").PgColumn<{
                name: "dow";
                tableName: "reminders";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            enabled: import("drizzle-orm/pg-core").PgColumn<{
                name: "enabled";
                tableName: "reminders";
                dataType: "boolean";
                columnType: "PgBoolean";
                data: boolean;
                driverParam: boolean;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            id: import("drizzle-orm/pg-core").PgColumn<{
                name: "id";
                tableName: "reminders";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: true;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            mid: import("drizzle-orm/pg-core").PgColumn<{
                name: "mid";
                tableName: "reminders";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            minutes_before: import("drizzle-orm/pg-core").PgColumn<{
                name: "minutes_before";
                tableName: "reminders";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            name: import("drizzle-orm/pg-core").PgColumn<{
                name: "name";
                tableName: "reminders";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            scope: import("drizzle-orm/pg-core").PgColumn<{
                name: "scope";
                tableName: "reminders";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            sid: import("drizzle-orm/pg-core").PgColumn<{
                name: "sid";
                tableName: "reminders";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: false;
                hasDefault: false;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            time: import("drizzle-orm/pg-core").PgColumn<{
                name: "time";
                tableName: "reminders";
                dataType: "number";
                columnType: "PgInteger";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            timezone: import("drizzle-orm/pg-core").PgColumn<{
                name: "timezone";
                tableName: "reminders";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            uid: import("drizzle-orm/pg-core").PgColumn<{
                name: "uid";
                tableName: "reminders";
                dataType: "string";
                columnType: "PgText";
                data: string;
                driverParam: string;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: [string, ...string[]];
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
            updated: import("drizzle-orm/pg-core").PgColumn<{
                name: "updated";
                tableName: "reminders";
                dataType: "number";
                columnType: "PgBigInt53";
                data: number;
                driverParam: string | number;
                notNull: true;
                hasDefault: true;
                isPrimaryKey: false;
                isAutoincrement: false;
                hasRuntimeDefault: false;
                enumValues: undefined;
                baseColumn: never;
                identity: undefined;
                generated: undefined;
            }, {}, {}>;
        };
        dialect: "pg";
    }>;
    constructor(db: DrizzleDatabase);
    /**
     * Find reminder by ID
     */
    findById(id: string): Promise<RecoverySkyResult<reminder | null>>;
    /**
     * Find all reminders for a user
     */
    findByUserId(uid: string): Promise<RecoverySkyResult<reminder[]>>;
    /**
     * Find all reminders for a meeting
     */
    findByMeetingId(mid: string): Promise<RecoverySkyResult<reminder[]>>;
    /**
     * Find multiple reminders by IDs
     */
    findByIds(ids: string[]): Promise<RecoverySkyResult<reminder[]>>;
    /**
     * Find all enabled reminders for a set of meeting IDs
     */
    findEnabledByMeetingIds(mids: string[]): Promise<RecoverySkyResult<reminder[]>>;
    /**
     * Find a user's reminder for a specific meeting
     */
    findByUserAndMeeting(uid: string, mid: string): Promise<RecoverySkyResult<reminder | null>>;
    /**
     * Find all enabled reminders for a user
     */
    findEnabledByUserId(uid: string): Promise<RecoverySkyResult<reminder[]>>;
    /**
     * Insert a single reminder
     */
    create(data: reminder): Promise<RecoverySkyResult<reminder>>;
    /**
     * Update a reminder by ID
     */
    update(id: string, data: Partial<reminder>): Promise<RecoverySkyResult<reminder | null>>;
    /**
     * Delete a reminder by ID
     */
    delete(id: string): Promise<RecoverySkyResult<reminder | null>>;
    /**
     * Delete all reminders for a user
     */
    deleteByUserId(uid: string): Promise<RecoverySkyResult<void>>;
    /**
     * Execute custom query with Result wrapper
     */
    search<T>(queryFn: (db: DrizzleDatabase) => Promise<T>, operation?: string): Promise<RecoverySkyResult<T>>;
}
