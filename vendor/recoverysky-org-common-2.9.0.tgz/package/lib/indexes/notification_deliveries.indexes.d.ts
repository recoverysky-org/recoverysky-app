/**
 * Indexes for the notification_deliveries table
 *
 * NOTE: The indexes between the markers below are automatically extracted and
 * injected into the generated notification_deliveries.drizzle.ts file by
 * json-to-drizzle.ts. This file is NOT regenerated — it is the only safe home
 * for a unique index, because @index annotations emit non-unique indexes only.
 */
export declare const notificationDeliveriesSourceOccurrenceUniqIdx: import("drizzle-orm/pg-core").IndexBuilder;
