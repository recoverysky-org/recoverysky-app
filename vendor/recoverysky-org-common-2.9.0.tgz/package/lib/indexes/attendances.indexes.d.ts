/**
 * Indexes for the attendances table
 *
 * NOTE: The indexes between the markers below are automatically extracted and
 * injected into the generated attendances.drizzle.ts file by json-to-drizzle.ts
 */
export declare const attendancesAridIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const attendancesUidIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const attendancesUidUpdatedIdx: import("drizzle-orm/pg-core").IndexBuilder;
