/**
 * Indexes for the notification_schedules table
 *
 * NOTE: Extracted between the markers and injected into the generated
 * notification_schedules.drizzle.ts by json-to-drizzle.ts.
 */
export declare const notificationSchedulesSlotTzPeriodUniqIdx: import("drizzle-orm/pg-core").IndexBuilder;
