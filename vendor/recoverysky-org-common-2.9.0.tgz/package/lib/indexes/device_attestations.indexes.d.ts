/**
 * Indexes for the device_attestations table
 *
 * NOTE: Extracted between the markers and injected into the generated
 * device_attestations.drizzle.ts by json-to-drizzle.ts. This file is NOT
 * regenerated — see project/2026-08-02-notification-claim-step-plan.md for what
 * happens to constraints that live only in migration SQL.
 */
export declare const deviceAttestationsKeyIdIdx: import("drizzle-orm/pg-core").IndexBuilder;
