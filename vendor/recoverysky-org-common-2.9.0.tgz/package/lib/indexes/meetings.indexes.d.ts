/**
 * Indexes for the meetings table
 *
 * Add indexes here to optimize query performance without regenerating the schema.
 * These are manually maintained and won't be overwritten by the schema generator.
 *
 * NOTE: The indexes between the markers below are automatically extracted and
 * injected into the generated meetings.drizzle.ts file by json-to-drizzle.ts
 */
export declare const meetingsNameIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const meetingsStatusIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const meetingsFellowshipIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const meetingsUidIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const meetingsIidIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const meetingsStatusUidIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const meetingsVerifiedIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const meetingsSidIdx: import("drizzle-orm/pg-core").IndexBuilder;
