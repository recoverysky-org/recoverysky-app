/**
 * Indexes for the unsubscribes table
 *
 * NOTE: The indexes between the markers below are automatically extracted and
 * injected into the generated unsubscribes.drizzle.ts file by json-to-drizzle.ts
 */
export declare const unsubscribesEmailUniqIdx: import("drizzle-orm/pg-core").IndexBuilder;
