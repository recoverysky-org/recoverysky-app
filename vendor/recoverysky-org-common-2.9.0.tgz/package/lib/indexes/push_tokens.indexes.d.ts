/**
 * Indexes for the push_tokens table
 *
 * NOTE: The indexes between the markers below are automatically extracted and
 * injected into the generated push_tokens.drizzle.ts file by json-to-drizzle.ts
 */
export declare const pushTokensUserIdDeviceIdUniqIdx: import("drizzle-orm/pg-core").IndexBuilder;
