/**
 * Indexes for the system_prompts table
 *
 * Add indexes here to optimize query performance without regenerating the schema.
 * These are manually maintained and won't be overwritten by the schema generator.
 *
 * NOTE: The indexes between the markers below are automatically extracted and
 * injected into the generated system_prompts.drizzle.ts file by json-to-drizzle.ts
 */
export declare const systemPromptsNameIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const systemPromptsActiveUniqueIdx: import("drizzle-orm/pg-core").IndexBuilder;
