/**
 * Indexes for the reminders table
 *
 * NOTE: The indexes between the markers below are automatically extracted and
 * injected into the generated reminders.drizzle.ts file by json-to-drizzle.ts
 */
export declare const remindersUidIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const remindersSidIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const remindersMidIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const remindersEnabledIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const remindersUidEnabledIdx: import("drizzle-orm/pg-core").IndexBuilder;
