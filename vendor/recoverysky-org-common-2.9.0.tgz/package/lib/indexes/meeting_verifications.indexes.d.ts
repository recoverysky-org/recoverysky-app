/**
 * Indexes for the meeting_verifications table
 *
 * NOTE: The indexes between the markers below are automatically extracted and
 * injected into the generated meeting_verifications.drizzle.ts file by
 * json-to-drizzle.ts
 */
export declare const meetingVerificationsMidObservedIdx: import("drizzle-orm/pg-core").IndexBuilder;
