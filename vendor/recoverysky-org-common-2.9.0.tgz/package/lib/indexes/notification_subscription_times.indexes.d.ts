/**
 * Constraints for the notification_subscription_times join table
 *
 * NOTE: Extracted between the markers and injected into the generated
 * notification_subscription_times.drizzle.ts by json-to-drizzle.ts. This table
 * has no `id` column, so the generator gives it no primary key at all — the
 * composite key has to come from here.
 */
export declare const notificationSubscriptionTimesPk: import("drizzle-orm/pg-core").PrimaryKeyBuilder;
