/**
 * Indexes for the auth_keys table
 *
 * NOTE: The indexes between the markers below are automatically extracted and
 * injected into the generated auth_keys.drizzle.ts file by json-to-drizzle.ts
 */
export declare const authKeysUuidIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const authKeysKeyIdx: import("drizzle-orm/pg-core").IndexBuilder;
