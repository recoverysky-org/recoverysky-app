/**
 * Indexes for the attendance_reports table
 *
 * NOTE: The indexes between the markers below are automatically extracted and
 * injected into the generated attendance_reports.drizzle.ts file by json-to-drizzle.ts
 */
export declare const attendanceReportsConfirmedErrorIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const attendanceReportsUidUpdatedIdx: import("drizzle-orm/pg-core").IndexBuilder;
