/**
 * Indexes for the notification_subscriptions table
 *
 * NOTE: Extracted between the markers and injected into the generated
 * notification_subscriptions.drizzle.ts by json-to-drizzle.ts.
 */
export declare const notificationSubscriptionsUidDidTypeUniqIdx: import("drizzle-orm/pg-core").IndexBuilder;
