/**
 * Indexes for the schedules table
 *
 * Add indexes here to optimize query performance without regenerating the schema.
 * These are manually maintained and won't be overwritten by the schema generator.
 *
 * NOTE: The indexes between the markers below are automatically extracted and
 * injected into the generated schedules.drizzle.ts file by json-to-drizzle.ts
 */
export declare const schedulesNameIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const schedulesStatusIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const schedulesFellowshipIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const schedulesMidsGinIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const schedulesZidsGinIdx: import("drizzle-orm/pg-core").IndexBuilder;
