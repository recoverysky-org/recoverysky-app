/**
 * Indexes for the auth_keys_access table
 *
 * NOTE: The indexes between the markers below are automatically extracted and
 * injected into the generated auth_keys_access.drizzle.ts file by json-to-drizzle.ts
 */
export declare const authKeysAccessIpIdx: import("drizzle-orm/pg-core").IndexBuilder;
