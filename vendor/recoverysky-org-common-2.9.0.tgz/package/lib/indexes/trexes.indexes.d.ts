/**
 * Indexes for the trexes table
 *
 * Add indexes here to optimize query performance without regenerating the schema.
 * These are manually maintained and won't be overwritten by the schema generator.
 *
 * NOTE: The indexes between the markers below are automatically extracted and
 * injected into the generated meetings.drizzle.ts file by json-to-drizzle.ts
 */
export declare const trexDowIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const trexCoordinateIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const trexTimezoneIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const trexPeriodicityIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const trexCoordPeriodicityTzIdx: import("drizzle-orm/pg-core").IndexBuilder;
export declare const trexCoordEndPeriodicityTzIdx: import("drizzle-orm/pg-core").IndexBuilder;
