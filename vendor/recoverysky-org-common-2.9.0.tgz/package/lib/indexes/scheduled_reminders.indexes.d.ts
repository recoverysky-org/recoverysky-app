/**
 * Indexes for the scheduled_reminders table
 *
 * NOTE: The indexes between the markers below are automatically extracted and
 * injected into the generated scheduled_reminders.drizzle.ts file by json-to-drizzle.ts
 */
export declare const scheduledRemindersReminderOccurrenceUniqIdx: import("drizzle-orm/pg-core").IndexBuilder;
