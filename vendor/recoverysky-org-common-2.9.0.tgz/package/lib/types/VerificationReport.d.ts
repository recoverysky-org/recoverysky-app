import type { VerifiedStatus } from "../enums/index.js";
/**
 * Roster-derived counts from a hugo probe that joined the meeting.
 *
 * ALL counts here EXCLUDE hugo itself. (The top-level participantCount
 * INCLUDES hugo — that asymmetry is hugo's contract, preserved verbatim.)
 *
 * Derived aggregates only — hugo ships no attendee names or identities.
 *
 * Every count is individually optional: hugo emits whichever aggregates its
 * SDK build can actually derive, and that set has changed over time (today
 * it is `videoOnCount` alone). An omitted count persists as NULL — "not
 * observed" — never 0. At least one count must be present; an empty `data`
 * block carries no information and is rejected.
 */
export interface VerificationData {
    coHostCount?: number;
    guestCount?: number;
    botCount?: number;
    videoOnCount?: number;
    audioJoinedCount?: number;
    phoneUserCount?: number;
    unmutedCount?: number;
}
/**
 * The POST body hugo sends after probing a meeting. Mirrors hugo's payload
 * verbatim (camelCase) so the camelCase → snake_case column mapping happens
 * in exactly one place: MeetingVerificationRepository.
 */
export interface VerificationReport {
    /** meetings.id — hugo reports our uuid, not the Zoom id */
    id: string;
    status: VerifiedStatus;
    /** Headcount including hugo. EMPTY status means only hugo was present. */
    participantCount: number;
    /** UTC millis when the probe completed */
    validatedAt: number;
    errorCode?: number;
    errorMessage?: string;
    /** Only present on the joined path — absent when hugo never got in */
    data?: VerificationData;
}
