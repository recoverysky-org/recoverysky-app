/**
 * Kind of contact attached to a meeting.
 *
 * - `person`   an individual (NA `contact_name_1/2`, TSML `author`)
 * - `entity`   a service body or intergroup (TSML `entity_*`)
 * - `helpline` a published helpline number
 */
export type ContactKind = "person" | "entity" | "helpline";
/**
 * A published contact for a meeting.
 *
 * This is intentionally-published data. Service bodies publish contacts so
 * that someone seeking help can reach a human being. It is retained, not
 * stripped. Removal propagates through the normal refresh path: when a source
 * drops a contact, the meeting's sha256 changes and merge emits an UPDATE.
 */
export type Contact = {
    kind: ContactKind;
    name: string;
    phone: string;
    email: string;
};
/**
 * Returns a new array of contacts in canonical order.
 *
 * Ordering is `kind`, then `email`, then `name`, then `phone`. Sources do not
 * guarantee contact ordering, and unordered arrays would change the meeting's
 * sha256 between runs and produce spurious UPDATEs.
 *
 * Does not mutate the input.
 */
export declare function sortContacts(contacts: Contact[]): Contact[];
