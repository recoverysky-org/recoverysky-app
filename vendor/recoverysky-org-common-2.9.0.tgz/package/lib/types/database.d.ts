/**
 * Database type definitions for multi-driver support.
 *
 * Supports both postgres-js and node-postgres drivers with Drizzle ORM.
 * The actual query API is identical across both drivers.
 *
 * @example
 * // Using postgres-js
 * import postgres from "postgres";
 * import { drizzle } from "drizzle-orm/postgres-js";
 * const client = postgres(connectionString);
 * const db = drizzle(client);
 * const repo = new MeetingRepository(db);
 *
 * @example
 * // Using node-postgres
 * import { Pool } from "pg";
 * import { drizzle } from "drizzle-orm/node-postgres";
 * const pool = new Pool({ connectionString });
 * const db = drizzle(pool);
 * const repo = new MeetingRepository(db);
 */
import type { PostgresJsDatabase } from "drizzle-orm/postgres-js";
import type { NodePgDatabase } from "drizzle-orm/node-postgres";
import type { BaseSQLiteDatabase } from "drizzle-orm/sqlite-core";
/**
 * Supported Drizzle database types for PostgreSQL.
 *
 * This union type allows repositories to accept either:
 * - `PostgresJsDatabase` from postgres-js driver
 * - `NodePgDatabase` from node-postgres (pg) driver
 */
export type DrizzleDatabase = PostgresJsDatabase | NodePgDatabase;
/**
 * Generic Drizzle SQLite database type.
 *
 * Works with any SQLite driver:
 * - `expo-sqlite` for React Native/Expo
 * - `better-sqlite3` for Node.js
 * - `libsql` for Turso
 *
 * @example
 * // Using expo-sqlite (React Native)
 * import { openDatabaseSync } from 'expo-sqlite';
 * import { drizzle } from 'drizzle-orm/expo-sqlite';
 * const expoDb = openDatabaseSync('app.db');
 * const db = drizzle(expoDb);
 * const repo = new MeetingSqliteRepository(db);
 *
 * @example
 * // Using better-sqlite3 (Node.js)
 * import Database from 'better-sqlite3';
 * import { drizzle } from 'drizzle-orm/better-sqlite3';
 * const sqlite = new Database('app.db');
 * const db = drizzle(sqlite);
 * const repo = new MeetingSqliteRepository(db);
 */
export type DrizzleSqliteDatabase = BaseSQLiteDatabase<"sync" | "async", any, any>;
