export type MeetingNotes = {
    [key: string]: string;
};
