export declare const counties: {
    County: string;
    State: string;
}[];
