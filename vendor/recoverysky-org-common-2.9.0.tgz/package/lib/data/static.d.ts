/**
 * 70sTime Weekday Mapping System
 *
 * This module handles the complex mapping between ISO weekday ordering and the first week of 1970.
 * The first week of 1970 has a unique structure that requires careful mapping to maintain
 * proper day-of-week relationships across different time reference frames.
 */
/**
 * Maps ISO weekday numbers/names to their corresponding day numbers in the first week of 1970.
 *
 * ISO weekday ordering: Monday=1, Tuesday=2, Wednesday=3, Thursday=4, Friday=5, Saturday=6, Sunday=7
 * 1970 first week: Jan 1=Thursday, Jan 2=Friday, Jan 3=Saturday, Jan 4=Sunday, Jan 5=Monday, Jan 6=Tuesday, Jan 7=Wednesday
 *
 * This mapping allows us to convert any ISO weekday into the correct day number within the 1970 reference week.
 *
 * @example
 * // Tuesday (ISO weekday 2) maps to January 6th (day 6) in 1970
 * iso_weekday_2_70s_dow['2'] // returns 6
 * iso_weekday_2_70s_dow['Tuesday'] // returns 6
 *
 * // Thursday (ISO weekday 4) maps to January 1st (day 1) in 1970
 * iso_weekday_2_70s_dow['4'] // returns 1
 * iso_weekday_2_70s_dow['Thursday'] // returns 1
 */
export declare const iso_weekday_2_70s_dow: {
    Monday: number;
    '1': number;
    Tuesday: number;
    '2': number;
    Wednesday: number;
    '3': number;
    Thursday: number;
    '4': number;
    Friday: number;
    '5': number;
    Saturday: number;
    '6': number;
    Sunday: number;
    '7': number;
};
/**
 * Reverse mapping: converts 1970 day numbers back to ISO weekday numbers.
 *
 * This is the inverse of iso_weekday_2_70s_dow and is used when we need to
 * convert from 70sTime back to standard ISO weekday ordering.
 *
 * @example
 * // January 1st (day 1) in 1970 is Thursday (ISO weekday 4)
 * _70s_dow_2_iso_weekday['1'] // returns 4
 * _70s_dow_2_iso_weekday['Thursday'] // returns 4
 *
 * // January 6th (day 6) in 1970 is Tuesday (ISO weekday 2)
 * _70s_dow_2_iso_weekday['6'] // returns 2
 * _70s_dow_2_iso_weekday['Tuesday'] // returns 2
 */
export declare const _70s_dow_2_iso_weekday: {
    Thursday: number;
    '1': number;
    Friday: number;
    '2': number;
    Saturday: number;
    '3': number;
    Sunday: number;
    '4': number;
    Monday: number;
    '5': number;
    Tuesday: number;
    '6': number;
    Wednesday: number;
    '7': number;
};
/**
 * Standard array of weekday names in ISO order.
 * Used for consistent weekday name references throughout the application.
 */
export declare const weekdays: string[];
/**
 * Number of milliseconds in one day.
 * Used for time calculations and duration computations.
 */
export declare const oneDayMillis = 86400000;
/**
 * Number of milliseconds in one week.
 * Used for weekly time calculations and 70sTime projections.
 */
export declare const oneWeekMillis: number;
