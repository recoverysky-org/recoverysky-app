import { schedule } from "../../models/schedule.js";
import { meeting } from "../../models/meeting.js";
import { trex } from "../../models/trex.js";
import { type ScheduleResult } from "../../errors/results.js";
import { Meeting } from "../Meeting/Meeting.js";
/**
 * Business logic class for meeting schedules.
 *
 * **Browser Compatible**: This class works in browsers, React Native, and Node.js.
 * All methods use pure TypeScript implementations with no Python dependencies.
 *
 * **IMPORTANT FOR CONSUMERS**: This is the class you should use for creating instances
 * and working with business logic.
 *
 * ## When to Use This (Uppercase `Schedule`)
 *
 * ✅ **Use for**:
 * - Creating new schedule instances (`Schedule.create()`)
 * - Working with business logic methods
 * - Staleness checking (`isStale()`)
 * - Managing meeting collections
 * - Getting formatted schedule data (`getScheduleData()`)
 * - Any operation requiring methods
 *
 * ❌ **Don't use for**:
 * - Type annotations (use lowercase `schedule` instead)
 * - Direct RxDB/Drizzle query results (they return plain data)
 *
 * ## Relationship to schedule Model
 *
 * This class **extends** the plain `schedule` model, adding business logic methods
 * on top of the data structure.
 *
 * ```typescript
 * // ✅ CORRECT: Using class for instances
 * import { Schedule } from '@recoverysky-org/common';
 *
 * const result = Schedule.create();
 * if (result.ok) {
 *   const schedule = result.value;
 *   schedule.name = 'Weekly Meetings';
 *   await schedule.update();
 * }
 * ```
 *
 * ## Factory Pattern
 *
 * Always use `Schedule.create()` instead of `new Schedule()`:
 *
 * ```typescript
 * // ✅ CORRECT: Factory creates ID and timestamps
 * const result = Schedule.create();
 * const schedule = result.unwrap();
 * console.log(schedule.id); // Has generated UUID
 * console.log(schedule.created); // Has timestamp
 *
 * // ❌ AVOID: Direct instantiation (no ID or timestamps)
 * const schedule = new Schedule();
 * console.log(schedule.id); // Empty string
 * ```
 *
 * ## Converting from Plain Data
 *
 * When querying RxDB or Drizzle, convert plain data to class instances:
 *
 * ```typescript
 * import { Schedule } from '@recoverysky-org/common';
 *
 * // Database query returns plain data
 * const rows = await db.select().from(schedules);
 *
 * // Convert to class for business logic
 * const scheduleInstances = rows.map(row =>
 *   Schedule.create(row, meetingRows, trexRows).unwrap()
 * );
 *
 * // Now can use methods
 * for (const schedule of scheduleInstances) {
 *   const data = schedule.getScheduleData(); // Sync!
 *   if (data.ok) {
 *     console.log(data.value);
 *   }
 * }
 * ```
 *
 * ## Decorators
 *
 * This class uses decorators for integration:
 * - `@RxModel("schedule")` - Links to RxDB schema
 * - `@addFunctions({})` - Function injection pattern
 *
 * @see {@link schedule} - Plain data model that this class extends
 * @see {@link https://github.com/recoverysky-org/recoverysky-common/blob/main/content/consumer-guide.md} - Consumer Guide
 * @see {@link https://github.com/recoverysky-org/recoverysky-common/blob/main/content/architecture.md} - Architecture Guide
 */
export declare class Schedule extends schedule {
    /**
     * Hydrated Meeting instances belonging to this schedule.
     *
     * This property is populated when constructing a Schedule with meetings data.
     * Each Meeting is fully hydrated with its corresponding TREX data.
     *
     * It is NOT included in toJSON() serialization.
     *
     * @see {@link Meeting} - The Meeting class
     */
    meetings: Meeting[];
    /**
     * IANA timezone for displaying schedule times.
     *
     * Used by getScheduleData() to format times in the user's timezone.
     * Set via constructor or setTimezone().
     * Defaults to the system's local timezone.
     *
     * @example "America/New_York", "Europe/London", "Asia/Tokyo"
     */
    private _timezone;
    /**
     * Cached schedule data from getScheduleData().
     * Cleared when the schedule is reloaded or meetings change.
     */
    private _scheduleDataCache;
    /**
     * Creates a new Schedule instance, optionally hydrating from existing data
     * with associated meetings and TREX data.
     *
     * When meetings and trexes are provided, each meeting is hydrated as a Meeting
     * class instance with its corresponding TREX attached. TREX matching is done
     * by meeting.id === trex.id (shared primary key).
     *
     * @param scheduleData - Optional schedule data to hydrate from
     * @param meetingsData - Optional array of meeting data to hydrate
     * @param trexesData - Optional array of TREX data to attach to meetings
     * @param timezone - IANA timezone for displaying times (default: system timezone)
     * @throws Error if a meeting is provided without a corresponding TREX
     *
     * @example
     * // Empty schedule (use Schedule.create() for generated ID/timestamps)
     * const schedule = new Schedule();
     *
     * @example
     * // Hydrate from database row
     * const schedule = new Schedule(dbRow);
     *
     * @example
     * // Fully hydrated schedule with meetings, trexes, and timezone
     * const schedule = new Schedule(scheduleRow, meetingRows, trexRows, 'America/New_York');
     * console.log(schedule.meetings.length); // Hydrated Meeting instances
     * const data = schedule.getScheduleData(); // Sync!
     * // Returns times formatted as "9:00 AM", "2:30 PM", etc.
     */
    constructor(scheduleData?: Partial<schedule>, meetingsData?: Partial<meeting>[], trexesData?: Partial<trex>[], timezone?: string);
    /**
     * Get the current display timezone.
     */
    get timezone(): string;
    /**
     * Set the display timezone and clear the schedule data cache.
     *
     * @param tz - IANA timezone identifier (e.g., "America/New_York")
     */
    setTimezone(tz: string): void;
    toString(): string;
    private static readonly JSON_EXCLUDED_KEYS;
    toJSON(): schedule;
    /**
     * Returns true if the schedule has at least one meeting on every day of the week.
     *
     * Checks the `dow` (day of week) property of each meeting's TREX data.
     * Days are numbered 1-7 (ISO 8601: 1=Monday, 7=Sunday).
     *
     * @returns true if all 7 days are covered, false otherwise
     *
     * @example
     * const schedule = new Schedule(scheduleData, meetings, trexes);
     * if (schedule.daily) {
     *   console.log('This schedule has meetings every day!');
     * }
     */
    get daily(): boolean;
    /**
     * Get schedule data organized by day of week with formatted times.
     *
     * Returns an array of arrays where each inner array represents a meeting.
     * Each inner array has 7 elements (Mon-Sun, indices 0-6).
     * On the day the meeting occurs, the cell contains the formatted time (e.g., "9:00 AM").
     * All other cells are null.
     *
     * Times are formatted in the schedule's timezone (set via constructor or setTimezone()).
     *
     * Results are cached after first calculation. Use `clearScheduleDataCache()`
     * to force recalculation, or `setTimezone()` which automatically clears the cache.
     *
     * This method is synchronous - it uses pure TypeScript TREX calculations.
     *
     * @param fromDt - Reference datetime for calculating next occurrences (default: now)
     * @returns Result containing array of meeting schedule arrays, or error if calculation fails
     *
     * @example
     * const schedule = new Schedule(data, meetings, trexes, 'America/New_York');
     * const result = schedule.getScheduleData();
     * if (result.ok) {
     *   // result.value is Array<Array<string | null>>
     *   // Each inner array: [Mon, Tue, Wed, Thu, Fri, Sat, Sun]
     *   for (const meetingRow of result.value) {
     *     console.log(meetingRow);
     *     // e.g., [null, null, null, "7:00 PM", null, null, null] for a Thursday meeting
     *   }
     * }
     */
    getScheduleData(fromDt?: string | Date): ScheduleResult<Array<Array<string | null>>>;
    /**
     * Clear the cached schedule data.
     *
     * Call this method when the schedule's meetings have changed and you need
     * fresh next occurrence calculations.
     *
     * @example
     * schedule.clearScheduleDataCache();
     * const freshResult = schedule.getScheduleData(); // Sync!
     */
    clearScheduleDataCache(): void;
    /**
     * Factory method to create a new Schedule instance with generated ID and timestamps.
     *
     * @param data - Optional schedule data to hydrate from
     * @param meetingsData - Optional array of meeting data to hydrate (requires trexesData)
     * @param trexesData - Optional array of TREX data to attach to meetings
     * @param timezone - IANA timezone for displaying times (default: system timezone)
     * @returns Result containing new Schedule instance, or error if creation fails
     *
     * @example
     * // Create empty schedule with generated ID
     * const result = Schedule.create();
     * if (result.ok) {
     *   const schedule = result.value;
     *   console.log('Created:', schedule.id);
     * }
     *
     * @example
     * // Hydrate from database with meetings, trexes, and timezone
     * const result = Schedule.create(scheduleRow, meetingRows, trexRows, 'America/New_York');
     * if (result.ok) {
     *   const schedule = result.value;
     *   console.log('Meetings:', schedule.meetings.length);
     * }
     */
    static create(data?: Partial<schedule>, meetingsData?: Partial<meeting>[], trexesData?: Partial<trex>[], timezone?: string): ScheduleResult<Schedule>;
    /**
     * Updates the schedule's timestamp and validates data.
     *
     * Algorithm:
     * - Validates schedule data using Zod schema
     * - Updates timestamp
     *
     * @returns Result containing void on success, or error if validation fails
     *
     * @example
     * const result = await schedule.update();
     * if (result.ok) {
     *   console.log('Schedule updated');
     * } else {
     *   console.error('Update failed:', result.error.message);
     * }
     */
    update(): Promise<ScheduleResult<boolean>>;
}
