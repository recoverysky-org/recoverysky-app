import type { IMeetingMethods } from "./IMeetingMethods.js";
import type { Fellowship, MeetingStatus, VenueType, VerifiedStatus } from "../../../enums/index.js";
import type { Contact } from "../../../types/index.js";
/**
 * Meeting data interface aligned with the meeting model.
 * Combines plain data properties with business logic methods.
 *
 * IMPORTANT: `meeting` (the class at models/meeting.ts) is the single source of
 * truth. This interface mirrors it. Never the reverse. A test at
 * `__tests__/IMeeting.alignment.test.ts` enforces structural equality.
 *
 * @see {@link meeting} - Plain data model (no methods)
 * @see {@link Meeting} - Class that implements this interface with business logic
 */
export interface IMeeting extends IMeetingMethods {
    id: string;
    iid: string;
    uid: string;
    zid: string;
    sid: string;
    status: MeetingStatus;
    verified: VerifiedStatus;
    verified_retry: number;
    verified_on: number;
    participants: number;
    /** @deprecated Never implemented. Retained as a column only. */
    locked: boolean;
    created: number;
    updated: number;
    version: number;
    url: string;
    password: string;
    passwordEnc: string;
    continuous: boolean;
    fellowship: Fellowship;
    meetingTypes: string[];
    language: string;
    closed: boolean;
    requiresLogin: boolean;
    restricted: boolean;
    restrictedDescription: string;
    description: string;
    email: string;
    name: string;
    phone: string;
    website: string;
    conferencePhone: string;
    tags: string[];
    location: string;
    venueType: VenueType;
    hybrid: boolean;
    venueName: string;
    street: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
    formattedAddress: string;
    locationInfo: string;
    region: string;
    latitude: number;
    longitude: number;
    approximate: boolean;
    sourceHost: string;
    sourceEntity: string;
    sourceEntityId: string;
    locationId: string;
    groupId: string;
    sourceFormats: string[];
    contacts: Contact[];
    sha256: string;
}
