import { MeetingResult } from "../../../errors/index";
export interface IMeetingMethods {
    update(): Promise<MeetingResult<boolean>>;
    toString(): string;
    toJSON(): any;
}
