import { meeting } from "../../models/meeting.js";
import { DateTime } from "luxon";
import { type MeetingResult } from "../../errors/results.js";
import { trex } from "../../models/trex.js";
import { Schedule } from "../Schedule/Schedule.js";
/**
 * Business logic class for recovery meetings.
 *
 * **Browser Compatible**: This class works in browsers, React Native, and Node.js.
 * The `getNextOccurrence()` method uses pure TypeScript TREX calculations with no
 * Python dependencies.
 *
 * **IMPORTANT FOR CONSUMERS**: This is the class you should use for creating instances
 * and working with business logic.
 *
 * ## When to Use This (Uppercase `Meeting`)
 *
 * ✅ **Use for**:
 * - Creating new meeting instances (`Meeting.create()`)
 * - Working with business logic methods
 * - Hash generation (`update()`)
 * - Getting next occurrence (`getNextOccurrence()`) - sync!
 * - Any operation requiring methods
 *
 * ❌ **Don't use for**:
 * - Type annotations (use lowercase `meeting` instead)
 * - Direct RxDB/Drizzle query results (they return plain data)
 *
 * ## Relationship to meeting Model
 *
 * This class **extends** the plain `meeting` model, adding business logic methods
 * on top of the data structure.
 *
 * ```typescript
 * // ✅ CORRECT: Using class for instances
 * import { Meeting } from '@recoverysky-org/common';
 *
 * const result = Meeting.create();
 * if (result.ok) {
 *   const meeting = result.value;
 *   meeting.name = 'Monday Night';
 *   meeting.fellowship = 'AA';
 *   await meeting.update(); // Generates SHA256 hash
 *
 *   // Get next occurrence (sync - no Python!)
 *   const nextResult = meeting.getNextOccurrence();
 *   if (nextResult.ok) {
 *     console.log('Next:', new Date(nextResult.value));
 *   }
 * }
 * ```
 *
 * ## Factory Pattern
 *
 * Always use `Meeting.create()` instead of `new Meeting()`:
 *
 * ```typescript
 * // ✅ CORRECT: Factory creates ID and timestamps
 * const result = Meeting.create();
 * const meeting = result.unwrap();
 * console.log(meeting.id); // Has generated ObjectID
 * console.log(meeting.created); // Has timestamp
 *
 * // ❌ AVOID: Direct instantiation (no ID or timestamps)
 * const meeting = new Meeting();
 * console.log(meeting.id); // Empty string
 * ```
 *
 * ## Converting from Plain Data
 *
 * When querying RxDB or Drizzle, convert plain data to class instances:
 *
 * ```typescript
 * import { meetingDocType } from '@recoverysky-org/common/lib/models/rxdb/meeting.rxdb';
 * import { Meeting } from '@recoverysky-org/common';
 *
 * // RxDB query returns plain data
 * const docs: meetingDocType[] = await db.meetings.find().exec();
 *
 * // Convert to class for business logic
 * const meetings = docs.map(doc => Object.assign(new Meeting(), doc));
 *
 * // Now can use methods
 * for (const meeting of meetings) {
 *   if (meeting.isStale()) {
 *     await meeting.update();
 *   }
 * }
 * ```
 *
 * ## Result Pattern
 *
 * This class uses the Result<T, E> pattern for error handling:
 *
 * ```typescript
 * import { Meeting } from '@recoverysky-org/common';
 *
 * // Pattern 1: Check ok property
 * const result = Meeting.create();
 * if (result.ok) {
 *   const meeting = result.value;
 *   // Use meeting
 * } else {
 *   console.error('Error:', result.error.message);
 * }
 *
 * // Pattern 2: Use unwrap (throws on error)
 * const meeting = Meeting.create().unwrap();
 *
 * // Pattern 3: Use unwrapOr (fallback value)
 * const meeting = result.unwrapOr(new Meeting());
 * ```
 *
 * ## Decorators
 *
 * This class uses the `@RxModel("meeting")` decorator for future RxDB integration.
 * The decorator is preserved for dormant RxDB infrastructure but not actively used.
 *
 * @see {@link meeting} - Plain data model that this class extends
 * @see {@link https://github.com/recoverysky-org/recoverysky-common/blob/main/content/consumer-guide.md} - Consumer Guide
 * @see {@link https://github.com/recoverysky-org/recoverysky-common/blob/main/content/architecture.md} - Architecture Guide
 */
export declare class Meeting extends meeting {
    /**
     * Loaded TREX event data (not serialized to JSON).
     *
     * This property is populated by MeetingRepository when loading meetings
     * and hydrated from the id foreign key reference.
     *
     * It is NOT included in toJSON() serialization.
     *
     * @see {@link TrexRepository} - For TREX event management
     */
    trex?: trex;
    /**
     * Loaded Schedule data (not serialized to JSON).
     *
     * This property can be populated by consumers when loading meetings
     * and hydrated from the `sid` foreign key reference.
     * It is NOT included in toJSON() serialization.
     *
     * @see {@link sid} - The foreign key to the schedules table
     * @see {@link ScheduleRepository} - For Schedule management
     */
    schedule?: Schedule;
    /**
     * Creates a new Meeting instance, optionally hydrating from existing data.
     *
     * @param meetingData - Optional meeting data to hydrate from
     * @param trexData - Optional TREX data to attach
     *
     * @example
     * // Empty meeting (use Meeting.create() for generated ID/timestamps)
     * const meeting = new Meeting();
     *
     * @example
     * // Hydrate from database row
     * const meeting = new Meeting(dbRow);
     *
     * @example
     * // Hydrate with TREX data
     * const meeting = new Meeting(meetingRow, trexRow);
     */
    constructor(meetingData?: Partial<meeting>, trexData?: Partial<trex>);
    /**
     * Get the next occurrence of this meeting as milliseconds since epoch.
     *
     * Uses hydrateNext() from @trex-ts/core/browser to calculate the next
     * occurrence with current IANA timezone rules. This is a pure TypeScript
     * implementation that works in browser environments.
     *
     * @param fromDt - Reference datetime to calculate from (default: now)
     * @returns Result containing next occurrence millis, or error if no TREX data or calculation fails
     *
     * @example
     * const result = meeting.getNextOccurrence();
     * if (result.ok) {
     *   console.log('Next occurrence:', new Date(result.value));
     * }
     *
     * @example
     * // Get next occurrence after a specific date
     * const result = meeting.getNextOccurrence(new Date('2025-01-15'));
     */
    getNextOccurrence(fromDt?: DateTime | Date): MeetingResult<number>;
    /**
     * Helper to build TREXJSON from the attached trex data.
     */
    private buildTrexJson;
    /**
     * Get the current period's occurrence as a DateTime.
     *
     * For a WEEKLY meeting at Thursday 6pm, this returns "this Thursday 6pm"
     * even if today is Monday. The occurrence may be in the past or future
     * depending on the current day/time.
     *
     * @returns DateTime of this period's occurrence, or undefined if no TREX data
     *
     * @example
     * const meeting = new Meeting(meetingData, trexData);
     * console.log(meeting.current?.toISO()); // "2025-01-16T18:00:00.000-05:00"
     */
    get current(): DateTime | undefined;
    /**
     * Get the next occurrence of this meeting as a DateTime.
     *
     * Uses hydrateNext() from @trex-ts/core/browser to calculate the next
     * occurrence after now.
     *
     * @returns DateTime of the next occurrence, or undefined if no TREX data
     *
     * @example
     * const meeting = new Meeting(meetingData, trexData);
     * console.log(meeting.next?.toISO()); // "2025-01-23T18:00:00.000-05:00"
     */
    get next(): DateTime | undefined;
    /**
     * Check if this meeting is currently live (in progress).
     *
     * Uses isLiveInterval() from @trex-ts/core/browser to determine if the
     * current time falls within the meeting's duration window.
     *
     * @returns true if the meeting is currently live, false otherwise
     *
     * @example
     * const meeting = new Meeting(meetingData, trexData);
     * if (meeting.isLive) {
     *   console.log("Meeting is in progress!");
     * }
     */
    get isLive(): boolean;
    /**
     * Factory method to create a new Meeting instance.
     *
     * When called without arguments, generates a new meeting with ObjectID, timestamps,
     * and default status (INVALID). When called with partial data, hydrates a Meeting
     * instance from existing data (e.g., from database queries or API responses).
     *
     * @param data - Optional initial meeting data. If omitted, creates new meeting with generated ID and timestamps
     * @param trexData - Optional TREX data to attach to the meeting. Validated with Zod schema.
     * @returns Result containing Meeting instance, or error if creation/validation fails
     *
     * @example
     * // Create new meeting with generated ID and timestamps
     * const result = Meeting.create();
     * if (result.ok) {
     *   const meeting = result.value;
     *   console.log('Created:', meeting.id);
     * }
     *
     * @example
     * // Hydrate from existing data (database query, API response)
     * const result = Meeting.create(dbRow);
     * const meeting = result.unwrap();
     *
     * @example
     * // Create meeting with attached TREX data
     * const result = Meeting.create(meetingData, {
     *   id: 'trex-123',
     *   coordinate: 259200000,
     *   timezone: 'America/New_York',
     *   periodicity: 1, // WEEKLY
     * });
     * if (result.ok) {
     *   const meeting = result.value;
     *   console.log('Meeting with TREX:', meeting.trex?.timezone);
     * }
     */
    static create(data?: Partial<meeting>, trexData?: Partial<trex>): MeetingResult<Meeting>;
    toString(): string;
    /**
     * Properties excluded from JSON serialization.
     * These are typically loaded relations or computed properties.
     */
    private static readonly JSON_EXCLUDED_KEYS;
    toJSON(): meeting;
    /**
     * Updates the meeting's UID and SHA256 hash based on current data.
     *
     * Algorithm:
     * - Validates meeting data using Zod schema
     * - Validates attached trex data using Zod schema (if present)
     * - Generates UID from zid and trex.coordinate
     * - Serializes meeting + trex data (excluding version, updated, sha256)
     * - Computes SHA256 hash of serialized data
     * - Updates timestamp and version if hash changed
     *
     * @returns Result containing true if data changed, false if unchanged, or error
     *
     * @example
     * const result = await meeting.update();
     * if (result.ok) {
     *   if (result.value) {
     *     console.log('Meeting updated, hash:', meeting.sha256);
     *   } else {
     *     console.log('No changes detected');
     *   }
     * } else {
     *   console.error('Update failed:', result.error.message);
     * }
     */
    update(): Promise<MeetingResult<boolean>>;
}
