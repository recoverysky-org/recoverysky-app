import { IMeeting } from "../interfaces/IMeeting.js";
export declare const getNextTime: (meeting?: IMeeting) => number;
