import { IMeeting } from '../interfaces/IMeeting.js';
export declare const isLiveAt: (meeting?: IMeeting, dateTime?: any) => boolean;
