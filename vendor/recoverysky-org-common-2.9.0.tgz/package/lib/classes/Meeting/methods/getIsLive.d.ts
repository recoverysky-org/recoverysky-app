import { IMeeting } from '../interfaces/IMeeting.js';
export declare const getIsLive: (meeting?: IMeeting) => boolean;
