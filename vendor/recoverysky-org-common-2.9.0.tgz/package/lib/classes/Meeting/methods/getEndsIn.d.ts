import { IMeeting } from "../interfaces/IMeeting.js";
export declare const getEndsIn: (meeting?: IMeeting) => number;
