import { IMeeting } from '../interfaces/IMeeting.js';
export declare const getWeekday: (meeting?: IMeeting) => number;
