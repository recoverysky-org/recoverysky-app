import { IMeeting } from '../interfaces/IMeeting.js';
export declare const getNextTimeEnd: (meeting?: IMeeting) => any;
