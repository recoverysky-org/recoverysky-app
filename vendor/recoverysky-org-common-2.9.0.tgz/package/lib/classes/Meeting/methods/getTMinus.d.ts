import { IMeeting } from '../interfaces/IMeeting.js';
export declare const getTMinus: (meeting?: IMeeting) => number | null;
