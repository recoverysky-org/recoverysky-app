/**
 * Browser-compatible exports for @recoverysky-org/common
 *
 * This entry point excludes:
 * - Repositories - require Drizzle ORM / PostgreSQL (server-side)
 * - Node.js TREX class - uses Python bridge (use TREXBrowser instead)
 * - drizzle-orm re-exports - server-side only
 *
 * Includes browser-safe:
 * - Meeting class - getNextOccurrence() uses pure TypeScript implementation
 * - Schedule class - manages collections of meetings with timezone support
 * - Models (pure TypeScript interfaces)
 * - Types
 * - Enums
 * - Decorators
 * - Error handling (Result types, error constructors)
 * - Zod validation schemas
 * - TREX browser utilities (TREXBrowser, hydrateNext, buildSearchRanges)
 * - Browser-safe utilities (validation, audit, createNewJWK, getNextFrequency)
 */
export * from "./models/chat_message.js";
export * from "./models/meeting.js";
export * from "./models/meeting_history.js";
export * from "./models/schedule.js";
export * from "./models/news.js";
export * from "./models/system_prompt.js";
export * from "./models/trex.js";
export * from "./models/unsubscribe.js";
export * from "./types/index.js";
export * from "./enums/index.js";
export * from "./decorators/index.js";
export * from "./errors/index.js";
export * from "./models/zod/meeting.zod.js";
export * from "./models/zod/schedule.zod.js";
export * from "./models/zod/trex.zod.js";
export * from "./models/zod/news.zod.js";
export * from "./models/zod/system_prompt.zod.js";
export * from "./models/zod/timestamp.zod.js";
export * from "./models/zod/unsubscribe.zod.js";
export * from "./utils/audit.js";
export * from "./utils/createNewJWK.js";
export * from "./utils/getNextFrequency.js";
export * from "./utils/validation.js";
export * from "./utils/deterministicStringify.js";
export * from "./utils/normalizeEmail.js";
export * from "./utils/scheduleGrid.js";
export * from "./utils/fellowshipStyles.js";
export { Meeting } from "./classes/Meeting/Meeting.js";
export { Schedule } from "./classes/Schedule/Schedule.js";
export { DateTime, TREXBrowser, hydrate, hydrateNext, hydrateCurrent, isLiveInterval, buildSearchRanges, normalize, BrowserMemoryAdapter, type TREXJSON, Periodicity, DAY_MS, WEEK_MS, MONTH_MS, YEAR_MS, } from "@trex-ts/core/browser";
